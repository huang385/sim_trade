from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
from typing import Literal

from .exceptions import YMMMessageHubConfigurationError


LAN_SERVER_URL = "wss://192.168.11.172:18443/v1/live"
TAILSCALE_SERVER_URL = "wss://100.96.143.111:18443/v1/live"
LOCAL_SERVER_URL = "wss://127.0.0.1:18443/v1/live"
LIVE_TOKEN_PREFIX = "ymmlive_"
LIVE_TOKEN_PAYLOAD_LENGTH = 64
LIVE_TOKEN_LENGTH = len(LIVE_TOKEN_PREFIX) + LIVE_TOKEN_PAYLOAD_LENGTH
ServerMode = Literal["lan", "local", "TS"]

_URLSAFE_TOKEN_CHARS = frozenset(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
)

_SERVER_URLS = {
    "lan": LAN_SERVER_URL,
    "local": LOCAL_SERVER_URL,
    "ts": TAILSCALE_SERVER_URL,
}


@dataclass(frozen=True)
class ClientConfig:
    token: str
    server_url: str
    ca_file: str
    connect_timeout: float = 10.0
    command_timeout: float = 10.0
    feed_queue_size: int = 4096


_DEFAULT_CONFIG: ClientConfig | None = None


def configure(
    token: str | None,
    mode: str | None,
    server_url: str | None,
    ca_file: str | None,
) -> ClientConfig:
    resolved_token = (token or os.environ.get("YMM_LIVE_DATA_TOKEN") or "").strip()
    if not resolved_token:
        raise YMMMessageHubConfigurationError(
            "token is required; pass token=... or set YMM_LIVE_DATA_TOKEN"
        )
    if not _is_live_token(resolved_token):
        raise YMMMessageHubConfigurationError(
            f"invalid live-data token format: expected {LIVE_TOKEN_LENGTH} characters "
            f"starting with {LIVE_TOKEN_PREFIX!r}; database SDK tokens are not accepted"
        )
    normalized_mode = _normalize_mode(mode)
    resolved_url = (
        server_url
        or os.environ.get("YMM_LIVE_DATA_SERVER_URL")
        or (_SERVER_URLS.get(normalized_mode) if normalized_mode else None)
        or LAN_SERVER_URL
    ).rstrip("/")
    if not resolved_url.startswith("wss://"):
        raise YMMMessageHubConfigurationError("server_url must use wss://")
    resolved_ca = ca_file or os.environ.get("YMM_LIVE_DATA_CA_FILE") or _bundled_ca_file()
    if not resolved_ca or not Path(resolved_ca).is_file():
        raise YMMMessageHubConfigurationError(
            "a trusted root CA is required; install a deployment wheel containing "
            "root_ca.pem or pass ca_file=..."
        )
    return ClientConfig(
        token=resolved_token,
        server_url=resolved_url,
        ca_file=str(Path(resolved_ca).resolve()),
    )


def set_default(config: ClientConfig) -> None:
    global _DEFAULT_CONFIG
    _DEFAULT_CONFIG = config


def get_default() -> ClientConfig:
    if _DEFAULT_CONFIG is None:
        raise YMMMessageHubConfigurationError(
            "ymm_live_data_sdk is not initialized; call init(token=..., mode=...) first"
        )
    return _DEFAULT_CONFIG


def clear_default() -> None:
    global _DEFAULT_CONFIG
    _DEFAULT_CONFIG = None


def merged_config(
    *,
    token: str | None,
    mode: str | None,
    server_url: str | None,
    ca_file: str | None,
) -> ClientConfig:
    if all(value is None for value in (token, mode, server_url, ca_file)):
        return get_default()
    default = _DEFAULT_CONFIG
    return configure(
        token=token or (default.token if default else None),
        mode=mode,
        server_url=server_url or (default.server_url if default and mode is None else None),
        ca_file=ca_file or (default.ca_file if default else None),
    )


def _normalize_mode(mode: str | None) -> str | None:
    if mode is None:
        return None
    if not isinstance(mode, str) or mode.strip().lower() not in _SERVER_URLS:
        raise YMMMessageHubConfigurationError("mode must be one of: 'lan', 'local', 'TS'")
    return mode.strip().lower()


def _is_live_token(token: str) -> bool:
    if len(token) != LIVE_TOKEN_LENGTH or not token.startswith(LIVE_TOKEN_PREFIX):
        return False
    payload = token[len(LIVE_TOKEN_PREFIX) :]
    return len(payload) == LIVE_TOKEN_PAYLOAD_LENGTH and all(
        character in _URLSAFE_TOKEN_CHARS for character in payload
    )


def _bundled_ca_file() -> str | None:
    path = Path(__file__).with_name("ca") / "root_ca.pem"
    return str(path) if path.is_file() else None
