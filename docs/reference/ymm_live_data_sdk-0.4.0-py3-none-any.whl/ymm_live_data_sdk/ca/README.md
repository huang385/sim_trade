`root_ca.pem` is deployment-specific and intentionally excluded from source
control. `deployment/build_sdk.py` injects it into a temporary SDK tree and
verifies the resulting wheel. The root certificate is public; the root private
key must never be copied here.
