from __future__ import annotations

from .client import LiveMarketDataClient
from .config import clear_default, configure, set_default
from .exceptions import (
    YMMMessageHubAuthenticationError,
    YMMMessageHubConfigurationError,
    YMMMessageHubConnectionError,
    YMMMessageHubError,
    YMMMessageHubProtocolError,
    YMMMessageHubReplacedError,
)
from .models import CenterStatus, StatusEvent


__version__ = "0.4.0"

__all__ = [
    "CenterStatus",
    "LiveMarketDataClient",
    "StatusEvent",
    "YMMMessageHubAuthenticationError",
    "YMMMessageHubConfigurationError",
    "YMMMessageHubConnectionError",
    "YMMMessageHubError",
    "YMMMessageHubProtocolError",
    "YMMMessageHubReplacedError",
    "close",
    "init",
]


def init(
    token: str | None = None,
    mode: str | None = None,
    server_url: str | None = None,
    ca_file: str | None = None,
) -> None:
    """Configure token and network mode for subsequent clients."""
    set_default(
        configure(
            token=token,
            mode=mode,
            server_url=server_url,
            ca_file=ca_file,
        )
    )


def close() -> None:
    """Clear package-level defaults; existing clients are unaffected."""
    clear_default()
