from __future__ import annotations


class YMMMessageHubError(Exception):
    """Base exception for the live-data SDK."""


class YMMMessageHubConfigurationError(YMMMessageHubError):
    """The SDK wasn't initialized with a usable configuration."""


class YMMMessageHubAuthenticationError(YMMMessageHubError):
    """The hub rejected the token or its bound network identity."""


class YMMMessageHubConnectionError(YMMMessageHubError):
    """The hub connection failed."""


class YMMMessageHubProtocolError(YMMMessageHubError):
    """The peer sent an unsupported or malformed protocol message."""


class YMMMessageHubReplacedError(YMMMessageHubConnectionError):
    """A newer connection using the same token replaced this client."""
