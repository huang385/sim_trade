from __future__ import annotations

import asyncio
from collections import deque
from collections.abc import Generator, Iterable
import itertools
import json
import os
import queue
import socket
import ssl
import threading
import time
from typing import Any, Callable
import uuid
import warnings

from .config import ClientConfig, merged_config
from .exceptions import (
    YMMMessageHubAuthenticationError,
    YMMMessageHubConnectionError,
    YMMMessageHubProtocolError,
    YMMMessageHubReplacedError,
    YMMMessageHubTokenInUseError,
)
from .models import CenterStatus, StatusEvent, TokenSession
from .protocol import (
    FEED_BATCH_CAPABILITY,
    PROTOCOL_VERSION,
    SUBPROTOCOL,
    decode_feed_frame,
)
from .session import _get_token_session
from .version import SDK_VERSION


_STOP = object()


class _YMMMessageHubSessionClosedError(YMMMessageHubConnectionError):
    pass


class _FeedBatchQueue:
    """Bounded message queue with one lock operation per decoded WSS frame."""

    def __init__(self, capacity: int) -> None:
        if capacity < 1:
            raise ValueError("feed queue capacity must be positive")
        self._capacity = capacity
        self._batches: deque[tuple[Any, ...]] = deque()
        self._size = 0
        self._terminal = False
        self._condition = threading.Condition()

    def put_many(self, values: tuple[Any, ...] | list[Any]) -> int:
        incoming = tuple(values)
        if not incoming:
            return 0
        dropped = 0
        with self._condition:
            if self._terminal:
                return len(incoming)
            if len(incoming) >= self._capacity:
                dropped = self._size + len(incoming) - self._capacity
                self._batches.clear()
                self._size = 0
                incoming = incoming[-self._capacity :]
            overflow = max(0, self._size + len(incoming) - self._capacity)
            dropped += overflow
            while overflow:
                oldest = self._batches.popleft()
                if len(oldest) <= overflow:
                    self._size -= len(oldest)
                    overflow -= len(oldest)
                    continue
                self._batches.appendleft(oldest[overflow:])
                self._size -= overflow
                overflow = 0
            self._batches.append(incoming)
            self._size += len(incoming)
            self._condition.notify()
        return dropped

    def get_batch(self) -> tuple[Any, ...]:
        with self._condition:
            while not self._batches and not self._terminal:
                self._condition.wait()
            if self._batches:
                values = self._batches.popleft()
                self._size -= len(values)
                return values
            return (_STOP,)

    def put_terminal(self) -> None:
        with self._condition:
            self._terminal = True
            self._condition.notify_all()

    def qsize(self) -> int:
        with self._condition:
            return self._size

    def empty(self) -> bool:
        return self.qsize() == 0


class LiveMarketDataClient:
    """RQData-like client backed by the internal live-data hub."""

    def __init__(
        self,
        token: str | None = None,
        mode: str | None = None,
        server_url: str | None = None,
        ca_file: str | None = None,
    ) -> None:
        self._config: ClientConfig = merged_config(
            token=token,
            mode=mode,
            server_url=server_url,
            ca_file=ca_file,
        )
        occupied = _get_token_session(self._config)
        if occupied is not None:
            raise YMMMessageHubTokenInUseError(_token_in_use_message(occupied), occupied)
        self._client_instance_id = uuid.uuid4().hex
        self._computer_name = _computer_name()
        self._process_id = os.getpid()
        self._reconnect_lease: str | None = None
        self._desired: set[str] = set()
        self._desired_lock = threading.RLock()
        self._connection_lock = threading.RLock()
        self._pending_lock = threading.Lock()
        self._pending: dict[str, queue.Queue[dict[str, Any]]] = {}
        self._outgoing: queue.Queue[str] = queue.Queue()
        self._request_ids = itertools.count(1)
        self._feed_queue = _FeedBatchQueue(self._config.feed_queue_size)
        self._status_queue: queue.Queue[Any] = queue.Queue()
        self._status = CenterStatus(
            hub="disconnected",
            rqdata="disconnected",
            catalog="loading",
            storage="starting",
        )
        self._info: dict[str, Any] = {}
        self._ws: Any = None
        self._stop = threading.Event()
        self._connected = threading.Event()
        self._initial_ready = threading.Event()
        self._initial_error: BaseException | None = None
        self._last_connect_error: str | None = None
        self._replaced = False
        self._remote_closed = False
        self._closed = False
        self._local_status_sequence = itertools.count(1)
        self._dropped_messages = 0
        self._received_feed_frames = 0
        self._received_feed_messages = 0
        self._largest_feed_frame_messages = 0
        self._last_drop_notice = 0.0
        self._thread = threading.Thread(
            target=self._thread_main,
            name="ymm-live-data-connection",
            daemon=True,
        )
        self._thread.start()
        if not self._initial_ready.wait(self._config.connect_timeout):
            self.close()
            raise YMMMessageHubConnectionError(
                f"timed out connecting to {self._config.server_url}"
                + (f" ({self._last_connect_error})" if self._last_connect_error else "")
            )
        if self._initial_error is not None:
            error = self._initial_error
            self.close()
            raise error

    @property
    def subscriptions(self) -> list[str]:
        with self._desired_lock:
            return sorted(self._desired)

    @property
    def info(self) -> dict[str, Any]:
        return dict(self._info)

    @property
    def status(self) -> CenterStatus:
        return self._status

    def get_status(self) -> CenterStatus:
        response = self._send_command("get_status", {})
        if response is None:
            return self._status
        payload = response.get("result")
        if not isinstance(payload, dict):
            raise YMMMessageHubProtocolError("get_status returned an invalid payload")
        self._status = CenterStatus.from_payload(payload)
        return self._status

    def subscribe(self, channels: str | Iterable[str]) -> None:
        normalized = _normalize_channels(channels)
        valid: list[str] = []
        for channel in normalized:
            if not channel.startswith(("bar_", "tick_")):
                warnings.warn(f"invalid channel: {channel}, ignored", stacklevel=2)
                continue
            valid.append(channel)
        if not valid:
            return
        with self._desired_lock:
            added = [channel for channel in valid if channel not in self._desired]
            self._desired.update(valid)
        if not added:
            return
        response = self._send_command("subscribe", {"channels": added})
        if response is not None:
            _emit_warnings(response.get("warnings"))
            accepted = response.get("result", {}).get("accepted")
            if isinstance(accepted, list):
                rejected = set(added) - {str(value) for value in accepted}
                if rejected:
                    with self._desired_lock:
                        self._desired.difference_update(rejected)

    def unsubscribe(self, channels: str | Iterable[str]) -> None:
        normalized = _normalize_channels(channels)
        with self._desired_lock:
            removed = [channel for channel in normalized if channel in self._desired]
            self._desired.difference_update(normalized)
        if not removed:
            return
        response = self._send_command("unsubscribe", {"channels": removed})
        if response is not None:
            _emit_warnings(response.get("warnings"))

    def listen(
        self,
        handler: Callable[[Any], Any] | None = None,
    ) -> Generator[Any, None, None] | threading.Thread:
        if self._closed:
            raise RuntimeError("this connection is closed.")
        if handler is None:
            return self._iter_feed()

        def consume() -> None:
            for message in self._iter_feed():
                handler(message)

        thread = threading.Thread(
            target=consume,
            name="ymm-live-data-handler",
            daemon=True,
        )
        thread.start()
        return thread

    def listen_status(
        self,
        handler: Callable[[StatusEvent], Any] | None = None,
    ) -> Generator[StatusEvent, None, None] | threading.Thread:
        if self._closed:
            raise RuntimeError("this connection is closed.")
        if handler is None:
            return self._iter_status()

        def consume() -> None:
            for event in self._iter_status():
                handler(event)

        thread = threading.Thread(
            target=consume,
            name="ymm-live-data-status-handler",
            daemon=True,
        )
        thread.start()
        return thread

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._stop.set()
        with self._connection_lock:
            self._ws = None
        self._fail_pending("connection closed")
        _put_terminal(self._feed_queue)
        self._status_queue.put(_STOP)
        if self._thread.is_alive() and threading.current_thread() is not self._thread:
            self._thread.join(timeout=2)

    def _iter_feed(self) -> Generator[Any, None, None]:
        if isinstance(self._feed_queue, _FeedBatchQueue):
            while True:
                for item in self._feed_queue.get_batch():
                    if item is _STOP:
                        return
                    yield item
        while True:
            item = self._feed_queue.get()
            if item is _STOP:
                return
            yield item

    def _iter_status(self) -> Generator[StatusEvent, None, None]:
        while True:
            item = self._status_queue.get()
            if item is _STOP:
                return
            yield item

    def _thread_main(self) -> None:
        asyncio.run(self._connection_loop())

    async def _connection_loop(self) -> None:
        delay = 0.5
        connected_once = False
        while not self._stop.is_set() and not self._replaced and not self._remote_closed:
            websocket = None
            try:
                websocket, hello = await self._connect()
                with self._connection_lock:
                    self._ws = websocket
                self._consume_hello(hello)
                self._connected.set()
                is_recovery = connected_once
                if not connected_once:
                    connected_once = True
                    self._initial_ready.set()
                await self._replay_subscriptions(websocket)
                if is_recovery:
                    self._publish_local_status(
                        "hub", "recovered", "connection and subscriptions recovered"
                    )
                delay = 0.5
                await self._receive_loop(websocket)
            except Exception as exc:  # noqa: BLE001 - network loop translates errors.
                self._last_connect_error = f"{type(exc).__name__}: {exc}"
                if isinstance(exc, YMMMessageHubTokenInUseError):
                    self._remote_closed = True
                    if not connected_once:
                        self._initial_error = exc
                        self._initial_ready.set()
                    else:
                        self._publish_local_status(
                            "session",
                            "in_use",
                            str(exc),
                            {"session_id": exc.session.session_id},
                        )
                        _put_terminal(self._feed_queue)
                        self._status_queue.put(_STOP)
                    return
                if isinstance(exc, _YMMMessageHubSessionClosedError):
                    self._remote_closed = True
                    self._stop.set()
                    if not connected_once and not self._initial_ready.is_set():
                        self._initial_error = YMMMessageHubConnectionError(str(exc))
                        self._initial_ready.set()
                    return
                if not connected_once and _is_authentication_failure(exc):
                    self._initial_error = YMMMessageHubAuthenticationError(str(exc))
                    self._initial_ready.set()
                    return
                if not connected_once and not self._initial_ready.is_set():
                    # Retry transient startup failures until the constructor timeout.
                    pass
                if self._replaced or self._remote_closed or self._stop.is_set():
                    break
                self._publish_local_status("hub", "disconnected", str(exc))
                self._publish_local_status(
                    "hub", "reconnecting", f"retrying in {delay:.1f} seconds"
                )
            finally:
                self._connected.clear()
                with self._connection_lock:
                    self._ws = None
                if websocket is not None:
                    try:
                        await websocket.close()
                    except Exception:
                        pass
                self._fail_pending("connection interrupted")
            if not await _wait_for_stop(self._stop, delay):
                delay = min(delay * 2, 30.0)
        if not connected_once and not self._initial_ready.is_set():
            self._initial_error = YMMMessageHubConnectionError(
                f"unable to connect to {self._config.server_url}"
            )
            self._initial_ready.set()

    async def _connect(self) -> tuple[Any, dict[str, Any]]:
        from websockets.asyncio.client import connect

        context = ssl.create_default_context(cafile=self._config.ca_file)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        headers = {
            "Authorization": f"Bearer {self._config.token}",
            "User-Agent": f"ymm-live-data-sdk/{SDK_VERSION}",
            "X-YMM-Live-Client-ID": self._client_instance_id,
            "X-YMM-Live-Process-ID": str(self._process_id),
            "X-YMM-Live-Capabilities": FEED_BATCH_CAPABILITY,
        }
        if self._computer_name is not None:
            headers["X-YMM-Live-Computer-Name"] = self._computer_name
        if self._reconnect_lease is not None:
            headers["X-YMM-Live-Session-Lease"] = self._reconnect_lease
        websocket = await connect(
            self._config.server_url,
            ssl=context,
            additional_headers=headers,
            subprotocols=[SUBPROTOCOL],
            compression=None,
            proxy=None,
            open_timeout=self._config.connect_timeout,
            close_timeout=2,
            max_size=None,
        )
        first = await asyncio.wait_for(
            websocket.recv(), timeout=self._config.connect_timeout
        )
        if not isinstance(first, str):
            await websocket.close()
            raise YMMMessageHubProtocolError("hub didn't send a JSON hello message")
        payload = _load_json(first)
        if payload.get("type") == "auth_error":
            error = payload.get("error") or {}
            await websocket.close()
            raise YMMMessageHubAuthenticationError(
                str(error.get("message") or "market-data hub authentication failed")
            )
        if payload.get("type") == "session_error":
            error = payload.get("error") or {}
            error_type = str(error.get("type") or "SessionError")
            message = str(error.get("message") or "market-data session was rejected")
            await websocket.close()
            if error_type == "TokenInUseError":
                session_payload = payload.get("session")
                if not isinstance(session_payload, dict):
                    raise YMMMessageHubProtocolError(
                        "token-in-use response is missing session details"
                    )
                try:
                    session = TokenSession.from_payload(session_payload)
                except (TypeError, ValueError) as exc:
                    raise YMMMessageHubProtocolError(str(exc)) from exc
                raise YMMMessageHubTokenInUseError(
                    _token_in_use_message(session), session
                )
            if error_type == "SessionClosedError":
                raise _YMMMessageHubSessionClosedError(message)
            raise YMMMessageHubConnectionError(f"{error_type}: {message}")
        if payload.get("type") != "hello" or payload.get("version") != PROTOCOL_VERSION:
            await websocket.close()
            raise YMMMessageHubProtocolError("hub sent an unsupported hello message")
        return websocket, payload

    def _consume_hello(self, payload: dict[str, Any]) -> None:
        info = payload.get("info")
        status = payload.get("status")
        reconnect_lease = payload.get("reconnect_lease")
        if (
            not isinstance(info, dict)
            or not isinstance(status, dict)
            or not _is_hex_identifier(reconnect_lease)
        ):
            raise YMMMessageHubProtocolError(
                "hello message is missing info, status, or reconnect lease"
            )
        self._reconnect_lease = reconnect_lease
        self._info = dict(info)
        self._status = CenterStatus.from_payload(status)

    async def _replay_subscriptions(self, websocket: Any) -> None:
        with self._desired_lock:
            channels = sorted(self._desired)
        if not channels:
            return
        request_id = self._next_request_id()
        await websocket.send(
            json.dumps(
                {
                    "version": PROTOCOL_VERSION,
                    "type": "subscribe",
                    "request_id": request_id,
                    "channels": channels,
                    "replay": True,
                },
                separators=(",", ":"),
            )
        )

    async def _receive_loop(self, websocket: Any) -> None:
        while not self._stop.is_set() and not self._replaced and not self._remote_closed:
            while True:
                try:
                    outgoing = self._outgoing.get_nowait()
                except queue.Empty:
                    break
                await websocket.send(outgoing)
            try:
                frame = await asyncio.wait_for(websocket.recv(), timeout=0.02)
            except TimeoutError:
                continue
            if isinstance(frame, bytes):
                feeds = decode_feed_frame(frame)
                self._received_feed_frames += 1
                self._received_feed_messages += len(feeds)
                self._largest_feed_frame_messages = max(
                    self._largest_feed_frame_messages,
                    len(feeds),
                )
                self._enqueue_feed_batch(feeds)
                continue
            if not isinstance(frame, str):
                raise YMMMessageHubProtocolError("unsupported WebSocket frame")
            payload = _load_json(frame)
            message_type = payload.get("type")
            if message_type == "response":
                request_id = str(payload.get("request_id") or "")
                with self._pending_lock:
                    waiter = self._pending.pop(request_id, None)
                if waiter is not None:
                    waiter.put(payload)
            elif message_type == "status":
                event_payload = payload.get("event")
                if not isinstance(event_payload, dict):
                    raise YMMMessageHubProtocolError("invalid status event")
                event = StatusEvent.from_payload(event_payload)
                self._status_queue.put(event)
                snapshot = payload.get("snapshot")
                if isinstance(snapshot, dict):
                    self._status = CenterStatus.from_payload(snapshot)
                if event.details.get("reason") == "token_revoked":
                    self._stop.set()
                    self._fail_pending("token revoked")
                    _put_terminal(self._feed_queue)
                    self._status_queue.put(_STOP)
                    raise YMMMessageHubAuthenticationError(
                        event.message or "token was revoked"
                    )
                if event.state == "replaced":
                    self._replaced = True
                    self._fail_pending("connection replaced")
                    _put_terminal(self._feed_queue)
                    self._status_queue.put(_STOP)
                    raise YMMMessageHubReplacedError(event.message or "connection replaced")
                if event.state == "closed" and event.details.get("reason") == "manual_close":
                    self._remote_closed = True
                    self._stop.set()
                    self._fail_pending("session manually closed")
                    _put_terminal(self._feed_queue)
                    self._status_queue.put(_STOP)
                    raise _YMMMessageHubSessionClosedError(
                        event.message or "session manually closed"
                    )
            elif message_type == "hello":
                self._consume_hello(payload)
            else:
                raise YMMMessageHubProtocolError(
                    f"unsupported hub message type: {message_type!r}"
                )

    def _send_command(
        self,
        command: str,
        fields: dict[str, Any],
    ) -> dict[str, Any] | None:
        if self._closed:
            raise RuntimeError("this connection is closed.")
        if self._replaced:
            raise YMMMessageHubReplacedError("connection was replaced by a newer client")
        if self._remote_closed:
            raise YMMMessageHubConnectionError("this session was closed manually")
        if not self._connected.is_set():
            return None
        request_id = self._next_request_id()
        waiter: queue.Queue[dict[str, Any]] = queue.Queue(maxsize=1)
        with self._pending_lock:
            self._pending[request_id] = waiter
        payload = {
            "version": PROTOCOL_VERSION,
            "type": command,
            "request_id": request_id,
            **fields,
        }
        try:
            self._outgoing.put(json.dumps(payload, separators=(",", ":")))
            response = waiter.get(timeout=self._config.command_timeout)
        except queue.Empty as exc:
            with self._pending_lock:
                self._pending.pop(request_id, None)
            raise YMMMessageHubConnectionError(
                f"hub didn't acknowledge {command} within {self._config.command_timeout:g}s"
            ) from exc
        except Exception:
            with self._pending_lock:
                self._pending.pop(request_id, None)
            raise
        if not response.get("ok"):
            error = response.get("error") or {}
            error_type = str(error.get("type") or "RemoteError")
            message = str(error.get("message") or f"{command} failed")
            if error_type in {"AuthenticationError", "SourceAuthorizationError"}:
                raise YMMMessageHubAuthenticationError(message)
            raise YMMMessageHubConnectionError(f"{error_type}: {message}")
        return response

    def _next_request_id(self) -> str:
        return f"c{next(self._request_ids)}"

    def _fail_pending(self, message: str) -> None:
        with self._pending_lock:
            waiters = list(self._pending.values())
            self._pending.clear()
        response = {
            "type": "response",
            "ok": False,
            "error": {"type": "ConnectionError", "message": message},
        }
        for waiter in waiters:
            try:
                waiter.put_nowait(response)
            except queue.Full:
                pass

    def _enqueue_feed(self, message: Any) -> None:
        self._enqueue_feed_batch((message,))

    def _enqueue_feed_batch(self, messages: tuple[Any, ...]) -> None:
        if isinstance(self._feed_queue, _FeedBatchQueue):
            dropped = self._feed_queue.put_many(messages)
            self._record_local_feed_drops(dropped)
            return
        dropped = 0
        for message in messages:
            try:
                self._feed_queue.put_nowait(message)
            except queue.Full:
                try:
                    self._feed_queue.get_nowait()
                except queue.Empty:
                    pass
                self._feed_queue.put_nowait(message)
                dropped += 1
        self._record_local_feed_drops(dropped)

    def _record_local_feed_drops(self, dropped: int) -> None:
        if not dropped:
            return
        self._dropped_messages += dropped
        now = time.monotonic()
        if now - self._last_drop_notice >= 5:
            self._last_drop_notice = now
            self._publish_local_status(
                "session",
                "slow_consumer",
                "local SDK feed queue overflowed; oldest messages were dropped",
                {"dropped_messages": self._dropped_messages},
            )

    def _publish_local_status(
        self,
        component: str,
        state: str,
        message: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        from datetime import datetime, timezone

        event = StatusEvent(
            component=component,
            state=state,
            timestamp=datetime.now(timezone.utc).isoformat(),
            message=message,
            details=dict(details or {}),
            sequence=next(self._local_status_sequence),
        )
        self._status_queue.put(event)
        if component == "hub":
            self._status = CenterStatus(
                **{
                    **self._status.__dict__,
                    "hub": "connected" if state == "recovered" else state,
                    "dropped_messages": self._dropped_messages,
                }
            )


def _normalize_channels(channels: str | Iterable[str]) -> list[str]:
    if isinstance(channels, str):
        return [channels]
    try:
        values = list(channels)
    except TypeError as exc:
        raise TypeError("channels must be a string or an iterable of strings") from exc
    if any(not isinstance(value, str) for value in values):
        raise TypeError("channels must contain only strings")
    return values


def _emit_warnings(records: Any) -> None:
    if not isinstance(records, list):
        return
    for record in records:
        if isinstance(record, dict):
            message = str(record.get("message") or "")
        else:
            message = str(record)
        if message:
            warnings.warn(message, UserWarning, stacklevel=3)


def _load_json(value: str) -> dict[str, Any]:
    try:
        payload = json.loads(value)
    except json.JSONDecodeError as exc:
        raise YMMMessageHubProtocolError("hub sent invalid JSON") from exc
    if not isinstance(payload, dict):
        raise YMMMessageHubProtocolError("hub JSON message must be an object")
    return payload


def _token_in_use_message(session: TokenSession) -> str:
    owner = f"strategy {session.strategy!r}"
    if session.computer_name:
        owner += f" on computer {session.computer_name!r}"
    if session.process_id is not None:
        owner += f" (process {session.process_id})"
    return (
        f"this token is already in use by {owner}; "
        "the existing connection was not interrupted; call get_token_session() and "
        "close_token_session(session_id) if you intend to close it"
    )


def _computer_name() -> str | None:
    try:
        value = socket.gethostname().strip()
    except OSError:
        return None
    value = "".join(character for character in value if 32 <= ord(character) < 127)[:128]
    return value or None


def _is_hex_identifier(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 32
        and all(character in "0123456789abcdef" for character in value.lower())
    )


def _put_terminal(target: Any) -> None:
    put_terminal = getattr(target, "put_terminal", None)
    if callable(put_terminal):
        put_terminal()
        return
    try:
        target.put_nowait(_STOP)
    except queue.Full:
        try:
            target.get_nowait()
        except queue.Empty:
            pass
        target.put_nowait(_STOP)


def _is_authentication_failure(exc: BaseException) -> bool:
    name = type(exc).__name__
    if name in {"InvalidStatus", "InvalidStatusCode"}:
        response = getattr(exc, "response", None)
        status_code = getattr(response, "status_code", None) or getattr(exc, "status_code", None)
        return status_code in {401, 403}
    return isinstance(exc, YMMMessageHubAuthenticationError)


async def _wait_for_stop(stop: threading.Event, seconds: float) -> bool:
    deadline = time.monotonic() + seconds
    while not stop.is_set() and time.monotonic() < deadline:
        await asyncio.sleep(min(0.05, max(0.0, deadline - time.monotonic())))
    return stop.is_set()
