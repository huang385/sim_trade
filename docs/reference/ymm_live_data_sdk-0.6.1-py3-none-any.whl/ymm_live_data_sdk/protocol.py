from __future__ import annotations

import pickle
import struct
from typing import Any

from .exceptions import YMMMessageHubProtocolError


PROTOCOL_VERSION = 1
SUBPROTOCOL = "ymm-live-data.v1"
FEED_MAGIC = b"YMLD"
BATCH_FEED_MAGIC = b"YMLB"
FEED_BATCH_CAPABILITY = "feed-batch-v1"
FLAG_ZSTD = 0x01
HEADER = struct.Struct("!4sBBI")
COMPRESS_THRESHOLD = 1024
MAX_FEED_BYTES = 64 * 1024 * 1024
MAX_BATCH_MESSAGES = 512


def encode_feed(value: Any) -> bytes:
    raw = pickle.dumps(value, protocol=5)
    if len(raw) > MAX_FEED_BYTES:
        raise ValueError("feed message exceeds 64 MiB")
    flags = 0
    body = raw
    if len(raw) >= COMPRESS_THRESHOLD:
        import zstandard

        compressed = zstandard.ZstdCompressor(level=1).compress(raw)
        if len(compressed) < len(raw):
            body = compressed
            flags |= FLAG_ZSTD
    return HEADER.pack(FEED_MAGIC, PROTOCOL_VERSION, flags, len(raw)) + body


def decode_feed(frame: bytes) -> Any:
    values = decode_feed_frame(frame)
    if len(values) != 1:
        raise YMMMessageHubProtocolError(
            "batch feed frame cannot be decoded as a single feed"
        )
    return values[0]


def decode_feed_frame(frame: bytes) -> tuple[Any, ...]:
    if len(frame) < HEADER.size:
        raise YMMMessageHubProtocolError("truncated feed frame")
    magic, version, flags, raw_length = HEADER.unpack_from(frame)
    if magic not in {FEED_MAGIC, BATCH_FEED_MAGIC} or version != PROTOCOL_VERSION:
        raise YMMMessageHubProtocolError("unsupported feed protocol")
    if flags & ~FLAG_ZSTD:
        raise YMMMessageHubProtocolError("unsupported feed flags")
    if raw_length > MAX_FEED_BYTES:
        raise YMMMessageHubProtocolError("feed message exceeds 64 MiB")
    body = frame[HEADER.size :]
    if flags & FLAG_ZSTD:
        import zstandard

        try:
            raw = zstandard.ZstdDecompressor().decompress(body, max_output_size=raw_length)
        except zstandard.ZstdError as exc:
            raise YMMMessageHubProtocolError("invalid compressed feed frame") from exc
    else:
        raw = body
    if len(raw) != raw_length:
        raise YMMMessageHubProtocolError("feed length mismatch")
    try:
        value = pickle.loads(raw)
    except Exception as exc:
        raise YMMMessageHubProtocolError("invalid feed payload") from exc
    if magic == FEED_MAGIC:
        return (value,)
    if (
        not isinstance(value, tuple)
        or not value
        or len(value) > MAX_BATCH_MESSAGES
    ):
        raise YMMMessageHubProtocolError("invalid batch feed payload")
    return value
