from __future__ import annotations

from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from .models import TokenSession


class YMMMessageHubError(Exception):
    """Base exception for the live-data SDK."""


class YMMMessageHubConfigurationError(YMMMessageHubError):
    """The SDK wasn't initialized with a usable configuration."""


class YMMMessageHubAuthenticationError(YMMMessageHubError):
    """The hub rejected the token or its bound network identity."""


class YMMMessageHubConnectionError(YMMMessageHubError):
    """The hub connection failed."""


class YMMMessageHubProtocolError(YMMMessageHubError):
    """The peer sent an unsupported or malformed protocol message."""


class YMMMessageHubReplacedError(YMMMessageHubConnectionError):
    """A newer connection using the same token replaced this client."""


class YMMMessageHubTokenInUseError(YMMMessageHubConnectionError):
    """The token already has an active connection that was left untouched."""

    def __init__(self, message: str, session: "TokenSession") -> None:
        super().__init__(message)
        self.session = session
