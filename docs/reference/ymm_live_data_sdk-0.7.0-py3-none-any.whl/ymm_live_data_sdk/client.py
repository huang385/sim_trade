from __future__ import annotations

import asyncio
from collections import deque
from collections.abc import Generator, Iterable
from dataclasses import dataclass
import itertools
import json
import os
import queue
import socket
import ssl
import threading
import time
from typing import Any, Callable
import uuid
import warnings

from .config import ClientConfig, merged_config
from .exceptions import (
    YMMMessageHubAuthenticationError,
    YMMMessageHubConnectionError,
    YMMMessageHubProtocolError,
    YMMMessageHubReplacedError,
    YMMMessageHubTokenInUseError,
)
from .models import CenterStatus, StatusEvent, TokenSession
from .protocol import (
    FeedFrameMetadata,
    PROTOCOL_VERSION,
    SUBPROTOCOL,
    decode_feed_frame_with_metadata,
)
from .session import _get_token_session
from .version import SDK_VERSION


_STOP = object()
_FEED_KINDS = ("tick", "1m", "higher")


class _YMMMessageHubSessionClosedError(YMMMessageHubConnectionError):
    pass


@dataclass(frozen=True, slots=True)
class _QueuedFeedBatch:
    messages: tuple[Any, ...]
    frame_received_at: float
    decode_started_at: float
    decoded_at: float
    enqueued_at: float
    metadata: FeedFrameMetadata | None = None


class _FeedBatchQueue:
    """Bounded frame-order FIFO whose capacity is measured in feed rows."""

    def __init__(self, capacity: int) -> None:
        if capacity < 1:
            raise ValueError("feed queue capacity must be positive")
        self._capacity = capacity
        self._batches: deque[_QueuedFeedBatch] = deque()
        self._sizes = {kind: 0 for kind in _FEED_KINDS}
        self._size = 0
        self._terminal = False
        self._condition = threading.Condition()

    def put_many(
        self,
        values: tuple[Any, ...] | list[Any],
        *,
        frame_received_at: float | None = None,
        decode_started_at: float | None = None,
        decoded_at: float | None = None,
        metadata: FeedFrameMetadata | None = None,
    ) -> dict[str, int]:
        incoming = tuple(values)
        if not incoming:
            return {kind: 0 for kind in _FEED_KINDS}
        now = time.monotonic()
        frame_received = now if frame_received_at is None else float(frame_received_at)
        decode_started = (
            frame_received
            if decode_started_at is None
            else float(decode_started_at)
        )
        decoded = now if decoded_at is None else float(decoded_at)
        dropped = {kind: 0 for kind in _FEED_KINDS}
        with self._condition:
            if self._terminal:
                self._add_kind_counts(dropped, incoming)
                return dropped
            if len(incoming) > self._capacity:
                while self._batches:
                    removed = self._batches.popleft()
                    self._add_kind_counts(dropped, removed.messages)
                self._size = 0
                self._sizes = {kind: 0 for kind in _FEED_KINDS}
                self._add_kind_counts(dropped, incoming)
                return dropped
            while self._batches and self._size + len(incoming) > self._capacity:
                oldest = self._batches.popleft()
                self._remove_kind_counts(oldest.messages)
                self._add_kind_counts(dropped, oldest.messages)
                self._size -= len(oldest.messages)
            queued = _QueuedFeedBatch(
                messages=incoming,
                frame_received_at=frame_received,
                decode_started_at=decode_started,
                decoded_at=decoded,
                enqueued_at=time.monotonic(),
                metadata=metadata,
            )
            self._batches.append(queued)
            self._size += len(incoming)
            for message in incoming:
                self._sizes[_feed_kind(message)] += 1
            if self._size:
                self._condition.notify()
        return dropped

    def get_batch(self) -> tuple[Any, ...]:
        batch = self.get_batch_with_metadata()
        if batch is None:
            return (_STOP,)
        return batch.messages

    def get_batch_with_metadata(self) -> _QueuedFeedBatch | None:
        with self._condition:
            while self._size == 0 and not self._terminal:
                self._condition.wait()
            if not self._batches:
                return None
            batch = self._batches.popleft()
            self._remove_kind_counts(batch.messages)
            self._size -= len(batch.messages)
            return batch

    def put_terminal(self) -> None:
        with self._condition:
            self._terminal = True
            self._condition.notify_all()

    def qsize(self) -> int:
        with self._condition:
            return self._size

    def empty(self) -> bool:
        return self.qsize() == 0

    def qsize_by_kind(self) -> dict[str, int]:
        with self._condition:
            return dict(self._sizes)

    @staticmethod
    def _add_kind_counts(target: dict[str, int], messages: Iterable[Any]) -> None:
        for message in messages:
            target[_feed_kind(message)] += 1

    def _remove_kind_counts(self, messages: Iterable[Any]) -> None:
        for message in messages:
            self._sizes[_feed_kind(message)] -= 1


class _FeedDeliveryMetrics:
    """Bounded local timing diagnostics; never participates in delivery."""

    SAMPLE_LIMIT = 16_384

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._frame_decode_ms: deque[float] = deque(maxlen=self.SAMPLE_LIMIT)
        self._queue_wait_ms: dict[str, deque[float]] = {
            kind: deque(maxlen=self.SAMPLE_LIMIT) for kind in _FEED_KINDS
        }
        self._handler_ms: dict[str, deque[float]] = {
            kind: deque(maxlen=self.SAMPLE_LIMIT) for kind in _FEED_KINDS
        }
        self._parent_to_handler_ms: dict[str, deque[float]] = {
            kind: deque(maxlen=self.SAMPLE_LIMIT) for kind in _FEED_KINDS
        }
        self._batch_sizes: dict[str, deque[float]] = {
            kind: deque(maxlen=self.SAMPLE_LIMIT) for kind in _FEED_KINDS
        }
        self._delivered_batches = {kind: 0 for kind in _FEED_KINDS}
        self._delivered_messages = {kind: 0 for kind in _FEED_KINDS}
        self._dropped_messages = {kind: 0 for kind in _FEED_KINDS}
        self._delivery_epoch: int | None = None
        self._last_delivery_sequence = 0
        self._sequence_gap_frames = 0
        self._sequence_gap_messages = 0
        self._sequence_reorders_or_duplicates = 0
        self._frame_trace: deque[dict[str, Any]] = deque(maxlen=self.SAMPLE_LIMIT)
        # The global trace is a recent tail. A minute-boundary higher burst can
        # otherwise fall out of that tail during the following tick flood, so
        # retain a smaller independent tail for every feed kind as well.
        self._frame_trace_by_kind: dict[str, deque[dict[str, Any]]] = {
            kind: deque(maxlen=4_096) for kind in _FEED_KINDS
        }

    def observe_frame(self, metadata: FeedFrameMetadata, message_count: int) -> None:
        if metadata.delivery_sequence <= 0:
            return
        with self._lock:
            if self._delivery_epoch is None or metadata.delivery_epoch > self._delivery_epoch:
                self._delivery_epoch = metadata.delivery_epoch
                self._last_delivery_sequence = 0
            elif metadata.delivery_epoch < self._delivery_epoch:
                self._sequence_reorders_or_duplicates += 1
                return
            expected = self._last_delivery_sequence + 1
            if metadata.delivery_sequence > expected:
                self._sequence_gap_frames += metadata.delivery_sequence - expected
                # A missing frame's row count is unknowable from the receiver;
                # retain a conservative lower bound for diagnostics.
                self._sequence_gap_messages += 1
            elif metadata.delivery_sequence < expected:
                self._sequence_reorders_or_duplicates += 1
            self._last_delivery_sequence = max(
                metadata.delivery_sequence,
                self._last_delivery_sequence,
            )

    def observe_decode(self, decode_started_at: float, decoded_at: float) -> None:
        with self._lock:
            self._frame_decode_ms.append(
                max(0.0, (decoded_at - decode_started_at) * 1000.0)
            )

    def observe_delivery(self, batch: _QueuedFeedBatch, started_at: float) -> None:
        counts = _feed_kind_counts(batch.messages)
        with self._lock:
            metadata = batch.metadata
            trace = {
                "delivery_epoch": (
                    None if metadata is None else metadata.delivery_epoch
                ),
                "delivery_sequence": (
                    None if metadata is None else metadata.delivery_sequence
                ),
                "message_count": len(batch.messages),
                "socket_received_monotonic": batch.frame_received_at,
                "decode_started_monotonic": batch.decode_started_at,
                "decode_ended_monotonic": batch.decoded_at,
                "handler_started_monotonic": started_at,
                "handler_ended_monotonic": None,
                "hub_parent_received_monotonic_ns": (
                    None
                    if metadata is None
                    else metadata.parent_received_monotonic_ns
                ),
                "hub_routed_monotonic_ns": (
                    None if metadata is None else metadata.routed_monotonic_ns
                ),
            }
            self._frame_trace.append(trace)
            for kind, count in counts.items():
                if count == 0:
                    continue
                self._frame_trace_by_kind[kind].append(trace)
                self._queue_wait_ms[kind].append(
                    max(0.0, (started_at - batch.enqueued_at) * 1000.0)
                )
                self._batch_sizes[kind].append(float(count))
                self._delivered_batches[kind] += 1
                self._delivered_messages[kind] += count
                if (
                    batch.metadata is not None
                    and batch.metadata.parent_received_monotonic_ns > 0
                ):
                    self._parent_to_handler_ms[kind].append(
                        max(
                            0.0,
                            (
                                started_at
                                - batch.metadata.parent_received_monotonic_ns
                                / 1_000_000_000.0
                            )
                            * 1000.0,
                        )
                    )

    def observe_handler(self, batch: _QueuedFeedBatch, elapsed_ms: float) -> None:
        counts = _feed_kind_counts(batch.messages)
        with self._lock:
            if self._frame_trace:
                self._frame_trace[-1]["handler_ended_monotonic"] = (
                    self._frame_trace[-1]["handler_started_monotonic"]
                    + max(0.0, elapsed_ms) / 1000.0
                )
            for kind, count in counts.items():
                if count:
                    self._handler_ms[kind].append(max(0.0, elapsed_ms))

    def observe_drops(self, dropped: dict[str, int]) -> None:
        with self._lock:
            for kind in _FEED_KINDS:
                self._dropped_messages[kind] += int(dropped.get(kind) or 0)

    def snapshot(self, *, queue_rows: dict[str, int]) -> dict[str, Any]:
        with self._lock:
            return {
                "frame_receive_to_decode": _local_latency_summary(
                    list(self._frame_decode_ms), suffix="ms"
                ),
                "sequence_gap_frames": self._sequence_gap_frames,
                "sequence_gap_messages_lower_bound": self._sequence_gap_messages,
                "sequence_reorders_or_duplicates": (
                    self._sequence_reorders_or_duplicates
                ),
                "frame_trace": tuple(dict(value) for value in self._frame_trace),
                "frame_trace_by_kind": {
                    kind: tuple(dict(value) for value in values)
                    for kind, values in self._frame_trace_by_kind.items()
                },
                "by_kind": {
                    kind: {
                        "delivered_batches": self._delivered_batches[kind],
                        "delivered_messages": self._delivered_messages[kind],
                        "dropped_messages": self._dropped_messages[kind],
                        "queue_rows": int(queue_rows.get(kind) or 0),
                        "batch_size": _local_latency_summary(
                            list(self._batch_sizes[kind]), suffix="rows"
                        ),
                        "decode_to_handler": _local_latency_summary(
                            list(self._queue_wait_ms[kind]), suffix="ms"
                        ),
                        "handler_duration": _local_latency_summary(
                            list(self._handler_ms[kind]), suffix="ms"
                        ),
                        "hub_parent_to_handler": _local_latency_summary(
                            list(self._parent_to_handler_ms[kind]), suffix="ms"
                        ),
                    }
                    for kind in _FEED_KINDS
                },
            }


class LiveMarketDataClient:
    """RQData-like client backed by the internal live-data hub."""

    def __init__(
        self,
        token: str | None = None,
        mode: str | None = None,
        server_url: str | None = None,
        ca_file: str | None = None,
    ) -> None:
        self._config: ClientConfig = merged_config(
            token=token,
            mode=mode,
            server_url=server_url,
            ca_file=ca_file,
        )
        occupied = _get_token_session(self._config)
        if occupied is not None:
            raise YMMMessageHubTokenInUseError(_token_in_use_message(occupied), occupied)
        self._client_instance_id = uuid.uuid4().hex
        self._computer_name = _computer_name()
        self._process_id = os.getpid()
        self._reconnect_lease: str | None = None
        self._desired: set[str] = set()
        self._desired_lock = threading.RLock()
        self._connection_lock = threading.RLock()
        self._pending_lock = threading.Lock()
        self._pending: dict[str, queue.Queue[dict[str, Any]]] = {}
        self._outgoing: queue.Queue[str] = queue.Queue()
        self._request_ids = itertools.count(1)
        self._feed_queue = _FeedBatchQueue(self._config.feed_queue_size)
        self._feed_delivery_metrics = _FeedDeliveryMetrics()
        self._feed_consumer_lock = threading.Lock()
        self._feed_consumer_started = False
        self._status_queue: queue.Queue[Any] = queue.Queue()
        self._status = CenterStatus(
            hub="disconnected",
            rqdata="disconnected",
            catalog="loading",
            storage="starting",
        )
        self._info: dict[str, Any] = {}
        self._ws: Any = None
        self._stop = threading.Event()
        self._connected = threading.Event()
        self._initial_ready = threading.Event()
        self._initial_error: BaseException | None = None
        self._last_connect_error: str | None = None
        self._replaced = False
        self._remote_closed = False
        self._closed = False
        self._local_status_sequence = itertools.count(1)
        self._dropped_messages = 0
        self._received_feed_frames = 0
        self._received_feed_messages = 0
        self._largest_feed_frame_messages = 0
        self._last_drop_notice = 0.0
        self._thread = threading.Thread(
            target=self._thread_main,
            name="ymm-live-data-connection",
            daemon=True,
        )
        self._thread.start()
        if not self._initial_ready.wait(self._config.connect_timeout):
            self.close()
            raise YMMMessageHubConnectionError(
                f"timed out connecting to {self._config.server_url}"
                + (f" ({self._last_connect_error})" if self._last_connect_error else "")
            )
        if self._initial_error is not None:
            error = self._initial_error
            self.close()
            raise error

    @property
    def subscriptions(self) -> list[str]:
        with self._desired_lock:
            return sorted(self._desired)

    @property
    def info(self) -> dict[str, Any]:
        return dict(self._info)

    @property
    def status(self) -> CenterStatus:
        return self._status

    @property
    def delivery_metrics(self) -> dict[str, Any]:
        """Return bounded local decode, queue, batch, and handler diagnostics."""

        queue_rows = (
            self._feed_queue.qsize_by_kind()
            if isinstance(self._feed_queue, _FeedBatchQueue)
            else {"1m": self._feed_queue.qsize()}
        )
        return self._feed_delivery_metrics.snapshot(queue_rows=queue_rows)

    def get_status(self) -> CenterStatus:
        response = self._send_command("get_status", {})
        if response is None:
            return self._status
        payload = response.get("result")
        if not isinstance(payload, dict):
            raise YMMMessageHubProtocolError("get_status returned an invalid payload")
        self._status = CenterStatus.from_payload(payload)
        return self._status

    def subscribe(self, channels: str | Iterable[str]) -> None:
        normalized = _normalize_channels(channels)
        valid: list[str] = []
        for channel in normalized:
            if not channel.startswith(("bar_", "tick_")):
                warnings.warn(f"invalid channel: {channel}, ignored", stacklevel=2)
                continue
            if channel.startswith("bar_") and channel.endswith("_1m"):
                warnings.warn(
                    f"invalid channel: {channel}, use {channel[:-3]} for raw 1m",
                    stacklevel=2,
                )
                continue
            valid.append(channel)
        if not valid:
            return
        with self._desired_lock:
            added = [channel for channel in valid if channel not in self._desired]
            self._desired.update(valid)
        if not added:
            return
        response = self._send_command("subscribe", {"channels": added})
        if response is not None:
            _emit_warnings(response.get("warnings"))
            accepted = response.get("result", {}).get("accepted")
            if isinstance(accepted, list):
                rejected = set(added) - {str(value) for value in accepted}
                if rejected:
                    with self._desired_lock:
                        self._desired.difference_update(rejected)

    def unsubscribe(self, channels: str | Iterable[str]) -> None:
        normalized = _normalize_channels(channels)
        with self._desired_lock:
            removed = [channel for channel in normalized if channel in self._desired]
            self._desired.difference_update(normalized)
        if not removed:
            return
        response = self._send_command("unsubscribe", {"channels": removed})
        if response is not None:
            _emit_warnings(response.get("warnings"))

    def listen(
        self,
        handler: Callable[[tuple[Any, ...]], Any] | None = None,
    ) -> Generator[tuple[Any, ...], None, None] | threading.Thread:
        if self._closed:
            raise RuntimeError("this connection is closed.")
        self._claim_feed_consumer()
        if handler is None:
            return self._iter_feed_batches()

        def consume() -> None:
            for batch, started_at in self._iter_feed_batches_with_started_at():
                try:
                    handler(batch.messages)
                except Exception as exc:  # noqa: BLE001 - isolate user callbacks.
                    self._publish_local_status(
                        "session",
                        "handler_failed",
                        f"market-data batch handler failed ({type(exc).__name__}: {exc})",
                        {
                            "batch_size": len(batch.messages),
                            "batch_kind_counts": _feed_kind_counts(batch.messages),
                        },
                    )
                    self.close()
                    return
                finally:
                    self._feed_delivery_metrics.observe_handler(
                        batch,
                        (time.monotonic() - started_at) * 1000.0,
                    )

        thread = threading.Thread(
            target=consume,
            name="ymm-live-data-handler",
            daemon=True,
        )
        thread.start()
        return thread

    def listen_status(
        self,
        handler: Callable[[StatusEvent], Any] | None = None,
    ) -> Generator[StatusEvent, None, None] | threading.Thread:
        if self._closed:
            raise RuntimeError("this connection is closed.")
        if handler is None:
            return self._iter_status()

        def consume() -> None:
            for event in self._iter_status():
                handler(event)

        thread = threading.Thread(
            target=consume,
            name="ymm-live-data-status-handler",
            daemon=True,
        )
        thread.start()
        return thread

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._stop.set()
        with self._connection_lock:
            self._ws = None
        self._fail_pending("connection closed")
        _put_terminal(self._feed_queue)
        self._status_queue.put(_STOP)
        if self._thread.is_alive() and threading.current_thread() is not self._thread:
            self._thread.join(timeout=2)

    def _iter_feed_batches(self) -> Generator[tuple[Any, ...], None, None]:
        for batch, _started_at in self._iter_feed_batches_with_started_at():
            yield batch.messages

    def _iter_feed_batches_with_started_at(
        self,
    ) -> Generator[tuple[_QueuedFeedBatch, float], None, None]:
        if isinstance(self._feed_queue, _FeedBatchQueue):
            while True:
                batch = self._feed_queue.get_batch_with_metadata()
                if batch is None:
                    return
                started_at = time.monotonic()
                self._feed_delivery_metrics.observe_delivery(batch, started_at)
                yield batch, started_at
        while True:
            item = self._feed_queue.get()
            if item is _STOP:
                return
            now = time.monotonic()
            batch = _QueuedFeedBatch((item,), now, now, now, now)
            self._feed_delivery_metrics.observe_delivery(batch, now)
            yield batch, now

    def _claim_feed_consumer(self) -> None:
        # Some surface tests instantiate with __new__.  Lazy initialization
        # keeps that supported without weakening the real constructor path.
        if not hasattr(self, "_feed_delivery_metrics"):
            self._feed_delivery_metrics = _FeedDeliveryMetrics()
        lock = getattr(self, "_feed_consumer_lock", None)
        if lock is None:
            lock = threading.Lock()
            self._feed_consumer_lock = lock
            self._feed_consumer_started = False
        with lock:
            if self._feed_consumer_started:
                raise RuntimeError("this connection already has a market-data consumer")
            self._feed_consumer_started = True

    def _iter_status(self) -> Generator[StatusEvent, None, None]:
        while True:
            item = self._status_queue.get()
            if item is _STOP:
                return
            yield item

    def _thread_main(self) -> None:
        asyncio.run(self._connection_loop())

    async def _connection_loop(self) -> None:
        delay = 0.5
        connected_once = False
        while not self._stop.is_set() and not self._replaced and not self._remote_closed:
            websocket = None
            try:
                websocket, hello = await self._connect()
                with self._connection_lock:
                    self._ws = websocket
                self._consume_hello(hello)
                self._connected.set()
                is_recovery = connected_once
                if not connected_once:
                    connected_once = True
                    self._initial_ready.set()
                await self._replay_subscriptions(websocket)
                if is_recovery:
                    self._publish_local_status(
                        "hub", "recovered", "connection and subscriptions recovered"
                    )
                delay = 0.5
                await self._receive_loop(websocket)
            except Exception as exc:  # noqa: BLE001 - network loop translates errors.
                self._last_connect_error = f"{type(exc).__name__}: {exc}"
                if isinstance(exc, YMMMessageHubTokenInUseError):
                    self._remote_closed = True
                    if not connected_once:
                        self._initial_error = exc
                        self._initial_ready.set()
                    else:
                        self._publish_local_status(
                            "session",
                            "in_use",
                            str(exc),
                            {"session_id": exc.session.session_id},
                        )
                        _put_terminal(self._feed_queue)
                        self._status_queue.put(_STOP)
                    return
                if isinstance(exc, _YMMMessageHubSessionClosedError):
                    self._remote_closed = True
                    self._stop.set()
                    if not connected_once and not self._initial_ready.is_set():
                        self._initial_error = YMMMessageHubConnectionError(str(exc))
                        self._initial_ready.set()
                    return
                if not connected_once and _is_authentication_failure(exc):
                    self._initial_error = YMMMessageHubAuthenticationError(str(exc))
                    self._initial_ready.set()
                    return
                if not connected_once and not self._initial_ready.is_set():
                    # Retry transient startup failures until the constructor timeout.
                    pass
                if self._replaced or self._remote_closed or self._stop.is_set():
                    break
                self._publish_local_status("hub", "disconnected", str(exc))
                self._publish_local_status(
                    "hub", "reconnecting", f"retrying in {delay:.1f} seconds"
                )
            finally:
                self._connected.clear()
                with self._connection_lock:
                    self._ws = None
                if websocket is not None:
                    try:
                        await websocket.close()
                    except Exception:
                        pass
                self._fail_pending("connection interrupted")
            if not await _wait_for_stop(self._stop, delay):
                delay = min(delay * 2, 30.0)
        if not connected_once and not self._initial_ready.is_set():
            self._initial_error = YMMMessageHubConnectionError(
                f"unable to connect to {self._config.server_url}"
            )
            self._initial_ready.set()

    async def _connect(self) -> tuple[Any, dict[str, Any]]:
        from websockets.asyncio.client import connect

        context = ssl.create_default_context(cafile=self._config.ca_file)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        headers = {
            "Authorization": f"Bearer {self._config.token}",
            "User-Agent": f"ymm-live-data-sdk/{SDK_VERSION}",
            "X-YMM-Live-Client-ID": self._client_instance_id,
            "X-YMM-Live-Process-ID": str(self._process_id),
        }
        if self._computer_name is not None:
            headers["X-YMM-Live-Computer-Name"] = self._computer_name
        if self._reconnect_lease is not None:
            headers["X-YMM-Live-Session-Lease"] = self._reconnect_lease
        websocket = await connect(
            self._config.server_url,
            ssl=context,
            additional_headers=headers,
            subprotocols=[SUBPROTOCOL],
            compression=None,
            proxy=None,
            open_timeout=self._config.connect_timeout,
            close_timeout=2,
            max_size=None,
        )
        first = await asyncio.wait_for(
            websocket.recv(), timeout=self._config.connect_timeout
        )
        if not isinstance(first, str):
            await websocket.close()
            raise YMMMessageHubProtocolError("hub didn't send a JSON hello message")
        payload = _load_json(first)
        if payload.get("type") == "auth_error":
            error = payload.get("error") or {}
            await websocket.close()
            raise YMMMessageHubAuthenticationError(
                str(error.get("message") or "market-data hub authentication failed")
            )
        if payload.get("type") == "session_error":
            error = payload.get("error") or {}
            error_type = str(error.get("type") or "SessionError")
            message = str(error.get("message") or "market-data session was rejected")
            await websocket.close()
            if error_type == "TokenInUseError":
                session_payload = payload.get("session")
                if not isinstance(session_payload, dict):
                    raise YMMMessageHubProtocolError(
                        "token-in-use response is missing session details"
                    )
                try:
                    session = TokenSession.from_payload(session_payload)
                except (TypeError, ValueError) as exc:
                    raise YMMMessageHubProtocolError(str(exc)) from exc
                raise YMMMessageHubTokenInUseError(
                    _token_in_use_message(session), session
                )
            if error_type == "SessionClosedError":
                raise _YMMMessageHubSessionClosedError(message)
            raise YMMMessageHubConnectionError(f"{error_type}: {message}")
        if payload.get("type") != "hello" or payload.get("version") != PROTOCOL_VERSION:
            await websocket.close()
            raise YMMMessageHubProtocolError("hub sent an unsupported hello message")
        return websocket, payload

    def _consume_hello(self, payload: dict[str, Any]) -> None:
        info = payload.get("info")
        status = payload.get("status")
        reconnect_lease = payload.get("reconnect_lease")
        if (
            not isinstance(info, dict)
            or not isinstance(status, dict)
            or not _is_hex_identifier(reconnect_lease)
        ):
            raise YMMMessageHubProtocolError(
                "hello message is missing info, status, or reconnect lease"
            )
        self._reconnect_lease = reconnect_lease
        self._info = dict(info)
        self._status = CenterStatus.from_payload(status)

    async def _replay_subscriptions(self, websocket: Any) -> None:
        with self._desired_lock:
            channels = sorted(self._desired)
        if not channels:
            return
        request_id = self._next_request_id()
        await websocket.send(
            json.dumps(
                {
                    "version": PROTOCOL_VERSION,
                    "type": "subscribe",
                    "request_id": request_id,
                    "channels": channels,
                    "replay": True,
                },
                separators=(",", ":"),
            )
        )

    async def _receive_loop(self, websocket: Any) -> None:
        while not self._stop.is_set() and not self._replaced and not self._remote_closed:
            while True:
                try:
                    outgoing = self._outgoing.get_nowait()
                except queue.Empty:
                    break
                await websocket.send(outgoing)
            try:
                frame = await asyncio.wait_for(websocket.recv(), timeout=0.02)
            except TimeoutError:
                continue
            if isinstance(frame, bytes):
                frame_received_at = time.monotonic()
                decode_started_at = time.monotonic()
                decoded = decode_feed_frame_with_metadata(frame)
                feeds = decoded.messages
                decoded_at = time.monotonic()
                self._feed_delivery_metrics.observe_decode(
                    decode_started_at, decoded_at
                )
                self._received_feed_frames += 1
                self._feed_delivery_metrics.observe_frame(
                    decoded.metadata, len(feeds)
                )
                self._received_feed_messages += len(feeds)
                self._largest_feed_frame_messages = max(
                    self._largest_feed_frame_messages,
                    len(feeds),
                )
                self._enqueue_feed_batch(
                    feeds,
                    frame_received_at=frame_received_at,
                    decode_started_at=decode_started_at,
                    decoded_at=decoded_at,
                    metadata=decoded.metadata,
                )
                continue
            if not isinstance(frame, str):
                raise YMMMessageHubProtocolError("unsupported WebSocket frame")
            payload = _load_json(frame)
            message_type = payload.get("type")
            if message_type == "response":
                request_id = str(payload.get("request_id") or "")
                with self._pending_lock:
                    waiter = self._pending.pop(request_id, None)
                if waiter is not None:
                    waiter.put(payload)
            elif message_type == "status":
                event_payload = payload.get("event")
                if not isinstance(event_payload, dict):
                    raise YMMMessageHubProtocolError("invalid status event")
                event = StatusEvent.from_payload(event_payload)
                self._status_queue.put(event)
                snapshot = payload.get("snapshot")
                if isinstance(snapshot, dict):
                    self._status = CenterStatus.from_payload(snapshot)
                if event.details.get("reason") == "token_revoked":
                    self._stop.set()
                    self._fail_pending("token revoked")
                    _put_terminal(self._feed_queue)
                    self._status_queue.put(_STOP)
                    raise YMMMessageHubAuthenticationError(
                        event.message or "token was revoked"
                    )
                if event.state == "replaced":
                    self._replaced = True
                    self._fail_pending("connection replaced")
                    _put_terminal(self._feed_queue)
                    self._status_queue.put(_STOP)
                    raise YMMMessageHubReplacedError(event.message or "connection replaced")
                if event.state == "closed" and event.details.get("reason") == "manual_close":
                    self._remote_closed = True
                    self._stop.set()
                    self._fail_pending("session manually closed")
                    _put_terminal(self._feed_queue)
                    self._status_queue.put(_STOP)
                    raise _YMMMessageHubSessionClosedError(
                        event.message or "session manually closed"
                    )
            elif message_type == "hello":
                self._consume_hello(payload)
            else:
                raise YMMMessageHubProtocolError(
                    f"unsupported hub message type: {message_type!r}"
                )

    def _send_command(
        self,
        command: str,
        fields: dict[str, Any],
    ) -> dict[str, Any] | None:
        if self._closed:
            raise RuntimeError("this connection is closed.")
        if self._replaced:
            raise YMMMessageHubReplacedError("connection was replaced by a newer client")
        if self._remote_closed:
            raise YMMMessageHubConnectionError("this session was closed manually")
        if not self._connected.is_set():
            return None
        request_id = self._next_request_id()
        waiter: queue.Queue[dict[str, Any]] = queue.Queue(maxsize=1)
        with self._pending_lock:
            self._pending[request_id] = waiter
        payload = {
            "version": PROTOCOL_VERSION,
            "type": command,
            "request_id": request_id,
            **fields,
        }
        try:
            self._outgoing.put(json.dumps(payload, separators=(",", ":")))
            response = waiter.get(timeout=self._config.command_timeout)
        except queue.Empty as exc:
            with self._pending_lock:
                self._pending.pop(request_id, None)
            raise YMMMessageHubConnectionError(
                f"hub didn't acknowledge {command} within {self._config.command_timeout:g}s"
            ) from exc
        except Exception:
            with self._pending_lock:
                self._pending.pop(request_id, None)
            raise
        if not response.get("ok"):
            error = response.get("error") or {}
            error_type = str(error.get("type") or "RemoteError")
            message = str(error.get("message") or f"{command} failed")
            if error_type in {"AuthenticationError", "SourceAuthorizationError"}:
                raise YMMMessageHubAuthenticationError(message)
            raise YMMMessageHubConnectionError(f"{error_type}: {message}")
        return response

    def _next_request_id(self) -> str:
        return f"c{next(self._request_ids)}"

    def _fail_pending(self, message: str) -> None:
        with self._pending_lock:
            waiters = list(self._pending.values())
            self._pending.clear()
        response = {
            "type": "response",
            "ok": False,
            "error": {"type": "ConnectionError", "message": message},
        }
        for waiter in waiters:
            try:
                waiter.put_nowait(response)
            except queue.Full:
                pass

    def _enqueue_feed(self, message: Any) -> None:
        self._enqueue_feed_batch((message,))

    def _enqueue_feed_batch(
        self,
        messages: tuple[Any, ...],
        *,
        frame_received_at: float | None = None,
        decode_started_at: float | None = None,
        decoded_at: float | None = None,
        metadata: FeedFrameMetadata | None = None,
    ) -> None:
        if isinstance(self._feed_queue, _FeedBatchQueue):
            dropped_by_kind = self._feed_queue.put_many(
                messages,
                frame_received_at=frame_received_at,
                decode_started_at=decode_started_at,
                decoded_at=decoded_at,
                metadata=metadata,
            )
            self._feed_delivery_metrics.observe_drops(dropped_by_kind)
            self._record_local_feed_drops(sum(dropped_by_kind.values()))
            return
        dropped = 0
        for message in messages:
            try:
                self._feed_queue.put_nowait(message)
            except queue.Full:
                try:
                    self._feed_queue.get_nowait()
                except queue.Empty:
                    pass
                self._feed_queue.put_nowait(message)
                dropped += 1
        self._record_local_feed_drops(dropped)

    def _record_local_feed_drops(self, dropped: int) -> None:
        if not dropped:
            return
        self._dropped_messages += dropped
        now = time.monotonic()
        if now - self._last_drop_notice >= 5:
            self._last_drop_notice = now
            self._publish_local_status(
                "session",
                "slow_consumer",
                "local SDK feed queue overflowed; oldest messages were dropped",
                {"dropped_messages": self._dropped_messages},
            )

    def _publish_local_status(
        self,
        component: str,
        state: str,
        message: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        from datetime import datetime, timezone

        event = StatusEvent(
            component=component,
            state=state,
            timestamp=datetime.now(timezone.utc).isoformat(),
            message=message,
            details=dict(details or {}),
            sequence=next(self._local_status_sequence),
        )
        self._status_queue.put(event)
        if component == "hub":
            self._status = CenterStatus(
                **{
                    **self._status.__dict__,
                    "hub": "connected" if state == "recovered" else state,
                    "dropped_messages": self._dropped_messages,
                }
            )


def _normalize_channels(channels: str | Iterable[str]) -> list[str]:
    if isinstance(channels, str):
        return [channels]
    try:
        values = list(channels)
    except TypeError as exc:
        raise TypeError("channels must be a string or an iterable of strings") from exc
    if any(not isinstance(value, str) for value in values):
        raise TypeError("channels must contain only strings")
    return values


def _feed_kind(message: Any) -> str:
    channel = str(message.get("channel") or "") if isinstance(message, dict) else ""
    if channel.startswith("tick_"):
        return "tick"
    if channel.endswith(("_5m", "_15m", "_30m", "_60m", "_120m", "_240m")):
        return "higher"
    return "1m"


def _feed_kind_counts(messages: Iterable[Any]) -> dict[str, int]:
    counts = {kind: 0 for kind in _FEED_KINDS}
    for message in messages:
        counts[_feed_kind(message)] += 1
    return counts


def _local_latency_summary(
    values: list[float], *, suffix: str
) -> dict[str, float | int | None]:
    ordered = sorted(values)

    def percentile(percent: int) -> float | None:
        if not ordered:
            return None
        index = max(
            0,
            min(len(ordered) - 1, (len(ordered) * percent + 99) // 100 - 1),
        )
        return round(ordered[index], 3)

    return {
        "sample_count": len(ordered),
        f"p50_{suffix}": percentile(50),
        f"p95_{suffix}": percentile(95),
        f"p99_{suffix}": percentile(99),
        f"max_{suffix}": None if not ordered else round(ordered[-1], 3),
    }


def _emit_warnings(records: Any) -> None:
    if not isinstance(records, list):
        return
    for record in records:
        if isinstance(record, dict):
            message = str(record.get("message") or "")
        else:
            message = str(record)
        if message:
            warnings.warn(message, UserWarning, stacklevel=3)


def _load_json(value: str) -> dict[str, Any]:
    try:
        payload = json.loads(value)
    except json.JSONDecodeError as exc:
        raise YMMMessageHubProtocolError("hub sent invalid JSON") from exc
    if not isinstance(payload, dict):
        raise YMMMessageHubProtocolError("hub JSON message must be an object")
    return payload


def _token_in_use_message(session: TokenSession) -> str:
    owner = f"strategy {session.strategy!r}"
    if session.computer_name:
        owner += f" on computer {session.computer_name!r}"
    if session.process_id is not None:
        owner += f" (process {session.process_id})"
    return (
        f"this token is already in use by {owner}; "
        "the existing connection was not interrupted; call get_token_session() and "
        "close_token_session(session_id) if you intend to close it"
    )


def _computer_name() -> str | None:
    try:
        value = socket.gethostname().strip()
    except OSError:
        return None
    value = "".join(character for character in value if 32 <= ord(character) < 127)[:128]
    return value or None


def _is_hex_identifier(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 32
        and all(character in "0123456789abcdef" for character in value.lower())
    )


def _put_terminal(target: Any) -> None:
    put_terminal = getattr(target, "put_terminal", None)
    if callable(put_terminal):
        put_terminal()
        return
    try:
        target.put_nowait(_STOP)
    except queue.Full:
        try:
            target.get_nowait()
        except queue.Empty:
            pass
        target.put_nowait(_STOP)


def _is_authentication_failure(exc: BaseException) -> bool:
    name = type(exc).__name__
    if name in {"InvalidStatus", "InvalidStatusCode"}:
        response = getattr(exc, "response", None)
        status_code = getattr(response, "status_code", None) or getattr(exc, "status_code", None)
        return status_code in {401, 403}
    return isinstance(exc, YMMMessageHubAuthenticationError)


async def _wait_for_stop(stop: threading.Event, seconds: float) -> bool:
    deadline = time.monotonic() + seconds
    while not stop.is_set() and time.monotonic() < deadline:
        await asyncio.sleep(min(0.05, max(0.0, deadline - time.monotonic())))
    return stop.is_set()
