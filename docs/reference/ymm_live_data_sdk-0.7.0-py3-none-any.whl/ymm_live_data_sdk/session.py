from __future__ import annotations

import json
import ssl
from typing import Any
import urllib.error
import urllib.parse
import urllib.request

from .config import ClientConfig, merged_config
from .exceptions import (
    YMMMessageHubAuthenticationError,
    YMMMessageHubConnectionError,
    YMMMessageHubProtocolError,
)
from .models import TokenSession
from .version import SDK_VERSION


def get_token_session(
    token: str | None = None,
    mode: str | None = None,
    server_url: str | None = None,
    ca_file: str | None = None,
) -> TokenSession | None:
    """Return the active connection for this token without opening a live feed."""
    config = merged_config(
        token=token,
        mode=mode,
        server_url=server_url,
        ca_file=ca_file,
    )
    return _get_token_session(config)


def close_token_session(
    session_id: str,
    *,
    token: str | None = None,
    mode: str | None = None,
    server_url: str | None = None,
    ca_file: str | None = None,
) -> bool:
    """Close the expected active session, without risking a newer session."""
    if (
        not isinstance(session_id, str)
        or len(session_id.strip()) != 32
        or any(character not in "0123456789abcdef" for character in session_id.strip().lower())
    ):
        raise ValueError("session_id must be a 32-character hexadecimal identifier")
    config = merged_config(
        token=token,
        mode=mode,
        server_url=server_url,
        ca_file=ca_file,
    )
    payload = _request(config, "DELETE", f"/v1/session/{session_id.strip()}")
    closed = payload.get("closed")
    if not isinstance(closed, bool):
        raise YMMMessageHubProtocolError("session close returned an invalid response")
    return closed


def _get_token_session(config: ClientConfig) -> TokenSession | None:
    payload = _request(config, "GET", "/v1/session")
    in_use = payload.get("in_use")
    session_payload = payload.get("session")
    if not isinstance(in_use, bool):
        raise YMMMessageHubProtocolError("session query returned an invalid response")
    if not in_use:
        if session_payload is not None:
            raise YMMMessageHubProtocolError("unused token returned unexpected session data")
        return None
    if not isinstance(session_payload, dict):
        raise YMMMessageHubProtocolError("occupied token response is missing session data")
    try:
        return TokenSession.from_payload(session_payload)
    except (TypeError, ValueError) as exc:
        raise YMMMessageHubProtocolError(str(exc)) from exc


def _request(config: ClientConfig, method: str, path: str) -> dict[str, Any]:
    context = ssl.create_default_context(cafile=config.ca_file)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    request = urllib.request.Request(
        _control_url(config.server_url, path),
        method=method,
        headers={
            "Authorization": f"Bearer {config.token}",
            "Accept": "application/json",
            "User-Agent": f"ymm-live-data-sdk/{SDK_VERSION}",
        },
    )
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({}),
        urllib.request.HTTPSHandler(context=context),
    )
    try:
        with opener.open(request, timeout=config.command_timeout) as response:
            raw = response.read()
    except urllib.error.HTTPError as exc:
        payload = _error_payload(exc)
        detail = str(payload.get("detail") or f"session control failed with HTTP {exc.code}")
        if exc.code in {401, 403}:
            raise YMMMessageHubAuthenticationError(detail) from exc
        if exc.code == 404:
            raise YMMMessageHubProtocolError(
                "FeedHub server does not support safe session control; "
                "Live Data SDK 0.7 requires FeedHub Server 0.9 or newer"
            ) from exc
        if exc.code == 409:
            raise YMMMessageHubConnectionError(
                "the active session changed; call get_token_session() again before closing"
            ) from exc
        raise YMMMessageHubConnectionError(detail) from exc
    except (OSError, TimeoutError, urllib.error.URLError) as exc:
        raise YMMMessageHubConnectionError(f"session control request failed: {exc}") from exc
    try:
        payload = json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise YMMMessageHubProtocolError("session control returned invalid JSON") from exc
    if not isinstance(payload, dict):
        raise YMMMessageHubProtocolError("session control returned an invalid response")
    return payload


def _control_url(server_url: str, path: str) -> str:
    parsed = urllib.parse.urlsplit(server_url)
    if parsed.scheme != "wss" or not parsed.netloc:
        raise YMMMessageHubProtocolError("server_url must be an absolute wss:// URL")
    return urllib.parse.urlunsplit(("https", parsed.netloc, path, "", ""))


def _error_payload(exc: urllib.error.HTTPError) -> dict[str, Any]:
    try:
        value = json.loads(exc.read())
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}
