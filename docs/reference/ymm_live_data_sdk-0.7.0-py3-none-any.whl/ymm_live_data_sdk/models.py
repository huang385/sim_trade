from __future__ import annotations

from dataclasses import dataclass, field, fields
from typing import Any


@dataclass(frozen=True)
class TokenSession:
    session_id: str
    user: str
    strategy: str
    computer_name: str | None
    process_id: int | None
    connected_at: str

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "TokenSession":
        session_id = payload.get("session_id")
        user = payload.get("user")
        strategy = payload.get("strategy")
        connected_at = payload.get("connected_at")
        if not all(
            isinstance(value, str) and value
            for value in (session_id, user, strategy, connected_at)
        ):
            raise ValueError("session response is missing required fields")
        computer_name = payload.get("computer_name")
        if computer_name is not None and not isinstance(computer_name, str):
            raise ValueError("session computer_name must be a string or null")
        process_id = payload.get("process_id")
        if process_id is not None and (isinstance(process_id, bool) or not isinstance(process_id, int)):
            raise ValueError("session process_id must be an integer or null")
        return cls(
            session_id=session_id,
            user=user,
            strategy=strategy,
            computer_name=computer_name,
            process_id=process_id,
            connected_at=connected_at,
        )


@dataclass(frozen=True)
class StatusEvent:
    component: str
    state: str
    timestamp: str
    message: str = ""
    details: dict[str, Any] = field(default_factory=dict)
    sequence: int = 0

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "StatusEvent":
        return cls(
            component=str(payload.get("component") or "hub"),
            state=str(payload.get("state") or "disconnected"),
            timestamp=str(payload.get("timestamp") or ""),
            message=str(payload.get("message") or ""),
            details=dict(payload.get("details") or {}),
            sequence=int(payload.get("sequence") or 0),
        )


@dataclass(frozen=True)
class CenterStatus:
    hub: str
    rqdata: str = "disconnected"
    catalog: str = "loading"
    aggregation: str = "starting"
    storage: str = "starting"
    authenticated_as: str | None = None
    strategy: str | None = None
    session_id: str | None = None
    server_version: str | None = None
    last_market_data_at: str | None = None
    certificate_not_after: str | None = None
    certificate_days_remaining: int | None = None
    dropped_messages: int = 0
    catalog_trading_date: str | None = None
    catalog_instrument_count: int = 0
    catalog_updated_at: str | None = None
    catalog_metadata_state: str = "loading"
    catalog_metadata_source: str | None = None
    catalog_metadata_target_date: str | None = None
    catalog_metadata_fetched_at: str | None = None
    catalog_metadata_source_instrument_count: int = 0
    catalog_metadata_covered_instrument_count: int = 0
    catalog_missing_trading_period_count: int = 0
    catalog_metadata_duration_ms: int | None = None
    catalog_metadata_request_count: int = 0
    catalog_metadata_last_error: str | None = None
    catalog_last_refresh_kind: str | None = None
    catalog_event_stream_state: str = "connecting"
    catalog_event_watermark: int | None = None
    catalog_event_cursor: int | None = None
    catalog_event_last_method: str | None = None
    catalog_event_last_status: str | None = None
    catalog_event_last_received_at: str | None = None
    catalog_event_last_applied_at: str | None = None
    catalog_event_last_error: str | None = None
    catalog_event_reconnect_count: int = 0
    catalog_loaded_event_id: int | None = None
    catalog_loaded_generation: int = 0
    target_channel_count: int = 0
    confirmed_channel_count: int = 0
    failed_channel_count: int = 0
    subscription_synced: bool = False
    baseline_target_channel_count: int = 0
    baseline_confirmed_channel_count: int = 0
    baseline_failed_channel_count: int = 0
    baseline_subscription_synced: bool = False
    critical_stop_requested: bool = False
    critical_stop_reason: str | None = None
    upstream_received_message_count: int = 0
    upstream_received_feed_count: int = 0
    upstream_received_bytes: int = 0
    rqdata_active_shards: int = 0
    rqdata_total_shards: int = 8
    rqdata_bytes_used: int = 0
    rqdata_bytes_limit: int = 0
    rqdata_quota_updated_at: str | None = None
    upstream_receive_queue: int = 0
    upstream_receive_queue_high_watermark: int = 0
    upstream_receive_queue_limit: int = 0
    upstream_receive_queue_paused: bool = False
    upstream_ipc_delivered_feed_count: int = 0
    upstream_ipc_dropped_feed_count: int = 0
    upstream_ipc_pending_feed_count: int = 0
    hub_ingress_queue: int = 0
    hub_ingress_dropped: int = 0
    hub_received_feed_count: int = 0
    aggregation_received_1m_rows: int = 0
    aggregation_accepted_1m_rows: int = 0
    aggregation_duplicate_bar_rows: int = 0
    aggregation_conflicting_bar_rows: int = 0
    aggregation_stale_bar_rows: int = 0
    aggregation_dropped_1m_rows: int = 0
    aggregation_emitted_5m_rows: int = 0
    aggregation_emitted_15m_rows: int = 0
    aggregation_emitted_30m_rows: int = 0
    aggregation_emitted_60m_rows: int = 0
    aggregation_emitted_120m_rows: int = 0
    aggregation_emitted_240m_rows: int = 0
    aggregation_invalidated_bucket_count: int = 0
    aggregation_fanout_rows: int = 0
    aggregation_last_bar_at: str | None = None
    aggregation_queue: int = 0
    aggregation_queue_high_watermark: int = 0
    aggregation_queue_limit: int = 0
    aggregation_pending_1m_rows: int = 0
    storage_ingress_queue: int = 0
    storage_batch_queue: int = 0
    storage_last_write_at: str | None = None
    storage_dropped_rows: int = 0
    storage_dropped_batches: int = 0
    storage_received_feed_count: int = 0
    storage_inserted_tick_rows: int = 0
    storage_inserted_1m_rows: int = 0
    storage_inserted_higher_bar_rows: int = 0
    storage_rejected_rows: int = 0
    pipeline_accounting_ok: bool = False
    cleanup_last_run_at: str | None = None
    cleanup_cutoff_trading_date: str | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "CenterStatus":
        allowed = {item.name for item in fields(cls)}
        values = {name: payload[name] for name in allowed if name in payload}
        values["hub"] = str(payload.get("hub") or "disconnected")
        for name in {
            "dropped_messages",
            "catalog_instrument_count",
            "catalog_metadata_source_instrument_count",
            "catalog_metadata_covered_instrument_count",
            "catalog_missing_trading_period_count",
            "catalog_metadata_request_count",
            "catalog_loaded_generation",
            "catalog_event_reconnect_count",
            "target_channel_count",
            "confirmed_channel_count",
            "failed_channel_count",
            "baseline_target_channel_count",
            "baseline_confirmed_channel_count",
            "baseline_failed_channel_count",
            "upstream_received_message_count",
            "upstream_received_feed_count",
            "upstream_received_bytes",
            "rqdata_active_shards",
            "rqdata_total_shards",
            "rqdata_bytes_used",
            "rqdata_bytes_limit",
            "upstream_receive_queue",
            "upstream_receive_queue_high_watermark",
            "upstream_receive_queue_limit",
            "upstream_ipc_delivered_feed_count",
            "upstream_ipc_dropped_feed_count",
            "upstream_ipc_pending_feed_count",
            "hub_ingress_queue",
            "hub_ingress_dropped",
            "hub_received_feed_count",
            "aggregation_received_1m_rows",
            "aggregation_accepted_1m_rows",
            "aggregation_duplicate_bar_rows",
            "aggregation_conflicting_bar_rows",
            "aggregation_stale_bar_rows",
            "aggregation_dropped_1m_rows",
            "aggregation_emitted_5m_rows",
            "aggregation_emitted_15m_rows",
            "aggregation_emitted_30m_rows",
            "aggregation_emitted_60m_rows",
            "aggregation_emitted_120m_rows",
            "aggregation_emitted_240m_rows",
            "aggregation_invalidated_bucket_count",
            "aggregation_fanout_rows",
            "aggregation_queue",
            "aggregation_queue_high_watermark",
            "aggregation_queue_limit",
            "aggregation_pending_1m_rows",
            "storage_ingress_queue",
            "storage_batch_queue",
            "storage_dropped_rows",
            "storage_dropped_batches",
            "storage_received_feed_count",
            "storage_inserted_tick_rows",
            "storage_inserted_1m_rows",
            "storage_inserted_higher_bar_rows",
            "storage_rejected_rows",
        }:
            values[name] = int(payload.get(name) or 0)
        values["subscription_synced"] = bool(payload.get("subscription_synced", False))
        values["baseline_subscription_synced"] = bool(
            payload.get("baseline_subscription_synced", False)
        )
        values["critical_stop_requested"] = bool(
            payload.get("critical_stop_requested", False)
        )
        values["upstream_receive_queue_paused"] = bool(
            payload.get("upstream_receive_queue_paused", False)
        )
        values["pipeline_accounting_ok"] = bool(
            payload.get("pipeline_accounting_ok", False)
        )
        if payload.get("certificate_days_remaining") is not None:
            values["certificate_days_remaining"] = int(payload["certificate_days_remaining"])
        if payload.get("catalog_metadata_duration_ms") is not None:
            values["catalog_metadata_duration_ms"] = int(
                payload["catalog_metadata_duration_ms"]
            )
        for name in {
            "catalog_event_watermark",
            "catalog_event_cursor",
            "catalog_loaded_event_id",
        }:
            if payload.get(name) is not None:
                values[name] = int(payload[name])
        return cls(**values)
