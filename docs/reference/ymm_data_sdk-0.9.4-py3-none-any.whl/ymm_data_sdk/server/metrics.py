"""Loopback-only Proxy metrics and in-process backup-license sampling."""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
import os
from pathlib import Path
import time
from typing import Any, AsyncIterator

from prometheus_client import CollectorRegistry, Counter, Gauge, Histogram, start_http_server
from starlette.concurrency import run_in_threadpool

from ymm_data_sdk.monitoring.quota import QuotaAuditRecord, sample_quota

from .rqdatac_proxy import get_quota


REGISTRY = CollectorRegistry(auto_describe=True)
REQUESTS = Counter(
    "ymm_data_sdk_proxy_requests_total",
    "Authorized RQData Proxy calls.",
    ("user", "realm", "method", "outcome", "error_type"),
    registry=REGISTRY,
)
REQUEST_BYTES = Counter(
    "ymm_data_sdk_proxy_request_bytes_total",
    "Compressed SDK request bytes received by the Proxy.",
    ("user", "realm", "method"),
    registry=REGISTRY,
)
RESPONSE_BYTES = Counter(
    "ymm_data_sdk_proxy_response_bytes_total",
    "Compressed SDK response bytes returned by the Proxy.",
    ("user", "realm", "method", "outcome"),
    registry=REGISTRY,
)
DURATION = Histogram(
    "ymm_data_sdk_proxy_request_duration_seconds",
    "Authorized Proxy call duration including serialization.",
    ("user", "realm", "method", "outcome"),
    buckets=(0.01, 0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10, 30, 60, 180, 600),
    registry=REGISTRY,
)
IN_FLIGHT = Gauge(
    "ymm_data_sdk_proxy_in_flight",
    "Currently executing authorized Proxy calls.",
    ("user", "realm", "method"),
    registry=REGISTRY,
)
QUOTA_LIMIT = Gauge(
    "ymm_data_sdk_rqdatac_quota_bytes_limit",
    "RQData daily traffic limit by isolated role.",
    ("role",),
    registry=REGISTRY,
)
QUOTA_USED = Gauge(
    "ymm_data_sdk_rqdatac_quota_bytes_used",
    "RQData daily traffic counter by isolated role.",
    ("role",),
    registry=REGISTRY,
)
QUOTA_LAST_SAMPLE = Gauge(
    "ymm_data_sdk_rqdatac_quota_last_sample_timestamp_seconds",
    "Unix time of the last quota sample attempt.",
    ("role", "status"),
    registry=REGISTRY,
)
QUOTA_SAMPLE_ERRORS = Counter(
    "ymm_data_sdk_rqdatac_quota_sample_errors_total",
    "Quota sampling failures, which do not affect Proxy requests.",
    ("role", "error_type"),
    registry=REGISTRY,
)


def realm_for_source(source: dict[str, Any] | None) -> str:
    return {
        "loopback": "local",
        "lan_ip": "lan",
        "tailscale_device": "tailscale",
    }.get(str((source or {}).get("kind") or ""), "unknown")


class ProxyCallObservation:
    def __init__(self, *, user: str, realm: str, method: str, request_bytes: int) -> None:
        self.user = user[:128]
        self.realm = realm[:32]
        self.method = method[:160]
        self.started = time.perf_counter()
        self._closed = False
        REQUEST_BYTES.labels(self.user, self.realm, self.method).inc(max(0, request_bytes))
        IN_FLIGHT.labels(self.user, self.realm, self.method).inc()

    def finish(
        self,
        *,
        outcome: str,
        response_bytes: int = 0,
        error_type: str = "none",
    ) -> None:
        if self._closed:
            return
        self._closed = True
        safe_outcome = outcome[:32]
        safe_error = error_type[:96]
        elapsed = max(0.0, time.perf_counter() - self.started)
        REQUESTS.labels(
            self.user,
            self.realm,
            self.method,
            safe_outcome,
            safe_error,
        ).inc()
        RESPONSE_BYTES.labels(
            self.user, self.realm, self.method, safe_outcome
        ).inc(max(0, response_bytes))
        DURATION.labels(
            self.user, self.realm, self.method, safe_outcome
        ).observe(elapsed)
        IN_FLIGHT.labels(self.user, self.realm, self.method).dec()


def _observe_quota(record: QuotaAuditRecord) -> None:
    when = record.timestamp.timestamp()
    QUOTA_LAST_SAMPLE.labels(record.role, record.status).set(when)
    if record.error_type:
        QUOTA_SAMPLE_ERRORS.labels(record.role, record.error_type).inc()
        return
    if record.bytes_limit is not None:
        QUOTA_LIMIT.labels(record.role).set(record.bytes_limit)
    if record.bytes_used is not None:
        QUOTA_USED.labels(record.role).set(record.bytes_used)


async def _quota_loop(stop: asyncio.Event, interval: int, ledger_dir: Path) -> None:
    while not stop.is_set():
        record = await run_in_threadpool(
            sample_quota,
            get_quota,
            role="proxy",
            phase="periodic",
            ledger_dir=ledger_dir,
        )
        _observe_quota(record)
        try:
            await asyncio.wait_for(stop.wait(), timeout=interval)
        except TimeoutError:
            continue


@asynccontextmanager
async def monitoring_lifespan() -> AsyncIterator[None]:
    enabled = os.environ.get("YMM_DATA_SDK_METRICS_ENABLED", "false").lower() == "true"
    if not enabled:
        yield
        return
    host = os.environ.get("YMM_DATA_SDK_METRICS_HOST", "127.0.0.1")
    if host not in {"127.0.0.1", "::1", "localhost"}:
        raise RuntimeError("Proxy metrics must bind to loopback")
    port = int(os.environ.get("YMM_DATA_SDK_METRICS_PORT", "18081"))
    interval = int(os.environ.get("YMM_DATA_SDK_QUOTA_SAMPLE_INTERVAL_SECONDS", "300"))
    if not 60 <= interval <= 3600:
        raise RuntimeError("quota sampling interval must be between 60 and 3600 seconds")
    ledger_dir = Path(
        os.environ.get(
            "YMM_DATA_SDK_QUOTA_LEDGER_DIR",
            "/var/lib/ymm-data-sdk/monitoring/quota-audit",
        )
    )
    httpd, thread = start_http_server(port, addr=host, registry=REGISTRY)
    stop = asyncio.Event()
    task = asyncio.create_task(_quota_loop(stop, interval, ledger_dir))
    try:
        yield
    finally:
        stop.set()
        await asyncio.gather(task, return_exceptions=True)
        httpd.shutdown()
        httpd.server_close()
        thread.join(timeout=5)
