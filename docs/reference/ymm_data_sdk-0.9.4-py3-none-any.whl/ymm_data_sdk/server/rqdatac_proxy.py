from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Any


_RQ_INITIALIZED = False
_RQDATAC_HOST = "rqdatad-pro.ricequant.com:16011"
_RQDATAC_ENV_KEYS = ("RQDATAC_CONF", "RQDATAC2_CONF", "RQSDK_LICENSE")
_YMM_DATA_SDK_RQDATAC_ENV_KEYS = ("YMM_DATA_SDK_RQDATAC_CONF", "YMM_DATA_SDK_RQDATAC_LICENSE")


def call_rqdatac(method: str, args: list[Any], kwargs: dict[str, Any]) -> Any:
    rqdatac_module = _rqdatac()
    func = _resolve_method(rqdatac_module, method)
    return func(*args, **kwargs)


def warmup_rqdatac() -> None:
    rqdatac_module = _rqdatac()
    rqdatac_module.user.get_quota()


def get_quota() -> dict[str, Any]:
    """Use the Proxy's existing RQData process and one-connection pool."""

    return dict(_rqdatac().user.get_quota())


def _rqdatac():
    global _RQ_INITIALIZED
    import rqdatac

    if not _RQ_INITIALIZED:
        _configure_rqdatac_env()
        rqdatac.init(use_pool=True, max_pool_size=1)
        _RQ_INITIALIZED = True
    return rqdatac


def _resolve_method(root: Any, method: str) -> Any:
    if not method or method.startswith("_") or ".." in method:
        raise ValueError(f"invalid rqdatac method: {method!r}")
    obj = root
    for part in method.split("."):
        if not part or part.startswith("_"):
            raise ValueError(f"invalid rqdatac method: {method!r}")
        obj = getattr(obj, part)
    if not callable(obj):
        raise ValueError(f"rqdatac attribute is not callable: {method!r}")
    return obj


def _hydrate_rqdatac_conf_from_interactive_shell() -> None:
    if os.environ.get("RQDATAC_CONF"):
        return
    try:
        conf = subprocess.check_output(
            ["bash", "-ic", 'printf %s "$RQDATAC_CONF"'],
            text=True,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        return
    if conf:
        os.environ["RQDATAC_CONF"] = conf


def _configure_rqdatac_env() -> None:
    raw = _first_env_value(_YMM_DATA_SDK_RQDATAC_ENV_KEYS)
    if not raw:
        license_file = os.environ.get("YMM_DATA_SDK_RQDATAC_LICENSE_FILE")
        if license_file:
            raw = Path(license_file).read_text(encoding="utf-8").strip()
    if not raw:
        raw = _first_env_value(_RQDATAC_ENV_KEYS)
    if not raw:
        _hydrate_rqdatac_conf_from_interactive_shell()
        raw = _first_env_value(_RQDATAC_ENV_KEYS)
    if not raw:
        return

    uri = _normalize_rqdatac_uri(raw)
    for key in _RQDATAC_ENV_KEYS:
        os.environ[key] = uri


def _first_env_value(keys: tuple[str, ...]) -> str:
    for key in keys:
        value = os.environ.get(key)
        if value and value.strip():
            return value.strip()
    return ""


def _normalize_rqdatac_uri(raw: str) -> str:
    value = raw.strip()
    if value.startswith(("tcp://", "rqdata://", "rqdatac://")):
        return value
    if ":" in value:
        return f"tcp://{value}@{_RQDATAC_HOST}"
    return f"tcp://license:{value}@{_RQDATAC_HOST}"
