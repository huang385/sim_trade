from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import inspect
import json
import math
import time
import warnings
from pathlib import Path
from typing import Any, Callable

from ymm_data_sdk.registry import LOCAL_METHODS, PROXY_METHODS


YMM_DATA_SDK_EXTENSION_METHODS = {
    "get_night_trading_dates",
    "futures.get_dominant_batch",
    "futures.get_contracts_batch",
    "options.get_contracts_batch",
    "options.get_dominant_month_batch",
}


@dataclasses.dataclass(frozen=True)
class Case:
    case_id: str
    method: str
    backend: str
    args: tuple[Any, ...] = ()
    kwargs: dict[str, Any] = dataclasses.field(default_factory=dict)
    policy: str = "strict"


def _cases() -> list[Case]:
    cases = [
        Case("all_instruments_cs", "all_instruments", "local", kwargs={"type": "CS", "date": "2025-01-10"}, policy="all_instruments"),
        Case("all_instruments_stock_alias", "all_instruments", "local", kwargs={"type": "STOCK", "date": "2025-01-10"}, policy="all_instruments"),
        Case("get_ex_factor_stock", "get_ex_factor", "local", ("000001.XSHE", "2020-01-01", "2025-12-31")),
        Case("get_open_auction_info_stock", "get_open_auction_info", "local", ("688001.XSHG", "2025-01-02", "2025-01-10"), policy="shared_columns"),
        Case("get_price_stock_daily", "get_price", "local", ("000001.XSHE", "2025-01-02", "2025-01-10"), {"frequency": "1d", "fields": ["open", "high", "low", "close", "volume", "total_turnover"]}),
        Case("get_price_stock_default_fields", "get_price", "local", ("000001.XSHE", "2025-01-02", "2025-01-10"), policy="shared_columns"),
        Case("get_price_stock_adjusted_compat", "get_price", "local", ("000001.XSHE", "2025-01-02", "2025-01-10"), {"fields": ["close", "volume"], "adjusted": False}),
        Case("get_price_expect_df_false", "get_price", "local", ("000001.XSHE", "2025-01-02", "2025-01-10"), {"fields": "close", "expect_df": False}),
        Case("get_price_daily_time_slice_warning", "get_price", "local", ("000001.XSHE", "2025-01-02", "2025-01-10"), {"fields": ["close"], "time_slice": ("09:30", "10:00")}),
        Case("get_price_stock_1m", "get_price", "local", ("000001.XSHE", "2025-01-02", "2025-01-02"), {"frequency": "1m", "fields": ["open", "high", "low", "close", "volume"]}),
        Case("get_price_stock_5m", "get_price", "local", ("000001.XSHE", "2025-01-02", "2025-01-02"), {"frequency": "5m", "fields": ["open", "high", "low", "close", "volume"]}),
        Case("get_price_stock_15m", "get_price", "local", ("000001.XSHE", "2025-01-02", "2025-01-02"), {"frequency": "15m", "fields": ["open", "high", "low", "close", "volume"]}),
        Case("get_price_stock_30m", "get_price", "local", ("000001.XSHE", "2025-01-02", "2025-01-02"), {"frequency": "30m", "fields": ["open", "high", "low", "close", "volume"]}),
        Case("get_price_stock_60m", "get_price", "local", ("000001.XSHE", "2025-01-02", "2025-01-02"), {"frequency": "60m", "fields": ["open", "high", "low", "close", "volume"]}),
        Case("get_price_stock_120m", "get_price", "local", ("000001.XSHE", "2025-01-02", "2025-01-02"), {"frequency": "120m", "fields": ["open", "high", "low", "close", "volume"]}),
        Case("get_price_stock_240m", "get_price", "local", ("000001.XSHE", "2025-01-02", "2025-01-02"), {"frequency": "240m", "fields": ["open", "high", "low", "close", "volume"]}),
        Case("get_price_stock_tick", "get_price", "local", ("000001.XSHE", "2025-01-02", "2025-01-02"), {"frequency": "tick", "fields": ["last", "volume", "total_turnover"]}),
        Case("get_price_etf", "get_price", "local", ("510300.XSHG", "2025-01-02", "2025-01-10"), {"fields": ["open", "high", "low", "close", "volume"]}),
        Case("get_price_lof", "get_price", "local", ("161713.XSHE", "2025-01-02", "2025-01-10"), {"fields": ["open", "high", "low", "close", "volume"]}),
        Case("get_price_index", "get_price", "local", ("000300.XSHG", "2025-01-02", "2025-01-10"), {"fields": ["open", "high", "low", "close", "volume"]}),
        Case("get_price_convertible", "get_price", "local", ("123198.XSHE", "2025-01-02", "2025-01-10"), {"fields": ["open", "high", "low", "close", "volume"]}),
        Case("get_price_future", "get_price", "local", ("IF2501", "2025-01-02", "2025-01-10"), {"fields": ["open", "high", "low", "close", "volume", "open_interest"]}),
        Case("get_price_mixed", "get_price", "local", (["000001.XSHE", "IF2501"], "2025-01-02", "2025-01-03"), {"fields": ["open", "high", "low", "close", "volume"]}),
        Case(
            "current_snapshot_stock_batch",
            "current_snapshot",
            "local",
            (["000001.XSHE", "510300.XSHG"],),
            policy="current_snapshot",
        ),
        Case("get_price_change_rate_stock", "get_price_change_rate", "local", ("000001.XSHE", "2025-01-02", "2025-01-10")),
        Case("get_price_change_rate_convertible", "get_price_change_rate", "local", ("123198.XSHE", "2025-01-02", "2025-01-10")),
        Case("get_split_stock", "get_split", "local", ("000001.XSHE", "2000-01-01", "2025-12-31")),
        Case("get_vwap_stock", "get_vwap", "local", ("000001.XSHE", "2025-01-02", "2025-01-10"), {"frequency": "1d"}),
        Case(
            "instruments_mixed",
            "instruments",
            "local",
            ([
                "000001.XSHE",
                "510300.XSHG",
                "161713.XSHE",
                "015849.XSHG",
                "180101.XSHE",
                "000300.XSHG",
                "IF2501",
                "IPS_CF2511_CY2511",
                "M2609C3000",
                "123198.XSHE",
                "131800.XSHE",
                "AG999.SGEX",
            ],),
            policy="instruments",
        ),
        Case("industry_a01", "industry", "local", ("A01",), policy="classification"),
        Case("get_night_trading_dates", "get_night_trading_dates", "local", ("2025-01-01", "2025-01-31"), policy="ymm_data_sdk_extension"),
        Case("get_latest_trading_date", "get_latest_trading_date", "local"),
        Case("get_future_latest_trading_date", "get_future_latest_trading_date", "local"),
        Case("get_next_trading_date", "get_next_trading_date", "local", ("2025-01-01",)),
        Case("get_previous_trading_date", "get_previous_trading_date", "local", ("2025-01-06",)),
        Case("get_trading_dates", "get_trading_dates", "local", ("2025-01-01", "2025-01-31")),
        Case("get_trading_periods_stock_1m", "get_trading_periods", "local", ("000001.XSHE", "2025-01-02", "2025-01-06"), {"frequency": "1m"}),
        Case("get_trading_periods_future_tick", "get_trading_periods", "local", ("AG1406", "2013-07-01", "2013-07-10"), {"frequency": "tick"}),
        Case("get_trading_dates_pre_2000", "get_trading_dates", "local", ("1998-04-20", "1998-05-10")),
        Case("get_previous_trading_date_2000_boundary", "get_previous_trading_date", "local", ("2000-01-04",)),
        Case("get_next_trading_date_1999_boundary", "get_next_trading_date", "local", ("1999-12-31",)),
        Case("is_suspended_stock", "is_suspended", "local", ("600005.XSHG", "2016-06-24", "2016-06-30")),
        Case("is_suspended_stock_2000_boundary", "is_suspended", "local", ("000029.XSHE", "2000-01-04", "2000-01-21")),
        Case("is_st_stock", "is_st_stock", "local", (["002336.XSHE", "000001.XSHE"], "2016-04-11", "2016-05-10")),
        Case("is_st_stock_pre_2000", "is_st_stock", "local", ("000511.XSHE", "1998-04-20", "1998-05-10")),
        Case("sector_energy", "sector", "local", ("Energy",), policy="classification"),
        Case("convertible_is_suspended", "convertible.is_suspended", "local", ("123198.XSHE", "2023-01-01", "2025-12-31")),
        Case("convertible_is_suspended_delisted", "convertible.is_suspended", "local", ("110030.XSHG", "2025-01-01", "2025-01-31")),
        Case(
            "convertible_all_instruments",
            "convertible.all_instruments",
            "local",
            ("2025-01-02",),
            policy="metadata_snapshot",
        ),
        Case(
            "convertible_instruments",
            "convertible.instruments",
            "local",
            (["110074.XSHG", "123198.XSHE"],),
            policy="convertible_instruments",
        ),
        Case("convertible_get_conversion_price", "convertible.get_conversion_price", "local", ("110030.XSHG", "2014-01-01", "2025-12-31")),
        Case("convertible_get_conversion_info", "convertible.get_conversion_info", "local", ("110044.XSHG", "2018-01-01", "2025-12-31")),
        Case("convertible_get_call_info", "convertible.get_call_info", "local", ("110020.XSHG", "2014-01-01", "2025-12-31")),
        Case("convertible_get_put_info", "convertible.get_put_info", "local", ("132002.XSHG", "2017-01-01", "2025-12-31")),
        Case("convertible_get_cash_flow", "convertible.get_cash_flow", "local", ("110032.XSHG",)),
        Case("convertible_get_instrument_industry", "convertible.get_instrument_industry", "local", (["110074.XSHG", "123198.XSHE"],), {"source": "citics_2019", "level": 0, "date": "2025-01-10"}),
        Case("convertible_get_industry", "convertible.get_industry", "local", ("电力设备及新能源",), {"source": "citics_2019", "date": "2025-01-10"}),
        Case("convertible_get_accrued_interest_eod", "convertible.get_accrued_interest_eod", "local", (["110074.XSHG", "123198.XSHE"], "2024-02-25", "2024-03-03")),
        Case("convertible_get_call_announcement", "convertible.get_call_announcement", "local", ("113541.XSHG", "2020-01-01", "2025-12-31")),
        Case("convertible_get_close_price", "convertible.get_close_price", "local", (["132020.XSHG", "132026.XSHG"], "2024-04-30", "2024-04-30")),
        Case("convertible_get_indicators", "convertible.get_indicators", "local", (["110031.XSHG", "110033.XSHG"], "2020-08-03", "2020-08-03")),
        Case("convertible_get_credit_rating", "convertible.get_credit_rating", "local", ("110031.XSHG", "2014-01-01", "2025-12-31")),
        Case("convertible_get_std_discount", "convertible.get_std_discount", "local", ("110059.XSHG", "2024-06-15", "2024-06-21")),
        Case("futures_get_dominant", "futures.get_dominant", "local", ("IF", "2025-01-02", "2025-01-10"), {"rule": 1, "rank": 2}),
        Case(
            "futures_get_dominant_batch",
            "futures.get_dominant_batch",
            "local",
            (["IF", "A", "TF"], "2026-01-01", "2026-01-05"),
            {"rule": 1, "rank": 2},
            policy="dominant_batch",
        ),
        Case("futures_get_contracts", "futures.get_contracts", "local", ("IF", "2016-08-01")),
        Case(
            "futures_get_ex_factor",
            "futures.get_ex_factor",
            "local",
            (["AL", "AG"], "2025-01-01", "2025-12-31"),
            {"adjust_method": "prev_close_spread", "rule": 0, "rank": 1},
        ),
        Case(
            "futures_get_contracts_batch",
            "futures.get_contracts_batch",
            "local",
            (["IF", "A", "TF"], "2026-01-01", "2026-01-05"),
            policy="contracts_batch",
        ),
        Case(
            "futures_get_contracts_batch_pre_2000",
            "futures.get_contracts_batch",
            "local",
            (["AL", "CU"], "1999-01-04", "1999-01-08"),
            policy="contracts_batch",
        ),
        Case(
            "futures_get_contract_multiplier_transition",
            "futures.get_contract_multiplier",
            "local",
            (["FB", "I"], "2019-11-28", "2019-12-03"),
        ),
        Case(
            "futures_get_contract_multiplier_multiple_changes",
            "futures.get_contract_multiplier",
            "local",
            (["FU", "WH", "RU"], "2011-01-20", "2012-08-01"),
        ),
        Case(
            "futures_get_exchange_daily_default_fields",
            "futures.get_exchange_daily",
            "local",
            (["A2409", "IF2408", "TF2409"], "2024-08-01", "2024-08-05"),
        ),
        Case(
            "futures_get_exchange_daily_selected_fields",
            "futures.get_exchange_daily",
            "local",
            (["A2409", "IF2408"], "2024-08-01", "2024-08-05"),
            {"fields": ["volume", "close", "volume"]},
        ),
        Case(
            "futures_get_exchange_daily_invalid_mixed",
            "futures.get_exchange_daily",
            "local",
            (["A2409", "000001.XSHE", "BAD"], "2024-08-01", "2024-08-05"),
            {"fields": "close"},
        ),
        Case(
            "futures_get_continuous_contracts_front",
            "futures.get_continuous_contracts",
            "local",
            ("IF", "2025-06-16", "2025-07-01"),
            {"type": "front_month"},
        ),
        Case(
            "futures_get_continuous_contracts_next",
            "futures.get_continuous_contracts",
            "local",
            ("AL", "2025-01-02", "2025-01-10"),
            {"type": "next_month"},
        ),
        Case(
            "futures_get_continuous_contracts_quarters",
            "futures.get_continuous_contracts",
            "local",
            ("IF", "2025-06-16", "2025-07-01"),
            {"type": "next_quarter"},
        ),
        Case(
            "futures_get_continuous_contracts_empty",
            "futures.get_continuous_contracts",
            "local",
            ("TF", "2025-01-02", "2025-01-10"),
        ),
        Case(
            "futures_get_trading_parameters",
            "futures.get_trading_parameters",
            "local",
            (["A2501", "IF2501", "TF2503"], "2025-01-02", "2025-01-10"),
        ),
        Case(
            "futures_get_trading_parameters_fields",
            "futures.get_trading_parameters",
            "local",
            (["AG2506", "SC2506"], "2025-01-02", "2025-01-10"),
            {"fields": ["commission_type", "open_commission", "long_margin_ratio"]},
        ),
        Case(
            "futures_get_member_rank",
            "futures.get_member_rank",
            "proxy",
            ("A1901",),
            {"trading_date": 20180910, "rank_by": "short"},
        ),
        Case(
            "futures_get_warehouse_stocks",
            "futures.get_warehouse_stocks",
            "proxy",
            ("CF",),
            {"start_date": 20191201, "end_date": 20191205},
        ),
        Case(
            "futures_get_basis",
            "futures.get_basis",
            "proxy",
            (["IF2106", "IH2106"], "20210412", "20210413"),
        ),
        Case(
            "futures_get_roll_yield",
            "futures.get_roll_yield",
            "proxy",
            (["RB", "HC"], "2023-01-03", "2023-01-10"),
            {"type": "main_sub", "rule": 0},
        ),
        Case(
            "futures_get_predicted_dividend_point",
            "futures.get_predicted_dividend_point",
            "proxy",
            (["IF2506", "IH2506"], "2025-04-01", "2025-04-10"),
        ),
        Case(
            "options_get_contracts_commodity_symbol",
            "options.get_contracts",
            "local",
            ("M",),
            {"trading_date": "2018-12-03"},
        ),
        Case(
            "options_get_contracts_underlying_contract",
            "options.get_contracts",
            "local",
            ("M1901",),
            {"option_type": "C", "trading_date": "2018-12-03"},
        ),
        Case(
            "options_get_contracts_historical_etf_strike",
            "options.get_contracts",
            "local",
            ("510050.XSHG",),
            {"strike": 2.006, "trading_date": "2016-11-29"},
        ),
        Case(
            "options_get_contracts_batch",
            "options.get_contracts_batch",
            "local",
            (["M", "M1901", "510050.XSHG"], "2018-12-03", "2018-12-05"),
            policy="option_contracts_batch",
        ),
        Case(
            "options_get_contract_property",
            "options.get_contract_property",
            "local",
            (["90000493", "10002752"], "2021-01-15", "2021-01-18"),
        ),
        Case(
            "options_get_contract_property_fields",
            "options.get_contract_property",
            "local",
            (["90000493", "10002752"], "2021-01-15", "2021-01-18"),
            {"fields": ["strike_price"]},
        ),
        Case(
            "options_get_dominant_month",
            "options.get_dominant_month",
            "local",
            ("CU", 20230701, 20230726),
        ),
        Case(
            "options_get_dominant_month_rank2_rule1",
            "options.get_dominant_month",
            "local",
            ("M", 20250102, 20250110),
            {"rule": 1, "rank": 2},
        ),
        Case(
            "options_get_dominant_month_batch",
            "options.get_dominant_month_batch",
            "local",
            (["M", "CU", "SC"], 20250102, 20250110),
            {"rule": 1, "rank": 2},
            policy="option_dominant_month_batch",
        ),
        Case(
            "options_get_greeks_daily_etf",
            "options.get_greeks",
            "local",
            (["10001739"], "2019-06-01", "2019-06-05"),
        ),
        Case(
            "options_get_greeks_daily_commodity",
            "options.get_greeks",
            "local",
            (["A2503C3400"], "2025-01-02", "2025-01-03"),
        ),
        Case(
            "options_get_greeks_1m_etf",
            "options.get_greeks",
            "local",
            (["10001739"], "2019-06-03", "2019-06-03"),
            {"frequency": "1m"},
        ),
        Case(
            "options_get_greeks_1m_cffex",
            "options.get_greeks",
            "local",
            (["IO2501C3450", "HO2501C2300", "MO2501C5100"], "2025-01-02", "2025-01-02"),
            {"frequency": "1m"},
        ),
        Case(
            "options_get_greeks_1m_commodity_none",
            "options.get_greeks",
            "local",
            (["A2503C3400"], "2025-01-02", "2025-01-02"),
            {"frequency": "1m"},
        ),
        Case(
            "options_get_indicators_mixed",
            "options.get_indicators",
            "local",
            (["CU", "510050.XSHG", "IO"], "2502", "2025-01-01", "2025-01-03"),
        ),
        Case(
            "options_get_indicators_fields",
            "options.get_indicators",
            "local",
            ("CU", 2502, "2025-01-01", "2025-01-03"),
            {"fields": ["VL_PCR", "skew"]},
        ),
        Case("current_performance", "current_performance", "proxy", ("000001.XSHE",), {"info_date": "2025-04-30"}),
        Case("get_pit_financials_ex", "get_pit_financials_ex", "proxy", ("000001.XSHE", ["revenue", "net_profit"], "2024q1", "2024q4"), {"date": "2025-06-30"}, policy="unordered_columns"),
        Case("get_auction_info", "get_auction_info", "proxy", ("688001.XSHG", "2025-01-02", "2025-01-10")),
        Case("get_concept", "get_concept", "proxy", (["人工智能"], "2024-01-01", "2025-12-31")),
        Case("get_concept_list", "get_concept_list", "proxy", ("2025-01-01", "2025-12-31")),
        Case("get_dividend", "get_dividend", "proxy", ("000001.XSHE", "2020-01-01", "2025-12-31")),
        Case("get_dividend_warning", "get_dividend", "proxy", ("000001.XSHE", "2020-01-01", "2025-12-31"), {"adjusted": True}),
        Case("get_dividend_amount", "get_dividend_amount", "proxy", ("000001.XSHE", "2020q1", "2024q4"), {"date": "2025-12-31"}),
        Case("get_dividend_info", "get_dividend_info", "proxy", ("000001.XSHE", "2020-01-01", "2025-12-31")),
        Case("get_all_factor_names", "get_all_factor_names", "proxy"),
        Case(
            "get_all_factor_names_obos",
            "get_all_factor_names",
            "proxy",
            kwargs={"type": "obos_indicator"},
        ),
        Case("get_factor_financial", "get_factor", "proxy", (["000001.XSHE", "000002.XSHE"], "debt_to_equity_ratio", "2018-01-02", "2018-01-03")),
        Case("get_industry", "get_industry", "proxy", ("银行",), {"date": "2025-01-10"}),
        Case("get_industry_change", "get_industry_change", "proxy", ("银行",), {"level": 1}),
        Case("get_industry_mapping", "get_industry_mapping", "proxy", kwargs={"date": "2025-01-10"}),
        Case("get_instrument_industry", "get_instrument_industry", "proxy", (["000001.XSHE", "000002.XSHE"],), {"level": 0, "date": "2025-01-10"}),
        Case("get_share_transformation", "get_share_transformation", "proxy", ("000022.XSHE",)),
        Case("get_shares", "get_shares", "proxy", (["000001.XSHE", "600519.XSHG"], "2025-01-02", "2025-01-10")),
        Case("get_main_shareholder", "get_main_shareholder", "proxy", ("000001.XSHE", "2024-01-01", "2025-12-31")),
        Case("get_private_placement", "get_private_placement", "proxy", ("000001.XSHE", "1990-01-01", "2025-12-31"), {"progress": "all", "issue_type": "all"}),
        Case("get_allotment", "get_allotment", "proxy", ("000001.XSHE", "1990-01-01", "2025-12-31")),
        Case("get_block_trade", "get_block_trade", "proxy", ("600519.XSHG", "2025-01-01", "2025-12-31")),
        Case("get_symbol_change_info", "get_symbol_change_info", "proxy", (["000001.XSHE", "002336.XSHE"],)),
        Case("get_special_treatment_info", "get_special_treatment_info", "proxy", (["000001.XSHE", "002336.XSHE"],)),
        Case("get_holder_number", "get_holder_number", "proxy", ("000001.XSHE", "2024-01-01", "2025-12-31")),
        Case("get_abnormal_stocks", "get_abnormal_stocks", "proxy", ("2025-01-01", "2025-01-31")),
        Case("get_abnormal_stocks_detail", "get_abnormal_stocks_detail", "proxy", ("000001.XSHE", "2020-01-01", "2025-12-31")),
        Case("get_buy_back", "get_buy_back", "proxy", ("000002.XSHE", "2015-01-01", "2025-12-31")),
        Case("get_capital_flow", "get_capital_flow", "proxy", ("000001.XSHE", "2019-04-12", "2019-04-15"), {"frequency": "1d"}),
        Case("get_securities_margin", "get_securities_margin", "proxy", ("000001.XSHE", "2025-01-02", "2025-01-10")),
        Case("get_margin_stocks", "get_margin_stocks", "proxy", kwargs={"date": "2025-01-02"}),
        Case("get_eligible_securities_margin", "get_eligible_securities_margin", "proxy", kwargs={"date": "2025-01-02"}),
        Case("get_margin_haircut", "get_margin_haircut", "proxy", ("000001.XSHE", "2025-01-02", "2025-01-10")),
        Case("get_stock_connect", "get_stock_connect", "proxy", ("000049.XSHE", "2018-05-08", "2018-05-10")),
        Case("current_stock_connect_quota", "current_stock_connect_quota", "proxy"),
        Case("get_stock_connect_quota", "get_stock_connect_quota", "proxy", (["hk_to_sh", "hk_to_sz"], "2024-01-02", "2024-01-10")),
        Case("get_incentive_plan", "get_incentive_plan", "proxy", ("002074.XSHE", "2020-01-01", "2025-12-31")),
        Case("get_investor_ra", "get_investor_ra", "proxy", ("002458.XSHE", "2025-01-01", "2025-12-31")),
        Case("get_announcement", "get_announcement", "proxy", ("000001.XSHE", "2022-10-01", "2022-10-10")),
        Case("get_audit_opinion", "get_audit_opinion", "proxy", ("000001.XSHE", "2024q1", "2024q4"), {"date": "2025-06-30"}),
        Case("get_restricted_shares", "get_restricted_shares", "proxy", ("000001.XSHE", "2010-01-01", "2024-01-01")),
        Case("get_staff_count", "get_staff_count", "proxy", ("000001.XSHE", "2024-01-01", "2025-08-01")),
        Case("get_leader_shares_change", "get_leader_shares_change", "proxy", ("002559.XSHE", "2025-07-23", "2025-07-29")),
        Case("get_forecast_report_date", "get_forecast_report_date", "proxy", ("000001.XSHE", "2024q1", "2025q1")),
        Case("get_investor_qa", "get_investor_qa", "proxy", ("300057.XSHE", "2025-01-01", "2025-12-31")),
        Case("get_turnover_rate", "get_turnover_rate", "proxy", (["000001.XSHE", "600519.XSHG"], "2025-01-02", "2025-01-10")),
        Case("get_yield_curve", "get_yield_curve", "proxy", (dt.date(2025, 1, 2), dt.date(2025, 1, 10)), {"tenor": ["1Y", "10Y"]}),
        Case("id_convert", "id_convert", "proxy", (["000001", "IF2501"],)),
        Case("performance_forecast", "performance_forecast", "proxy", ("000001.XSHE",), {"info_date": "2025-04-30"}),
        Case("index_indicator", "index_indicator", "proxy", (["000016.XSHG", "000300.XSHG"], "2025-01-02", "2025-01-10")),
        Case("index_components", "index_components", "proxy", ("000300.XSHG",), {"start_date": "2019-07-01", "end_date": "2019-07-06"}),
        Case("index_weights", "index_weights", "proxy", ("000016.XSHG", "2016-08-01")),
        Case("index_weights_ex", "index_weights_ex", "proxy", ("000300.XSHG", "2025-01-02")),
        Case("etf_get_components", "etf.get_components", "proxy", ("510050.XSHG",), {"date": "2019-01-17"}),
        Case("etf_get_cash_components", "etf.get_cash_components", "proxy", (["510050.XSHG", "510300.XSHG"], "2019-12-01", "2019-12-05")),
    ]
    for adjust_method in ("prev_close_spread", "open_spread", "prev_close_ratio", "open_ratio"):
        for adjust_type in ("none", "pre", "post"):
            cases.append(
                Case(
                    f"futures_get_dominant_price_{adjust_method}_{adjust_type}",
                    "futures.get_dominant_price",
                    "local",
                    ("AL", "2025-01-02", "2025-01-10"),
                    {"adjust_method": adjust_method, "adjust_type": adjust_type},
                )
            )
    cases.extend(
        [
            Case(
                "futures_get_dominant_price_dynamic",
                "futures.get_dominant_price",
                "local",
                ("AL", "2026-06-15", "2026-06-26"),
                {
                    "rule": 1,
                    "rank": 2,
                    "adjust_method": "open_ratio",
                    "adjust_type": "post",
                },
            ),
            Case(
                "futures_get_dominant_price_index_rank3",
                "futures.get_dominant_price",
                "local",
                ("IF", "2026-06-15", "2026-06-26"),
                {"rule": 1, "rank": 3, "adjust_type": "none"},
            ),
            Case(
                "futures_get_dominant_price_dynamic_rule2",
                "futures.get_dominant_price",
                "local",
                ("AL", "2026-06-15", "2026-06-26"),
                {"rule": 2, "rank": 2, "fields": ["close", "volume"]},
            ),
            Case(
                "futures_get_dominant_price_dynamic_rule3",
                "futures.get_dominant_price",
                "local",
                ("AL", "2026-06-15", "2026-06-26"),
                {"rule": 3, "rank": 3, "fields": ["close", "volume"]},
            ),
            Case(
                "futures_get_dominant_price_multi_1m",
                "futures.get_dominant_price",
                "local",
                (["AL", "IF", "TF"], "2025-01-02", "2025-01-02"),
                {"frequency": "1m", "fields": ["trading_date", "open", "close", "volume"]},
            ),
            Case(
                "futures_get_dominant_price_tick",
                "futures.get_dominant_price",
                "local",
                ("AL", "2025-01-02", "2025-01-02"),
                {
                    "frequency": "tick",
                    "fields": [
                        "trading_date", "open", "last", "prev_close", "prev_settlement",
                        "limit_up", "limit_down", "change_rate", "a1", "a1_v", "volume",
                        "total_turnover",
                    ],
                },
            ),
            Case(
                "futures_get_dominant_price_cross_midnight",
                "futures.get_dominant_price",
                "local",
                ("AL", "2025-01-03", "2025-01-03"),
                {
                    "frequency": "1m",
                    "fields": ["trading_date", "open", "close"],
                    "adjust_type": "none",
                    "time_slice": ("21:00", "01:00"),
                },
            ),
        ]
    )
    for frequency in ("5m", "15m", "30m", "60m", "120m", "240m"):
        cases.append(
            Case(
                f"futures_get_dominant_price_{frequency}",
                "futures.get_dominant_price",
                "local",
                (["AL", "IF", "TF"], "2025-01-02", "2025-01-02"),
                {
                    "frequency": frequency,
                    "fields": ["trading_date", "open", "high", "low", "close", "volume"],
                },
            )
        )
    return cases


def _resolve(root: Any, method: str) -> Callable[..., Any]:
    value = root
    for part in method.split("."):
        value = getattr(value, part)
    if not callable(value):
        raise TypeError(f"{method} is not callable")
    return value


def _capture(func: Callable[..., Any], args: tuple[Any, ...], kwargs: dict[str, Any]) -> tuple[Any, list[tuple[str, str]]]:
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        result = func(*args, **kwargs)
    api_warnings = []
    for item in caught:
        message = str(item.message)
        if issubclass(item.category, ResourceWarning):
            continue
        if issubclass(item.category, FutureWarning) and message.startswith(
            "Series.__getitem__ treating keys as positions is deprecated"
        ):
            continue
        api_warnings.append((item.category.__name__, message))
    return result, api_warnings


def _assert_equal(actual: Any, expected: Any, *, exact: bool) -> None:
    import numpy as np
    import pandas as pd

    if isinstance(expected, pd.DataFrame):
        if not isinstance(actual, pd.DataFrame):
            raise AssertionError(f"type mismatch: {type(actual).__name__} != DataFrame")
        pd.testing.assert_frame_equal(
            actual,
            expected,
            check_exact=exact,
            rtol=0 if exact else 1e-9,
            atol=0 if exact else 1e-9,
            check_dtype=True,
            check_names=True,
            check_like=False,
        )
        return
    if isinstance(expected, pd.Series):
        if not isinstance(actual, pd.Series):
            raise AssertionError(f"type mismatch: {type(actual).__name__} != Series")
        pd.testing.assert_series_equal(
            actual,
            expected,
            check_exact=exact,
            rtol=0 if exact else 1e-9,
            atol=0 if exact else 1e-9,
            check_dtype=True,
            check_names=True,
        )
        return
    if isinstance(expected, pd.Index):
        if not isinstance(actual, pd.Index):
            raise AssertionError(f"type mismatch: {type(actual).__name__} != {type(expected).__name__}")
        pd.testing.assert_index_equal(actual, expected, exact=True, check_names=True)
        return
    if isinstance(expected, np.ndarray):
        if not isinstance(actual, np.ndarray):
            raise AssertionError(f"type mismatch: {type(actual).__name__} != ndarray")
        np.testing.assert_array_equal(actual, expected, strict=True)
        return
    if isinstance(expected, dict):
        if not isinstance(actual, dict) or list(actual) != list(expected):
            raise AssertionError("mapping type/key/order mismatch")
        for key in expected:
            _assert_equal(actual[key], expected[key], exact=exact)
        return
    if isinstance(expected, (list, tuple)):
        if type(actual) is not type(expected) or len(actual) != len(expected):
            raise AssertionError("sequence type/length mismatch")
        for left, right in zip(actual, expected):
            _assert_equal(left, right, exact=exact)
        return
    if isinstance(expected, float) and math.isnan(expected):
        if not isinstance(actual, float) or not math.isnan(actual):
            raise AssertionError(f"expected NaN, got {actual!r}")
        return
    if type(actual) is not type(expected) or actual != expected:
        raise AssertionError(f"value mismatch: {actual!r} != {expected!r}")


def _compare_approved(case: Case, actual: Any, expected: Any) -> tuple[str, dict[str, Any]]:
    import pandas as pd

    if case.policy == "current_snapshot":
        actual_values = actual if isinstance(actual, list) else [actual]
        expected_values = expected if isinstance(expected, list) else [expected]
        if len(actual_values) != len(expected_values):
            raise AssertionError("current_snapshot list length mismatch")
        required = (
            "order_book_id",
            "datetime",
            "last",
            "volume",
            "total_turnover",
            "asks",
            "ask_vols",
            "bids",
            "bid_vols",
        )
        for left, right in zip(actual_values, expected_values):
            if not bool(getattr(left, "available", False)):
                raise AssertionError(
                    f"local current_snapshot is empty for {left.order_book_id}"
                )
            if left.order_book_id != right.order_book_id:
                raise AssertionError("current_snapshot order_book_id/order mismatch")
            for name in required:
                if not hasattr(left, name) or not hasattr(right, name):
                    raise AssertionError(f"current_snapshot missing property: {name}")
            for name in ("asks", "ask_vols", "bids", "bid_vols"):
                if len(getattr(left, name)) != 5 or len(getattr(right, name)) != 5:
                    raise AssertionError(f"current_snapshot {name} must contain five levels")
            if left.datetime == dt.datetime.min:
                raise AssertionError("current_snapshot datetime is empty")
        return "data_freshness_warning", {
            "reason": (
                "local current_snapshot is the latest successfully persisted tick; "
                "instantaneous values can lag or advance during the two sequential calls"
            )
        }
    if case.policy == "ymm_data_sdk_extension":
        if not isinstance(actual, list) or not all(isinstance(value, dt.date) for value in actual):
            raise AssertionError("ymm_data_sdk extension must return list[datetime.date]")
        return "approved_difference", {"reason": "ymm_data_sdk-only extension method"}
    if case.policy == "contracts_batch":
        import pandas as pd

        expected_columns = ["underlying_symbol", "date", "future_chain"]
        if not isinstance(actual, pd.DataFrame) or list(actual.columns) != expected_columns:
            raise AssertionError("contracts batch must return the documented DataFrame columns")
        if not actual["future_chain"].map(lambda value: isinstance(value, list)).all():
            raise AssertionError("future_chain values must be lists")
        if not actual["date"].map(lambda value: value.weekday() < 5).all():
            raise AssertionError("contracts batch returned a weekend date")
        return "approved_difference", {"reason": "ymm_data_sdk-only batch extension method"}
    if case.policy == "dominant_batch":
        expected_columns = ["underlying_symbol", "date", "dominant"]
        if not isinstance(actual, pd.DataFrame) or list(actual.columns) != expected_columns:
            raise AssertionError("dominant batch must return the documented DataFrame columns")
        if not actual["dominant"].map(lambda value: value is None or isinstance(value, str)).all():
            raise AssertionError("dominant values must be strings or None")
        if not actual["date"].map(lambda value: value.weekday() < 5).all():
            raise AssertionError("dominant batch returned a weekend date")
        if actual.duplicated(["underlying_symbol", "date"]).any():
            raise AssertionError("dominant batch returned duplicate symbol/date rows")
        return "approved_difference", {"reason": "ymm_data_sdk-only dominant batch extension method"}
    if case.policy == "option_contracts_batch":
        expected_columns = ["underlying", "date", "option_chain"]
        if not isinstance(actual, pd.DataFrame) or list(actual.columns) != expected_columns:
            raise AssertionError("option contracts batch must return the documented DataFrame columns")
        if not actual["option_chain"].map(lambda value: isinstance(value, list)).all():
            raise AssertionError("option_chain values must be lists")
        if not actual["date"].map(lambda value: value.weekday() < 5).all():
            raise AssertionError("option contracts batch returned a weekend date")
        return "approved_difference", {"reason": "ymm_data_sdk-only option batch extension method"}
    if case.policy == "option_dominant_month_batch":
        expected_columns = ["underlying_symbol", "date", "dominant"]
        if not isinstance(actual, pd.DataFrame) or list(actual.columns) != expected_columns:
            raise AssertionError("option dominant month batch must return the documented DataFrame columns")
        if str(actual["date"].dtype) != "int64":
            raise AssertionError("option dominant month batch date must use int64 YYYYMMDD")
        if not actual["dominant"].map(lambda value: value is None or isinstance(value, str)).all():
            raise AssertionError("option dominant month values must be strings or None")
        dates = pd.to_datetime(actual["date"].astype(str), format="%Y%m%d")
        if not dates.map(lambda value: value.weekday() < 5).all():
            raise AssertionError("option dominant month batch returned a weekend date")
        if actual.duplicated(["underlying_symbol", "date"]).any():
            raise AssertionError("option dominant month batch returned duplicate symbol/date rows")
        return "approved_difference", {"reason": "ymm_data_sdk-only option dominant month batch extension"}
    if case.policy == "classification":
        if not isinstance(actual, list) or not isinstance(expected, list):
            raise AssertionError("classification method must return list")
        if actual == expected:
            return "exact_match", {}
        return "data_freshness_warning", {
            "reason": "local instrument metadata can lag rqdatac",
            "local_count": len(actual),
            "rqdatac_count": len(expected),
            "missing_local": sorted(set(expected) - set(actual))[:20],
            "extra_local": sorted(set(actual) - set(expected))[:20],
        }
    if case.policy == "instruments":
        actual_values = actual if isinstance(actual, list) else [actual]
        expected_values = expected if isinstance(expected, list) else [expected]
        if len(actual_values) != len(expected_values):
            raise AssertionError("instrument list length mismatch")
        attrs = ("order_book_id", "type", "symbol", "listed_date", "de_listed_date")
        for left, right in zip(actual_values, expected_values):
            for attr in attrs:
                left_value = getattr(left, attr, None)
                right_value = getattr(right, attr, None)
                if attr in {"listed_date", "de_listed_date"}:
                    left_value = None if left_value in {None, "0000-00-00", "2999-12-31"} else left_value
                    right_value = None if right_value in {None, "0000-00-00", "2999-12-31"} else right_value
                if left_value != right_value:
                    raise AssertionError(f"instrument attribute mismatch: {attr}")
            if left.tick_size() != right.tick_size():
                raise AssertionError("instrument tick_size mismatch")
        return "approved_difference", {"reason": "ymm_data_sdk returns lightweight Instrument objects"}
    if case.policy == "convertible_instruments":
        actual_values = actual if isinstance(actual, list) else [actual]
        expected_values = expected if isinstance(expected, list) else [expected]
        if len(actual_values) != len(expected_values):
            raise AssertionError("convertible instrument list length mismatch")
        for left, right in zip(actual_values, expected_values):
            left_values = dict(left.items())
            right_values = {
                key: value for key, value in right.items() if not key.startswith("_")
            }
            _assert_equal(left_values, right_values, exact=True)
            _assert_equal(left.coupon_rate_table(), right.coupon_rate_table(), exact=True)
            _assert_equal(left.option(), right.option(), exact=True)
        return "approved_difference", {
            "reason": (
                "ymm_data_sdk returns a lightweight convertible Instrument; public attributes, "
                "coupon_rate_table() and option() are exact"
            )
        }
    if case.policy == "metadata_snapshot":
        if not isinstance(actual, pd.DataFrame) or not isinstance(expected, pd.DataFrame):
            raise AssertionError("metadata snapshot policy expects DataFrames")
        if list(actual.columns) != list(expected.columns):
            raise AssertionError("metadata snapshot columns differ")
        try:
            _assert_equal(actual, expected, exact=True)
        except AssertionError as exc:
            return "data_freshness_warning", {
                "reason": "local metadata snapshot can lag rqdatac between daily refreshes",
                "local_rows": len(actual),
                "rqdatac_rows": len(expected),
                "first_mismatch": str(exc).splitlines()[0],
            }
        return "exact_match", {}
    if case.policy in {"shared_columns", "all_instruments"}:
        if not isinstance(actual, pd.DataFrame) or not isinstance(expected, pd.DataFrame):
            raise AssertionError("shared-column policy expects DataFrames")
        if case.policy == "all_instruments":
            key = "order_book_id"
            common = [name for name in expected.columns if name in actual.columns and name != key]
            if key not in actual or key not in expected or not common:
                raise AssertionError("all_instruments has no comparable common columns")
            left = actual.set_index(key).sort_index().loc[:, common]
            right = expected.set_index(key).sort_index().loc[:, common]
            shared = left.index.intersection(right.index)
            if shared.empty:
                raise AssertionError("all_instruments has no shared order_book_id")
            status = "approved_difference"
            mismatch = None
            try:
                _assert_equal(left.loc[shared], right.loc[shared], exact=False)
            except AssertionError as exc:
                status = "data_freshness_warning"
                mismatch = str(exc).splitlines()[0]
            return status, {
                "reason": "local all_instruments exposes a documented field subset and may lag rqdatac",
                "local_rows": len(left),
                "rqdatac_rows": len(right),
                "common_columns": common,
                "freshness_mismatch": mismatch,
            }
        common = [name for name in expected.columns if name in actual.columns]
        if not common:
            raise AssertionError("no shared columns")
        if case.method == "get_open_auction_info":
            left = actual.reset_index()
            right = expected.reset_index()
            left["date"] = left["datetime"].dt.normalize()
            right["date"] = right["datetime"].dt.normalize()
            left = left.set_index(["order_book_id", "date"]).loc[:, common].sort_index()
            right = right.set_index(["order_book_id", "date"]).loc[:, common].sort_index()
            _assert_equal(left, right, exact=False)
        else:
            _assert_equal(actual.loc[:, common], expected.loc[:, common], exact=False)
        return "approved_difference", {
            "reason": "local table only exposes fields physically available in the mirror",
            "missing_local_columns": [name for name in expected.columns if name not in actual.columns],
        }
    if case.policy == "unordered_columns":
        if not isinstance(actual, pd.DataFrame) or not isinstance(expected, pd.DataFrame):
            raise AssertionError("unordered-column policy expects DataFrames")
        if set(actual.columns) != set(expected.columns):
            raise AssertionError("DataFrame column sets differ")
        columns = sorted(actual.columns)
        _assert_equal(actual.loc[:, columns], expected.loc[:, columns], exact=True)
        return "approved_difference", {
            "reason": "rqdatac builds this result's columns from set(fields), so order varies across processes"
        }
    raise AssertionError(f"unknown comparison policy: {case.policy}")


def _signature_shape(func: Callable[..., Any]) -> list[tuple[str, str, str]]:
    out = []
    for parameter in inspect.signature(func).parameters.values():
        default = "<required>" if parameter.default is inspect.Parameter.empty else repr(parameter.default)
        out.append((parameter.name, parameter.kind.name, default))
    return out


def _summary(value: Any) -> dict[str, Any]:
    shape = getattr(value, "shape", None)
    return {
        "type": type(value).__name__,
        "shape": list(shape) if isinstance(shape, tuple) else None,
        "length": len(value) if hasattr(value, "__len__") else None,
    }


def _run_case(case: Case, ymm_data_sdk: Any, rq: Any) -> dict[str, Any]:
    started = time.perf_counter()
    actual_func = _resolve(ymm_data_sdk, case.method)
    direct_func = None if case.method in YMM_DATA_SDK_EXTENSION_METHODS else _resolve(rq, case.method)
    try:
        expected, expected_warnings = (None, []) if direct_func is None else _capture(direct_func, case.args, case.kwargs)
        actual, actual_warnings = _capture(actual_func, case.args, case.kwargs)
        if case.policy == "strict":
            _assert_equal(actual, expected, exact=case.backend == "proxy")
            if actual_warnings != expected_warnings:
                raise AssertionError(f"warning mismatch: {actual_warnings!r} != {expected_warnings!r}")
            status, detail = "exact_match", {}
        else:
            status, detail = _compare_approved(case, actual, expected)
        return {
            "case_id": case.case_id,
            "method": case.method,
            "backend": case.backend,
            "status": status,
            "elapsed_seconds": round(time.perf_counter() - started, 6),
            "local_or_proxy": _summary(actual),
            "rqdatac": _summary(expected) if direct_func is not None else None,
            "warnings": {"ymm_data_sdk": actual_warnings, "rqdatac": expected_warnings},
            **detail,
        }
    except Exception as exc:  # noqa: BLE001 - report every conformance failure.
        return {
            "case_id": case.case_id,
            "method": case.method,
            "backend": case.backend,
            "status": "failed",
            "elapsed_seconds": round(time.perf_counter() - started, 6),
            "error_type": type(exc).__name__,
            "error_message": str(exc),
        }


def _proxy_exception_case(ymm_data_sdk: Any, rq: Any) -> dict[str, Any]:
    args = ("000001.XSHE", "2025-01-02", "2025-01-10")
    kwargs = {"fields": ["not_a_turnover_field"]}
    types = []
    messages = []
    for root in (rq, ymm_data_sdk):
        try:
            root.get_turnover_rate(*args, **kwargs)
        except Exception as exc:  # noqa: BLE001 - exception type is the value under test.
            types.append(type(exc).__name__)
            messages.append(str(exc))
        else:
            types.append("<no error>")
            messages.append("")
    status = "exact_match" if types[0] == types[1] and types[0] != "<no error>" else "failed"
    return {
        "case_id": "proxy_builtin_exception_restore",
        "method": "get_turnover_rate",
        "backend": "proxy",
        "status": status,
        "rqdatac_error_type": types[0],
        "ymm_data_sdk_error_type": types[1],
        "messages": messages,
    }


def _local_exception_case(ymm_data_sdk: Any, rq: Any) -> dict[str, Any]:
    types = []
    messages = []
    for root in (rq, ymm_data_sdk):
        try:
            root.get_price("000001.XSHE", "2025-01-02", "2025-01-03", unknown_argument=True)
        except Exception as exc:  # noqa: BLE001 - exception type is the value under test.
            types.append(type(exc).__name__)
            messages.append(str(exc))
        else:
            types.append("<no error>")
            messages.append("")
    status = "exact_match" if types[0] == types[1] == "ValueError" else "failed"
    return {
        "case_id": "local_unknown_parameter_rejected",
        "method": "get_price",
        "backend": "local",
        "status": status,
        "rqdatac_error_type": types[0],
        "ymm_data_sdk_error_type": types[1],
        "messages": messages,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Compare every registered ymm_data_sdk method with rqdatac.")
    parser.add_argument("--token", required=True)
    parser.add_argument("--server-url", required=True)
    parser.add_argument("--backend", choices=("all", "local", "proxy"), default="all")
    parser.add_argument("--output", default="ymm_data_sdk_conformance_report.json")
    args = parser.parse_args()

    import rqdatac as rq
    import ymm_data_sdk
    from ymm_data_sdk.server.rqdatac_proxy import _configure_rqdatac_env

    _configure_rqdatac_env()
    rq.init()
    ymm_data_sdk.init(token=args.token, server_url=args.server_url)
    selected = [case for case in _cases() if args.backend == "all" or case.backend == args.backend]
    registered = set(LOCAL_METHODS) | set(PROXY_METHODS)
    covered = {case.method for case in _cases()}
    missing = sorted(registered - covered)

    signature_results = []
    for method in sorted(registered):
        if method in YMM_DATA_SDK_EXTENSION_METHODS:
            signature_results.append({"method": method, "status": "approved_difference", "reason": "ymm_data_sdk-only extension"})
            continue
        try:
            left = _signature_shape(_resolve(ymm_data_sdk, method))
            right = _signature_shape(_resolve(rq, method))
            signature_results.append({
                "method": method,
                "status": "exact_match" if left == right else "failed",
                "ymm_data_sdk": left,
                "rqdatac": right,
            })
        except Exception as exc:  # noqa: BLE001
            signature_results.append({"method": method, "status": "failed", "error": str(exc)})

    results = []
    for case in selected:
        result = _run_case(case, ymm_data_sdk, rq)
        results.append(result)
        print(f"[{result['status']}] {case.case_id} ({result['elapsed_seconds']}s)")
    if args.backend in {"all", "local"}:
        result = _local_exception_case(ymm_data_sdk, rq)
        results.append(result)
        print(f"[{result['status']}] {result['case_id']}")
    if args.backend in {"all", "proxy"}:
        result = _proxy_exception_case(ymm_data_sdk, rq)
        results.append(result)
        print(f"[{result['status']}] {result['case_id']}")

    report = {
        "generated_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        "backend": args.backend,
        "registry": {
            "local_methods": sorted(LOCAL_METHODS),
            "proxy_methods": sorted(PROXY_METHODS),
            "missing_conformance_methods": missing,
        },
        "signature_results": signature_results,
        "case_results": results,
    }
    path = Path(args.output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(f"[report] {path}")

    failed = missing or any(item["status"] == "failed" for item in results)
    if args.backend == "all":
        failed = failed or any(item["status"] == "failed" for item in signature_results)
    raise SystemExit(1 if failed else 0)


if __name__ == "__main__":
    main()
