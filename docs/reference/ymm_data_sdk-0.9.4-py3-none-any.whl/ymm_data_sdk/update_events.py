from __future__ import annotations

import json
import inspect
import threading
from collections.abc import Callable, Iterator, Sequence
from typing import Any
from urllib.parse import urlencode, urlsplit, urlunsplit

from .config import SessionConfig, get_session
from .exceptions import YMMDataSDKRemoteError
from .registry import LOCAL_METHODS, LOCAL_UPDATE_SOURCES, PROXY_METHODS


_UNCHANGED = object()
_MISSING = object()
_PRICE_STATUS_COLUMNS = ("asset_type", "frequency", "last_updated_at")


class _UpdateEventStream(Iterator[dict[str, Any]]):
    """Closeable synchronous iterator over durable SDK update events."""

    def __init__(
        self,
        *,
        session: SessionConfig,
        methods: Sequence[str] | None,
        after_event_id: int | None,
        source_kinds: Sequence[str] | None,
        statuses: Sequence[str] | None,
        reconnect: bool,
    ) -> None:
        self._session = session
        self._methods = _values(methods, "methods")
        self._source_kinds = _values(source_kinds, "source_kinds")
        self._statuses = _values(statuses, "statuses")
        self._last_event_id = _event_id(after_event_id)
        self._reconnect = bool(reconnect)
        self._connection: Any = None
        self._closed = threading.Event()

    @property
    def last_event_id(self) -> int | None:
        return self._last_event_id

    def __iter__(self) -> _UpdateEventStream:
        return self

    def __next__(self) -> dict[str, Any]:
        while not self._closed.is_set():
            try:
                if self._connection is None:
                    self._connection = self._open()
                raw = self._connection.recv()
                if raw is None:
                    raise ConnectionError("update-event WebSocket closed")
                payload = json.loads(raw)
                if not isinstance(payload, dict) or not isinstance(payload.get("event_id"), int):
                    raise YMMDataSDKRemoteError(
                        "ProtocolError", "update-event WebSocket returned an invalid event"
                    )
                event_id = int(payload["event_id"])
                if self._last_event_id is not None and event_id <= self._last_event_id:
                    continue
                self._last_event_id = event_id
                _invalidate_local_status_caches()
                return payload
            except Exception as exc:  # noqa: BLE001 - transport errors vary by version.
                self._disconnect()
                if (
                    not self._reconnect
                    or self._closed.is_set()
                    or not _retryable_transport_error(exc)
                ):
                    if isinstance(exc, YMMDataSDKRemoteError):
                        raise
                    raise YMMDataSDKRemoteError(type(exc).__name__, str(exc)) from exc
                self._closed.wait(1.0)
        raise StopIteration

    def close(self) -> None:
        self._closed.set()
        self._disconnect()

    def __enter__(self) -> _UpdateEventStream:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def _open(self):
        try:
            from websockets.sync.client import connect
        except ImportError as exc:
            raise RuntimeError(
                "update-status transport requires the declared 'websockets' dependency"
            ) from exc
        headers: dict[str, str] = {}
        if self._session.token:
            headers["Authorization"] = f"Bearer {self._session.token}"
        options: dict[str, Any] = {
            "additional_headers": headers,
            "open_timeout": 15,
            "close_timeout": 5,
        }
        # websockets 15 added explicit proxy control. Disable environment HTTP
        # proxies for direct LAN/Tailscale transport while keeping 12-14 usable.
        if "proxy" in inspect.signature(connect).parameters:
            options["proxy"] = None
        return connect(
            _websocket_url(
                self._session.server_url,
                methods=self._methods,
                source_kinds=self._source_kinds,
                statuses=self._statuses,
                after_event_id=self._last_event_id,
            ),
            **options,
        )

    def _disconnect(self) -> None:
        connection, self._connection = self._connection, None
        if connection is not None:
            try:
                connection.close()
            except Exception:
                pass


class UpdateStatusStream(Iterator[Any]):
    """Yield changed status values for one or more local public methods."""

    def __init__(self, *, session: SessionConfig, method: str | Sequence[str]) -> None:
        methods, multiple = _status_watch_methods(method)
        self._session = session
        self._methods = methods
        self._multiple = multiple
        event_id, initial = _status_watch_baseline(session, method)
        initial_by_method = initial if multiple else {methods[0]: initial}
        self._last_values = {
            name: _status_snapshot(initial_by_method[name])
            for name in methods
        }
        source_methods = tuple(dict.fromkeys(
            source
            for name in methods
            for source in LOCAL_UPDATE_SOURCES[name]
        ))
        self._events = _UpdateEventStream(
            session=session,
            methods=source_methods,
            after_event_id=event_id,
            source_kinds=("authoritative",),
            statuses=("succeeded",),
            reconnect=True,
        )
        self._closed = threading.Event()
        self._consume_lock = threading.Lock()
        self._listener_lock = threading.Lock()
        self._listener_thread: threading.Thread | None = None
        self._last_error: Exception | None = None

    @property
    def is_listening(self) -> bool:
        """Whether a non-blocking listener thread is currently running."""

        thread = self._listener_thread
        return thread is not None and thread.is_alive()

    @property
    def last_error(self) -> Exception | None:
        """Return the exception that stopped background listening, if any."""

        return self._last_error

    def __iter__(self) -> UpdateStatusStream:
        return self

    def __next__(self) -> Any:
        listener = self._listener_thread
        if listener is not None and threading.current_thread() is not listener:
            raise RuntimeError(
                "this update-status stream is running with listen(); "
                "do not also call next() or iterate over it"
            )
        if not self._consume_lock.acquire(blocking=False):
            raise RuntimeError(
                "this update-status stream is already being consumed; "
                "do not combine listen() with next() or iteration"
            )
        try:
            while not self._closed.is_set():
                next(self._events)
                requested: str | Sequence[str] = (
                    self._methods if self._multiple else self._methods[0]
                )
                current = _current_update_status(self._session, requested)
                current_by_method = current if self._multiple else {self._methods[0]: current}
                changed: dict[str, Any] = {}
                for name in self._methods:
                    current_value = current_by_method[name]
                    delta = _status_delta(name, self._last_values[name], current_value)
                    if delta is _UNCHANGED:
                        continue
                    self._last_values[name] = _status_snapshot(current_value)
                    changed[name] = delta
                if not changed:
                    continue
                if self._multiple:
                    return changed
                return changed[self._methods[0]]
            raise StopIteration
        finally:
            self._consume_lock.release()

    def listen(self, callback: Callable[[Any], Any]) -> UpdateStatusStream:
        """Invoke ``callback`` for updates in a background thread and return immediately."""

        if not callable(callback):
            raise TypeError("callback must be callable")
        with self._listener_lock:
            if self._closed.is_set():
                raise RuntimeError("this update-status stream is closed")
            if self._listener_thread is not None:
                raise RuntimeError("listen() has already been called for this stream")
            thread = threading.Thread(
                target=self._listen,
                args=(callback,),
                name="ymm-data-sdk-update-status",
                daemon=True,
            )
            self._listener_thread = thread
            thread.start()
        return self

    def close(self) -> None:
        self._closed.set()
        self._events.close()
        thread = self._listener_thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=6.0)

    def __enter__(self) -> UpdateStatusStream:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def _listen(self, callback: Callable[[Any], Any]) -> None:
        try:
            for changed in self:
                callback(changed)
        except Exception as exc:  # noqa: BLE001 - retain callback/transport failure.
            if not self._closed.is_set():
                self._last_error = exc
        finally:
            self.close()


def watch_update_status(*, method: str | Sequence[str]) -> UpdateStatusStream:
    """Wait for successful updates to one method or a sequence of methods."""

    return UpdateStatusStream(session=get_session(), method=method)


def _status_watch_methods(
    method: str | Sequence[str],
) -> tuple[tuple[str, ...], bool]:
    multiple = not isinstance(method, str)
    methods = tuple(method) if multiple else (method,)
    if (
        not methods
        or any(not isinstance(item, str) or not item for item in methods)
        or any(item.startswith("rq.") for item in methods)
    ):
        raise ValueError(
            "method must be a public ymm_data_sdk name or a non-empty sequence of names "
            "without the rq. prefix"
        )
    methods = tuple(dict.fromkeys(methods))
    for name in methods:
        if name in PROXY_METHODS:
            raise ValueError(f"proxy method {name!r} has no local update status to watch")
        if name not in LOCAL_METHODS:
            raise ValueError(f"method {name!r} is not a supported local method")
        if not LOCAL_UPDATE_SOURCES[name]:
            raise ValueError(f"method {name!r} has no data update status to watch")
    return methods, multiple


def _status_watch_baseline(
    session: SessionConfig,
    method: str | Sequence[str],
) -> tuple[int, Any]:
    from .local_backend import _get_update_status_watch_baseline

    return _get_update_status_watch_baseline(method=method, session=session)


def _current_update_status(
    session: SessionConfig,
    method: str | Sequence[str],
) -> Any:
    from .local_backend import get_update_status

    return get_update_status(method=method, session=session)


def _status_key(value: Any) -> Any:
    """Create an immutable equality key for scalar or get_price status values."""

    if value is None:
        return ("none",)
    columns = getattr(value, "columns", None)
    itertuples = getattr(value, "itertuples", None)
    if columns is not None and callable(itertuples):
        import pandas as pd

        return (
            "table",
            tuple(str(column) for column in columns),
            tuple(
                tuple(None if pd.isna(value) else value for value in row)
                for row in itertuples(index=False, name=None)
            ),
        )
    return ("scalar", value)


def _status_snapshot(value: Any) -> Any:
    copy = getattr(value, "copy", None)
    if callable(copy):
        try:
            return copy(deep=True)
        except TypeError:
            return copy()
    return value


def _status_delta(method: str, previous: Any, current: Any) -> Any:
    if method == "get_price":
        delta = _price_status_delta(previous, current)
        if delta is not None:
            return _UNCHANGED if delta.empty else delta
    if _status_key(previous) == _status_key(current):
        return _UNCHANGED
    return current


def _price_status_delta(previous: Any, current: Any) -> Any | None:
    import pandas as pd

    if not isinstance(previous, pd.DataFrame) or not isinstance(current, pd.DataFrame):
        return None
    if not set(_PRICE_STATUS_COLUMNS).issubset(previous.columns) or not set(
        _PRICE_STATUS_COLUMNS
    ).issubset(current.columns):
        return None
    previous_rows = {
        (str(asset_type), str(frequency)): _normalized_status_value(last_updated_at)
        for asset_type, frequency, last_updated_at in previous.loc[
            :, list(_PRICE_STATUS_COLUMNS)
        ].itertuples(index=False, name=None)
    }
    changed = [
        previous_rows.get((str(asset_type), str(frequency)), _MISSING)
        != _normalized_status_value(last_updated_at)
        for asset_type, frequency, last_updated_at in current.loc[
            :, list(_PRICE_STATUS_COLUMNS)
        ].itertuples(index=False, name=None)
    ]
    return current.loc[changed, list(_PRICE_STATUS_COLUMNS)].reset_index(drop=True).copy()


def _normalized_status_value(value: Any) -> Any:
    import pandas as pd

    try:
        if bool(pd.isna(value)):
            return None
    except (TypeError, ValueError):
        pass
    return value


def _values(values: Sequence[str] | None, label: str) -> tuple[str, ...]:
    if values is None:
        return ()
    result = tuple(values)
    if any(not isinstance(value, str) or not value for value in result):
        raise ValueError(f"{label} must contain non-empty strings")
    if label == "methods" and any(value.startswith("rq.") for value in result):
        raise ValueError("methods must use public ymm_data_sdk names without the rq. prefix")
    return tuple(dict.fromkeys(result))


def _event_id(value: int | None) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or int(value) < 0:
        raise ValueError("after_event_id must be a non-negative integer")
    return int(value)


def _retryable_transport_error(exc: Exception) -> bool:
    if isinstance(exc, YMMDataSDKRemoteError):
        return False
    code = getattr(exc, "code", None)
    if code is None:
        code = getattr(getattr(exc, "rcvd", None), "code", None)
    return code not in {4400, 4401, 4403}


def _invalidate_local_status_caches() -> None:
    # Event delivery must not fail merely because a process has no local pool.
    try:
        from .local_pool import invalidate_update_status_caches

        invalidate_update_status_caches()
    except Exception:
        pass


def _websocket_url(
    server_url: str,
    *,
    methods: Sequence[str],
    source_kinds: Sequence[str],
    statuses: Sequence[str],
    after_event_id: int | None,
) -> str:
    parsed = urlsplit(server_url)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    query: list[tuple[str, str]] = []
    query.extend(("method", value) for value in methods)
    query.extend(("source_kind", value) for value in source_kinds)
    query.extend(("status", value) for value in statuses)
    if after_event_id is not None:
        query.append(("after_event_id", str(after_event_id)))
    return urlunsplit((scheme, parsed.netloc, "/ws/update-events", urlencode(query), ""))
