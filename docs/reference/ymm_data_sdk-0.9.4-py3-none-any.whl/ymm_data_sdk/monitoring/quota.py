"""Sanitized RQData quota audit records and deterministic aggregations.

The audit deliberately stores no credential, query, method argument, event
body, or result content. Files are split by Shanghai calendar date so each
file remains append-only and retention can remove whole expired files.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable, Iterable, Mapping
from dataclasses import asdict, dataclass
import datetime as dt
import fcntl
import json
import math
import os
from pathlib import Path
import statistics
from typing import Any
from zoneinfo import ZoneInfo


SCHEMA_VERSION = 1
SHANGHAI = ZoneInfo("Asia/Shanghai")
DEFAULT_LEDGER_DIR = Path("/var/lib/ymm-data-sdk/monitoring/quota-audit")
VALID_ROLES = frozenset({"primary", "proxy"})
SUCCESS_STATUSES = frozenset({"ok", "succeeded", "failed"})


@dataclass(frozen=True)
class QuotaAuditRecord:
    schema_version: int
    role: str
    observed_at: str
    bytes_limit: int | None
    bytes_used: int | None
    run_id: str | None
    batch: str | None
    target_trading_date: str | None
    attempt: int | None
    phase: str
    status: str
    error_type: str | None

    @property
    def timestamp(self) -> dt.datetime:
        value = dt.datetime.fromisoformat(self.observed_at)
        if value.tzinfo is None:
            raise ValueError("quota record timestamp must include a timezone")
        return value.astimezone(SHANGHAI)


def _now() -> dt.datetime:
    return dt.datetime.now(tz=SHANGHAI)


def _integer(value: Any, name: str) -> int:
    if isinstance(value, bool):
        raise TypeError(f"{name} must be an integer")
    number = int(value)
    if number < 0:
        raise ValueError(f"{name} must be non-negative")
    return number


def normalize_quota(value: Any) -> dict[str, int | str | None]:
    if not isinstance(value, Mapping):
        raise TypeError("get_quota returned a non-mapping value")
    return {
        "bytes_limit": _integer(value.get("bytes_limit"), "bytes_limit"),
        "bytes_used": _integer(value.get("bytes_used"), "bytes_used"),
    }


def _safe_optional_text(value: Any, *, maximum: int = 160) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    if any(character in text for character in ("\n", "\r", "\x00")):
        raise ValueError("quota audit metadata must be a single line")
    return text[:maximum]


def sample_quota(
    getter: Callable[[], Any],
    *,
    role: str,
    phase: str,
    status: str = "ok",
    ledger_dir: Path | None = None,
    observed_at: dt.datetime | None = None,
    run_id: str | None = None,
    batch: str | None = None,
    target_trading_date: str | dt.date | None = None,
    attempt: int | None = None,
) -> QuotaAuditRecord:
    """Sample quota without allowing monitoring failure to escape."""

    if role not in VALID_ROLES:
        raise ValueError(f"unsupported quota role: {role!r}")
    when = (observed_at or _now()).astimezone(SHANGHAI)
    quota: dict[str, int | str | None] = {
        "bytes_limit": None,
        "bytes_used": None,
    }
    error_type: str | None = None
    record_status = status
    try:
        quota = normalize_quota(getter())
    except BaseException as exc:  # Monitoring must never block business work.
        error_type = type(exc).__name__[:96]
        record_status = "sample_error"
    record = QuotaAuditRecord(
        schema_version=SCHEMA_VERSION,
        role=role,
        observed_at=when.isoformat(timespec="seconds"),
        bytes_limit=quota["bytes_limit"],
        bytes_used=quota["bytes_used"],
        run_id=_safe_optional_text(run_id),
        batch=_safe_optional_text(batch),
        target_trading_date=(
            target_trading_date.isoformat()
            if isinstance(target_trading_date, dt.date)
            else _safe_optional_text(target_trading_date, maximum=10)
        ),
        attempt=None if attempt is None else max(1, int(attempt)),
        phase=_safe_optional_text(phase, maximum=32) or "unknown",
        status=_safe_optional_text(record_status, maximum=32) or "unknown",
        error_type=error_type,
    )
    try:
        append_quota_record(record, ledger_dir=ledger_dir)
    except BaseException:
        # A full disk or permission regression is itself exported by the
        # snapshot collector. It must not fail a Proxy call or update run.
        pass
    return record


def append_quota_record(
    record: QuotaAuditRecord,
    *,
    ledger_dir: Path | None = None,
) -> Path:
    root = Path(
        ledger_dir
        or os.environ.get("YMM_DATA_SDK_QUOTA_LEDGER_DIR", "")
        or DEFAULT_LEDGER_DIR
    )
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    try:
        root.chmod(0o700)
    except PermissionError:
        pass
    path = root / f"{record.timestamp.date().isoformat()}.jsonl"
    line = json.dumps(asdict(record), ensure_ascii=False, separators=(",", ":")) + "\n"
    flags = os.O_APPEND | os.O_CREAT | os.O_WRONLY
    descriptor = os.open(path, flags, 0o600)
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX)
        os.write(descriptor, line.encode("utf-8"))
        os.fsync(descriptor)
    finally:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_UN)
        finally:
            os.close(descriptor)
    return path


def mark_license_switch(
    *,
    role: str,
    ledger_dir: Path | None = None,
    observed_at: dt.datetime | None = None,
) -> QuotaAuditRecord:
    """Record a content-free boundary for an operator-managed credential switch."""

    if role not in VALID_ROLES:
        raise ValueError(f"unsupported quota role: {role!r}")
    when = (observed_at or _now()).astimezone(SHANGHAI)
    record = QuotaAuditRecord(
        schema_version=SCHEMA_VERSION,
        role=role,
        observed_at=when.isoformat(timespec="seconds"),
        bytes_limit=None,
        bytes_used=None,
        run_id=None,
        batch=None,
        target_trading_date=None,
        attempt=None,
        phase="marker",
        status="license_switch",
        error_type=None,
    )
    append_quota_record(record, ledger_dir=ledger_dir)
    return record


def prune_quota_files(
    *,
    ledger_dir: Path | None = None,
    retain_days: int = 366,
    today: dt.date | None = None,
) -> list[Path]:
    if retain_days < 365:
        raise ValueError("quota audit retention must be at least 365 days")
    root = Path(ledger_dir or DEFAULT_LEDGER_DIR)
    if not root.is_dir():
        return []
    cutoff = (today or _now().date()) - dt.timedelta(days=retain_days)
    removed: list[Path] = []
    for path in root.glob("????-??-??.jsonl"):
        try:
            day = dt.date.fromisoformat(path.stem)
        except ValueError:
            continue
        if day < cutoff:
            path.unlink(missing_ok=True)
            removed.append(path)
    return removed


def _record_from_mapping(value: Mapping[str, Any]) -> QuotaAuditRecord:
    if int(value.get("schema_version", 0)) != SCHEMA_VERSION:
        raise ValueError("unsupported quota audit schema")
    role = str(value.get("role") or "")
    if role not in VALID_ROLES:
        raise ValueError("invalid quota audit role")
    record = QuotaAuditRecord(
        schema_version=SCHEMA_VERSION,
        role=role,
        observed_at=str(value["observed_at"]),
        bytes_limit=None if value.get("bytes_limit") is None else _integer(value["bytes_limit"], "bytes_limit"),
        bytes_used=None if value.get("bytes_used") is None else _integer(value["bytes_used"], "bytes_used"),
        run_id=_safe_optional_text(value.get("run_id")),
        batch=_safe_optional_text(value.get("batch")),
        target_trading_date=_safe_optional_text(value.get("target_trading_date"), maximum=10),
        attempt=None if value.get("attempt") is None else max(1, int(value["attempt"])),
        phase=_safe_optional_text(value.get("phase"), maximum=32) or "unknown",
        status=_safe_optional_text(value.get("status"), maximum=32) or "unknown",
        error_type=_safe_optional_text(value.get("error_type"), maximum=96),
    )
    record.timestamp
    return record


def read_quota_records(
    *,
    ledger_dir: Path | None = None,
    start_date: dt.date | None = None,
) -> list[QuotaAuditRecord]:
    root = Path(ledger_dir or DEFAULT_LEDGER_DIR)
    if not root.is_dir():
        return []
    records: list[QuotaAuditRecord] = []
    for path in sorted(root.glob("????-??-??.jsonl")):
        try:
            file_date = dt.date.fromisoformat(path.stem)
        except ValueError:
            continue
        if start_date is not None and file_date < start_date:
            continue
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except OSError:
            continue
        for line in lines:
            try:
                value = json.loads(line)
                if isinstance(value, Mapping):
                    records.append(_record_from_mapping(value))
            except (KeyError, TypeError, ValueError, json.JSONDecodeError):
                continue
    return sorted(records, key=lambda item: item.timestamp)


def _usable(records: Iterable[QuotaAuditRecord], role: str) -> list[QuotaAuditRecord]:
    return sorted(
        (
            item
            for item in records
            if item.role == role
            and item.status in SUCCESS_STATUSES
            and item.bytes_used is not None
            and item.bytes_limit is not None
        ),
        key=lambda item: item.timestamp,
    )


def natural_day_usage(
    records: Iterable[QuotaAuditRecord],
    *,
    role: str,
    now: dt.datetime | None = None,
    boundary_tolerance_minutes: int = 15,
) -> list[dict[str, Any]]:
    """Aggregate observed upstream counters into Shanghai natural days.

    A complete day needs observations near both day boundaries. Counter drops
    are treated as upstream reset points; more than one reset inside a day is
    retained as actual use but marks the sample incomplete.
    """

    source = list(records)
    usable = _usable(source, role)
    all_records = sorted(
        (item for item in source if item.role == role),
        key=lambda item: item.timestamp,
    )
    if not usable:
        return []
    current = (now or _now()).astimezone(SHANGHAI)
    grouped: dict[dt.date, list[QuotaAuditRecord]] = defaultdict(list)
    for item in usable:
        grouped[item.timestamp.date()].append(item)
    results: list[dict[str, Any]] = []
    tolerance = dt.timedelta(minutes=boundary_tolerance_minutes)
    for day in sorted(grouped):
        samples = grouped[day]
        start = dt.datetime.combine(day, dt.time.min, SHANGHAI)
        end = start + dt.timedelta(days=1)
        first, last = samples[0], samples[-1]
        prior = next((item for item in reversed(usable) if item.timestamp < first.timestamp), None)
        following = next((item for item in usable if item.timestamp > last.timestamp), None)
        # A sample shortly after midnight is not enough by itself: without a
        # preceding boundary sample its initial counter value would be lost
        # from the delta. Keep the first observed day explicitly incomplete.
        complete_start = bool(
            first.timestamp <= start + tolerance
            and prior is not None
            and prior.timestamp >= start - tolerance
        )
        complete_end = (
            last.timestamp >= end - tolerance
            or (following is not None and following.timestamp <= end + tolerance)
        )
        use = 0
        resets = 0
        previous_value: int | None = None
        if prior is not None and prior.timestamp >= start - tolerance:
            previous_value = prior.bytes_used
        for sample in samples:
            value = int(sample.bytes_used or 0)
            if previous_value is None:
                previous_value = value
                continue
            if value >= previous_value:
                use += value - previous_value
            else:
                resets += 1
                use += value
            previous_value = value
        complete = bool(
            day < current.date()
            and complete_start
            and complete_end
            and resets <= 1
            and not any(
                item.status == "license_switch" and item.timestamp.date() == day
                for item in all_records
            )
        )
        results.append(
            {
                "date": day.isoformat(),
                "bytes_used": use,
                "sample_count": len(samples),
                "reset_count": resets,
                "complete": complete,
            }
        )
    return results


def trading_day_usage(
    records: Iterable[QuotaAuditRecord],
    *,
    role: str = "primary",
) -> list[dict[str, Any]]:
    all_records = sorted(
        (item for item in records if item.role == role),
        key=lambda item: item.timestamp,
    )
    usable = _usable(all_records, role)
    groups: dict[tuple[str, int], list[QuotaAuditRecord]] = defaultdict(list)
    for item in usable:
        if not item.run_id or not item.target_trading_date:
            continue
        groups[(item.run_id, item.attempt or 1)].append(item)

    run_rows: list[dict[str, Any]] = []
    for (run_id, attempt), samples in sorted(groups.items()):
        before = next((item for item in samples if item.phase == "before"), None)
        after = next((item for item in reversed(samples) if item.phase == "after"), None)
        complete = before is not None and after is not None
        delta = 0
        if complete:
            before_used = int(before.bytes_used or 0)
            after_used = int(after.bytes_used or 0)
            if after_used >= before_used:
                delta = after_used - before_used
            else:
                complete = False
            if complete and any(
                item.status == "license_switch"
                and before.timestamp <= item.timestamp <= after.timestamp
                for item in all_records
            ):
                complete = False
        exemplar = after or before or samples[-1]
        run_rows.append(
            {
                "target_trading_date": exemplar.target_trading_date,
                "run_id": run_id,
                "attempt": attempt,
                "batch": exemplar.batch,
                "bytes_used": delta,
                "complete": complete,
                "status": None if after is None else after.status,
            }
        )

    by_day: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in run_rows:
        by_day[str(row["target_trading_date"])].append(row)
    return [
        {
            "target_trading_date": day,
            "bytes_used": sum(int(row["bytes_used"]) for row in rows),
            "run_count": len(rows),
            "complete": bool(rows) and all(bool(row["complete"]) for row in rows),
            "runs": rows,
        }
        for day, rows in sorted(by_day.items())
    ]


def summarize_complete_days(
    rows: Iterable[Mapping[str, Any]],
    *,
    limit: int = 5,
) -> dict[str, float | int]:
    values = [
        int(row["bytes_used"])
        for row in rows
        if bool(row.get("complete")) and row.get("bytes_used") is not None
    ][-limit:]
    if not values:
        return {"mean": math.nan, "median": math.nan, "max": math.nan, "sample_count": 0}
    return {
        "mean": float(statistics.fmean(values)),
        "median": float(statistics.median(values)),
        "max": float(max(values)),
        "sample_count": len(values),
    }
