import datetime as dt
from typing import Any, Literal, Sequence, overload
from .instrument import Instrument
from .exceptions import YMMDataSchemaError, YMMDataUnavailableError
from .update_events import UpdateStatusStream as UpdateStatusStream
from . import convertible as convertible
from . import futures as futures
from . import options as options
from . import etf as etf

__version__: str
__updated_at__: str

class Tick:
    @property
    def available(self) -> bool: ...
    @property
    def order_book_id(self) -> str: ...
    @property
    def datetime(self) -> dt.datetime: ...
    @property
    def open(self) -> Any: ...
    @property
    def high(self) -> Any: ...
    @property
    def low(self) -> Any: ...
    @property
    def last(self) -> Any: ...
    @property
    def limit_up(self) -> Any: ...
    @property
    def limit_down(self) -> Any: ...
    @property
    def prev_close(self) -> Any: ...
    @property
    def prev_settlement(self) -> Any: ...
    @property
    def volume(self) -> Any: ...
    @property
    def total_turnover(self) -> Any: ...
    @property
    def open_interest(self) -> Any: ...
    @property
    def num_trades(self) -> Any: ...
    @property
    def iopv(self) -> Any: ...
    @property
    def prev_iopv(self) -> Any: ...
    @property
    def close(self) -> Any: ...
    @property
    def settlement(self) -> Any: ...
    @property
    def trading_phase_code(self) -> Any: ...
    @property
    def asks(self) -> list[Any]: ...
    @property
    def ask_vols(self) -> list[Any]: ...
    @property
    def bids(self) -> list[Any]: ...
    @property
    def bid_vols(self) -> list[Any]: ...
    def __getitem__(self, key: str) -> Any: ...
    def to_dict(self) -> dict[str, Any]: ...

def init(
    token: str | None = None,
    mode: Literal["lan", "local", "TS"] | None = None,
    server_url: str | None = None,
    warmup: bool = True,
    local_pool_size: int = 2,
) -> None: ...
def clear_session() -> None: ...
def close() -> None: ...
def warmup(local: bool = True, proxy: bool = False) -> dict[str, Any]: ...
def get_session() -> Any: ...
def all_instruments(
    type: str | Sequence[str] | None = None,
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
    **kwargs: Any,
) -> Any: ...
def get_ex_factor(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_pit_financials_ex(
    order_book_ids: str | Sequence[str],
    fields: Sequence[str],
    start_quarter: str,
    end_quarter: str,
    date: str | int | dt.date | dt.datetime | None = None,
    statements: str = "latest",
    market: str = "cn",
) -> Any: ...
def current_performance(
    order_book_ids: str | Sequence[str],
    info_date: str | int | dt.date | dt.datetime | None = None,
    quarter: str | None = None,
    interval: str = "1q",
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...
def performance_forecast(
    order_book_ids: str | Sequence[str],
    info_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...
def get_share_transformation(
    predecessor: str | None = None,
    market: str = "cn",
) -> Any: ...
def sector(code: str, market: str = "cn") -> list[str]: ...
def industry(code: str, market: str = "cn") -> list[str]: ...
def get_concept_list(
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_concept(
    concepts: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_industry_mapping(
    source: str = "citics_2019",
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_industry(
    industry: str,
    source: str = "citics_2019",
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_industry_change(
    industry: str,
    source: str = "citics_2019",
    level: int | None = None,
    market: str = "cn",
) -> Any: ...
def get_instrument_industry(
    order_book_ids: str | Sequence[str],
    source: str = "citics_2019",
    level: int | str = 1,
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_shares(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    expect_df: bool = True,
    market: str = "cn",
) -> Any: ...
def get_main_shareholder(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    is_total: bool = False,
    start_rank: int | None = None,
    end_rank: int | None = None,
    market: str = "cn",
) -> Any: ...
def get_private_placement(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    progress: str = "complete",
    issue_type: str = "private",
    market: str = "cn",
) -> Any: ...
def get_allotment(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...
def get_block_trade(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_symbol_change_info(order_book_ids: str | Sequence[str], market: str = "cn") -> Any: ...
def get_special_treatment_info(order_book_ids: str | Sequence[str], market: str = "cn") -> Any: ...
def current_freefloat_turnover(order_book_ids: str | Sequence[str]) -> Any: ...
def get_holder_number(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_abnormal_stocks(
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    types: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...
def get_abnormal_stocks_detail(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    sides: str | Sequence[str] | None = None,
    types: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...
def get_buy_back(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...
def get_capital_flow(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    frequency: str = "1d",
    market: str = "cn",
) -> Any: ...
def current_capital_flow_minute(order_book_ids: str | Sequence[str], market: str = "cn") -> Any: ...
def get_securities_margin(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    expect_df: bool = True,
    market: str = "cn",
) -> Any: ...
def get_margin_stocks(
    date: str | int | dt.date | dt.datetime | None = None,
    exchange: str | None = None,
    margin_type: str = "stock",
    market: str = "cn",
) -> Any: ...
def get_eligible_securities_margin(
    date: str | int | dt.date | dt.datetime | None = None,
    exchange: str | None = None,
    market: str = "cn",
) -> Any: ...
def get_margin_haircut(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_stock_connect(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    expect_df: bool = True,
) -> Any: ...
def current_stock_connect_quota(
    connect: str | Sequence[str] | None = None,
    fields: str | Sequence[str] | None = None,
) -> Any: ...
def get_stock_connect_quota(
    connect: str | Sequence[str] | None = None,
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
) -> Any: ...
def get_incentive_plan(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_investor_ra(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_announcement(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...
def get_audit_opinion(
    order_book_ids: str | Sequence[str],
    start_quarter: str,
    end_quarter: str,
    date: str | int | dt.date | dt.datetime | None = None,
    type: str | None = None,
    opinion_types: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...
def get_restricted_shares(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_staff_count(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_leader_shares_change(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_forecast_report_date(
    order_book_ids: str | Sequence[str],
    start_quarter: str,
    end_quarter: str,
    market: str = "cn",
) -> Any: ...
def get_investor_qa(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_turnover_rate(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    expect_df: bool = True,
    market: str = "cn",
) -> Any: ...
def get_dividend_info(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_dividend(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    adjusted: bool = False,
    expect_df: bool = True,
    market: str = "cn",
) -> Any: ...
def get_dividend_amount(
    order_book_ids: str | Sequence[str],
    start_quarter: str | None = None,
    end_quarter: str | None = None,
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_factor(
    order_book_ids: str | Sequence[str],
    factor: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    universe: str | None = None,
    expect_df: bool = True,
    market: str = "cn",
    **kwargs: Any,
) -> Any: ...
def get_all_factor_names(
    type: str | None = None,
    market: str = "cn",
) -> list[str]: ...
def get_price(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    frequency: str = "1d",
    fields: str | Sequence[str] | None = None,
    adjust_type: str = "pre",
    skip_suspended: bool = False,
    expect_df: bool = True,
    time_slice: tuple[str | dt.time, str | dt.time] | None = None,
    market: str = "cn",
    **kwargs: Any,
) -> Any: ...
def get_update_status(
    *,
    method: str | Sequence[str],
) -> Any: ...
def watch_update_status(*, method: str | Sequence[str]) -> UpdateStatusStream: ...
def id_convert(
    order_book_ids: str | Sequence[str],
    to: str | None = None,
) -> Any: ...
def get_auction_info(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    frequency: str = "1d",
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...
def get_open_auction_info(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...
def current_minute(
    order_book_ids: str | Sequence[str],
    skip_suspended: bool = False,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...
def get_price_change_rate(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    expect_df: bool = True,
    market: str = "cn",
) -> Any: ...
@overload
def current_snapshot(order_book_ids: str, market: str = "cn") -> Tick: ...
@overload
def current_snapshot(
    order_book_ids: Sequence[str],
    market: str = "cn",
) -> list[Tick]: ...
def get_ticks(
    order_book_id: str,
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    expect_df: bool = True,
    market: str = "cn",
) -> Any: ...
def get_live_ticks(
    order_book_ids: str | Sequence[str],
    start_dt: str | int | dt.date | dt.datetime | None = None,
    end_dt: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...
def get_split(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def instruments(
    order_book_ids: str | Sequence[str],
    market: str = "cn",
) -> Instrument | list[Instrument]: ...
def get_night_trading_dates(
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def get_previous_trading_date(
    date: str | int | dt.date | dt.datetime,
    n: int = 1,
    market: str = "cn",
) -> Any: ...
def get_next_trading_date(
    date: str | int | dt.date | dt.datetime,
    n: int = 1,
    market: str = "cn",
) -> Any: ...
def get_trading_dates(
    start_date: str | int | dt.date | dt.datetime,
    end_date: str | int | dt.date | dt.datetime,
    market: str = "cn",
) -> Any: ...
def get_trading_periods(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    frequency: str = "1m",
    market: str = "cn",
) -> Any: ...
def get_latest_trading_date(market: str = "cn") -> dt.date: ...
def get_yield_curve(
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    tenor: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...
def get_live_minute_price_change_rate(order_book_ids: str | Sequence[str]) -> Any: ...
def get_future_latest_trading_date(market: str = "cn") -> dt.date: ...
def get_vwap(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    frequency: str = "1d",
) -> Any: ...
def is_data_ready(
    categories: str | Sequence[str] | None = None,
    expected_date: str | int | dt.date | dt.datetime | None = None,
    market: str | Sequence[str] | None = None,
) -> Any: ...
def is_suspended(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def is_st_stock(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def index_indicator(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...
def index_components(
    order_book_id: str,
    date: str | int | dt.date | dt.datetime | None = None,
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    return_create_tm: bool = False,
    market: str = "cn",
) -> Any: ...
def index_weights(
    order_book_id: str,
    date: str | int | dt.date | dt.datetime | None = None,
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
def index_weights_ex(
    order_book_id: str,
    date: str | int | dt.date | dt.datetime | None = None,
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
