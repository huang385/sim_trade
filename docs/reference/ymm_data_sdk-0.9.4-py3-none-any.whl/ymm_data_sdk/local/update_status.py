from __future__ import annotations

import datetime as dt
import time
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any
from zoneinfo import ZoneInfo

from ..exceptions import YMMDataSchemaError, YMMDataSDKError, YMMDataUnavailableError
from ..registry import LOCAL_METHODS, LOCAL_UPDATE_SOURCES, PROXY_METHODS
from .price_dimensions import (
    ASSETS,
    AUTHORITATIVE_DATASET_BY_DIMENSION,
    FREQUENCIES,
    PRICE_DIMENSIONS,
)

SHANGHAI = ZoneInfo("Asia/Shanghai")
STATUS_SCHEMA_VERSION = 3


@dataclass(frozen=True)
class SourceSegment:
    source: str
    start_date: str | None
    end_date: str | None
    status: str
    warning: str | None = None
    reason_code: str | None = None
    reason: str | None = None

    def as_dict(self) -> dict[str, Any]:
        payload = {
            "source": self.source,
            "start_date": self.start_date,
            "end_date": self.end_date,
            "status": self.status,
        }
        if self.reason_code:
            payload["reason_code"] = self.reason_code
        if self.reason:
            payload["reason"] = self.reason
        return payload


class UpdateStatusRouter:
    def __init__(self, connection: Any, *, cache_seconds: float = 30.0) -> None:
        self.connection = connection
        self.cache_seconds = cache_seconds
        self._loaded_at = float("-inf")
        self._contract: dict[str, Any] | None = None
        self._authoritative_cutoffs: dict[tuple[str, str], dt.date] = {}
        self._live_statuses: dict[tuple[str, str, dt.date], dict[str, Any]] = {}

    def invalidate(self) -> None:
        """Force the next status-dependent query to reload shared watermarks."""

        self._loaded_at = float("-inf")

    def get_update_status(
        self,
        *,
        method: str | Sequence[str],
    ):
        """Return the latest successful local materialization time for a method.

        Proxy methods use ``None`` as an explicit sentinel because their data is
        evaluated against RQDataC at call time.  ``get_price`` is the sole
        dimensional result and returns one row per authoritative asset/frequency
        watermark.
        """

        methods, multiple = _public_methods(method)
        if multiple:
            return {
                name: self._get_update_status(name)
                for name in methods
            }
        return self._get_update_status(methods[0])

    def _get_update_status(self, method: str):
        if method in PROXY_METHODS:
            return None
        if method not in LOCAL_METHODS:
            raise YMMDataSDKError(f"method {method!r} is not a supported local or proxy method")

        try:
            with self.connection.cursor() as cursor:
                _require_status_contract(cursor)
                if method == "get_price":
                    import pandas as pd

                    cursor.execute(
                        """SELECT asset_type, frequency,
                                  completed_at AS last_updated_at
                             FROM public.sdk_authoritative_price_watermarks
                            WHERE method = 'get_price'
                            ORDER BY asset_type, frequency"""
                    )
                    updated_at = {
                        (str(asset_type), str(frequency)): completed_at
                        for asset_type, frequency, completed_at in cursor.fetchall()
                    }
                    return pd.DataFrame(
                        [
                            (
                                dimension["asset_type"],
                                dimension["frequency"],
                                updated_at.get((
                                    dimension["asset_type"],
                                    dimension["frequency"],
                                )),
                            )
                            for dimension in PRICE_DIMENSIONS
                        ],
                        columns=["asset_type", "frequency", "last_updated_at"],
                    )

                sources = LOCAL_UPDATE_SOURCES[method]
                if not sources:
                    return None
                cursor.execute(
                    """WITH latest AS (
                           SELECT method, max(completed_at) AS completed_at
                             FROM public.sdk_method_update_status
                            WHERE method = ANY(%s)
                              AND status = 'succeeded'
                              AND completed_at IS NOT NULL
                            GROUP BY method
                       )
                       SELECT CASE WHEN count(*) = %s THEN min(completed_at) END
                         FROM latest""",
                    (list(sources), len(sources)),
                )
                row = cursor.fetchone()
                return None if row is None else row[0]
        except Exception as exc:
            if getattr(exc, "sqlstate", None) != "42P01":
                raise
            rollback = getattr(self.connection, "rollback", None)
            if callable(rollback):
                rollback()
            raise YMMDataSchemaError(
                "data-update status contract is not installed on the server"
            ) from exc

    def segments(
        self,
        *,
        asset_type: str,
        frequency: str,
        start_date: str | None,
        end_date: str | None,
    ) -> list[SourceSegment]:
        if asset_type not in ASSETS or frequency not in FREQUENCIES:
            raise ValueError(f"unsupported live route dimension: {asset_type}/{frequency}")
        self._refresh()
        contract = dict(self._contract or {})
        activation = contract.get("activation_trading_date")
        if not activation or not bool(contract.get("live_query_enabled")):
            return [SourceSegment("historical", start_date, end_date, "succeeded")]
        if isinstance(activation, str):
            activation = dt.date.fromisoformat(activation)
        start = dt.date.fromisoformat(start_date) if start_date else None
        end = dt.date.fromisoformat(end_date) if end_date else None
        cutoff = self._authoritative_cutoffs.get((asset_type, frequency))
        authority_cutoff = activation - dt.timedelta(days=1)
        if cutoff is not None:
            authority_cutoff = max(authority_cutoff, cutoff)
        if end is not None and end <= authority_cutoff:
            return [SourceSegment("historical", start_date, end_date, "succeeded")]

        result: list[SourceSegment] = []
        if start is None or start <= authority_cutoff:
            historical_end = authority_cutoff
            if end is not None:
                historical_end = min(historical_end, end)
            result.append(SourceSegment(
                "historical", start_date, historical_end.isoformat(), "succeeded"
            ))
        live_start = max(
            start or activation,
            activation,
            authority_cutoff + dt.timedelta(days=1),
        )
        if end is not None and end < live_start:
            return result
        status_dates = [
            trading_date
            for status_asset, status_frequency, trading_date in self._live_statuses
            if status_asset == asset_type
            and status_frequency == frequency
            and trading_date >= live_start
            and (end is None or trading_date <= end)
        ]
        today = dt.datetime.now(SHANGHAI).date()
        if end is not None:
            upper = end
        elif frequency == "1d":
            upper = max([today, *status_dates])
        else:
            upper = max(status_dates) if status_dates else today
        trading_dates = self._trading_dates(live_start, upper)

        daily: list[SourceSegment] = []
        for trading_day in trading_dates:
            daily.append(self._live_segment_for_day(
                asset_type=asset_type,
                frequency=frequency,
                trading_day=trading_day,
            ))
        result.extend(daily)
        return _merge_adjacent(result)

    def source_for_trading_date(
        self,
        *,
        asset_type: str,
        frequency: str,
        trading_date: dt.date | str,
    ) -> SourceSegment:
        """Resolve one known trading day without scanning the calendar table."""

        if asset_type not in ASSETS or frequency not in FREQUENCIES:
            raise ValueError(f"unsupported live route dimension: {asset_type}/{frequency}")
        trading_day = _date_value(trading_date)
        self._refresh()
        contract = dict(self._contract or {})
        activation = contract.get("activation_trading_date")
        if not activation or not bool(contract.get("live_query_enabled")):
            return SourceSegment(
                "historical", trading_day.isoformat(), trading_day.isoformat(), "succeeded"
            )
        if isinstance(activation, str):
            activation = dt.date.fromisoformat(activation)
        cutoff = self._authoritative_cutoffs.get((asset_type, frequency))
        authority_cutoff = activation - dt.timedelta(days=1)
        if cutoff is not None:
            authority_cutoff = max(authority_cutoff, cutoff)
        if trading_day <= authority_cutoff:
            return SourceSegment(
                "historical", trading_day.isoformat(), trading_day.isoformat(), "succeeded"
            )
        return self._live_segment_for_day(
            asset_type=asset_type,
            frequency=frequency,
            trading_day=trading_day,
        )

    def _live_segment_for_day(
        self,
        *,
        asset_type: str,
        frequency: str,
        trading_day: dt.date,
    ) -> SourceSegment:
        dimension = f"{asset_type}_{frequency}"
        live = self._live_statuses.get((asset_type, frequency, trading_day))
        if live is None:
            if frequency == "1d":
                return SourceSegment(
                    "none", trading_day.isoformat(), trading_day.isoformat(), "pending"
                )
            raise YMMDataUnavailableError(
                f"live status is missing for {trading_day} {dimension}"
            )
        status = str(live["status"])
        if status == "incompatible":
            raise YMMDataSchemaError(
                f"live schema is incompatible for {trading_day} {dimension}"
            )
        if status == "running" and frequency == "1d":
            valid_until = live.get("valid_until")
            if valid_until is None or _aware(valid_until) < dt.datetime.now(dt.UTC):
                raise YMMDataUnavailableError(
                    f"live health lease expired for {trading_day} {dimension}"
                )
            warning = None
            if live.get("reason"):
                warning = (
                    f"live data for {trading_day} {dimension} is still "
                    f"materializing with a confirmed gap: {live['reason']}"
                )
            return SourceSegment(
                "live", trading_day.isoformat(), trading_day.isoformat(), status,
                warning,
                reason_code=live.get("reason_code"), reason=live.get("reason"),
            )
        if status in {"failed", "running"}:
            raise YMMDataUnavailableError(
                f"live data is unavailable for {trading_day} {dimension}: {status}"
            )
        if status in {"healthy", "degraded"} and not live.get("sealed_at"):
            valid_until = live.get("valid_until")
            if valid_until is None or _aware(valid_until) < dt.datetime.now(dt.UTC):
                raise YMMDataUnavailableError(
                    f"live health lease expired for {trading_day} {dimension}"
                )
        if status not in {"healthy", "degraded"}:
            raise YMMDataUnavailableError(
                f"unsupported live status for {trading_day} {dimension}: {status}"
            )
        warning = None
        if status == "degraded":
            detail = str(live.get("reason") or "confirmed technical data gap")
            warning = f"live data for {trading_day} {dimension} has a confirmed gap: {detail}"
        return SourceSegment(
            "live", trading_day.isoformat(), trading_day.isoformat(), status,
            warning, live.get("reason_code"), live.get("reason"),
        )

    def _require_contract(self) -> None:
        self._refresh()
        if not bool((self._contract or {}).get("installed")):
            raise YMMDataSchemaError(
                "data-update status contract is not installed on the server"
            )

    def _refresh(self) -> None:
        if self._contract is not None and time.monotonic() - self._loaded_at < self.cache_seconds:
            return
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    "SELECT schema_version, activation_trading_date, live_query_enabled, "
                    "cleanup_enabled FROM public.data_update_contract WHERE singleton"
                )
                row = cursor.fetchone()
                if row is None:
                    self._set_uninstalled()
                else:
                    if int(row[0]) != STATUS_SCHEMA_VERSION:
                        raise YMMDataSchemaError(
                            f"unsupported data-update contract schema_version: {row[0]!r}"
                        )
                    self._contract = {
                        "schema_version": row[0],
                        "activation_trading_date": row[1],
                        "live_query_enabled": row[2],
                        "cleanup_enabled": row[3],
                        "installed": True,
                    }
                    cursor.execute(
                        """SELECT asset_type, frequency, live_dataset,
                                  authoritative_dataset,
                                  latest_authoritative_trading_date
                             FROM public.sdk_authoritative_price_watermarks
                            WHERE method = 'get_price'"""
                    )
                    cutoffs: dict[tuple[str, str], dt.date] = {}
                    for (
                        asset_type,
                        frequency,
                        live_dataset,
                        authoritative_dataset,
                        cutoff,
                    ) in cursor.fetchall():
                        dimension = f"{asset_type}_{frequency}"
                        expected = AUTHORITATIVE_DATASET_BY_DIMENSION.get(dimension)
                        if (
                            expected is None
                            or live_dataset != dimension
                            or authoritative_dataset != expected
                        ):
                            raise YMMDataSchemaError(
                                "invalid authoritative get_price watermark dimension: "
                                f"{asset_type}/{frequency}"
                            )
                        cutoffs[(asset_type, frequency)] = cutoff
                    self._authoritative_cutoffs = cutoffs
                    authority_floor = (
                        row[1] - dt.timedelta(days=1)
                        if row[1] is not None
                        else dt.date.min
                    )
                    cursor.execute(
                        """SELECT live.trading_date, live.method, live.dataset,
                                  live.asset_type, live.frequency, live.status,
                                  live.valid_until, live.sealed_at,
                                  live.reason_code, live.reason
                             FROM public.live_data_status AS live
                        LEFT JOIN public.sdk_authoritative_price_watermarks AS watermark
                               ON watermark.method = live.method
                              AND watermark.asset_type = live.asset_type
                              AND watermark.frequency = live.frequency
                            WHERE live.trading_date > GREATEST(
                                COALESCE(
                                    watermark.latest_authoritative_trading_date,
                                    %s::date
                                ),
                                %s::date
                            )""",
                        (authority_floor, authority_floor),
                    )
                    columns = [item.name for item in cursor.description]
                    self._live_statuses = {}
                    for item in cursor.fetchall():
                        status = dict(zip(columns, item))
                        dimension = f"{status['asset_type']}_{status['frequency']}"
                        if (
                            status["method"] != "get_price"
                            or status["dataset"] != dimension
                            or dimension not in AUTHORITATIVE_DATASET_BY_DIMENSION
                        ):
                            raise YMMDataSchemaError(
                                "invalid live get_price status dimension: "
                                f"{status['asset_type']}/{status['frequency']}"
                            )
                        key = (
                            str(status["asset_type"]),
                            str(status["frequency"]),
                            status["trading_date"],
                        )
                        self._live_statuses[key] = status
        except Exception as exc:
            if getattr(exc, "sqlstate", None) != "42P01":
                raise
            rollback = getattr(self.connection, "rollback", None)
            if callable(rollback):
                rollback()
            if bool((self._contract or {}).get("installed")):
                self._authoritative_cutoffs = {}
                raise YMMDataSchemaError(
                    "authoritative get_price watermark projection is not installed on the server"
                ) from exc
            self._set_uninstalled()
        self._loaded_at = time.monotonic()

    def _set_uninstalled(self) -> None:
        self._contract = {
            "schema_version": STATUS_SCHEMA_VERSION,
            "activation_trading_date": None,
            "live_query_enabled": False,
            "cleanup_enabled": False,
            "installed": False,
        }
        self._authoritative_cutoffs = {}
        self._live_statuses = {}

    def _trading_dates(self, start: dt.date, end: dt.date) -> list[dt.date]:
        if end < start:
            return []
        with self.connection.cursor() as cursor:
            cursor.execute(
                "SELECT date FROM public.trading_dates WHERE is_trading "
                "AND date BETWEEN %s AND %s ORDER BY date",
                (start, end),
            )
            return [row[0] for row in cursor.fetchall()]


def _public_methods(method: str | Sequence[str]) -> tuple[tuple[str, ...], bool]:
    multiple = not isinstance(method, str)
    methods = tuple(method) if multiple else (method,)
    if (
        not methods
        or any(not isinstance(item, str) or not item for item in methods)
        or any(item.startswith("rq.") for item in methods)
    ):
        raise ValueError(
            "method must be a public ymm_data_sdk name or a non-empty sequence of names "
            "without the rq. prefix"
        )
    return tuple(dict.fromkeys(methods)), multiple


def _require_status_contract(cursor: Any) -> None:
    cursor.execute(
        "SELECT schema_version FROM public.data_update_contract WHERE singleton"
    )
    row = cursor.fetchone()
    if row is None:
        raise YMMDataSchemaError(
            "data-update status contract is not installed on the server"
        )
    if int(row[0]) != STATUS_SCHEMA_VERSION:
        raise YMMDataSchemaError(
            f"unsupported data-update contract schema_version: {row[0]!r}"
        )


def _merge_adjacent(values: list[SourceSegment]) -> list[SourceSegment]:
    result: list[SourceSegment] = []
    for item in values:
        if (
            result and result[-1].source == item.source
            and result[-1].status == item.status
            and result[-1].warning == item.warning
            and result[-1].reason_code == item.reason_code
            and result[-1].reason == item.reason
        ):
            previous = result[-1]
            result[-1] = SourceSegment(
                previous.source, previous.start_date, item.end_date,
                previous.status, previous.warning, previous.reason_code, previous.reason,
            )
        else:
            result.append(item)
    return result


def _aware(value: dt.datetime) -> dt.datetime:
    return value if value.tzinfo else value.replace(tzinfo=dt.UTC)


def _date_value(value: Any) -> dt.date:
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    if isinstance(value, int):
        value = str(value)
    text = str(value).strip()
    if len(text) == 8 and text.isdigit():
        return dt.date(int(text[:4]), int(text[4:6]), int(text[6:8]))
    return dt.date.fromisoformat(text[:10])
