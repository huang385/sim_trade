from __future__ import annotations

from typing import Any

from .config import get_session
from .exceptions import YMMDataSDKError
from .registry import backend_for
from .remote_proxy import call_proxy


def dispatch(method_name: str, *args: Any, **kwargs: Any) -> Any:
    backend = backend_for(method_name)
    if backend == "local":
        return _dispatch_local(method_name, *args, **kwargs)
    if backend == "proxy":
        return call_proxy(get_session(), method_name, args, kwargs)
    raise YMMDataSDKError(
        f"method {method_name!r} is not registered; "
        "add it to ymm_data_sdk.registry before use"
    )


def _dispatch_local(method_name: str, *args: Any, **kwargs: Any) -> Any:
    from . import local_backend

    if method_name == "all_instruments":
        return local_backend.all_instruments(*args, **kwargs)
    if method_name == "get_ex_factor":
        return local_backend.get_ex_factor(*args, **kwargs)
    if method_name == "get_open_auction_info":
        return local_backend.get_open_auction_info(*args, **kwargs)
    if method_name == "get_price":
        return local_backend.get_price(*args, **kwargs)
    if method_name == "current_snapshot":
        return local_backend.current_snapshot(*args, **kwargs)
    if method_name == "get_update_status":
        return local_backend.get_update_status(*args, **kwargs)
    if method_name == "get_price_change_rate":
        return local_backend.get_price_change_rate(*args, **kwargs)
    if method_name == "get_split":
        return local_backend.get_split(*args, **kwargs)
    if method_name == "get_vwap":
        return local_backend.get_vwap(*args, **kwargs)
    if method_name == "instruments":
        return local_backend.instruments(*args, **kwargs)
    if method_name == "industry":
        return local_backend.industry(*args, **kwargs)
    if method_name == "get_night_trading_dates":
        return local_backend.get_night_trading_dates(*args, **kwargs)
    if method_name == "get_next_trading_date":
        return local_backend.get_next_trading_date(*args, **kwargs)
    if method_name == "get_latest_trading_date":
        return local_backend.get_latest_trading_date(*args, **kwargs)
    if method_name == "get_future_latest_trading_date":
        return local_backend.get_future_latest_trading_date(*args, **kwargs)
    if method_name == "get_previous_trading_date":
        return local_backend.get_previous_trading_date(*args, **kwargs)
    if method_name == "get_trading_dates":
        return local_backend.get_trading_dates(*args, **kwargs)
    if method_name == "get_trading_periods":
        return local_backend.get_trading_periods(*args, **kwargs)
    if method_name == "is_suspended":
        return local_backend.is_suspended(*args, **kwargs)
    if method_name == "is_st_stock":
        return local_backend.is_st_stock(*args, **kwargs)
    if method_name == "sector":
        return local_backend.sector(*args, **kwargs)
    if method_name == "convertible.is_suspended":
        return local_backend.convertible_is_suspended(*args, **kwargs)
    if method_name == "convertible.all_instruments":
        return local_backend.convertible_all_instruments(*args, **kwargs)
    if method_name == "convertible.instruments":
        return local_backend.convertible_instruments(*args, **kwargs)
    if method_name.startswith("convertible.get_"):
        handler_name = method_name.replace(".", "_", 1)
        handler = getattr(local_backend, handler_name, None)
        if handler is not None:
            return handler(*args, **kwargs)
    if method_name == "futures.get_dominant":
        return local_backend.get_dominant(*args, **kwargs)
    if method_name == "futures.get_dominant_batch":
        return local_backend.get_dominant_batch(*args, **kwargs)
    if method_name == "futures.get_contracts":
        return local_backend.get_contracts(*args, **kwargs)
    if method_name == "futures.get_contracts_batch":
        return local_backend.get_contracts_batch(*args, **kwargs)
    if method_name == "futures.get_ex_factor":
        return local_backend.get_future_ex_factor(*args, **kwargs)
    if method_name == "futures.get_dominant_price":
        return local_backend.get_dominant_price(*args, **kwargs)
    if method_name == "futures.get_contract_multiplier":
        return local_backend.get_contract_multiplier(*args, **kwargs)
    if method_name == "futures.get_exchange_daily":
        return local_backend.get_exchange_daily(*args, **kwargs)
    if method_name == "futures.get_continuous_contracts":
        return local_backend.get_continuous_contracts(*args, **kwargs)
    if method_name == "futures.get_trading_parameters":
        return local_backend.get_trading_parameters(*args, **kwargs)
    if method_name == "options.get_contracts":
        return local_backend.get_option_contracts(*args, **kwargs)
    if method_name == "options.get_contracts_batch":
        return local_backend.get_option_contracts_batch(*args, **kwargs)
    if method_name == "options.get_contract_property":
        return local_backend.get_option_contract_property(*args, **kwargs)
    if method_name == "options.get_dominant_month":
        return local_backend.get_option_dominant_month(*args, **kwargs)
    if method_name == "options.get_dominant_month_batch":
        return local_backend.get_option_dominant_month_batch(*args, **kwargs)
    if method_name == "options.get_greeks":
        return local_backend.get_option_greeks(*args, **kwargs)
    if method_name == "options.get_indicators":
        return local_backend.get_option_indicators(*args, **kwargs)
    raise YMMDataSDKError(f"local method {method_name!r} has no handler")
