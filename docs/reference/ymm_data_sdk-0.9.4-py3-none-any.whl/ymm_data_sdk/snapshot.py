from __future__ import annotations

import datetime as dt
import math
from collections.abc import Mapping
from typing import Any


_FLOAT_FIELDS = (
    "open",
    "high",
    "low",
    "last",
    "limit_up",
    "limit_down",
    "prev_close",
    "iopv",
    "prev_iopv",
    "close",
    "settlement",
)
_COUNT_FIELDS = ("volume", "total_turnover", "num_trades")
_OPTIONAL_FIELDS = ("open_interest", "prev_settlement", "trading_phase_code")


class Tick:
    """Latest successfully persisted Level-1 tick for one instrument.

    The common properties follow the object returned by rqdatac's
    ``current_snapshot``.  ``available`` and ``to_dict`` are local SDK
    extensions that make a valid instrument with no tick for the selected
    trading day explicit.
    """

    __slots__ = ("_available", "_data", "_order_book_id")

    def __init__(
        self,
        order_book_id: str,
        data: Mapping[str, Any] | None = None,
    ) -> None:
        self._order_book_id = str(order_book_id)
        self._available = data is not None
        self._data = dict(data or {})

    @property
    def available(self) -> bool:
        return self._available

    @property
    def order_book_id(self) -> str:
        return self._order_book_id

    @property
    def datetime(self) -> dt.datetime:
        value = self._data.get("datetime")
        return value if isinstance(value, dt.datetime) else dt.datetime.min

    @property
    def open(self) -> Any:
        return self._float("open")

    @property
    def high(self) -> Any:
        return self._float("high")

    @property
    def low(self) -> Any:
        return self._float("low")

    @property
    def last(self) -> Any:
        return self._float("last")

    @property
    def limit_up(self) -> Any:
        return self._float("limit_up")

    @property
    def limit_down(self) -> Any:
        return self._float("limit_down")

    @property
    def prev_close(self) -> Any:
        return self._float("prev_close")

    @property
    def iopv(self) -> Any:
        return self._float("iopv")

    @property
    def prev_iopv(self) -> Any:
        return self._float("prev_iopv")

    @property
    def close(self) -> Any:
        return self._float("close")

    @property
    def settlement(self) -> Any:
        return self._float("settlement")

    @property
    def volume(self) -> Any:
        return self._data.get("volume", 0)

    @property
    def total_turnover(self) -> Any:
        return self._data.get("total_turnover", 0)

    @property
    def num_trades(self) -> Any:
        return self._data.get("num_trades", 0)

    @property
    def open_interest(self) -> Any:
        return self._data.get("open_interest")

    @property
    def prev_settlement(self) -> Any:
        return self._data.get("prev_settlement")

    @property
    def trading_phase_code(self) -> Any:
        return self._data.get("trading_phase_code")

    @property
    def asks(self) -> list[Any]:
        return self._levels("a")

    @property
    def ask_vols(self) -> list[Any]:
        return self._levels("a", volume=True)

    @property
    def bids(self) -> list[Any]:
        return self._levels("b")

    @property
    def bid_vols(self) -> list[Any]:
        return self._levels("b", volume=True)

    def __getitem__(self, key: str) -> Any:
        return getattr(self, key)

    def __repr__(self) -> str:
        values = self.to_dict()
        return "Tick({})".format(
            ", ".join(f"{name}: {value}" for name, value in values.items())
        )

    def to_dict(self) -> dict[str, Any]:
        """Return a detached, stable representation of the public snapshot."""

        return {
            "available": self.available,
            "order_book_id": self.order_book_id,
            "datetime": self.datetime,
            **{name: getattr(self, name) for name in _FLOAT_FIELDS},
            **{name: getattr(self, name) for name in _COUNT_FIELDS},
            **{name: getattr(self, name) for name in _OPTIONAL_FIELDS},
            "asks": self.asks,
            "ask_vols": self.ask_vols,
            "bids": self.bids,
            "bid_vols": self.bid_vols,
        }

    def _float(self, name: str) -> Any:
        return self._data.get(name, math.nan)

    def _levels(self, side: str, *, volume: bool = False) -> list[Any]:
        suffix = "_v" if volume else ""
        if not self.available:
            return [0, 0, 0, 0, 0]
        return [self._data.get(f"{side}{level}{suffix}", math.nan) for level in range(1, 6)]
