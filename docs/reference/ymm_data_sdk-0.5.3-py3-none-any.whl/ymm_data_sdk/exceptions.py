from __future__ import annotations


class YMMDataSDKError(Exception):
    """Base exception for ymm_data_sdk."""


class YMMDataSDKNotInitializedError(YMMDataSDKError):
    """Raised when a local/proxy call needs a session before init()."""


class YMMDataSDKAuthError(YMMDataSDKError):
    """Raised when token validation fails."""


class YMMDataSDKRemoteError(YMMDataSDKError):
    """Raised when the server-side rqdatac proxy reports an error."""

    def __init__(self, error_type: str, message: str, traceback: str | None = None) -> None:
        self.error_type = error_type
        self.traceback = traceback
        super().__init__(f"{error_type}: {message}")
