from __future__ import annotations

import datetime as dt
from dataclasses import replace
import sys
import time
from typing import Any, Sequence

from .config import clear_session, get_session, normalize_server_mode, set_session
from .dispatch import dispatch
from .instrument import Instrument
from .remote_proxy import create_session, warmup_proxy


__version__ = "0.5.3"
__updated_at__ = "2026-07-20 15:56:40 (Asia/Shanghai)"


print(
    "欢迎使用优美利数据库，如遇BUG或问题，以及其他需求，请在企业微信群中反映。\n"
    f"版本：{__version__}\n"
    f"最新更新时间：{__updated_at__}",
    file=sys.stderr,
)


__all__ = [
    "__updated_at__",
    "__version__",
    "all_instruments",
    "clear_session",
    "close",
    "current_capital_flow_minute",
    "current_stock_connect_quota",
    "current_minute",
    "current_performance",
    "current_snapshot",
    "get_ex_factor",
    "get_factor",
    "get_all_factor_names",
    "get_auction_info",
    "get_concept",
    "get_concept_list",
    "get_dividend",
    "get_dividend_amount",
    "get_dividend_info",
    "get_night_trading_dates",
    "get_next_trading_date",
    "get_open_auction_info",
    "get_previous_trading_date",
    "get_price",
    "get_price_change_rate",
    "get_split",
    "get_ticks",
    "get_live_ticks",
    "get_main_shareholder",
    "get_latest_trading_date",
    "get_live_minute_price_change_rate",
    "get_future_latest_trading_date",
    "get_industry",
    "get_industry_change",
    "get_industry_mapping",
    "get_instrument_industry",
    "get_pit_financials_ex",
    "get_session",
    "get_share_transformation",
    "get_shares",
    "get_private_placement",
    "get_allotment",
    "get_block_trade",
    "get_symbol_change_info",
    "get_special_treatment_info",
    "current_freefloat_turnover",
    "get_holder_number",
    "get_abnormal_stocks",
    "get_abnormal_stocks_detail",
    "get_buy_back",
    "get_announcement",
    "get_audit_opinion",
    "get_capital_flow",
    "get_eligible_securities_margin",
    "get_margin_haircut",
    "get_margin_stocks",
    "get_incentive_plan",
    "get_investor_qa",
    "get_investor_ra",
    "get_forecast_report_date",
    "get_leader_shares_change",
    "get_restricted_shares",
    "get_securities_margin",
    "get_stock_connect",
    "get_stock_connect_quota",
    "get_staff_count",
    "get_trading_dates",
    "get_turnover_rate",
    "get_vwap",
    "get_yield_curve",
    "id_convert",
    "industry",
    "index_indicator",
    "index_components",
    "index_weights",
    "index_weights_ex",
    "init",
    "instruments",
    "Instrument",
    "is_st_stock",
    "is_suspended",
    "is_data_ready",
    "performance_forecast",
    "sector",
    "warmup",
    "convertible",
    "futures",
    "options",
    "etf",
]


def init(
    token: str | None = None,
    mode: str | None = None,
    server_url: str | None = None,
    warmup: bool = True,
    local_pool_size: int = 2,
) -> None:
    """Initialize the SDK session from a server-issued token."""
    import os

    token = token or os.environ.get("YMM_DATA_SDK_TOKEN")
    if (
        server_url is None
        and isinstance(mode, str)
        and mode.strip().lower().startswith(("http://", "https://"))
    ):
        server_url, mode = mode, None
    if not token and normalize_server_mode(mode) != "local":
        raise ValueError(
            "token is required except when mode='local'; "
            "pass token=... or set YMM_DATA_SDK_TOKEN"
        )
    token = token or ""
    if not 1 <= local_pool_size <= 4:
        raise ValueError("local_pool_size must be between 1 and 4")
    session = replace(
        create_session(token=token, server_url=server_url, mode=mode),
        local_pool_size=local_pool_size,
    )
    set_session(session)
    if warmup:
        try:
            _warmup(local=True, proxy=False)
        except Exception:
            clear_session()
            raise


def warmup(local: bool = True, proxy: bool = False) -> dict[str, Any]:
    return _warmup(local=local, proxy=proxy)


def _warmup(*, local: bool, proxy: bool) -> dict[str, Any]:
    if not local and not proxy:
        raise ValueError("at least one of local or proxy must be true")
    session = get_session()
    started = time.perf_counter()
    report: dict[str, Any] = {}
    if local:
        from . import local_backend

        report["local"] = local_backend.warmup(session=session)
    if proxy:
        report["proxy"] = warmup_proxy(session)
    report["total_seconds"] = round(time.perf_counter() - started, 6)
    return report


def close() -> None:
    clear_session()


def all_instruments(
    type: str | Sequence[str] | None = None,
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
    **kwargs: Any,
) -> Any:
    return dispatch("all_instruments", type=type, date=date, market=market, **kwargs)


def get_ex_factor(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_ex_factor",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def get_pit_financials_ex(
    order_book_ids: str | Sequence[str],
    fields: Sequence[str],
    start_quarter: str,
    end_quarter: str,
    date: str | int | dt.date | dt.datetime | None = None,
    statements: str = "latest",
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_pit_financials_ex",
        order_book_ids,
        fields,
        start_quarter,
        end_quarter,
        date=date,
        statements=statements,
        market=market,
    )


def current_performance(
    order_book_ids: str | Sequence[str],
    info_date: str | int | dt.date | dt.datetime | None = None,
    quarter: str | None = None,
    interval: str = "1q",
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "current_performance",
        order_book_ids,
        info_date=info_date,
        quarter=quarter,
        interval=interval,
        fields=fields,
        market=market,
    )


def performance_forecast(
    order_book_ids: str | Sequence[str],
    info_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "performance_forecast",
        order_book_ids,
        info_date=info_date,
        end_date=end_date,
        fields=fields,
        market=market,
    )


def get_share_transformation(
    predecessor: str | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_share_transformation",
        predecessor=predecessor,
        market=market,
    )


def sector(code: str, market: str = "cn") -> Any:
    return dispatch("sector", code, market=market)


def industry(code: str, market: str = "cn") -> Any:
    return dispatch("industry", code, market=market)


def get_concept_list(
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_concept_list",
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def get_concept(
    concepts: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_concept",
        concepts,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def get_industry_mapping(
    source: str = "citics_2019",
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_industry_mapping",
        source=source,
        date=date,
        market=market,
    )


def get_industry(
    industry: str,
    source: str = "citics_2019",
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_industry",
        industry,
        source=source,
        date=date,
        market=market,
    )


def get_industry_change(
    industry: str,
    source: str = "citics_2019",
    level: int | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_industry_change",
        industry,
        source=source,
        level=level,
        market=market,
    )


def get_instrument_industry(
    order_book_ids: str | Sequence[str],
    source: str = "citics_2019",
    level: int | str = 1,
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_instrument_industry",
        order_book_ids,
        source=source,
        level=level,
        date=date,
        market=market,
    )


def get_shares(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    expect_df: bool = True,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_shares",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
        expect_df=expect_df,
        market=market,
    )


def get_main_shareholder(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    is_total: bool = False,
    start_rank: int | None = None,
    end_rank: int | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_main_shareholder",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        is_total=is_total,
        start_rank=start_rank,
        end_rank=end_rank,
        market=market,
    )


def get_private_placement(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    progress: str = "complete",
    issue_type: str = "private",
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_private_placement",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        progress=progress,
        issue_type=issue_type,
        market=market,
    )


def get_allotment(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_allotment",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
        market=market,
    )


def get_block_trade(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_block_trade",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def get_symbol_change_info(
    order_book_ids: str | Sequence[str],
    market: str = "cn",
) -> Any:
    return dispatch("get_symbol_change_info", order_book_ids, market=market)


def get_special_treatment_info(
    order_book_ids: str | Sequence[str],
    market: str = "cn",
) -> Any:
    return dispatch("get_special_treatment_info", order_book_ids, market=market)


def current_freefloat_turnover(order_book_ids: str | Sequence[str]) -> Any:
    raise NotImplementedError("ymm_data_sdk does not support current_freefloat_turnover")


def get_holder_number(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_holder_number",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def get_abnormal_stocks(
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    types: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_abnormal_stocks",
        start_date=start_date,
        end_date=end_date,
        types=types,
        market=market,
    )


def get_abnormal_stocks_detail(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    sides: str | Sequence[str] | None = None,
    types: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_abnormal_stocks_detail",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        sides=sides,
        types=types,
        market=market,
    )


def get_buy_back(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_buy_back",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
        market=market,
    )


def get_capital_flow(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    frequency: str = "1d",
    market: str = "cn",
) -> Any:
    raise NotImplementedError("ymm_data_sdk does not support get_capital_flow")


def current_capital_flow_minute(
    order_book_ids: str | Sequence[str],
    market: str = "cn",
) -> Any:
    raise NotImplementedError("ymm_data_sdk does not support current_capital_flow_minute")


def get_securities_margin(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    expect_df: bool = True,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_securities_margin",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
        expect_df=expect_df,
        market=market,
    )


def get_margin_stocks(
    date: str | int | dt.date | dt.datetime | None = None,
    exchange: str | None = None,
    margin_type: str = "stock",
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_margin_stocks",
        date=date,
        exchange=exchange,
        margin_type=margin_type,
        market=market,
    )


def get_eligible_securities_margin(
    date: str | int | dt.date | dt.datetime | None = None,
    exchange: str | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_eligible_securities_margin",
        date=date,
        exchange=exchange,
        market=market,
    )


def get_margin_haircut(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_margin_haircut",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def get_stock_connect(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    expect_df: bool = True,
) -> Any:
    return dispatch(
        "get_stock_connect",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
        expect_df=expect_df,
    )


def current_stock_connect_quota(
    connect: str | Sequence[str] | None = None,
    fields: str | Sequence[str] | None = None,
) -> Any:
    return dispatch("current_stock_connect_quota", connect=connect, fields=fields)


def get_stock_connect_quota(
    connect: str | Sequence[str] | None = None,
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
) -> Any:
    return dispatch(
        "get_stock_connect_quota",
        connect=connect,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
    )


def get_incentive_plan(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch("get_incentive_plan", order_book_ids, start_date=start_date, end_date=end_date, market=market)


def get_investor_ra(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch("get_investor_ra", order_book_ids, start_date=start_date, end_date=end_date, market=market)


def get_announcement(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_announcement",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
        market=market,
    )


def get_audit_opinion(
    order_book_ids: str | Sequence[str],
    start_quarter: str,
    end_quarter: str,
    date: str | int | dt.date | dt.datetime | None = None,
    type: str | None = None,
    opinion_types: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_audit_opinion",
        order_book_ids,
        start_quarter,
        end_quarter,
        date=date,
        type=type,
        opinion_types=opinion_types,
        market=market,
    )


def get_restricted_shares(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch("get_restricted_shares", order_book_ids, start_date=start_date, end_date=end_date, market=market)


def get_staff_count(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch("get_staff_count", order_book_ids, start_date=start_date, end_date=end_date, market=market)


def get_leader_shares_change(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_leader_shares_change",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def get_forecast_report_date(
    order_book_ids: str | Sequence[str],
    start_quarter: str,
    end_quarter: str,
    market: str = "cn",
) -> Any:
    return dispatch("get_forecast_report_date", order_book_ids, start_quarter, end_quarter, market=market)


def get_investor_qa(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch("get_investor_qa", order_book_ids, start_date=start_date, end_date=end_date, market=market)


def get_turnover_rate(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    expect_df: bool = True,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_turnover_rate",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
        expect_df=expect_df,
        market=market,
    )


def get_dividend_info(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_dividend_info",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def get_dividend(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    adjusted: bool = False,
    expect_df: bool = True,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_dividend",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        adjusted=adjusted,
        expect_df=expect_df,
        market=market,
    )


def get_dividend_amount(
    order_book_ids: str | Sequence[str],
    start_quarter: str | None = None,
    end_quarter: str | None = None,
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_dividend_amount",
        order_book_ids,
        start_quarter=start_quarter,
        end_quarter=end_quarter,
        date=date,
        market=market,
    )


def get_factor(
    order_book_ids: str | Sequence[str],
    factor: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    universe: str | None = None,
    expect_df: bool = True,
    market: str = "cn",
    **kwargs: Any,
) -> Any:
    raise NotImplementedError("ymm_data_sdk does not support get_factor")


def get_all_factor_names(
    type: str | None = None,
    market: str = "cn",
) -> Any:
    raise NotImplementedError("ymm_data_sdk does not support get_all_factor_names")


def get_price(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    frequency: str = "1d",
    fields: str | Sequence[str] | None = None,
    adjust_type: str = "pre",
    skip_suspended: bool = False,
    expect_df: bool = True,
    time_slice: tuple[str | dt.time, str | dt.time] | None = None,
    market: str = "cn",
    **kwargs: Any,
) -> Any:
    return dispatch(
        "get_price",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        frequency=frequency,
        fields=fields,
        adjust_type=adjust_type,
        skip_suspended=skip_suspended,
        expect_df=expect_df,
        time_slice=time_slice,
        market=market,
        **kwargs,
    )


def id_convert(
    order_book_ids: str | Sequence[str],
    to: str | None = None,
) -> Any:
    return dispatch("id_convert", order_book_ids, to=to)


def get_auction_info(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    frequency: str = "1d",
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_auction_info",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        frequency=frequency,
        fields=fields,
        market=market,
    )


def get_open_auction_info(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_open_auction_info",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
        market=market,
    )


def current_minute(
    order_book_ids: str | Sequence[str],
    skip_suspended: bool = False,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    raise NotImplementedError("ymm_data_sdk does not support current_minute")


def get_price_change_rate(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    expect_df: bool = True,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_price_change_rate",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        expect_df=expect_df,
        market=market,
    )


def current_snapshot(
    order_book_ids: str | Sequence[str],
    market: str = "cn",
) -> Any:
    raise NotImplementedError("ymm_data_sdk does not support current_snapshot")


def get_ticks(
    order_book_id: str,
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    expect_df: bool = True,
    market: str = "cn",
) -> Any:
    raise NotImplementedError("ymm_data_sdk does not support get_ticks; use get_price(..., frequency='tick') for local historical ticks")


def get_live_ticks(
    order_book_ids: str | Sequence[str],
    start_dt: str | int | dt.date | dt.datetime | None = None,
    end_dt: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    raise NotImplementedError("ymm_data_sdk does not support get_live_ticks")


def get_split(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_split",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def instruments(
    order_book_ids: str | Sequence[str],
    market: str = "cn",
) -> Any:
    return dispatch("instruments", order_book_ids, market=market)


def get_night_trading_dates(
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_night_trading_dates",
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def get_previous_trading_date(
    date: str | int | dt.date | dt.datetime,
    n: int = 1,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_previous_trading_date",
        date,
        n=n,
        market=market,
    )


def get_next_trading_date(
    date: str | int | dt.date | dt.datetime,
    n: int = 1,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_next_trading_date",
        date,
        n=n,
        market=market,
    )


def get_trading_dates(
    start_date: str | int | dt.date | dt.datetime,
    end_date: str | int | dt.date | dt.datetime,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_trading_dates",
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def get_trading_periods(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    frequency: str = "1m",
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_trading_periods",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        frequency=frequency,
        market=market,
    )


def get_latest_trading_date(market: str = "cn") -> Any:
    raise NotImplementedError("ymm_data_sdk does not support get_latest_trading_date")


def get_yield_curve(
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    tenor: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "get_yield_curve",
        start_date=start_date,
        end_date=end_date,
        tenor=tenor,
        market=market,
    )


def get_live_minute_price_change_rate(order_book_ids: str | Sequence[str]) -> Any:
    raise NotImplementedError("ymm_data_sdk does not support get_live_minute_price_change_rate")


def get_future_latest_trading_date(market: str = "cn") -> Any:
    raise NotImplementedError("ymm_data_sdk does not support get_future_latest_trading_date")


def get_vwap(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    frequency: str = "1d",
) -> Any:
    return dispatch(
        "get_vwap",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        frequency=frequency,
    )


def is_data_ready(
    categories: str | Sequence[str] | None = None,
    expected_date: str | int | dt.date | dt.datetime | None = None,
    market: str | Sequence[str] | None = None,
) -> Any:
    raise NotImplementedError("ymm_data_sdk does not support is_data_ready")


def is_suspended(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "is_suspended",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def is_st_stock(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "is_st_stock",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def index_indicator(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "index_indicator",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
        market=market,
    )


def index_components(
    order_book_id: str,
    date: str | int | dt.date | dt.datetime | None = None,
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    return_create_tm: bool = False,
    market: str = "cn",
) -> Any:
    return dispatch(
        "index_components",
        order_book_id,
        date=date,
        start_date=start_date,
        end_date=end_date,
        return_create_tm=return_create_tm,
        market=market,
    )


def index_weights(
    order_book_id: str,
    date: str | int | dt.date | dt.datetime | None = None,
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "index_weights",
        order_book_id,
        date=date,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def index_weights_ex(
    order_book_id: str,
    date: str | int | dt.date | dt.datetime | None = None,
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "index_weights_ex",
        order_book_id,
        date=date,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


from . import convertible  # noqa: E402  - imported last to expose ymm_data_sdk.convertible
from . import etf  # noqa: E402  - imported last to expose ymm_data_sdk.etf
from . import futures  # noqa: E402  - imported last to expose ymm_data_sdk.futures
from . import options  # noqa: E402  - imported last to expose ymm_data_sdk.options
