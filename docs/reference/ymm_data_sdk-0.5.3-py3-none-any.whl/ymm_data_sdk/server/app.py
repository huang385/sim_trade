from __future__ import annotations

import os
import time
import traceback as traceback_lib
import warnings
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Header, HTTPException, Request, Response
from pydantic import BaseModel
from starlette.concurrency import run_in_threadpool
from ymm_data_sdk import __version__

from ymm_data_sdk.serializers import (
    MAX_PROXY_REQUEST_BYTES,
    PICKLE_ZSTD_MEDIA_TYPE,
    PROXY_ENVELOPE_KEY,
    PROXY_PROTOCOL_VERSION,
    dumps_object,
    loads_object,
)
from ymm_data_sdk.registry import PROXY_METHODS

from .rqdatac_proxy import call_rqdatac, warmup_rqdatac
from .source_auth import SourceAuthorizationError, SourceAuthorizer
from .token_store import TokenRecord, TokenStore, session_payload


@asynccontextmanager
async def _service_lifespan(_: FastAPI) -> AsyncIterator[None]:
    try:
        token_store.reload()
    except Exception as exc:
        raise RuntimeError(
            f"Token snapshot load failed ({type(exc).__name__}); proxy service startup aborted"
        ) from exc
    try:
        await run_in_threadpool(warmup_rqdatac)
    except Exception as exc:
        raise RuntimeError(
            f"RQData warmup failed ({type(exc).__name__}); proxy service startup aborted"
        ) from exc
    yield


app = FastAPI(title="ymm_data_sdk rqdatac proxy", version=__version__, lifespan=_service_lifespan)
token_store = TokenStore()
source_authorizer = SourceAuthorizer()


class SessionRequest(BaseModel):
    token: str | None = None


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "version": __version__}


@app.post("/auth/session")
def auth_session(request: SessionRequest, http_request: Request) -> dict[str, Any]:
    record = _authorized_record(request.token, http_request)
    proxy_base = os.environ.get("YMM_DATA_SDK_PUBLIC_BASE_URL", "").rstrip("/")
    proxy_endpoint = (
        f"{proxy_base}/rqdatac/call"
        if proxy_base
        else str(http_request.url_for("rqdatac_call"))
    )
    return session_payload(record, proxy_endpoint=proxy_endpoint)


@app.post("/auth/warmup")
async def auth_warmup(
    request: SessionRequest,
    http_request: Request,
) -> dict[str, Any]:
    record = _authorized_record(request.token, http_request)
    started = time.perf_counter()
    await run_in_threadpool(warmup_rqdatac)
    return {
        "user": record.user,
        "rqdatac": "ok",
        "server_rqdatac_warmup_seconds": round(time.perf_counter() - started, 6),
    }


@app.post("/rqdatac/call")
async def rqdatac_call(
    request: Request,
    authorization: str | None = Header(default=None),
) -> Response:
    token = _bearer_token(authorization)
    _authorized_record(token, request)
    content_length = request.headers.get("content-length")
    if content_length:
        try:
            declared_length = int(content_length)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="invalid Content-Length header") from exc
        if declared_length > MAX_PROXY_REQUEST_BYTES:
            raise HTTPException(status_code=413, detail="proxy request body exceeds 16 MiB")
    content_type = request.headers.get("content-type", "").split(";", 1)[0].lower()
    if content_type != PICKLE_ZSTD_MEDIA_TYPE:
        raise HTTPException(
            status_code=415,
            detail=f"Content-Type must be {PICKLE_ZSTD_MEDIA_TYPE}",
        )
    body = await request.body()
    if len(body) > MAX_PROXY_REQUEST_BYTES:
        raise HTTPException(status_code=413, detail="proxy request body exceeds 16 MiB")

    try:
        payload = loads_object(body)
        method, args, kwargs = _validate_proxy_payload(payload)
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001 - malformed client request.
        raise HTTPException(status_code=400, detail=f"invalid proxy request: {exc}") from exc

    if method not in PROXY_METHODS:
        raise HTTPException(status_code=403, detail=f"method is not allowed: {method}")

    try:
        rqdatac_started = time.perf_counter()
        result, warning_records = await run_in_threadpool(
            _call_with_warnings,
            method,
            args,
            kwargs,
        )
        rqdatac_elapsed = time.perf_counter() - rqdatac_started
    except Exception as exc:  # noqa: BLE001 - proxy should return structured remote errors.
        payload = {
            "ok": False,
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            "error_args": [_safe_error_arg(value) for value in exc.args],
            "traceback": traceback_lib.format_exc(),
        }
        raise HTTPException(status_code=500, detail=payload) from exc
    response_payload = {
        PROXY_ENVELOPE_KEY: PROXY_PROTOCOL_VERSION,
        "result": result,
        "warnings": warning_records,
        "server_rqdatac_elapsed_seconds": rqdatac_elapsed,
    }
    return Response(content=dumps_object(response_payload), media_type=PICKLE_ZSTD_MEDIA_TYPE)


def _authorized_record(token: str | None, request: Request) -> TokenRecord:
    try:
        record = (
            token_store.require(token.strip())
            if token and token.strip()
            else token_store.require_local()
        )
    except KeyError as exc:
        detail = "invalid token" if token and token.strip() else "local SDK identity is not configured"
        raise HTTPException(status_code=401, detail=detail) from exc
    try:
        source_authorizer.authorize(
            record,
            None if request.client is None else request.client.host,
        )
    except SourceAuthorizationError as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.detail) from exc
    return record


def _validate_proxy_payload(
    payload: Any,
) -> tuple[str, tuple[Any, ...], dict[str, Any]]:
    if not isinstance(payload, dict):
        raise ValueError("payload must be a mapping")
    if payload.get("version") != PROXY_PROTOCOL_VERSION:
        raise ValueError(f"unsupported proxy protocol version: {payload.get('version')!r}")
    method = payload.get("method")
    args = payload.get("args", ())
    kwargs = payload.get("kwargs", {})
    if not isinstance(method, str) or not method:
        raise ValueError("method must be a non-empty string")
    if not isinstance(args, (list, tuple)):
        raise ValueError("args must be a list or tuple")
    if not isinstance(kwargs, dict):
        raise ValueError("kwargs must be a mapping")
    return method, tuple(args), kwargs


def _call_with_warnings(
    method: str,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> tuple[Any, list[dict[str, str]]]:
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        result = call_rqdatac(method, args, kwargs)
    records = [
        {
            "category": item.category.__name__,
            "category_module": item.category.__module__,
            "message": str(item.message),
        }
        for item in caught
    ]
    return result, records


def _safe_error_arg(value: Any) -> Any:
    return value if value is None or isinstance(value, (bool, int, float, str)) else repr(value)


def _bearer_token(value: str | None) -> str | None:
    if value is None:
        return None
    if not value.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="invalid authorization scheme")
    return value.split(" ", 1)[1].strip() or None
