from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import pickle
import queue
import threading
import time
from typing import Any, Callable, Iterable

from .protocol import FeedFrameMetadata


CANARY_INTERVAL_SECONDS = 15
CANARY_DEFAULT_DURATION_SECONDS = 600
CANARY_MAX_DURATION_SECONDS = 1800
CANARY_QUEUE_CAPACITY = 65_536
CANARY_CLOCK_PROBE_SECONDS = 30.0
CANARY_CLOCK_WARNING_MS = 1.0
CANARY_CLOCK_INVALID_MS = 5.0


@dataclass(frozen=True, slots=True)
class CanaryFrameTiming:
    lane: str
    messages: tuple[dict[str, Any], ...]
    message_count: int
    socket_received_monotonic: float
    socket_received_wall_ns: int
    decode_started_monotonic: float
    decoded_monotonic: float
    handler_started_monotonic: float
    handler_started_wall_ns: int
    metadata: FeedFrameMetadata


@dataclass(frozen=True, slots=True)
class CanaryHandlerTiming:
    kinds: tuple[tuple[str, str, int], ...]
    elapsed_ms: float
    observed_wall_ns: int = 0


@dataclass(frozen=True, slots=True)
class _ClockSample:
    offset_ns: float
    uncertainty_ns: float
    observed_monotonic: float


class _WeightedValues:
    __slots__ = ("count", "maximum", "total", "values")

    def __init__(self) -> None:
        self.values: list[tuple[float, int]] = []
        self.count = 0
        self.total = 0.0
        self.maximum: float | None = None

    def add(self, value: float, count: int) -> None:
        count = int(count)
        if count <= 0:
            return
        value = max(0.0, float(value))
        self.values.append((value, count))
        self.count += count
        self.total += value * count
        self.maximum = value if self.maximum is None else max(self.maximum, value)

    def payload(self) -> dict[str, float | int | None]:
        ordered = sorted(self.values, key=lambda item: item[0])
        bins: dict[int, int] = defaultdict(int)
        for value, count in self.values:
            bins[_histogram_bin(value)] += count
        return {
            "count": self.count,
            "sum_ms": self.total,
            "mean_ms": None if not self.count else self.total / self.count,
            "p50_ms": _weighted_percentile(ordered, self.count, 50),
            "p95_ms": _weighted_percentile(ordered, self.count, 95),
            "p99_ms": _weighted_percentile(ordered, self.count, 99),
            "max_ms": self.maximum,
            "histogram": {"bins": [[key, bins[key]] for key in sorted(bins)]},
        }


def _weighted_percentile(
    ordered: list[tuple[float, int]], total: int, percentile: int
) -> float | None:
    if total <= 0:
        return None
    rank = max(1, math.ceil(total * percentile / 100.0))
    cumulative = 0
    for value, count in ordered:
        cumulative += count
        if cumulative >= rank:
            return value
    return ordered[-1][0] if ordered else None


def _histogram_bin(value_ms: float) -> int:
    value = max(0.0, float(value_ms))
    if value < 10.0:
        return min(19, int(value * 2.0))
    if value < 100.0:
        return 20 + min(17, int((value - 10.0) / 5.0))
    if value < 1000.0:
        return 38 + min(17, int((value - 100.0) / 50.0))
    return 56 + min(7, int((value - 1000.0) / 500.0))


def histogram_bin_value_ms(index: int) -> float:
    value = max(0, min(63, int(index)))
    if value < 20:
        return value / 2.0
    if value < 38:
        return 10.0 + (value - 20) * 5.0
    if value < 56:
        return 100.0 + (value - 38) * 50.0
    return 1000.0 + (value - 56) * 500.0


class CanaryHandle:
    """Bounded, opt-in local WSS delivery diagnostic."""

    def __init__(
        self,
        *,
        duration_seconds: int = CANARY_DEFAULT_DURATION_SECONDS,
        interval_seconds: int = CANARY_INTERVAL_SECONDS,
        output: str | None = "console",
        time_probe: Callable[[int, int], dict[str, Any] | None] | None = None,
        on_finished: Callable[[CanaryHandle], None] | None = None,
        on_window_closed: Callable[[dict[str, Any]], None] | None = None,
        _unbounded: bool = False,
        _max_duration_seconds: int = CANARY_MAX_DURATION_SECONDS,
    ) -> None:
        duration = int(duration_seconds)
        if not _unbounded and not 1 <= duration <= int(_max_duration_seconds):
            raise ValueError(
                f"Canary duration must be 1-{int(_max_duration_seconds)} seconds"
            )
        if _unbounded and duration != 0:
            raise ValueError("persistent Canary duration must be zero")
        if int(interval_seconds) != CANARY_INTERVAL_SECONDS:
            raise ValueError("Canary interval_seconds must be 15")
        if output not in {None, "console"}:
            raise ValueError("Canary output must be 'console' or None")
        self.duration_seconds = duration
        self.interval_seconds = CANARY_INTERVAL_SECONDS
        self.output = output
        self._time_probe = time_probe
        self._on_finished = on_finished
        self._on_window_closed = on_window_closed
        self._queue: queue.Queue[CanaryFrameTiming | CanaryHandlerTiming] = queue.Queue(
            maxsize=CANARY_QUEUE_CAPACITY
        )
        self._stop = threading.Event()
        self._finished = threading.Event()
        self._lock = threading.Lock()
        self._started_wall_ns = time.time_ns()
        self._started_monotonic = time.monotonic()
        self._deadline = (
            float("inf") if _unbounded else self._started_monotonic + duration
        )
        self._active_start = _window_start(self._started_wall_ns)
        self._first_window = True
        self._active: dict[tuple[str, str, str], _WeightedValues] = {}
        self._fingerprints: dict[tuple[str, str], list[int]] = {}
        self._windows: deque[dict[str, Any]] = deque(maxlen=128)
        self._dropped_observations = 0
        self._clock_samples: deque[_ClockSample] = deque(maxlen=10)
        self._clock_state = "calibrating" if time_probe is not None else "unavailable"
        self._clock_error: str | None = None
        self._next_clock_probe = self._started_monotonic
        self._initial_clock_probes = 5
        self._thread = threading.Thread(
            target=self._run,
            name="ymm-live-data-canary",
            daemon=True,
        )
        self._thread.start()

    @property
    def active(self) -> bool:
        return not self._finished.is_set()

    def observe_frame(self, value: CanaryFrameTiming) -> None:
        if self._finished.is_set() or self._stop.is_set():
            return
        try:
            self._queue.put_nowait(value)
        except queue.Full:
            with self._lock:
                self._dropped_observations += max(1, int(value.message_count))

    def observe_handler(self, value: CanaryHandlerTiming) -> None:
        if self._finished.is_set() or self._stop.is_set():
            return
        try:
            self._queue.put_nowait(value)
        except queue.Full:
            with self._lock:
                self._dropped_observations += sum(
                    count for _kind, _frequency, count in value.kinds
                )

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return self._report_locked(include_active=True)

    def stop(self) -> dict[str, Any]:
        self._stop.set()
        if threading.current_thread() is not self._thread:
            self._thread.join(timeout=2.0)
        return self.snapshot()

    def wait(self, timeout: float | None = None) -> dict[str, Any]:
        self._finished.wait(timeout)
        return self.snapshot()

    def write_json(self, path: str | Path) -> Path:
        target = Path(path)
        target.write_text(
            json.dumps(self.snapshot(), ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        return target

    def _run(self) -> None:
        try:
            while not self._stop.is_set() and time.monotonic() < self._deadline:
                now = time.monotonic()
                if self._time_probe is not None and now >= self._next_clock_probe:
                    probe_ok = self._probe_clock()
                    if probe_ok and self._initial_clock_probes > 0:
                        self._initial_clock_probes -= 1
                        self._next_clock_probe = time.monotonic() + 0.05
                    else:
                        self._initial_clock_probes = 0
                        self._next_clock_probe = (
                            time.monotonic() + CANARY_CLOCK_PROBE_SECONDS
                        )
                timeout = min(0.1, max(0.0, self._deadline - time.monotonic()))
                try:
                    value = self._queue.get(timeout=timeout)
                except queue.Empty:
                    value = None
                if value is not None:
                    try:
                        if isinstance(value, CanaryFrameTiming):
                            self._record_frame(value)
                        else:
                            self._record_handler(value)
                    finally:
                        self._queue.task_done()
                self._rotate_if_needed(time.time_ns())
            while True:
                try:
                    value = self._queue.get_nowait()
                except queue.Empty:
                    break
                try:
                    if isinstance(value, CanaryFrameTiming):
                        self._record_frame(value)
                    else:
                        self._record_handler(value)
                finally:
                    self._queue.task_done()
            self._close_active(time.time_ns(), formal=False)
        finally:
            self._finished.set()
            if self._on_finished is not None:
                self._on_finished(self)

    def _probe_clock(self) -> bool:
        assert self._time_probe is not None
        client_sent_wall_ns = time.time_ns()
        client_sent_monotonic_ns = time.monotonic_ns()
        try:
            result = self._time_probe(
                client_sent_wall_ns,
                client_sent_monotonic_ns,
            )
            client_received_monotonic_ns = time.monotonic_ns()
            client_received_wall_ns = time.time_ns()
            if not isinstance(result, dict):
                raise RuntimeError("time_probe is unavailable")
            server_received_wall_ns = int(result["server_received_wall_ns"])
            server_sent_wall_ns = int(result["server_sent_wall_ns"])
            elapsed_ns = max(
                0,
                client_received_monotonic_ns - client_sent_monotonic_ns,
            )
            server_elapsed_ns = max(
                0,
                int(result["server_sent_monotonic_ns"])
                - int(result["server_received_monotonic_ns"]),
            )
            network_rtt_ns = max(0, elapsed_ns - server_elapsed_ns)
            offset_ns = (
                (server_received_wall_ns - client_sent_wall_ns)
                + (server_sent_wall_ns - client_received_wall_ns)
            ) / 2.0
            self._clock_samples.append(
                _ClockSample(
                    offset_ns,
                    network_rtt_ns / 2.0,
                    time.monotonic(),
                )
            )
            self._clock_error = None
            self._refresh_clock_state()
            return True
        except Exception as exc:  # noqa: BLE001 - diagnostic is fail-open.
            self._clock_error = f"{type(exc).__name__}: {exc}"
            if not self._clock_samples:
                self._clock_state = "unavailable"
            return False

    def _refresh_clock_state(self) -> None:
        sample = self._best_clock_sample()
        if sample is None:
            self._clock_state = "unavailable"
            return
        uncertainty_ms = sample.uncertainty_ns / 1_000_000.0
        if uncertainty_ms <= CANARY_CLOCK_WARNING_MS:
            self._clock_state = "trusted"
        elif uncertainty_ms <= CANARY_CLOCK_INVALID_MS:
            self._clock_state = "warning"
        else:
            self._clock_state = "invalid"

    def _best_clock_sample(self) -> _ClockSample | None:
        if not self._clock_samples:
            return None
        recent = [
            value
            for value in self._clock_samples
            if time.monotonic() - value.observed_monotonic <= 90.0
        ]
        if not recent:
            return None
        return min(recent, key=lambda value: value.uncertainty_ns)

    def _record_frame(self, value: CanaryFrameTiming) -> None:
        clock = self._best_clock_sample()
        cross_machine = clock is not None and self._clock_state in {
            "trusted",
            "warning",
        }
        aligned_wall_ns = int(
            value.handler_started_wall_ns
            + (0 if clock is None else clock.offset_ns)
        )
        self._rotate_if_needed(aligned_wall_ns)
        parent_ns = int(value.metadata.parent_received_monotonic_ns)
        parent_wall_ns = int(value.metadata.parent_received_wall_ns)
        ready_ns = int(value.metadata.routed_monotonic_ns)
        internal_ms = (
            None
            if parent_ns <= 0 or ready_ns < parent_ns
            else (ready_ns - parent_ns) / 1_000_000.0
        )
        ready_to_socket_ms: float | None = None
        data_plane_to_handler_ms: float | None = None
        if cross_machine and parent_wall_ns > 0 and ready_ns >= parent_ns:
            ready_wall_ns = parent_wall_ns + (ready_ns - parent_ns)
            ready_to_socket_ms = max(
                0.0,
                (
                    value.socket_received_wall_ns
                    + clock.offset_ns
                    - ready_wall_ns
                )
                / 1_000_000.0,
            )
            data_plane_to_handler_ms = max(
                0.0,
                (
                    value.handler_started_wall_ns
                    + clock.offset_ns
                    - parent_wall_ns
                )
                / 1_000_000.0,
            )
        socket_to_decode_ms = max(
            0.0,
            (value.decoded_monotonic - value.socket_received_monotonic) * 1000.0,
        )
        decode_to_handler_ms = max(
            0.0,
            (value.handler_started_monotonic - value.decoded_monotonic) * 1000.0,
        )
        for kind, frequency, count in _kind_frequency_counts(value.messages):
            if internal_ms is not None:
                self._add(kind, frequency, "data_plane_to_wss_frame_ready_ms", internal_ms, count)
            if ready_to_socket_ms is not None:
                self._add(kind, frequency, "wss_frame_ready_to_socket_ms", ready_to_socket_ms, count)
            self._add(kind, frequency, "socket_to_decode_ms", socket_to_decode_ms, count)
            self._add(kind, frequency, "decode_to_handler_start_ms", decode_to_handler_ms, count)
            if data_plane_to_handler_ms is not None:
                self._add(kind, frequency, "data_plane_to_handler_start_ms", data_plane_to_handler_ms, count)
        for message in value.messages:
            kind, frequency = _message_kind_frequency(message)
            digest = int.from_bytes(
                hashlib.blake2b(
                    pickle.dumps(message, protocol=5), digest_size=8
                ).digest(),
                "big",
            )
            fingerprint = self._fingerprints.setdefault(
                (kind, frequency), [0, 0, 0]
            )
            fingerprint[0] += 1
            fingerprint[1] = (fingerprint[1] + digest) & 0xFFFFFFFFFFFFFFFF
            fingerprint[2] ^= digest

    def _record_handler(self, value: CanaryHandlerTiming) -> None:
        wall_ns = value.observed_wall_ns or time.time_ns()
        clock = self._best_clock_sample()
        self._rotate_if_needed(
            int(wall_ns + (0 if clock is None else clock.offset_ns))
        )
        for kind, frequency, count in value.kinds:
            self._add(
                kind,
                frequency,
                "handler_execution_ms",
                value.elapsed_ms,
                count,
            )

    def _add(
        self,
        kind: str,
        frequency: str,
        stage: str,
        value_ms: float,
        count: int,
    ) -> None:
        key = (str(kind), str(frequency), str(stage))
        self._active.setdefault(key, _WeightedValues()).add(value_ms, count)

    def _rotate_if_needed(self, wall_ns: int) -> None:
        start = _window_start(wall_ns)
        if start <= self._active_start:
            return
        self._close_active(wall_ns, formal=True)
        self._active_start = start

    def _close_active(self, wall_ns: int, *, formal: bool) -> None:
        with self._lock:
            if not self._active and self._windows and not formal:
                return
            resolved_formal = bool(formal and not self._first_window)
            payload = {
                "window_start_epoch_seconds": self._active_start,
                "window_end_epoch_seconds": self._active_start + self.interval_seconds,
                "formal": resolved_formal,
                "clock": self._clock_payload(),
                "dropped_observations_total": self._dropped_observations,
                "series": [
                    {
                        "kind": kind,
                        "frequency": frequency,
                        "stage": stage,
                        **values.payload(),
                        "fingerprint": _fingerprint_payload(
                            self._fingerprints.get((kind, frequency))
                        ),
                    }
                    for (kind, frequency, stage), values in sorted(
                        self._active.items()
                    )
                ],
            }
            self._windows.append(payload)
            self._active = {}
            self._fingerprints = {}
            self._first_window = False
        if self.output == "console":
            print(_format_window(payload), flush=True)
        if self._on_window_closed is not None and resolved_formal:
            self._on_window_closed(dict(payload))

    def _clock_payload(self) -> dict[str, Any]:
        sample = self._best_clock_sample()
        return {
            "state": "unavailable" if sample is None else self._clock_state,
            "offset_ms": (
                None if sample is None else sample.offset_ns / 1_000_000.0
            ),
            "uncertainty_ms": (
                None if sample is None else sample.uncertainty_ns / 1_000_000.0
            ),
            "error": self._clock_error,
        }

    def _report_locked(self, *, include_active: bool) -> dict[str, Any]:
        active = [
            {
                "kind": kind,
                "frequency": frequency,
                "stage": stage,
                **values.payload(),
            }
            for (kind, frequency, stage), values in sorted(self._active.items())
        ]
        return {
            "schema_version": 1,
            "active": self.active,
            "started_epoch_seconds": self._started_wall_ns / 1_000_000_000.0,
            "duration_seconds": self.duration_seconds,
            "interval_seconds": self.interval_seconds,
            "clock": self._clock_payload(),
            "queue_rows": self._queue.qsize(),
            "queue_capacity": CANARY_QUEUE_CAPACITY,
            "dropped_observations_total": self._dropped_observations,
            "windows": list(self._windows),
            "active_window": (
                None
                if not include_active
                else {
                    "window_start_epoch_seconds": self._active_start,
                    "formal": False,
                    "series": active,
                }
            ),
        }


def _window_start(wall_ns: int) -> int:
    seconds = int(wall_ns // 1_000_000_000)
    return seconds - seconds % CANARY_INTERVAL_SECONDS


def _kind_frequency_counts(
    messages: Iterable[dict[str, Any]],
) -> tuple[tuple[str, str, int], ...]:
    counts: dict[tuple[str, str], int] = defaultdict(int)
    for message in messages:
        key = _message_kind_frequency(message)
        counts[key] += 1
    return tuple((kind, frequency, count) for (kind, frequency), count in sorted(counts.items()))


def _message_kind_frequency(message: dict[str, Any]) -> tuple[str, str]:
    channel = str(message.get("channel") or "")
    if channel.startswith("tick_"):
        return "tick", "tick"
    if channel.endswith(("_5m", "_15m", "_30m", "_60m", "_120m", "_240m")):
        return "higher", channel.rsplit("_", 1)[-1]
    return "1m", "1m"


def _fingerprint_payload(value: list[int] | None) -> dict[str, int]:
    if value is None:
        return {"count": 0, "sum_uint64": 0, "xor_uint64": 0}
    return {
        "count": int(value[0]),
        "sum_uint64": int(value[1]),
        "xor_uint64": int(value[2]),
    }


def build_handler_timing(
    messages: Iterable[dict[str, Any]], elapsed_ms: float
) -> CanaryHandlerTiming:
    return CanaryHandlerTiming(
        _kind_frequency_counts(messages),
        max(0.0, float(elapsed_ms)),
        time.time_ns(),
    )


def _format_window(payload: dict[str, Any]) -> str:
    parts = [
        f"CANARY window={payload['window_start_epoch_seconds']}",
        f"clock={payload['clock']['state']}",
        f"dropped={payload['dropped_observations_total']}",
    ]
    for series in payload.get("series") or ():
        if series.get("stage") not in {
            "wss_frame_ready_to_socket_ms",
            "data_plane_to_handler_start_ms",
        }:
            continue
        parts.append(
            f"{series['kind']}/{series['frequency']}/{series['stage']}"
            f":n={series['count']} p95={_display_ms(series.get('p95_ms'))}"
            f" p99={_display_ms(series.get('p99_ms'))}"
            f" max={_display_ms(series.get('max_ms'))}"
        )
    return " | ".join(parts)


def _display_ms(value: Any) -> str:
    return "-" if value is None else f"{float(value):.3f}ms"
