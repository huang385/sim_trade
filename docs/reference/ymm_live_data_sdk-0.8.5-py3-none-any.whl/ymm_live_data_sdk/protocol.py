from __future__ import annotations

from dataclasses import dataclass
import pickle
import struct
from typing import Any

from .exceptions import YMMMessageHubProtocolError


PROTOCOL_VERSION = 4
SUBPROTOCOL = "ymm-live-data.v4"
BATCH_FEED_MAGIC = b"YMLB"
FEED_BUNDLE_MAGIC = b"YMLM"
HEADER = struct.Struct("!4sBBHQQQQQI")
INDEX_ENTRY = struct.Struct("!II")
BUNDLE_HEADER = struct.Struct("!4sBBH")
BUNDLE_ENTRY = struct.Struct("!I")
MAX_FEED_BYTES = 64 * 1024 * 1024
MAX_BATCH_MESSAGES = 512
MAX_FEED_BUNDLE_FRAMES = 128
MAX_FEED_BUNDLE_MESSAGES = 2048
MAX_FEED_BUNDLE_BYTES = 64 * 1024 * 1024


@dataclass(frozen=True, slots=True)
class FeedFrameMetadata:
    delivery_epoch: int
    delivery_sequence: int
    parent_received_monotonic_ns: int
    parent_received_wall_ns: int
    routed_monotonic_ns: int


@dataclass(frozen=True, slots=True)
class DecodedFeedFrame:
    messages: tuple[Any, ...]
    metadata: FeedFrameMetadata


def decode_feed(frame: bytes) -> Any:
    values = decode_feed_frame(frame)
    if len(values) != 1:
        raise YMMMessageHubProtocolError(
            "batch feed frame cannot be decoded as a single feed"
        )
    return values[0]


def decode_feed_frame(frame: bytes) -> tuple[Any, ...]:
    return decode_feed_frame_with_metadata(frame).messages


def split_feed_transport_message(message: bytes) -> tuple[bytes, ...]:
    """Return the ordered logical v4 frames carried by one WS message."""

    if message[:4] == BATCH_FEED_MAGIC:
        return (message,)
    if len(message) < BUNDLE_HEADER.size:
        raise YMMMessageHubProtocolError("truncated feed transport message")
    magic, version, flags, frame_count = BUNDLE_HEADER.unpack_from(message)
    if magic != FEED_BUNDLE_MAGIC or version != PROTOCOL_VERSION:
        raise YMMMessageHubProtocolError("unsupported feed protocol")
    if flags:
        raise YMMMessageHubProtocolError("unsupported feed bundle flags")
    if not 2 <= frame_count <= MAX_FEED_BUNDLE_FRAMES:
        raise YMMMessageHubProtocolError("invalid feed bundle frame count")
    if len(message) > MAX_FEED_BUNDLE_BYTES:
        raise YMMMessageHubProtocolError("feed bundle exceeds 64 MiB")
    index_end = BUNDLE_HEADER.size + frame_count * BUNDLE_ENTRY.size
    if index_end > len(message):
        raise YMMMessageHubProtocolError("truncated feed bundle index")
    frames: list[bytes] = []
    total_messages = 0
    offset = index_end
    for index in range(frame_count):
        (length,) = BUNDLE_ENTRY.unpack_from(
            message,
            BUNDLE_HEADER.size + index * BUNDLE_ENTRY.size,
        )
        if length < HEADER.size or offset + length > len(message):
            raise YMMMessageHubProtocolError("invalid feed bundle frame length")
        frame = message[offset : offset + length]
        if frame[:4] != BATCH_FEED_MAGIC:
            raise YMMMessageHubProtocolError("feed bundle contains an invalid frame")
        total_messages += _logical_frame_message_count(frame)
        frames.append(frame)
        offset += length
    if offset != len(message):
        raise YMMMessageHubProtocolError("feed bundle length mismatch")
    if total_messages > MAX_FEED_BUNDLE_MESSAGES:
        raise YMMMessageHubProtocolError(
            f"feed bundle exceeds {MAX_FEED_BUNDLE_MESSAGES} messages"
        )
    return tuple(frames)


def _logical_frame_message_count(frame: bytes) -> int:
    if len(frame) < HEADER.size:
        raise YMMMessageHubProtocolError("truncated logical feed frame")
    (
        magic,
        version,
        flags,
        message_count,
        _delivery_epoch,
        _delivery_sequence,
        _parent_received_monotonic_ns,
        _parent_received_wall_ns,
        _routed_monotonic_ns,
        payload_size,
    ) = HEADER.unpack_from(frame)
    if (
        magic != BATCH_FEED_MAGIC
        or version != PROTOCOL_VERSION
        or flags
        or not 1 <= message_count <= MAX_BATCH_MESSAGES
        or len(frame) != HEADER.size + message_count * INDEX_ENTRY.size + payload_size
    ):
        raise YMMMessageHubProtocolError("invalid logical feed frame")
    return int(message_count)


def decode_feed_frame_with_metadata(frame: bytes) -> DecodedFeedFrame:
    if len(frame) < HEADER.size:
        raise YMMMessageHubProtocolError("truncated feed frame")
    (
        magic,
        version,
        flags,
        message_count,
        delivery_epoch,
        delivery_sequence,
        parent_received_monotonic_ns,
        parent_received_wall_ns,
        routed_monotonic_ns,
        payload_size,
    ) = HEADER.unpack_from(frame)
    if magic != BATCH_FEED_MAGIC or version != PROTOCOL_VERSION:
        raise YMMMessageHubProtocolError("unsupported feed protocol")
    if flags:
        raise YMMMessageHubProtocolError("unsupported feed flags")
    if not 1 <= message_count <= MAX_BATCH_MESSAGES:
        raise YMMMessageHubProtocolError("invalid batch feed message count")
    if payload_size > MAX_FEED_BYTES:
        raise YMMMessageHubProtocolError("feed message exceeds 64 MiB")
    index_end = HEADER.size + message_count * INDEX_ENTRY.size
    if index_end > len(frame) or len(frame) - index_end != payload_size:
        raise YMMMessageHubProtocolError("feed length mismatch")
    messages: list[Any] = []
    expected_offset = 0
    for index in range(message_count):
        offset, length = INDEX_ENTRY.unpack_from(
            frame, HEADER.size + index * INDEX_ENTRY.size
        )
        if (
            not length
            or offset != expected_offset
            or offset + length > payload_size
        ):
            raise YMMMessageHubProtocolError("invalid feed record index")
        try:
            messages.append(pickle.loads(frame[index_end + offset : index_end + offset + length]))
        except Exception as exc:
            raise YMMMessageHubProtocolError("invalid feed payload") from exc
        expected_offset += length
    if expected_offset != payload_size:
        raise YMMMessageHubProtocolError("feed payload index does not cover payload")
    return DecodedFeedFrame(
        tuple(messages),
        FeedFrameMetadata(
            delivery_epoch=delivery_epoch,
            delivery_sequence=delivery_sequence,
            parent_received_monotonic_ns=parent_received_monotonic_ns,
            parent_received_wall_ns=parent_received_wall_ns,
            routed_monotonic_ns=routed_monotonic_ns,
        ),
    )
