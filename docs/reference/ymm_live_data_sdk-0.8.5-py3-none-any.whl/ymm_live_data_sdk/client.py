from __future__ import annotations

import asyncio
from collections import deque
from collections.abc import Iterable
from dataclasses import dataclass
import json
import queue
import socket
import threading
import time
from typing import Any
import warnings

from .exceptions import (
    YMMMessageHubAuthenticationError,
    YMMMessageHubConnectionError,
    YMMMessageHubProtocolError,
)
from .models import TokenSession
from .protocol import FeedFrameMetadata


_STOP = object()
_FEED_KINDS = ("tick", "1m", "higher")
_FEED_LANES = ("tick", "bar")


class _YMMMessageHubSessionClosedError(YMMMessageHubConnectionError):
    pass


@dataclass(frozen=True, slots=True)
class _LogicalFeedFrameTiming:
    message_count: int
    frame_received_at: float
    decode_started_at: float
    decoded_at: float
    metadata: FeedFrameMetadata
    frame_received_wall_ns: int = 0


@dataclass(frozen=True, slots=True)
class _QueuedFeedBatch:
    messages: tuple[Any, ...]
    frame_received_at: float
    decode_started_at: float
    decoded_at: float
    enqueued_at: float
    metadata: FeedFrameMetadata | None = None
    logical_frames: tuple[_LogicalFeedFrameTiming, ...] = ()


class _FeedBatchQueue:
    """Bounded frame-order FIFO whose capacity is measured in feed rows."""

    def __init__(self, capacity: int) -> None:
        if capacity < 1:
            raise ValueError("feed queue capacity must be positive")
        self._capacity = capacity
        self._batches: deque[_QueuedFeedBatch] = deque()
        self._sizes = {kind: 0 for kind in _FEED_KINDS}
        self._size = 0
        self._terminal = False
        self._condition = threading.Condition()

    def put_many(
        self,
        values: tuple[Any, ...] | list[Any],
        *,
        frame_received_at: float | None = None,
        decode_started_at: float | None = None,
        decoded_at: float | None = None,
        metadata: FeedFrameMetadata | None = None,
        logical_frames: tuple[_LogicalFeedFrameTiming, ...] = (),
    ) -> dict[str, int]:
        incoming = tuple(values)
        if not incoming:
            return {kind: 0 for kind in _FEED_KINDS}
        now = time.monotonic()
        frame_received = now if frame_received_at is None else float(frame_received_at)
        decode_started = (
            frame_received
            if decode_started_at is None
            else float(decode_started_at)
        )
        decoded = now if decoded_at is None else float(decoded_at)
        dropped = {kind: 0 for kind in _FEED_KINDS}
        with self._condition:
            if self._terminal:
                self._add_kind_counts(dropped, incoming)
                return dropped
            if len(incoming) > self._capacity:
                while self._batches:
                    removed = self._batches.popleft()
                    self._add_kind_counts(dropped, removed.messages)
                self._size = 0
                self._sizes = {kind: 0 for kind in _FEED_KINDS}
                self._add_kind_counts(dropped, incoming)
                return dropped
            while self._batches and self._size + len(incoming) > self._capacity:
                oldest = self._batches.popleft()
                self._remove_kind_counts(oldest.messages)
                self._add_kind_counts(dropped, oldest.messages)
                self._size -= len(oldest.messages)
            queued = _QueuedFeedBatch(
                messages=incoming,
                frame_received_at=frame_received,
                decode_started_at=decode_started,
                decoded_at=decoded,
                enqueued_at=time.monotonic(),
                metadata=metadata,
                logical_frames=tuple(logical_frames),
            )
            self._batches.append(queued)
            self._size += len(incoming)
            for message in incoming:
                self._sizes[_feed_kind(message)] += 1
            if self._size:
                self._condition.notify()
        return dropped

    def get_batch(self) -> tuple[Any, ...]:
        batch = self.get_batch_with_metadata()
        if batch is None:
            return (_STOP,)
        return batch.messages

    def get_batch_with_metadata(self) -> _QueuedFeedBatch | None:
        with self._condition:
            while self._size == 0 and not self._terminal:
                self._condition.wait()
            if not self._batches:
                return None
            batch = self._batches.popleft()
            self._remove_kind_counts(batch.messages)
            self._size -= len(batch.messages)
            return batch

    def put_terminal(self) -> None:
        with self._condition:
            self._terminal = True
            self._condition.notify_all()

    def qsize(self) -> int:
        with self._condition:
            return self._size

    def empty(self) -> bool:
        return self.qsize() == 0

    def qsize_by_kind(self) -> dict[str, int]:
        with self._condition:
            return dict(self._sizes)

    @staticmethod
    def _add_kind_counts(target: dict[str, int], messages: Iterable[Any]) -> None:
        for message in messages:
            target[_feed_kind(message)] += 1

    def _remove_kind_counts(self, messages: Iterable[Any]) -> None:
        for message in messages:
            self._sizes[_feed_kind(message)] -= 1


class _FeedDeliveryMetrics:
    """Bounded local timing diagnostics; never participates in delivery."""

    SAMPLE_LIMIT = 16_384
    FRAME_SAMPLE_LIMIT = 4_096
    FRAME_SAMPLE_STRIDE = 64

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._frame_decode_ms: deque[float] = deque(maxlen=self.SAMPLE_LIMIT)
        self._queue_wait_ms: dict[str, deque[float]] = {
            kind: deque(maxlen=self.SAMPLE_LIMIT) for kind in _FEED_KINDS
        }
        self._handler_ms: dict[str, deque[float]] = {
            kind: deque(maxlen=self.SAMPLE_LIMIT) for kind in _FEED_KINDS
        }
        self._parent_to_handler_ms: dict[str, deque[float]] = {
            kind: deque(maxlen=self.SAMPLE_LIMIT) for kind in _FEED_KINDS
        }
        self._batch_sizes: dict[str, deque[float]] = {
            kind: deque(maxlen=self.SAMPLE_LIMIT) for kind in _FEED_KINDS
        }
        self._delivered_batches = {kind: 0 for kind in _FEED_KINDS}
        self._delivered_messages = {kind: 0 for kind in _FEED_KINDS}
        self._dropped_messages = {kind: 0 for kind in _FEED_KINDS}
        self._delivery_epoch: int | None = None
        self._last_delivery_sequence = 0
        self._sequence_gap_frames = 0
        self._sequence_gap_messages = 0
        self._sequence_reorders_or_duplicates = 0
        self._physical_messages = 0
        self._logical_frames = 0
        self._logical_frames_per_physical: deque[float] = deque(
            maxlen=self.SAMPLE_LIMIT
        )
        self._messages_per_physical: deque[float] = deque(
            maxlen=self.SAMPLE_LIMIT
        )
        self._frame_trace: deque[dict[str, Any]] = deque(maxlen=self.SAMPLE_LIMIT)
        # A deterministic whole-run sample complements the recent tail.  Peak
        # replays can deliver more than SAMPLE_LIMIT Tick frames, and using
        # only the tail would silently hide an earlier IPC backlog.
        self._sampled_frame_trace: deque[dict[str, Any]] = deque(
            maxlen=self.FRAME_SAMPLE_LIMIT
        )
        # The global trace is a recent tail. A minute-boundary higher burst can
        # otherwise fall out of that tail during the following tick flood, so
        # retain a smaller independent tail for every feed kind as well.
        self._frame_trace_by_kind: dict[str, deque[dict[str, Any]]] = {
            kind: deque(maxlen=4_096) for kind in _FEED_KINDS
        }

    def observe_frame(self, metadata: FeedFrameMetadata, message_count: int) -> None:
        if metadata.delivery_sequence <= 0:
            return
        with self._lock:
            if self._delivery_epoch is None or metadata.delivery_epoch > self._delivery_epoch:
                self._delivery_epoch = metadata.delivery_epoch
                self._last_delivery_sequence = 0
            elif metadata.delivery_epoch < self._delivery_epoch:
                self._sequence_reorders_or_duplicates += 1
                return
            expected = self._last_delivery_sequence + 1
            if metadata.delivery_sequence > expected:
                self._sequence_gap_frames += metadata.delivery_sequence - expected
                # A missing frame's row count is unknowable from the receiver;
                # retain a conservative lower bound for diagnostics.
                self._sequence_gap_messages += 1
            elif metadata.delivery_sequence < expected:
                self._sequence_reorders_or_duplicates += 1
            self._last_delivery_sequence = max(
                metadata.delivery_sequence,
                self._last_delivery_sequence,
            )

    def observe_decode(self, decode_started_at: float, decoded_at: float) -> None:
        with self._lock:
            self._frame_decode_ms.append(
                max(0.0, (decoded_at - decode_started_at) * 1000.0)
            )

    def observe_physical_bundle(
        self, logical_frame_count: int, message_count: int
    ) -> None:
        with self._lock:
            self._physical_messages += 1
            self._logical_frames += int(logical_frame_count)
            self._logical_frames_per_physical.append(float(logical_frame_count))
            self._messages_per_physical.append(float(message_count))

    def observe_delivery(self, batch: _QueuedFeedBatch, started_at: float) -> None:
        counts = _feed_kind_counts(batch.messages)
        with self._lock:
            logical_frames = batch.logical_frames or (
                _LogicalFeedFrameTiming(
                    len(batch.messages),
                    batch.frame_received_at,
                    batch.decode_started_at,
                    batch.decoded_at,
                    batch.metadata or FeedFrameMetadata(0, 0, 0, 0, 0),
                ),
            )
            message_offset = 0
            for logical in logical_frames:
                metadata = logical.metadata
                logical_messages = batch.messages[
                    message_offset : message_offset + logical.message_count
                ]
                message_offset += logical.message_count
                trace = {
                    "delivery_epoch": metadata.delivery_epoch,
                    "delivery_sequence": metadata.delivery_sequence,
                    "message_count": logical.message_count,
                    "socket_received_monotonic": logical.frame_received_at,
                    "decode_started_monotonic": logical.decode_started_at,
                    "decode_ended_monotonic": logical.decoded_at,
                    "handler_started_monotonic": started_at,
                    "handler_ended_monotonic": None,
                    "hub_parent_received_monotonic_ns": (
                        metadata.parent_received_monotonic_ns
                    ),
                    "hub_routed_monotonic_ns": metadata.routed_monotonic_ns,
                }
                self._frame_trace.append(trace)
                if (
                    metadata.delivery_sequence > 0
                    and metadata.delivery_sequence % self.FRAME_SAMPLE_STRIDE == 0
                ):
                    self._sampled_frame_trace.append(trace)
                logical_counts = _feed_kind_counts(logical_messages)
                for kind, count in logical_counts.items():
                    if not count:
                        continue
                    self._frame_trace_by_kind[kind].append(trace)
                    if metadata.parent_received_monotonic_ns > 0:
                        self._parent_to_handler_ms[kind].append(
                            max(
                                0.0,
                                (
                                    started_at
                                    - metadata.parent_received_monotonic_ns
                                    / 1_000_000_000.0
                                )
                                * 1000.0,
                            )
                        )
            for kind, count in counts.items():
                if count == 0:
                    continue
                self._queue_wait_ms[kind].append(
                    max(0.0, (started_at - batch.enqueued_at) * 1000.0)
                )
                self._batch_sizes[kind].append(float(count))
                self._delivered_batches[kind] += 1
                self._delivered_messages[kind] += count

    def observe_handler(self, batch: _QueuedFeedBatch, elapsed_ms: float) -> None:
        counts = _feed_kind_counts(batch.messages)
        with self._lock:
            trace_count = max(1, len(batch.logical_frames))
            for offset in range(1, min(trace_count, len(self._frame_trace)) + 1):
                trace = self._frame_trace[-offset]
                trace["handler_ended_monotonic"] = (
                    trace["handler_started_monotonic"]
                    + max(0.0, elapsed_ms) / 1000.0
                )
            for kind, count in counts.items():
                if count:
                    self._handler_ms[kind].append(max(0.0, elapsed_ms))

    def observe_drops(self, dropped: dict[str, int]) -> None:
        with self._lock:
            for kind in _FEED_KINDS:
                self._dropped_messages[kind] += int(dropped.get(kind) or 0)

    def snapshot(self, *, queue_rows: dict[str, int]) -> dict[str, Any]:
        with self._lock:
            return {
                "frame_receive_to_decode": _local_latency_summary(
                    list(self._frame_decode_ms), suffix="ms"
                ),
                "sequence_gap_frames": self._sequence_gap_frames,
                "sequence_gap_messages_lower_bound": self._sequence_gap_messages,
                "sequence_reorders_or_duplicates": (
                    self._sequence_reorders_or_duplicates
                ),
                "physical_messages": self._physical_messages,
                "logical_frames": self._logical_frames,
                "logical_frames_per_physical": _local_latency_summary(
                    list(self._logical_frames_per_physical),
                    suffix="frames",
                ),
                "messages_per_physical": _local_latency_summary(
                    list(self._messages_per_physical),
                    suffix="rows",
                ),
                "frame_trace": tuple(dict(value) for value in self._frame_trace),
                "sampled_frame_trace": tuple(
                    dict(value) for value in self._sampled_frame_trace
                ),
                "frame_trace_by_kind": {
                    kind: tuple(dict(value) for value in values)
                    for kind, values in self._frame_trace_by_kind.items()
                },
                "by_kind": {
                    kind: {
                        "delivered_batches": self._delivered_batches[kind],
                        "delivered_messages": self._delivered_messages[kind],
                        "dropped_messages": self._dropped_messages[kind],
                        "queue_rows": int(queue_rows.get(kind) or 0),
                        "batch_size": _local_latency_summary(
                            list(self._batch_sizes[kind]), suffix="rows"
                        ),
                        "decode_to_handler": _local_latency_summary(
                            list(self._queue_wait_ms[kind]), suffix="ms"
                        ),
                        "handler_duration": _local_latency_summary(
                            list(self._handler_ms[kind]), suffix="ms"
                        ),
                        "hub_parent_to_handler": _local_latency_summary(
                            list(self._parent_to_handler_ms[kind]), suffix="ms"
                        ),
                    }
                    for kind in _FEED_KINDS
                },
            }


def _normalize_channels(channels: str | Iterable[str]) -> list[str]:
    if isinstance(channels, str):
        return [channels]
    try:
        values = list(channels)
    except TypeError as exc:
        raise TypeError("channels must be a string or an iterable of strings") from exc
    if any(not isinstance(value, str) for value in values):
        raise TypeError("channels must contain only strings")
    return values


def _feed_kind(message: Any) -> str:
    channel = str(message.get("channel") or "") if isinstance(message, dict) else ""
    if channel.startswith("tick_"):
        return "tick"
    if channel.endswith(("_5m", "_15m", "_30m", "_60m", "_120m", "_240m")):
        return "higher"
    return "1m"


def _feed_kind_counts(messages: Iterable[Any]) -> dict[str, int]:
    counts = {kind: 0 for kind in _FEED_KINDS}
    for message in messages:
        counts[_feed_kind(message)] += 1
    return counts


def _local_latency_summary(
    values: list[float], *, suffix: str
) -> dict[str, float | int | None]:
    ordered = sorted(values)

    def percentile(percent: int) -> float | None:
        if not ordered:
            return None
        index = max(
            0,
            min(len(ordered) - 1, (len(ordered) * percent + 99) // 100 - 1),
        )
        return round(ordered[index], 3)

    return {
        "sample_count": len(ordered),
        f"p50_{suffix}": percentile(50),
        f"p95_{suffix}": percentile(95),
        f"p99_{suffix}": percentile(99),
        f"max_{suffix}": None if not ordered else round(ordered[-1], 3),
    }


def _emit_warnings(records: Any) -> None:
    if not isinstance(records, list):
        return
    for record in records:
        if isinstance(record, dict):
            message = str(record.get("message") or "")
        else:
            message = str(record)
        if message:
            warnings.warn(message, UserWarning, stacklevel=3)


def _load_json(value: str) -> dict[str, Any]:
    try:
        payload = json.loads(value)
    except json.JSONDecodeError as exc:
        raise YMMMessageHubProtocolError("hub sent invalid JSON") from exc
    if not isinstance(payload, dict):
        raise YMMMessageHubProtocolError("hub JSON message must be an object")
    return payload


def _token_in_use_message(session: TokenSession) -> str:
    owner = f"strategy {session.strategy!r}"
    if session.computer_name:
        owner += f" on computer {session.computer_name!r}"
    if session.process_id is not None:
        owner += f" (process {session.process_id})"
    return (
        f"this token is already in use by {owner}; "
        "the existing connection was not interrupted; call get_token_session() and "
        "close_token_session(session_id) if you intend to close it"
    )


def _computer_name() -> str | None:
    try:
        value = socket.gethostname().strip()
    except OSError:
        return None
    value = "".join(character for character in value if 32 <= ord(character) < 127)[:128]
    return value or None


def _is_hex_identifier(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 32
        and all(character in "0123456789abcdef" for character in value.lower())
    )


def _put_terminal(target: Any) -> None:
    put_terminal = getattr(target, "put_terminal", None)
    if callable(put_terminal):
        put_terminal()
        return
    try:
        target.put_nowait(_STOP)
    except queue.Full:
        try:
            target.get_nowait()
        except queue.Empty:
            pass
        target.put_nowait(_STOP)


def _is_authentication_failure(exc: BaseException) -> bool:
    name = type(exc).__name__
    if name in {"InvalidStatus", "InvalidStatusCode"}:
        response = getattr(exc, "response", None)
        status_code = getattr(response, "status_code", None) or getattr(exc, "status_code", None)
        return status_code in {401, 403}
    return isinstance(exc, YMMMessageHubAuthenticationError)


async def _wait_for_stop(stop: threading.Event, seconds: float) -> bool:
    deadline = time.monotonic() + seconds
    while not stop.is_set() and time.monotonic() < deadline:
        await asyncio.sleep(min(0.05, max(0.0, deadline - time.monotonic())))
    return stop.is_set()


# SDK 0.8.0 deliberately replaces the legacy single-socket/single-consumer
# implementation above.  Keeping the low-level bounded queue and diagnostics
# in this module avoids a compatibility import migration for internal tests;
# only the dual-lane client is public.
from .dual_client import LiveMarketDataClient as LiveMarketDataClient  # noqa: E402,F401
