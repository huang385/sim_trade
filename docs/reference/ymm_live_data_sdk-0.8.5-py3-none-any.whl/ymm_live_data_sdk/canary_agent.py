from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import date, datetime, time as wall_time, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import multiprocessing.connection
import os
from pathlib import Path
import threading
import time
import tomllib
from typing import Any
from zoneinfo import ZoneInfo

from .canary import CanaryHandle
from .canary_roster import (
    CanaryRoster,
    build_canary_roster,
    load_data_sdk_candidates,
)
from .dual_client import LiveMarketDataClient
from .exceptions import YMMMessageHubTokenInUseError


_SHANGHAI = ZoneInfo("Asia/Shanghai")
_CYCLE_SWITCH = wall_time(20, 15)
_DEFAULT_PIPE = r"\\.\pipe\ymm-live-data-canary"


@dataclass(frozen=True, slots=True)
class AgentConfig:
    token_file: str
    data_sdk_token_file: str
    ca_file: str | None = None
    mode: str = "lan"
    server_url: str | None = None
    exporter_host: str = "192.168.11.153"
    exporter_port: int = 18444
    report_dir: str = r"C:\ProgramData\YMM\LiveDataCanary\reports"
    control_pipe: str = _DEFAULT_PIPE
    control_auth_file: str = r"C:\ProgramData\YMM\LiveDataCanary\control.key"
    data_sdk_mode: str | None = None
    data_sdk_server_url: str | None = None
    retry_seconds: float = 60.0


def load_agent_config(path: str | Path) -> AgentConfig:
    raw = tomllib.loads(Path(path).read_text(encoding="utf-8"))
    section = raw.get("canary")
    if not isinstance(section, dict):
        raise ValueError("Canary config requires a [canary] table")
    for required in ("token_file", "data_sdk_token_file"):
        if not str(section.get(required) or "").strip():
            raise ValueError(f"Canary config requires {required}")
    config = AgentConfig(**section)
    if not 1 <= int(config.exporter_port) <= 65535:
        raise ValueError("Canary exporter_port must be in 1..65535")
    if float(config.retry_seconds) < 1.0:
        raise ValueError("Canary retry_seconds must be at least one second")
    return config


class CanaryAgent:
    def __init__(self, config: AgentConfig) -> None:
        self.config = config
        self.stop_event = threading.Event()
        self._lock = threading.RLock()
        self._client: LiveMarketDataClient | None = None
        self._base_handle: CanaryHandle | None = None
        self._diagnostic_handle: CanaryHandle | None = None
        self._diagnostic_channels: set[str] = set()
        self._roster: CanaryRoster | None = None
        self._roster_stale = True
        self._roster_error: str | None = None
        self._state = "starting"
        self._last_error_code: str | None = None
        self._last_roster_refresh_at: str | None = None
        self._last_report: str | None = None
        self._connected = False
        self._http: ThreadingHTTPServer | None = None
        self._control_listener: multiprocessing.connection.Listener | None = None
        self._fatal_error: BaseException | None = None
        self._intentional_stop = False
        self._exporter_ready = threading.Event()
        self._control_ready = threading.Event()

    def run(self) -> None:
        self._validate_secret_files()
        self._set_state("starting")
        threads = (
            self._critical_thread(
                "canary-exporter", self._serve_metrics, self._exporter_ready
            ),
            self._critical_thread(
                "canary-control", self._serve_control, self._control_ready
            ),
            threading.Thread(
                target=self._maintain_roster,
                name="canary-roster",
                daemon=True,
            ),
        )
        for thread in threads:
            thread.start()
        try:
            self._wait_for_infrastructure()
            self._runtime_loop()
            if self._fatal_error is not None and not self._intentional_stop:
                raise RuntimeError(
                    "Canary local infrastructure failed"
                ) from self._fatal_error
        finally:
            self._connected = False
            self.stop_event.set()
            self._shutdown_infrastructure()
            with self._lock:
                client = self._client
                self._client = None
            if client is not None:
                client.close()
            for thread in threads:
                thread.join(timeout=2.0)

    def stop(self) -> None:
        self._intentional_stop = True
        self._set_state("stopping")
        self.stop_event.set()
        with self._lock:
            client = self._client
        if client is not None:
            client.close()

    def _validate_secret_files(self) -> None:
        for label, value in (
            ("Live Token", self.config.token_file),
            ("Data SDK Token", self.config.data_sdk_token_file),
            ("control authentication key", self.config.control_auth_file),
        ):
            if not Path(value).is_file():
                raise RuntimeError(f"Canary {label} file is missing")
        if self.config.ca_file and not Path(self.config.ca_file).is_file():
            raise RuntimeError("Canary root CA file is missing")

    def _critical_thread(
        self,
        name: str,
        target: Any,
        ready: threading.Event,
    ) -> threading.Thread:
        def run() -> None:
            try:
                target(ready)
            except BaseException as exc:  # noqa: BLE001 - process boundary.
                if not self.stop_event.is_set():
                    with self._lock:
                        if self._fatal_error is None:
                            self._fatal_error = exc
                    self.stop_event.set()
                    with self._lock:
                        client = self._client
                    if client is not None:
                        client.close()
            finally:
                ready.set()

        return threading.Thread(target=run, name=name, daemon=True)

    def _wait_for_infrastructure(self) -> None:
        deadline = time.monotonic() + 5.0
        for ready in (self._exporter_ready, self._control_ready):
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not ready.wait(remaining):
                raise RuntimeError("Canary local control plane did not start")
            if self._fatal_error is not None:
                raise RuntimeError("Canary local control plane failed") from self._fatal_error

    def _runtime_loop(self) -> None:
        while not self.stop_event.is_set():
            client: LiveMarketDataClient | None = None
            try:
                self._set_state("connecting")
                token = Path(self.config.token_file).read_text(
                    encoding="utf-8"
                ).strip()
                client = LiveMarketDataClient(
                    token=token,
                    mode=self.config.mode,
                    server_url=self.config.server_url,
                    ca_file=self.config.ca_file,
                )
                with self._lock:
                    self._client = client
                self._set_state("loading_roster")
                roster = self._load_or_build_roster(client)
                self._install_roster(client, roster)
                client._canary_roster_heartbeat(roster.revision)
                with self._lock:
                    self._base_handle = client._start_persistent_canary(
                        on_window_closed=self._publish_baseline_window
                    )
                    self._connected = True
                    self._last_error_code = None
                    self._roster_error = None
                self._set_state("running")
                client.listen(
                    tick_handler=lambda _batch: None,
                    bar_handler=lambda _batch: None,
                )
                if not self.stop_event.is_set():
                    raise RuntimeError("Canary live client stopped unexpectedly")
            except YMMMessageHubTokenInUseError as exc:
                self._record_runtime_error("waiting_token", "token_in_use", exc)
            except Exception as exc:  # noqa: BLE001 - retryable external boundary.
                self._record_runtime_error("degraded", "runtime_error", exc)
            finally:
                with self._lock:
                    self._connected = False
                    if self._client is client:
                        self._client = None
                    handle = self._base_handle
                    self._base_handle = None
                if handle is not None:
                    handle.stop()
                if client is not None:
                    client.close()
            if not self.stop_event.is_set():
                self.stop_event.wait(float(self.config.retry_seconds))

    def _record_runtime_error(
        self, state: str, code: str, exc: BaseException
    ) -> None:
        with self._lock:
            self._last_error_code = code
            self._roster_error = f"{type(exc).__name__}: {exc}"
            self._roster_stale = True
        print(
            f"CANARY_RETRY state={state} code={code} error={type(exc).__name__}",
            flush=True,
        )
        self._set_state(state)

    def _set_state(self, state: str) -> None:
        with self._lock:
            changed = self._state != state
            self._state = state
        if changed:
            print(f"CANARY_STATE state={state}", flush=True)

    def _load_or_build_roster(
        self, client: LiveMarketDataClient
    ) -> CanaryRoster:
        catalog_date = str(client.status.catalog_trading_date or "")
        if not catalog_date:
            catalog_date = str(client.get_status().catalog_trading_date or "")
        try:
            published = client._canary_roster_get()
        except Exception:
            published = {}
        if (
            catalog_date
            and str(published.get("operational_date") or "") == catalog_date
        ):
            return CanaryRoster.from_payload(published)
        sdk, operational_date, previous_date = _data_sdk_dates(self.config)
        if catalog_date and operational_date.isoformat() != catalog_date:
            raise RuntimeError(
                "Data SDK operational date does not match FeedHub Catalog date"
            )
        candidates = load_data_sdk_candidates(
            operational_date=operational_date,
            previous_trading_date=previous_date,
            sdk=sdk,
        )
        with self._lock:
            previous_channels = set(
                () if self._roster is None else self._roster.channels
            )
        remaining = tuple(candidates)
        roster: CanaryRoster | None = None
        rejected_ids: set[str] = set()
        for _attempt in range(64):
            candidate = build_canary_roster(
                remaining,
                operational_date=operational_date,
            )
            if len(candidate.instruments) != 64 or len(candidate.channels) != 192:
                raise RuntimeError(
                    "Canary cannot fill 64 instruments from FeedHub-active channels"
                )
            client.subscribe(
                sorted(set(candidate.channels) - set(client.subscriptions))
            )
            accepted = set(client.subscriptions)
            invalid = {
                item.order_book_id
                for item, (_order_book_id, frequency) in zip(
                    candidate.instruments, candidate.assignments
                )
                if not {
                    f"tick_{item.order_book_id}",
                    f"bar_{item.order_book_id}",
                    f"bar_{item.order_book_id}_{frequency}",
                }.issubset(accepted)
            }
            if not invalid:
                roster = candidate
                break
            rejected_ids.update(invalid)
            remaining = tuple(
                item for item in remaining if item.order_book_id not in invalid
            )
        if roster is None:
            raise RuntimeError(
                "Canary active-channel convergence exceeded 64 attempts"
            )
        if rejected_ids:
            print(
                "CANARY_ROSTER_FILTERED "
                f"rejected_instruments={len(rejected_ids)}",
                flush=True,
            )
        try:
            client._canary_roster_publish(roster.payload())
        except Exception:
            additions = set(client.subscriptions) - previous_channels
            if additions:
                client.unsubscribe(sorted(additions))
            raise
        return roster

    def _install_roster(
        self, client: LiveMarketDataClient, roster: CanaryRoster
    ) -> None:
        with self._lock:
            diagnostic = set(self._diagnostic_channels)
        desired = set(roster.channels)
        client.subscribe(sorted(desired - set(client.subscriptions)))
        removable = set(client.subscriptions) - desired - diagnostic
        if removable:
            client.unsubscribe(sorted(removable))
        with self._lock:
            self._roster = roster
            self._roster_stale = False
            self._last_roster_refresh_at = datetime.now(_SHANGHAI).isoformat()

    def _shutdown_infrastructure(self) -> None:
        if self._http is not None:
            self._http.shutdown()
        listener = self._control_listener
        if listener is not None:
            try:
                listener.close()
            except OSError:
                pass

    def status(self) -> dict[str, Any]:
        with self._lock:
            base = None if self._base_handle is None else self._base_handle.snapshot()
            diagnostic_active = bool(
                self._diagnostic_handle is not None
                and self._diagnostic_handle.active
            )
            roster = None if self._roster is None else self._roster.payload()
            lanes = (
                {}
                if self._client is None
                else {
                    lane: event.is_set()
                    for lane, event in self._client._lane_connected.items()
                }
            )
            return {
                "schema_version": 1,
                "state": self._state,
                "healthy": self._fatal_error is None,
                "ready": self._is_ready_locked(),
                "last_error_code": self._last_error_code,
                "connected": self._connected,
                "lanes": lanes,
                "generated_epoch_seconds": time.time(),
                "roster": roster,
                "roster_stale": self._roster_stale,
                "roster_error": self._roster_error,
                "last_roster_refresh_at": self._last_roster_refresh_at,
                "diagnostic_active": diagnostic_active,
                "diagnostic_channel_count": len(self._diagnostic_channels),
                "last_report": self._last_report,
                "canary": base,
            }

    def _is_ready_locked(self) -> bool:
        if not self._connected or self._roster is None or self._client is None:
            return False
        return all(event.is_set() for event in self._client._lane_connected.values())

    def start_diagnostic(
        self,
        channels: list[str],
        *,
        duration_seconds: int,
    ) -> dict[str, Any]:
        requested = set(_validate_channels(channels))
        with self._lock:
            if self._diagnostic_handle is not None and self._diagnostic_handle.active:
                raise RuntimeError("a Canary diagnostic is already active")
            if self._client is None or self._roster is None:
                raise RuntimeError("Canary Agent is not connected")
            base_channels = set(self._roster.channels)
            combined = base_channels | requested
            if len(combined) > 512:
                raise ValueError("base plus diagnostic channels exceed 512")
            extras = requested - base_channels
            self._client.subscribe(sorted(extras))
            handle = self._client._start_diagnostic_canary(
                duration_seconds=duration_seconds,
                output=None,
            )
            self._diagnostic_handle = handle
            self._diagnostic_channels = extras
        thread = threading.Thread(
            target=self._finish_diagnostic,
            args=(handle, extras),
            name="canary-diagnostic-finish",
            daemon=True,
        )
        thread.start()
        return {
            "started": True,
            "duration_seconds": int(duration_seconds),
            "requested_channels": len(requested),
            "added_channels": len(extras),
        }

    def _finish_diagnostic(
        self, handle: CanaryHandle, extras: set[str]
    ) -> None:
        report = handle.wait()
        directory = Path(self.config.report_dir)
        directory.mkdir(parents=True, exist_ok=True)
        target = directory / (
            datetime.now(_SHANGHAI).strftime("canary-%Y%m%dT%H%M%S") + ".json"
        )
        _atomic_write_json(target, report)
        with self._lock:
            client = self._client
            roster_channels = set(
                () if self._roster is None else self._roster.channels
            )
            removable = extras - roster_channels
            if client is not None and removable:
                try:
                    client.unsubscribe(sorted(removable))
                except Exception:
                    pass
            self._last_report = str(target)
            self._diagnostic_channels = set()
            if self._diagnostic_handle is handle:
                self._diagnostic_handle = None

    def _serve_metrics(self, ready: threading.Event) -> None:
        agent = self

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:  # noqa: N802 - stdlib API.
                if self.path == "/-/healthy":
                    payload = agent.status()
                    status = 200 if payload.get("healthy") else 503
                    body = b"ok\n" if status == 200 else b"failed\n"
                elif self.path == "/-/ready":
                    status = 200 if agent.status().get("ready") else 503
                    body = b"ready\n" if status == 200 else b"not ready\n"
                elif self.path == "/metrics":
                    status = 200
                    body = render_agent_metrics(agent.status()).encode("utf-8")
                else:
                    self.send_error(404)
                    return
                self.send_response(status)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, _format: str, *_args: Any) -> None:
                return

        self._http = ThreadingHTTPServer(
            (self.config.exporter_host, int(self.config.exporter_port)), Handler
        )
        ready.set()
        self._http.serve_forever(poll_interval=0.5)

    def _serve_control(self, ready: threading.Event) -> None:
        authkey = Path(self.config.control_auth_file).read_bytes().strip()
        family = "AF_PIPE" if os.name == "nt" else "AF_UNIX"
        address = (
            self.config.control_pipe
            if os.name == "nt"
            else str(Path(self.config.control_pipe).with_suffix(".sock"))
        )
        if family == "AF_UNIX":
            Path(address).unlink(missing_ok=True)
        listener = multiprocessing.connection.Listener(
            address=address,
            family=family,
            authkey=authkey,
        )
        self._control_listener = listener
        ready.set()
        try:
            while not self.stop_event.is_set():
                connection = listener.accept()
                try:
                    command = connection.recv()
                    connection.send(self._control_command(command))
                except Exception as exc:  # noqa: BLE001 - local admin boundary.
                    connection.send(
                        {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
                    )
                finally:
                    connection.close()
        finally:
            self._control_listener = None
            listener.close()
            if family == "AF_UNIX":
                Path(address).unlink(missing_ok=True)

    def _control_command(self, command: Any) -> dict[str, Any]:
        if not isinstance(command, dict):
            raise ValueError("Canary control command must be an object")
        action = str(command.get("action") or "")
        if action == "status":
            return {"ok": True, "result": self.status()}
        if action == "diagnose":
            return {
                "ok": True,
                "result": self.start_diagnostic(
                    [str(value) for value in command.get("channels") or ()],
                    duration_seconds=int(command.get("duration_seconds") or 600),
                ),
            }
        if action == "stop":
            self.stop()
            return {"ok": True, "result": {"stopping": True}}
        raise ValueError(f"unsupported Canary control action: {action!r}")

    def _maintain_roster(self) -> None:
        refresh_at = 0.0
        while not self.stop_event.wait(30.0):
            with self._lock:
                client = self._client
                roster = self._roster
            if client is not None and roster is not None:
                try:
                    client._canary_roster_heartbeat(roster.revision)
                except Exception as exc:  # noqa: BLE001 - baseline is fail-open.
                    with self._lock:
                        self._roster_error = f"{type(exc).__name__}: {exc}"
            if time.monotonic() >= refresh_at:
                refresh_at = time.monotonic() + 60.0
                self._refresh_roster()

    def _refresh_roster(self) -> None:
        try:
            with self._lock:
                current = self._roster
                client = self._client
            if client is None:
                return
            catalog_date = str(client.get_status().catalog_trading_date or "")
            if current is not None and current.operational_date == catalog_date:
                client._canary_roster_heartbeat(current.revision)
                with self._lock:
                    self._roster_stale = False
                    self._roster_error = None
                    self._last_error_code = None
                    self._last_roster_refresh_at = datetime.now(
                        _SHANGHAI
                    ).isoformat()
                return
            roster = self._load_or_build_roster(client)
            self._install_roster(client, roster)
            client._canary_roster_heartbeat(roster.revision)
            with self._lock:
                self._roster_error = None
                self._last_error_code = None
        except Exception as exc:  # noqa: BLE001 - stale roster remains usable.
            with self._lock:
                self._roster_stale = True
                self._roster_error = f"{type(exc).__name__}: {exc}"
                self._last_error_code = "roster_refresh"
            print(
                "CANARY_RETRY state=degraded code=roster_refresh "
                f"error={type(exc).__name__}",
                flush=True,
            )

    def _publish_baseline_window(self, window: dict[str, Any]) -> None:
        with self._lock:
            client = self._client
            roster = self._roster
        if client is None or roster is None:
            return
        payload = {
            **dict(window),
            "schema_version": 1,
            "roster_revision": roster.revision,
            "sequence_gap_frames": _sequence_gap_total(client.delivery_metrics),
        }
        try:
            client._canary_baseline_publish(payload)
        except Exception as exc:  # noqa: BLE001 - comparison never blocks delivery.
            with self._lock:
                self._roster_error = f"{type(exc).__name__}: {exc}"


def render_agent_metrics(payload: dict[str, Any]) -> str:
    roster = dict(payload.get("roster") or {})
    canary = dict(payload.get("canary") or {})
    clock = dict(canary.get("clock") or {})
    lines = [
        "ymm_feedhub_canary_process_up 1",
        f"ymm_feedhub_canary_up {1 if payload.get('connected') else 0}",
        f"ymm_feedhub_canary_ready {1 if payload.get('ready') else 0}",
        f"ymm_feedhub_canary_roster_stale {1 if payload.get('roster_stale') else 0}",
        f"ymm_feedhub_canary_roster_instruments {int(roster.get('instrument_count') or 0)}",
        f"ymm_feedhub_canary_roster_channels {int(roster.get('channel_count') or 0)}",
        f"ymm_feedhub_canary_diagnostic_active {1 if payload.get('diagnostic_active') else 0}",
        f"ymm_feedhub_canary_clock_trusted {1 if clock.get('state') == 'trusted' else 0}",
        f"ymm_feedhub_canary_clock_offset_milliseconds {_number(clock.get('offset_ms'))}",
        f"ymm_feedhub_canary_clock_uncertainty_milliseconds {_number(clock.get('uncertainty_ms'))}",
        f"ymm_feedhub_canary_dropped_observations_total {int(canary.get('dropped_observations_total') or 0)}",
        "ymm_feedhub_canary_clock_state"
        f"{_labels({'state': str(clock.get('state') or 'unavailable')})} 1",
        "ymm_feedhub_canary_agent_state"
        f"{_labels({'state': str(payload.get('state') or 'starting')})} 1",
        "ymm_feedhub_canary_last_error"
        f"{_labels({'code': str(payload.get('last_error_code') or 'none')})} 1",
        "ymm_feedhub_canary_roster_info"
        f"{_labels({'operational_date': str(roster.get('operational_date') or ''), 'revision': str(roster.get('revision') or ''), 'coverage': 'degraded' if roster.get('coverage_degraded') else 'complete'})} 1",
    ]
    for lane, connected in sorted(dict(payload.get("lanes") or {}).items()):
        lines.append(
            "ymm_feedhub_canary_lane_connected"
            f"{_labels({'lane': str(lane)})} {1 if connected else 0}"
        )
    windows = canary.get("windows") or ()
    latest = windows[-1] if windows else {}
    for series in latest.get("series") or ():
        base_labels = {
            "kind": series.get("kind") or "unknown",
            "frequency": series.get("frequency") or "unknown",
            "stage": series.get("stage") or "unknown",
        }
        lines.append(
            "ymm_feedhub_canary_latency_samples"
            f"{_labels(base_labels)} {int(series.get('count') or 0)}"
        )
        for stat, field in (
            ("p50", "p50_ms"),
            ("p95", "p95_ms"),
            ("p99", "p99_ms"),
            ("max", "max_ms"),
        ):
            lines.append(
                "ymm_feedhub_canary_latency_milliseconds"
                f"{_labels({**base_labels, 'stat': stat})}"
                f" {_number(series.get(field))}"
            )
    return "\n".join(lines) + "\n"


def _sequence_gap_total(metrics: dict[str, Any]) -> int:
    return sum(
        int(dict(value).get("sequence_gap_frames") or 0)
        for value in dict(metrics.get("lanes") or {}).values()
    )


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="YMM FeedHub Windows Canary Agent")
    parser.add_argument("--config", required=True)
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("run")
    subparsers.add_parser("status")
    subparsers.add_parser("stop")
    diagnose = subparsers.add_parser("diagnose")
    diagnose.add_argument("--channels-file", required=True)
    diagnose.add_argument("--duration-seconds", type=int, default=600)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    config = load_agent_config(args.config)
    if args.command == "run":
        CanaryAgent(config).run()
        return
    command: dict[str, Any] = {"action": args.command}
    if args.command == "diagnose":
        command.update(
            {
                "channels": _load_channel_file(Path(args.channels_file)),
                "duration_seconds": int(args.duration_seconds),
            }
        )
    response = send_control(config, command)
    print(json.dumps(response, ensure_ascii=False, indent=2, sort_keys=True))


def send_control(config: AgentConfig, command: dict[str, Any]) -> dict[str, Any]:
    authkey = Path(config.control_auth_file).read_bytes().strip()
    family = "AF_PIPE" if os.name == "nt" else "AF_UNIX"
    address = (
        config.control_pipe
        if os.name == "nt"
        else str(Path(config.control_pipe).with_suffix(".sock"))
    )
    connection = multiprocessing.connection.Client(
        address=address,
        family=family,
        authkey=authkey,
    )
    try:
        connection.send(command)
        response = connection.recv()
    finally:
        connection.close()
    if not isinstance(response, dict):
        raise RuntimeError("Canary Agent returned an invalid response")
    return response


def _data_sdk_dates(config: AgentConfig) -> tuple[Any, date, date]:
    import ymm_data_sdk  # type: ignore[import-not-found]

    token = Path(config.data_sdk_token_file).read_text(encoding="utf-8").strip()
    if not token:
        raise RuntimeError("Canary Data SDK Token file is empty")
    try:
        ymm_data_sdk.get_session()
    except Exception:
        ymm_data_sdk.init(
            token=token,
            mode=config.data_sdk_mode,
            server_url=config.data_sdk_server_url,
            warmup=False,
        )
    now = datetime.now(_SHANGHAI)
    today = now.date()
    dates = [
        value if isinstance(value, date) else value.date()
        for value in ymm_data_sdk.get_trading_dates(today, today + timedelta(days=14))
    ]
    if now.time() >= _CYCLE_SWITCH:
        operational = next(value for value in dates if value > today)
    else:
        operational = next(value for value in dates if value >= today)
    previous = ymm_data_sdk.get_previous_trading_date(operational)
    if not isinstance(previous, date):
        previous = previous.date()
    return ymm_data_sdk, operational, previous


def _validate_channels(values: list[str]) -> list[str]:
    unique = list(dict.fromkeys(str(value).strip() for value in values if str(value).strip()))
    if not unique:
        raise ValueError("diagnostic requires at least one channel")
    if any(not value.startswith(("tick_", "bar_")) for value in unique):
        raise ValueError("diagnostic contains an invalid channel")
    return unique


def _load_channel_file(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8")
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        return _validate_channels(
            [line for line in text.splitlines() if not line.lstrip().startswith("#")]
        )
    if not isinstance(value, list):
        raise ValueError("channels JSON must be a list")
    return _validate_channels([str(item) for item in value])


def _atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    os.replace(temporary, path)


def _labels(values: dict[str, Any]) -> str:
    escaped = []
    for key, value in sorted(values.items()):
        text = str(value).replace("\\", "\\\\").replace('"', '\\"')
        escaped.append(f'{key}="{text}"')
    return "{" + ",".join(escaped) + "}"


def _number(value: Any) -> str:
    if value is None:
        return "NaN"
    return f"{float(value):.9g}"


if __name__ == "__main__":
    main()
