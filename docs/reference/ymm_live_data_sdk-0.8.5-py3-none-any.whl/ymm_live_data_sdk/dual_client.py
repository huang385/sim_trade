from __future__ import annotations

import asyncio
from collections.abc import Generator, Iterable
from dataclasses import replace
import itertools
import json
import os
import queue
import ssl
import threading
import time
from typing import Any, Callable
from urllib.parse import urlsplit, urlunsplit
import uuid
import warnings

from .client import (
    _FeedBatchQueue,
    _FeedDeliveryMetrics,
    _LogicalFeedFrameTiming,
    _QueuedFeedBatch,
    _STOP,
    _YMMMessageHubSessionClosedError,
    _computer_name,
    _emit_warnings,
    _is_authentication_failure,
    _is_hex_identifier,
    _load_json,
    _normalize_channels,
    _put_terminal,
    _token_in_use_message,
    _wait_for_stop,
)
from .canary import CanaryFrameTiming, CanaryHandle, build_handler_timing
from .config import ClientConfig, merged_config
from .exceptions import (
    YMMMessageHubAuthenticationError,
    YMMMessageHubConnectionError,
    YMMMessageHubProtocolError,
    YMMMessageHubReplacedError,
    YMMMessageHubTokenInUseError,
)
from .models import CenterStatus, StatusEvent, TokenSession
from .protocol import (
    MAX_BATCH_MESSAGES,
    MAX_FEED_BUNDLE_MESSAGES,
    PROTOCOL_VERSION,
    SUBPROTOCOL,
    decode_feed_frame_with_metadata,
    split_feed_transport_message,
)
from .session import _close_token_session, _get_token_session
from .version import SDK_VERSION


_LANES = ("tick", "bar")


class LiveMarketDataClient:
    """One logical FeedHub session backed by independent Tick and Bar sockets."""

    def __init__(
        self,
        token: str | None = None,
        mode: str | None = None,
        server_url: str | None = None,
        ca_file: str | None = None,
    ) -> None:
        self._config: ClientConfig = merged_config(
            token=token,
            mode=mode,
            server_url=server_url,
            ca_file=ca_file,
        )
        occupied = _get_token_session(self._config)
        if occupied is not None:
            raise YMMMessageHubTokenInUseError(_token_in_use_message(occupied), occupied)

        self._client_instance_id = uuid.uuid4().hex
        self._computer_name = _computer_name()
        self._process_id = os.getpid()
        self._reconnect_lease: str | None = None
        self._logical_session_id: str | None = None
        self._bar_server_url: str | None = None
        self._desired: set[str] = set()
        self._desired_lock = threading.RLock()

        self._connection_lock = threading.RLock()
        self._lane_websockets: dict[str, Any | None] = dict.fromkeys(_LANES)
        self._lane_connected = {lane: threading.Event() for lane in _LANES}
        self._tick_hello_ready = threading.Event()
        self._pending_lock = threading.Lock()
        self._pending: dict[str, queue.Queue[dict[str, Any]]] = {}
        self._outgoing: queue.Queue[str] = queue.Queue()
        self._request_ids = itertools.count(1)

        self._feed_queues = {
            "tick": _FeedBatchQueue(self._config.tick_queue_size),
            "bar": _FeedBatchQueue(self._config.bar_queue_size),
        }
        self._feed_delivery_metrics = {
            lane: _FeedDeliveryMetrics() for lane in _LANES
        }
        self._canary_lock = threading.Lock()
        self._canary_handle: CanaryHandle | None = None
        self._canary_diagnostic_handle: CanaryHandle | None = None
        self._consumer_lock = threading.Lock()
        self._consumer_started = dict.fromkeys(_LANES, False)
        self._consumer_modes: dict[str, str] = {}
        self._handler_error_lock = threading.Lock()
        self._handler_error: BaseException | None = None

        self._status_queue: queue.Queue[Any] = queue.Queue()
        self._status = CenterStatus(
            hub="disconnected",
            rqdata="disconnected",
            catalog="loading",
            storage="starting",
        )
        self._info: dict[str, Any] = {}
        self._stop = threading.Event()
        self._initial_ready = threading.Event()
        self._initial_error: BaseException | None = None
        self._initial_lane_ready: set[str] = set()
        self._initial_lock = threading.Lock()
        self._last_connect_error: dict[str, str | None] = dict.fromkeys(_LANES)
        self._replaced = False
        self._remote_closed = False
        self._closed = False
        self._close_lock = threading.Lock()
        self._local_status_sequence = itertools.count(1)
        self._dropped_messages = dict.fromkeys(_LANES, 0)
        self._last_drop_notice = dict.fromkeys(_LANES, 0.0)
        self._received_feed_frames = dict.fromkeys(_LANES, 0)
        self._received_feed_messages = dict.fromkeys(_LANES, 0)
        self._largest_feed_frame_messages = dict.fromkeys(_LANES, 0)

        self._network_threads = {
            lane: threading.Thread(
                target=self._thread_main,
                args=(lane,),
                name=f"ymm-live-data-{lane}-connection",
                daemon=True,
            )
            for lane in _LANES
        }
        self._network_threads["tick"].start()
        self._network_threads["bar"].start()
        if not self._initial_ready.wait(self._config.connect_timeout):
            errors = "; ".join(
                f"{lane}={error}"
                for lane, error in self._last_connect_error.items()
                if error
            )
            self.close()
            raise YMMMessageHubConnectionError(
                f"timed out establishing both FeedHub lanes at {self._config.server_url}"
                + (f" ({errors})" if errors else "")
            )
        if self._initial_error is not None:
            error = self._initial_error
            self.close()
            raise error

    @property
    def subscriptions(self) -> list[str]:
        with self._desired_lock:
            return sorted(self._desired)

    @property
    def info(self) -> dict[str, Any]:
        return dict(self._info)

    @property
    def status(self) -> CenterStatus:
        return self._status

    @property
    def delivery_metrics(self) -> dict[str, Any]:
        lane_snapshots = {
            lane: self._feed_delivery_metrics[lane].snapshot(
                queue_rows=self._feed_queues[lane].qsize_by_kind()
            )
            for lane in _LANES
        }
        # Keep a convenient by-kind view while making the independent lane
        # sequence and timing domains explicit.
        return {
            "lanes": lane_snapshots,
            "by_kind": {
                "tick": lane_snapshots["tick"]["by_kind"]["tick"],
                "1m": lane_snapshots["bar"]["by_kind"]["1m"],
                "higher": lane_snapshots["bar"]["by_kind"]["higher"],
            },
        }

    def start_canary(
        self,
        *,
        duration_seconds: int = 600,
        interval_seconds: int = 15,
        output: str | None = "console",
    ) -> CanaryHandle:
        """Start one bounded local delivery diagnostic without changing subscriptions."""

        with self._canary_lock:
            current = self._canary_handle
            if current is not None and current.active:
                raise RuntimeError("this client already has an active Canary")
            handle = CanaryHandle(
                duration_seconds=duration_seconds,
                interval_seconds=interval_seconds,
                output=output,
                time_probe=self._canary_time_probe,
                on_finished=self._canary_finished,
            )
            self._canary_handle = handle
            return handle

    def _start_persistent_canary(
        self,
        *,
        on_window_closed: Callable[[dict[str, Any]], None] | None = None,
    ) -> CanaryHandle:
        """Install the administrator Agent's unbounded observer."""

        with self._canary_lock:
            current = self._canary_handle
            if current is not None and current.active:
                raise RuntimeError("this client already has an active Canary")
            handle = CanaryHandle(
                duration_seconds=0,
                output=None,
                time_probe=self._canary_time_probe,
                on_finished=self._canary_finished,
                on_window_closed=on_window_closed,
                _unbounded=True,
            )
            self._canary_handle = handle
            return handle

    def _start_diagnostic_canary(
        self,
        *,
        duration_seconds: int = 600,
        output: str | None = "console",
    ) -> CanaryHandle:
        with self._canary_lock:
            current = self._canary_diagnostic_handle
            if current is not None and current.active:
                raise RuntimeError("this client already has an active diagnostic")
            handle = CanaryHandle(
                duration_seconds=duration_seconds,
                output=output,
                time_probe=self._canary_time_probe,
                on_finished=self._canary_finished,
            )
            self._canary_diagnostic_handle = handle
            return handle

    def _start_comparison_canary(self, *, duration_seconds: int) -> CanaryHandle:
        with self._canary_lock:
            current = self._canary_handle
            if current is not None and current.active:
                raise RuntimeError("this client already has an active Canary")
            handle = CanaryHandle(
                duration_seconds=int(duration_seconds) + 30,
                output=None,
                time_probe=self._canary_time_probe,
                on_finished=self._canary_finished,
                _max_duration_seconds=1830,
            )
            self._canary_handle = handle
            return handle

    def get_status(self) -> CenterStatus:
        response = self._send_command("get_status", {})
        if response is None:
            return self._status
        payload = response.get("result")
        if not isinstance(payload, dict):
            raise YMMMessageHubProtocolError("get_status returned an invalid payload")
        self._status = CenterStatus.from_payload(payload)
        return self._status

    def _canary_roster_get(self) -> dict[str, Any]:
        return self._canary_registry_command("canary_roster_get", {})

    def _canary_roster_publish(self, roster: dict[str, Any]) -> dict[str, Any]:
        return self._canary_registry_command(
            "canary_roster_publish", {"roster": roster}
        )

    def _canary_roster_heartbeat(self, revision: str) -> dict[str, Any]:
        return self._canary_registry_command(
            "canary_roster_heartbeat", {"roster_revision": revision}
        )

    def _canary_baseline_publish(self, baseline: dict[str, Any]) -> dict[str, Any]:
        return self._canary_registry_command(
            "canary_baseline_publish", {"baseline": baseline}
        )

    def _canary_baseline_get(
        self,
        *,
        revision: str,
        window_start_epoch_seconds: int,
        window_end_epoch_seconds: int,
    ) -> dict[str, Any]:
        return self._canary_registry_command(
            "canary_baseline_get",
            {
                "roster_revision": revision,
                "window_start_epoch_seconds": int(window_start_epoch_seconds),
                "window_end_epoch_seconds": int(window_end_epoch_seconds),
            },
        )

    def _canary_registry_command(
        self, action: str, fields: dict[str, Any]
    ) -> dict[str, Any]:
        response = self._send_command(action, fields, timeout=5.0)
        result = None if response is None else response.get("result")
        if not isinstance(result, dict):
            raise YMMMessageHubProtocolError(
                f"{action} returned an invalid payload"
            )
        return dict(result)

    def subscribe(self, channels: str | Iterable[str]) -> None:
        normalized = _normalize_channels(channels)
        valid: list[str] = []
        for channel in normalized:
            if not channel.startswith(("bar_", "tick_")):
                warnings.warn(f"invalid channel: {channel}, ignored", stacklevel=2)
                continue
            if channel.startswith("bar_") and channel.endswith("_1m"):
                warnings.warn(
                    f"invalid channel: {channel}, use {channel[:-3]} for raw 1m",
                    stacklevel=2,
                )
                continue
            valid.append(channel)
        if not valid:
            return
        with self._desired_lock:
            added = [channel for channel in valid if channel not in self._desired]
        self._ensure_runtime_consumers(added)
        if not added:
            return
        response = self._send_command("subscribe", {"channels": added})
        accepted = set(added)
        if response is not None:
            _emit_warnings(response.get("warnings"))
            raw_accepted = response.get("result", {}).get("accepted")
            if isinstance(raw_accepted, list):
                accepted = {str(value) for value in raw_accepted}
        with self._desired_lock:
            self._desired.update(accepted)

    def unsubscribe(self, channels: str | Iterable[str]) -> None:
        normalized = _normalize_channels(channels)
        with self._desired_lock:
            removed = [channel for channel in normalized if channel in self._desired]
        if not removed:
            return
        response = self._send_command("unsubscribe", {"channels": removed})
        if response is not None:
            _emit_warnings(response.get("warnings"))
        with self._desired_lock:
            self._desired.difference_update(removed)

    def listen(
        self,
        *,
        tick_handler: Callable[[tuple[dict[str, Any], ...]], Any] | None = None,
        bar_handler: Callable[[tuple[dict[str, Any], ...]], Any] | None = None,
    ) -> None:
        """Run independent handler threads and block until the client closes.

        Any unhandled handler exception closes both physical lanes and is
        re-raised in the thread which called ``listen``.
        """

        if self._closed:
            raise RuntimeError("this connection is closed.")
        handlers = {"tick": tick_handler, "bar": bar_handler}
        if all(handler is None for handler in handlers.values()):
            raise ValueError("at least one of tick_handler or bar_handler is required")
        with self._desired_lock:
            desired_lanes = {_channel_lane(channel) for channel in self._desired}
        missing = sorted(lane for lane in desired_lanes if handlers[lane] is None)
        if missing:
            raise RuntimeError(
                "subscribed lanes require consumers before listen starts: "
                + ", ".join(missing)
            )
        claimed = [lane for lane, handler in handlers.items() if handler is not None]
        self._claim_consumers({lane: "handler" for lane in claimed})

        workers = [
            threading.Thread(
                target=self._consume_handler,
                args=(lane, handler),
                name=f"ymm-live-data-{lane}-handler",
                daemon=True,
            )
            for lane, handler in handlers.items()
            if handler is not None
        ]
        for worker in workers:
            worker.start()
        while any(worker.is_alive() for worker in workers):
            for worker in workers:
                worker.join(timeout=0.1)
        with self._handler_error_lock:
            error = self._handler_error
        if error is not None:
            raise error

    def iter_ticks(self) -> Generator[tuple[dict[str, Any], ...], None, None]:
        if self._closed:
            raise RuntimeError("this connection is closed.")
        self._claim_consumers({"tick": "iterator"})
        return self._iter_lane_batches("tick")

    def iter_bars(self) -> Generator[tuple[dict[str, Any], ...], None, None]:
        if self._closed:
            raise RuntimeError("this connection is closed.")
        self._claim_consumers({"bar": "iterator"})
        return self._iter_lane_batches("bar")

    def listen_status(
        self,
        handler: Callable[[StatusEvent], Any] | None = None,
    ) -> Generator[StatusEvent, None, None] | threading.Thread:
        if self._closed:
            raise RuntimeError("this connection is closed.")
        if handler is None:
            return self._iter_status()

        def consume() -> None:
            for event in self._iter_status():
                handler(event)

        thread = threading.Thread(
            target=consume,
            name="ymm-live-data-status-handler",
            daemon=True,
        )
        thread.start()
        return thread

    def close(self) -> None:
        with self._close_lock:
            if self._closed:
                return
            self._closed = True
            session_id = self._logical_session_id
            release_remote = bool(
                session_id and not self._remote_closed and not self._replaced
            )
        if release_remote:
            try:
                _close_token_session(
                    replace(
                        self._config,
                        command_timeout=min(2.0, self._config.command_timeout),
                    ),
                    str(session_id),
                )
            except Exception as exc:  # noqa: BLE001 - local close must finish.
                warnings.warn(
                    "FeedHub Session could not be released during client.close(); "
                    f"the reconnect lease may remain active ({type(exc).__name__}: {exc})",
                    RuntimeWarning,
                    stacklevel=2,
                )
        canary_lock = getattr(self, "_canary_lock", None)
        if canary_lock is None:
            canaries = ()
        else:
            with canary_lock:
                canaries = (
                    getattr(self, "_canary_handle", None),
                    getattr(self, "_canary_diagnostic_handle", None),
                )
        for canary in canaries:
            if canary is not None:
                canary.stop()
        self._stop.set()
        with self._connection_lock:
            self._lane_websockets = dict.fromkeys(_LANES)
        self._fail_pending("connection closed")
        for target in self._feed_queues.values():
            _put_terminal(target)
        self._status_queue.put(_STOP)
        current = threading.current_thread()
        for thread in self._network_threads.values():
            if thread.is_alive() and current is not thread:
                thread.join(timeout=2)

    def _consume_handler(
        self,
        lane: str,
        handler: Callable[[tuple[dict[str, Any], ...]], Any],
    ) -> None:
        for batch, started_at in self._iter_lane_batches_with_started_at(lane):
            try:
                handler(batch.messages)
            except Exception as exc:  # noqa: BLE001 - public callback boundary.
                with self._handler_error_lock:
                    if self._handler_error is None:
                        self._handler_error = exc
                self._publish_local_status(
                    "session",
                    "handler_failed",
                    f"{lane} batch handler failed ({type(exc).__name__}: {exc})",
                    {"lane": lane, "batch_size": len(batch.messages)},
                )
                self.close()
                return
            finally:
                elapsed_ms = (time.monotonic() - started_at) * 1000.0
                self._feed_delivery_metrics[lane].observe_handler(
                    batch,
                    elapsed_ms,
                )
                self._observe_canary_handler(batch, elapsed_ms)

    def _iter_lane_batches(
        self, lane: str
    ) -> Generator[tuple[dict[str, Any], ...], None, None]:
        for batch, _started_at in self._iter_lane_batches_with_started_at(lane):
            yield batch.messages

    def _iter_lane_batches_with_started_at(
        self, lane: str
    ) -> Generator[tuple[_QueuedFeedBatch, float], None, None]:
        target = self._feed_queues[lane]
        while True:
            batch = target.get_batch_with_metadata()
            if batch is None:
                return
            started_at = time.monotonic()
            self._feed_delivery_metrics[lane].observe_delivery(batch, started_at)
            self._observe_canary_delivery(
                lane,
                batch,
                started_at,
                time.time_ns(),
            )
            yield batch, started_at

    def _canary_finished(self, handle: CanaryHandle) -> None:
        with self._canary_lock:
            if self._canary_handle is handle:
                self._canary_handle = None
            if self._canary_diagnostic_handle is handle:
                self._canary_diagnostic_handle = None

    def _active_canaries(self) -> tuple[CanaryHandle, ...]:
        canary_lock = getattr(self, "_canary_lock", None)
        if canary_lock is None:
            return ()
        with canary_lock:
            handles = (
                getattr(self, "_canary_handle", None),
                getattr(self, "_canary_diagnostic_handle", None),
            )
        return tuple(
            handle for handle in handles if handle is not None and handle.active
        )

    def _observe_canary_delivery(
        self,
        lane: str,
        batch: _QueuedFeedBatch,
        handler_started_at: float,
        handler_started_wall_ns: int,
    ) -> None:
        handles = self._active_canaries()
        if not handles or not batch.logical_frames:
            return
        offset = 0
        for logical in batch.logical_frames:
            messages = tuple(
                batch.messages[offset : offset + logical.message_count]
            )
            offset += logical.message_count
            observation = CanaryFrameTiming(
                lane=lane,
                messages=messages,
                message_count=logical.message_count,
                socket_received_monotonic=logical.frame_received_at,
                socket_received_wall_ns=logical.frame_received_wall_ns,
                decode_started_monotonic=logical.decode_started_at,
                decoded_monotonic=logical.decoded_at,
                handler_started_monotonic=handler_started_at,
                handler_started_wall_ns=handler_started_wall_ns,
                metadata=logical.metadata,
            )
            for handle in handles:
                handle.observe_frame(observation)

    def _observe_canary_handler(
        self,
        batch: _QueuedFeedBatch,
        elapsed_ms: float,
    ) -> None:
        handles = self._active_canaries()
        if handles:
            observation = build_handler_timing(batch.messages, elapsed_ms)
            for handle in handles:
                handle.observe_handler(observation)

    def _canary_time_probe(
        self,
        client_sent_wall_ns: int,
        client_sent_monotonic_ns: int,
    ) -> dict[str, Any] | None:
        response = self._send_command(
            "time_probe",
            {
                "client_sent_wall_ns": int(client_sent_wall_ns),
                "client_sent_monotonic_ns": int(client_sent_monotonic_ns),
            },
            timeout=2.0,
        )
        if response is None:
            return None
        result = response.get("result")
        return dict(result) if isinstance(result, dict) else None

    def _claim_consumers(self, requested: dict[str, str]) -> None:
        with self._consumer_lock:
            duplicate = [lane for lane in requested if self._consumer_started[lane]]
            if duplicate:
                raise RuntimeError(
                    f"{duplicate[0]} lane already has a market-data consumer"
                )
            for lane, mode in requested.items():
                self._consumer_started[lane] = True
                self._consumer_modes[lane] = mode
        for lane, mode in requested.items():
            self._publish_consumer_state(lane, mode)

    def _publish_consumer_state(self, lane: str, mode: str) -> None:
        """Best-effort monitoring update; delivery never waits for it."""

        if not self._lane_connected["tick"].is_set():
            return
        self._outgoing.put(
            json.dumps(
                {
                    "version": PROTOCOL_VERSION,
                    "type": "consumer_state",
                    "request_id": self._next_request_id(),
                    "lane": lane,
                    "mode": mode,
                },
                separators=(",", ":"),
            )
        )

    def _ensure_runtime_consumers(self, channels: Iterable[str]) -> None:
        lanes = {_channel_lane(channel) for channel in channels}
        with self._consumer_lock:
            consumption_started = any(self._consumer_started.values())
            missing = sorted(lane for lane in lanes if not self._consumer_started[lane])
        if consumption_started and missing:
            raise RuntimeError(
                "cannot subscribe a lane without its consumer while delivery is running: "
                + ", ".join(missing)
            )

    def _iter_status(self) -> Generator[StatusEvent, None, None]:
        while True:
            item = self._status_queue.get()
            if item is _STOP:
                return
            yield item

    def _thread_main(self, lane: str) -> None:
        asyncio.run(self._connection_loop(lane))

    async def _connection_loop(self, lane: str) -> None:
        delay = 0.5
        connected_once = False
        while not self._stop.is_set() and not self._replaced and not self._remote_closed:
            websocket = None
            try:
                if lane == "bar":
                    while not self._stop.is_set():
                        if self._tick_hello_ready.is_set() and (
                            not connected_once
                            or self._lane_connected["tick"].is_set()
                        ):
                            break
                        await asyncio.sleep(0.05)
                    if self._stop.is_set():
                        break
                websocket, hello = await self._connect(lane)
                with self._connection_lock:
                    self._lane_websockets[lane] = websocket
                if lane == "tick":
                    self._consume_tick_hello(hello)
                    await self._replay_subscriptions(websocket)
                else:
                    self._consume_bar_hello(hello)
                self._lane_connected[lane].set()
                is_recovery = connected_once
                connected_once = True
                self._mark_initial_ready(lane)
                if is_recovery:
                    self._publish_local_status(
                        "hub",
                        "recovered",
                        f"{lane} lane connection recovered",
                        {"lane": lane},
                    )
                delay = 0.5
                await self._receive_loop(lane, websocket)
            except Exception as exc:  # noqa: BLE001 - translate network failures.
                self._last_connect_error[lane] = f"{type(exc).__name__}: {exc}"
                if isinstance(exc, YMMMessageHubTokenInUseError):
                    self._remote_closed = True
                    self._set_initial_error(exc)
                    self.close()
                    return
                if isinstance(exc, _YMMMessageHubSessionClosedError):
                    self._remote_closed = True
                    self._set_initial_error(YMMMessageHubConnectionError(str(exc)))
                    self.close()
                    return
                if not connected_once and _is_authentication_failure(exc):
                    self._set_initial_error(YMMMessageHubAuthenticationError(str(exc)))
                    self.close()
                    return
                if self._replaced or self._remote_closed or self._stop.is_set():
                    break
                self._publish_local_status(
                    "hub",
                    "disconnected",
                    f"{lane} lane disconnected ({exc})",
                    {"lane": lane},
                )
                self._publish_local_status(
                    "hub",
                    "reconnecting",
                    f"{lane} lane retrying in {delay:.1f} seconds",
                    {"lane": lane},
                )
            finally:
                self._lane_connected[lane].clear()
                with self._connection_lock:
                    if self._lane_websockets.get(lane) is websocket:
                        self._lane_websockets[lane] = None
                if websocket is not None:
                    try:
                        await websocket.close()
                    except Exception:
                        pass
                if lane == "tick":
                    self._fail_pending("tick control connection interrupted")
            if not await _wait_for_stop(self._stop, delay):
                delay = min(delay * 2, 2.0)

    async def _connect(self, lane: str) -> tuple[Any, dict[str, Any]]:
        from websockets.asyncio.client import connect

        context = ssl.create_default_context(cafile=self._config.ca_file)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        headers = {
            "Authorization": f"Bearer {self._config.token}",
            "User-Agent": f"ymm-live-data-sdk/{SDK_VERSION}",
            "X-YMM-Live-Client-ID": self._client_instance_id,
            "X-YMM-Live-Process-ID": str(self._process_id),
            "X-YMM-Live-Lane": lane,
        }
        if lane == "tick":
            with self._desired_lock:
                headers["X-YMM-Live-Bar-Channel-Count"] = str(
                    sum(channel.startswith("bar_") for channel in self._desired)
                )
        if self._computer_name is not None:
            headers["X-YMM-Live-Computer-Name"] = self._computer_name
        if self._reconnect_lease is not None:
            headers["X-YMM-Live-Session-Lease"] = self._reconnect_lease
        if lane == "bar":
            if self._logical_session_id is None or self._bar_server_url is None:
                raise YMMMessageHubProtocolError("tick hello has no Bar lane attachment")
            headers["X-YMM-Live-Session-ID"] = self._logical_session_id
            url = self._bar_server_url
        else:
            url = self._config.server_url
        websocket = await connect(
            url,
            ssl=context,
            additional_headers=headers,
            subprotocols=[SUBPROTOCOL],
            compression=None,
            proxy=None,
            open_timeout=self._config.connect_timeout,
            close_timeout=2,
            max_size=None,
        )
        first = await asyncio.wait_for(
            websocket.recv(), timeout=self._config.connect_timeout
        )
        if not isinstance(first, str):
            await websocket.close()
            raise YMMMessageHubProtocolError("hub didn't send a JSON hello message")
        payload = _load_json(first)
        if payload.get("type") == "auth_error":
            error = payload.get("error") or {}
            await websocket.close()
            raise YMMMessageHubAuthenticationError(
                str(error.get("message") or "market-data hub authentication failed")
            )
        if payload.get("type") == "session_error":
            error = payload.get("error") or {}
            error_type = str(error.get("type") or "SessionError")
            message = str(error.get("message") or "market-data session was rejected")
            await websocket.close()
            if error_type == "TokenInUseError":
                session_payload = payload.get("session")
                if not isinstance(session_payload, dict):
                    raise YMMMessageHubProtocolError(
                        "token-in-use response is missing session details"
                    )
                session = TokenSession.from_payload(session_payload)
                raise YMMMessageHubTokenInUseError(
                    _token_in_use_message(session), session
                )
            if error_type == "SessionClosedError":
                raise _YMMMessageHubSessionClosedError(message)
            raise YMMMessageHubConnectionError(f"{error_type}: {message}")
        if (
            payload.get("type") != "hello"
            or payload.get("version") != PROTOCOL_VERSION
            or payload.get("lane") != lane
        ):
            await websocket.close()
            raise YMMMessageHubProtocolError("hub sent an unsupported lane hello")
        return websocket, payload

    def _consume_tick_hello(self, payload: dict[str, Any]) -> None:
        info = payload.get("info")
        status = payload.get("status")
        reconnect_lease = payload.get("reconnect_lease")
        bar_port = payload.get("bar_port")
        if (
            not isinstance(info, dict)
            or not isinstance(status, dict)
            or not _is_hex_identifier(reconnect_lease)
            or not isinstance(info.get("session_id"), str)
            or not isinstance(bar_port, int)
            or not 1 <= bar_port <= 65535
        ):
            raise YMMMessageHubProtocolError(
                "tick hello is missing info, status, reconnect lease, or Bar endpoint"
            )
        self._reconnect_lease = reconnect_lease
        self._logical_session_id = str(info["session_id"])
        self._bar_server_url = _replace_url_port(self._config.server_url, bar_port)
        self._info = {**dict(info), "bar_server_url": self._bar_server_url}
        self._status = CenterStatus.from_payload(status)
        self._tick_hello_ready.set()

    def _consume_bar_hello(self, payload: dict[str, Any]) -> None:
        info = payload.get("info")
        if (
            not isinstance(info, dict)
            or info.get("session_id") != self._logical_session_id
        ):
            raise YMMMessageHubProtocolError("Bar lane attached to a different session")

    async def _replay_subscriptions(self, websocket: Any) -> None:
        with self._desired_lock:
            channels = sorted(self._desired)
        if channels:
            await websocket.send(
                json.dumps(
                    {
                        "version": PROTOCOL_VERSION,
                        "type": "subscribe",
                        "request_id": self._next_request_id(),
                        "channels": channels,
                        "replay": True,
                    },
                    separators=(",", ":"),
                )
            )
        with self._consumer_lock:
            consumer_modes = dict(self._consumer_modes)
        for lane, mode in sorted(consumer_modes.items()):
            await websocket.send(
                json.dumps(
                    {
                        "version": PROTOCOL_VERSION,
                        "type": "consumer_state",
                        "request_id": self._next_request_id(),
                        "lane": lane,
                        "mode": mode,
                    },
                    separators=(",", ":"),
                )
            )

    async def _receive_loop(self, lane: str, websocket: Any) -> None:
        while not self._stop.is_set() and not self._replaced and not self._remote_closed:
            if lane == "tick":
                while True:
                    try:
                        outgoing = self._outgoing.get_nowait()
                    except queue.Empty:
                        break
                    await websocket.send(outgoing)
            try:
                frame = await asyncio.wait_for(websocket.recv(), timeout=0.02)
            except TimeoutError:
                continue
            if isinstance(frame, bytes):
                frame_received_at = time.monotonic()
                frame_received_wall_ns = time.time_ns()
                logical_frames = split_feed_transport_message(frame)
                decoded_logical: list[
                    tuple[tuple[dict[str, Any], ...], _LogicalFeedFrameTiming]
                ] = []
                total_messages = 0
                for logical_frame in logical_frames:
                    decode_started_at = time.monotonic()
                    decoded = decode_feed_frame_with_metadata(logical_frame)
                    decoded_at = time.monotonic()
                    if any(
                        _message_lane(message) != lane
                        for message in decoded.messages
                    ):
                        raise YMMMessageHubProtocolError(
                            f"{lane} socket received a message for the other lane"
                        )
                    metrics = self._feed_delivery_metrics[lane]
                    metrics.observe_decode(decode_started_at, decoded_at)
                    metrics.observe_frame(decoded.metadata, len(decoded.messages))
                    self._received_feed_frames[lane] += 1
                    self._received_feed_messages[lane] += len(decoded.messages)
                    self._largest_feed_frame_messages[lane] = max(
                        self._largest_feed_frame_messages[lane],
                        len(decoded.messages),
                    )
                    timing = _LogicalFeedFrameTiming(
                        len(decoded.messages),
                        frame_received_at,
                        decode_started_at,
                        decoded_at,
                        decoded.metadata,
                        frame_received_wall_ns,
                    )
                    decoded_logical.append((decoded.messages, timing))
                    total_messages += len(decoded.messages)
                physical_limit = (
                    MAX_BATCH_MESSAGES
                    if lane == "tick"
                    else MAX_FEED_BUNDLE_MESSAGES
                )
                if not 1 <= total_messages <= physical_limit:
                    raise YMMMessageHubProtocolError(
                        f"{lane} physical feed bundle must contain "
                        f"1-{physical_limit} messages"
                    )
                self._feed_delivery_metrics[lane].observe_physical_bundle(
                    len(logical_frames),
                    total_messages,
                )
                pending_messages: list[dict[str, Any]] = []
                pending_timings: list[_LogicalFeedFrameTiming] = []
                for logical_messages, timing in decoded_logical:
                    if (
                        pending_messages
                        and len(pending_messages) + len(logical_messages)
                        > MAX_BATCH_MESSAGES
                    ):
                        self._enqueue_feed_batch(
                            lane,
                            tuple(pending_messages),
                            frame_received_at=frame_received_at,
                            decode_started_at=pending_timings[0].decode_started_at,
                            decoded_at=pending_timings[-1].decoded_at,
                            metadata=pending_timings[0].metadata,
                            logical_frames=tuple(pending_timings),
                        )
                        # A 2048-row Bar transport can yield four public
                        # 512-row batches at once. Give the independent fast
                        # handler thread a scheduling point between chunks;
                        # this never waits for capacity and a genuinely slow
                        # handler still follows the existing FIFO drop rule.
                        if lane == "bar":
                            time.sleep(0)
                        pending_messages = []
                        pending_timings = []
                    pending_messages.extend(logical_messages)
                    pending_timings.append(timing)
                if pending_messages:
                    self._enqueue_feed_batch(
                        lane,
                        tuple(pending_messages),
                        frame_received_at=frame_received_at,
                        decode_started_at=pending_timings[0].decode_started_at,
                        decoded_at=pending_timings[-1].decoded_at,
                        metadata=pending_timings[0].metadata,
                        logical_frames=tuple(pending_timings),
                    )
                    if lane == "bar" and total_messages > MAX_BATCH_MESSAGES:
                        time.sleep(0)
                continue
            if not isinstance(frame, str):
                raise YMMMessageHubProtocolError("unsupported WebSocket frame")
            payload = _load_json(frame)
            if lane == "bar":
                raise YMMMessageHubProtocolError("Bar lane doesn't accept control frames")
            self._consume_control_payload(payload)

    def _consume_control_payload(self, payload: dict[str, Any]) -> None:
        message_type = payload.get("type")
        if message_type == "response":
            request_id = str(payload.get("request_id") or "")
            with self._pending_lock:
                waiter = self._pending.pop(request_id, None)
            if waiter is not None:
                waiter.put(payload)
            return
        if message_type == "status":
            event_payload = payload.get("event")
            if not isinstance(event_payload, dict):
                raise YMMMessageHubProtocolError("invalid status event")
            event = StatusEvent.from_payload(event_payload)
            self._status_queue.put(event)
            snapshot = payload.get("snapshot")
            if isinstance(snapshot, dict):
                self._status = CenterStatus.from_payload(snapshot)
            if event.details.get("reason") == "token_revoked":
                self._remote_closed = True
                self._stop.set()
                self._fail_pending("token revoked")
                self.close()
                raise YMMMessageHubAuthenticationError(event.message or "token was revoked")
            if event.state == "replaced":
                self._replaced = True
                self.close()
                raise YMMMessageHubReplacedError(event.message or "connection replaced")
            if event.state == "closed" and event.details.get("reason") == "manual_close":
                self._remote_closed = True
                self.close()
                raise _YMMMessageHubSessionClosedError(
                    event.message or "session manually closed"
                )
            return
        if message_type == "hello":
            self._consume_tick_hello(payload)
            return
        raise YMMMessageHubProtocolError(
            f"unsupported hub message type: {message_type!r}"
        )

    def _send_command(
        self,
        command: str,
        fields: dict[str, Any],
        *,
        timeout: float | None = None,
    ) -> dict[str, Any] | None:
        if self._closed:
            raise RuntimeError("this connection is closed.")
        if self._replaced:
            raise YMMMessageHubReplacedError("connection was replaced by a newer client")
        if self._remote_closed:
            raise YMMMessageHubConnectionError("this session was closed manually")
        if not self._lane_connected["tick"].is_set():
            return None
        request_id = self._next_request_id()
        waiter: queue.Queue[dict[str, Any]] = queue.Queue(maxsize=1)
        with self._pending_lock:
            self._pending[request_id] = waiter
        payload = {
            "version": PROTOCOL_VERSION,
            "type": command,
            "request_id": request_id,
            **fields,
        }
        try:
            self._outgoing.put(json.dumps(payload, separators=(",", ":")))
            command_timeout = (
                self._config.command_timeout
                if timeout is None
                else max(0.1, float(timeout))
            )
            response = waiter.get(timeout=command_timeout)
        except queue.Empty as exc:
            with self._pending_lock:
                self._pending.pop(request_id, None)
            raise YMMMessageHubConnectionError(
                f"hub didn't acknowledge {command} within "
                f"{command_timeout:g}s"
            ) from exc
        if not response.get("ok"):
            error = response.get("error") or {}
            error_type = str(error.get("type") or "RemoteError")
            message = str(error.get("message") or f"{command} failed")
            if error_type in {"AuthenticationError", "SourceAuthorizationError"}:
                raise YMMMessageHubAuthenticationError(message)
            raise YMMMessageHubConnectionError(f"{error_type}: {message}")
        return response

    def _next_request_id(self) -> str:
        return f"c{next(self._request_ids)}"

    def _fail_pending(self, message: str) -> None:
        with self._pending_lock:
            waiters = list(self._pending.values())
            self._pending.clear()
        response = {
            "type": "response",
            "ok": False,
            "error": {"type": "ConnectionError", "message": message},
        }
        for waiter in waiters:
            try:
                waiter.put_nowait(response)
            except queue.Full:
                pass

    def _enqueue_feed_batch(
        self,
        lane: str,
        messages: tuple[Any, ...],
        *,
        frame_received_at: float,
        decode_started_at: float,
        decoded_at: float,
        metadata: Any,
        logical_frames: tuple[_LogicalFeedFrameTiming, ...] = (),
    ) -> None:
        dropped_by_kind = self._feed_queues[lane].put_many(
            messages,
            frame_received_at=frame_received_at,
            decode_started_at=decode_started_at,
            decoded_at=decoded_at,
            metadata=metadata,
            logical_frames=logical_frames,
        )
        self._feed_delivery_metrics[lane].observe_drops(dropped_by_kind)
        dropped = sum(dropped_by_kind.values())
        if not dropped:
            return
        self._dropped_messages[lane] += dropped
        now = time.monotonic()
        if now - self._last_drop_notice[lane] >= 5:
            self._last_drop_notice[lane] = now
            self._publish_local_status(
                "session",
                "slow_consumer",
                f"local SDK {lane} queue overflowed; oldest frames were dropped",
                {
                    "lane": lane,
                    "dropped_messages": self._dropped_messages[lane],
                },
            )

    def _publish_local_status(
        self,
        component: str,
        state: str,
        message: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        from datetime import datetime, timezone

        self._status_queue.put(
            StatusEvent(
                component=component,
                state=state,
                timestamp=datetime.now(timezone.utc).isoformat(),
                message=message,
                details=dict(details or {}),
                sequence=next(self._local_status_sequence),
            )
        )

    def _mark_initial_ready(self, lane: str) -> None:
        with self._initial_lock:
            self._initial_lane_ready.add(lane)
            if self._initial_lane_ready == set(_LANES):
                self._initial_ready.set()

    def _set_initial_error(self, error: BaseException) -> None:
        with self._initial_lock:
            if self._initial_error is None:
                self._initial_error = error
            self._initial_ready.set()


def _channel_lane(channel: str) -> str:
    return "tick" if str(channel).startswith("tick_") else "bar"


def _message_lane(message: Any) -> str:
    channel = str(message.get("channel") or "") if isinstance(message, dict) else ""
    return _channel_lane(channel)


def _replace_url_port(value: str, port: int) -> str:
    parsed = urlsplit(value)
    host = parsed.hostname
    if host is None:
        raise YMMMessageHubProtocolError("configured server URL has no host")
    bracketed = f"[{host}]" if ":" in host else host
    return urlunsplit((parsed.scheme, f"{bracketed}:{int(port)}", "/v1/live", "", ""))
