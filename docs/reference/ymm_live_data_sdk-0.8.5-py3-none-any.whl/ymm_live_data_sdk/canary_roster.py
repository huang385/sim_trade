from __future__ import annotations

from dataclasses import dataclass
from datetime import date
import hashlib
from typing import Any, Iterable


CANARY_SHARDS = (
    "dce",
    "shfe",
    "czce",
    "gfex",
    "ine",
    "xshg",
    "xshe",
    "index_cffex",
)
_FREQUENCIES = ("5m", "15m", "30m", "60m", "120m", "240m", "5m", "5m")
_EXCHANGE_SHARDS = {
    "DCE": "dce",
    "SHFE": "shfe",
    "CZCE": "czce",
    "GFEX": "gfex",
    "INE": "ine",
    "XSHG": "xshg",
    "XSHE": "xshe",
    "CFFEX": "index_cffex",
}


@dataclass(frozen=True, slots=True)
class CanaryInstrument:
    order_book_id: str
    asset: str
    exchange: str
    processing_shard: str
    previous_data: bool


@dataclass(frozen=True, slots=True)
class CanaryRoster:
    operational_date: str
    revision: str
    instruments: tuple[CanaryInstrument, ...]
    channels: tuple[str, ...]
    assignments: tuple[tuple[str, str], ...]
    coverage_degraded: bool
    missing_shards: tuple[str, ...]

    def payload(self) -> dict[str, Any]:
        return {
            "operational_date": self.operational_date,
            "revision": self.revision,
            "instrument_count": len(self.instruments),
            "channel_count": len(self.channels),
            "coverage_degraded": self.coverage_degraded,
            "missing_shards": list(self.missing_shards),
            "instruments": [
                {
                    "order_book_id": item.order_book_id,
                    "asset": item.asset,
                    "exchange": item.exchange,
                    "processing_shard": item.processing_shard,
                    "previous_data": item.previous_data,
                    "higher_frequency": dict(self.assignments).get(
                        item.order_book_id
                    ),
                }
                for item in self.instruments
            ],
            "channels": list(self.channels),
        }

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> CanaryRoster:
        instruments = tuple(
            CanaryInstrument(
                order_book_id=str(item.get("order_book_id") or ""),
                asset=str(item.get("asset") or ""),
                exchange=str(item.get("exchange") or ""),
                processing_shard=str(item.get("processing_shard") or ""),
                previous_data=bool(item.get("previous_data")),
            )
            for item in (dict(value) for value in payload.get("instruments") or ())
        )
        assignments = tuple(
            (
                str(item.get("order_book_id") or ""),
                str(item.get("higher_frequency") or ""),
            )
            for item in (dict(value) for value in payload.get("instruments") or ())
        )
        roster = cls(
            operational_date=str(payload.get("operational_date") or ""),
            revision=str(payload.get("revision") or ""),
            instruments=instruments,
            channels=tuple(str(value) for value in payload.get("channels") or ()),
            assignments=assignments,
            coverage_degraded=bool(payload.get("coverage_degraded")),
            missing_shards=tuple(
                str(value) for value in payload.get("missing_shards") or ()
            ),
        )
        if len(roster.instruments) != 64 or len(roster.channels) != 192:
            raise ValueError("Canary Registry roster shape is invalid")
        return roster


def build_canary_roster(
    values: Iterable[CanaryInstrument],
    *,
    operational_date: date,
    instruments_per_shard: int = 8,
) -> CanaryRoster:
    if instruments_per_shard != 8:
        raise ValueError("Canary requires exactly eight instruments per shard")
    candidates = tuple(values)
    selected: list[CanaryInstrument] = []
    missing: list[str] = []
    degraded = False
    for shard in CANARY_SHARDS:
        shard_values = [
            value for value in candidates if value.processing_shard == shard
        ]
        preferred = [value for value in shard_values if value.previous_data]
        fallback = [value for value in shard_values if not value.previous_data]
        chosen = _stratified_pick(
            preferred,
            instruments_per_shard,
            seed=f"{operational_date.isoformat()}:{shard}:preferred",
        )
        if len(chosen) < instruments_per_shard:
            degraded = True
            remaining = instruments_per_shard - len(chosen)
            chosen.extend(
                _stratified_pick(
                    fallback,
                    remaining,
                    seed=f"{operational_date.isoformat()}:{shard}:fallback",
                )
            )
        if len(chosen) < instruments_per_shard:
            missing.append(shard)
            degraded = True
        selected.extend(chosen)
    assignments: list[tuple[str, str]] = []
    channels: list[str] = []
    for shard in CANARY_SHARDS:
        shard_values = [value for value in selected if value.processing_shard == shard]
        for index, instrument in enumerate(shard_values):
            frequency = _FREQUENCIES[index]
            assignments.append((instrument.order_book_id, frequency))
            channels.extend(
                (
                    f"tick_{instrument.order_book_id}",
                    f"bar_{instrument.order_book_id}",
                    f"bar_{instrument.order_book_id}_{frequency}",
                )
            )
    canonical = "\n".join(
        f"{item.order_book_id}:{frequency}"
        for item, (_order_book_id, frequency) in zip(selected, assignments)
    )
    revision = hashlib.sha256(
        f"{operational_date.isoformat()}\n{canonical}".encode("utf-8")
    ).hexdigest()
    return CanaryRoster(
        operational_date.isoformat(),
        revision,
        tuple(selected),
        tuple(channels),
        tuple(assignments),
        degraded,
        tuple(missing),
    )


def load_data_sdk_candidates(
    *,
    operational_date: date,
    previous_trading_date: date,
    sdk: Any | None = None,
) -> tuple[CanaryInstrument, ...]:
    if sdk is None:
        import ymm_data_sdk as sdk  # type: ignore[import-not-found,no-redef]

    frame = sdk.all_instruments(date=operational_date)
    order_book_ids = _column_values(frame, "order_book_id")
    if not order_book_ids:
        raise RuntimeError("Data SDK returned no active instruments")
    details: dict[str, Any] = {}
    for chunk in _chunks(order_book_ids, 500):
        result = sdk.instruments(chunk)
        raw_values = result if isinstance(result, (list, tuple)) else (result,)
        for value in raw_values:
            order_book_id = str(getattr(value, "order_book_id", "") or "")
            if order_book_id:
                details[order_book_id] = value
    with_data: set[str] = set()
    for chunk in _chunks(order_book_ids, 500):
        price = sdk.get_price(
            chunk,
            start_date=previous_trading_date,
            end_date=previous_trading_date,
            frequency="1d",
            fields=["close"],
            expect_df=True,
        )
        with_data.update(_price_order_book_ids(price))
    candidates: list[CanaryInstrument] = []
    for order_book_id in order_book_ids:
        detail = details.get(order_book_id)
        exchange = str(getattr(detail, "exchange", "") or "").upper()
        asset = str(
            getattr(detail, "type", "")
            or getattr(detail, "asset_type", "")
            or "unknown"
        ).lower()
        candidates.append(
            CanaryInstrument(
                order_book_id,
                asset,
                exchange,
                processing_shard(order_book_id, exchange),
                order_book_id in with_data,
            )
        )
    return tuple(candidates)


def processing_shard(order_book_id: str, exchange: str) -> str:
    explicit = _EXCHANGE_SHARDS.get(str(exchange).upper())
    if explicit is not None:
        return explicit
    if str(order_book_id).endswith(".XSHG"):
        return "xshg"
    if str(order_book_id).endswith(".XSHE"):
        return "xshe"
    return "index_cffex"


def _stratified_pick(
    values: list[CanaryInstrument], count: int, *, seed: str
) -> list[CanaryInstrument]:
    by_asset: dict[str, list[CanaryInstrument]] = {}
    for value in values:
        by_asset.setdefault(value.asset, []).append(value)
    for asset, items in by_asset.items():
        items.sort(key=lambda item: _stable_key(seed, asset, item.order_book_id))
    selected: list[CanaryInstrument] = []
    assets = sorted(by_asset)
    while len(selected) < count and assets:
        remaining: list[str] = []
        for asset in assets:
            items = by_asset[asset]
            if items and len(selected) < count:
                selected.append(items.pop(0))
            if items:
                remaining.append(asset)
        assets = remaining
    return selected


def _stable_key(seed: str, asset: str, order_book_id: str) -> bytes:
    return hashlib.blake2b(
        f"{seed}:{asset}:{order_book_id}".encode("utf-8"), digest_size=16
    ).digest()


def _chunks(values: list[str], size: int) -> Iterable[list[str]]:
    for start in range(0, len(values), size):
        yield values[start : start + size]


def _column_values(frame: Any, name: str) -> list[str]:
    try:
        raw = frame[name]
        values = raw.tolist() if hasattr(raw, "tolist") else list(raw)
    except Exception as exc:  # noqa: BLE001 - DataFrame adapter boundary.
        raise RuntimeError(f"Data SDK instrument result has no {name!r}") from exc
    return list(dict.fromkeys(str(value) for value in values if str(value)))


def _price_order_book_ids(frame: Any) -> set[str]:
    if frame is None or bool(getattr(frame, "empty", False)):
        return set()
    try:
        if "order_book_id" in frame.columns:
            return set(_column_values(frame, "order_book_id"))
    except Exception:
        pass
    index = getattr(frame, "index", ())
    result: set[str] = set()
    for value in index:
        candidate = value[0] if isinstance(value, tuple) and value else value
        text = str(candidate or "")
        if text:
            result.add(text)
    return result
