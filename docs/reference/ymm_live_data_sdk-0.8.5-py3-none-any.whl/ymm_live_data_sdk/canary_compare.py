from __future__ import annotations

from collections import defaultdict
import math
from typing import Any, Iterable

from .canary import histogram_bin_value_ms


def select_complete_windows(
    report: dict[str, Any], *, duration_seconds: int
) -> tuple[dict[str, Any], ...]:
    required = int(duration_seconds) // 15
    values = [
        dict(value)
        for value in report.get("windows") or ()
        if bool(value.get("formal"))
        and str(dict(value.get("clock") or {}).get("state") or "")
        in {"trusted", "warning"}
    ]
    values.sort(key=lambda value: int(value["window_start_epoch_seconds"]))
    for offset in range(max(0, len(values) - required + 1)):
        candidate = values[offset : offset + required]
        starts = [int(value["window_start_epoch_seconds"]) for value in candidate]
        if all(right - left == 15 for left, right in zip(starts, starts[1:])):
            return tuple(candidate)
    raise RuntimeError("Canary did not produce enough consecutive complete windows")


def compare_canary_windows(
    local_windows: Iterable[dict[str, Any]],
    baseline_payload: dict[str, Any],
    *,
    roster_revision: str,
) -> dict[str, Any]:
    local = {
        int(value["window_start_epoch_seconds"]): dict(value)
        for value in local_windows
    }
    baseline = {
        int(value["window_start_epoch_seconds"]): dict(value)
        for value in baseline_payload.get("windows") or ()
    }
    expected = sorted(local)
    comparable_starts: list[int] = []
    mismatches: list[dict[str, Any]] = []
    for start in expected:
        left = local[start]
        right = baseline.get(start)
        if right is None:
            mismatches.append({"window": start, "reason": "baseline_missing"})
            continue
        if str(right.get("roster_revision") or roster_revision) != roster_revision:
            mismatches.append({"window": start, "reason": "roster_revision"})
            continue
        if int(left.get("dropped_observations_total") or 0) or int(
            right.get("dropped_observations_total") or 0
        ):
            mismatches.append({"window": start, "reason": "monitoring_drop"})
            continue
        if int(left.get("sequence_gap_frames") or 0) or int(
            right.get("sequence_gap_frames") or 0
        ):
            mismatches.append({"window": start, "reason": "sequence_gap"})
            continue
        reason = _series_mismatch(left, right)
        if reason:
            mismatches.append({"window": start, "reason": reason})
            continue
        comparable_starts.append(start)
    local_selected = [local[value] for value in comparable_starts]
    baseline_selected = [baseline[value] for value in comparable_starts]
    overall = _compare_merged(local_selected, baseline_selected)
    minutes = []
    for index in range(0, len(comparable_starts), 4):
        starts = comparable_starts[index : index + 4]
        if len(starts) != 4 or any(
            right - left != 15 for left, right in zip(starts, starts[1:])
        ):
            continue
        minutes.append(
            {
                "window_start_epoch_seconds": starts[0],
                "window_end_epoch_seconds": starts[-1] + 15,
                "series": _compare_merged(
                    [local[value] for value in starts],
                    [baseline[value] for value in starts],
                ),
            }
        )
    return {
        "schema_version": 1,
        "roster_revision": roster_revision,
        "expected_window_count": len(expected),
        "comparable_window_count": len(comparable_starts),
        "comparable": len(comparable_starts) == len(expected),
        "window_start_epoch_seconds": expected[0] if expected else None,
        "window_end_epoch_seconds": expected[-1] + 15 if expected else None,
        "mismatches": mismatches,
        "overall": overall,
        "minutes": minutes,
        "windows": [
            {
                "window_start_epoch_seconds": start,
                "series": _compare_merged([local[start]], [baseline[start]]),
            }
            for start in comparable_starts
        ],
    }


def format_comparison(result: dict[str, Any]) -> str:
    lines = [
        "CANARY COMPARISON",
        f"Roster: {result.get('roster_revision')}",
        "Comparable windows: "
        f"{result.get('comparable_window_count')}/{result.get('expected_window_count')}",
    ]
    for item in result.get("overall") or ():
        baseline = dict(item.get("baseline") or {})
        candidate = dict(item.get("candidate") or {})
        lines.append(
            f"{item['kind']}/{item['frequency']}/{item['stage']} "
            f"p95={_display(baseline.get('p95_ms'))}->{_display(candidate.get('p95_ms'))} "
            f"p99={_display(baseline.get('p99_ms'))}->{_display(candidate.get('p99_ms'))} "
            f"ratio={_ratio(candidate.get('p95_ms'), baseline.get('p95_ms'))}"
        )
    for mismatch in result.get("mismatches") or ():
        lines.append(f"NOT_COMPARABLE {mismatch['window']} {mismatch['reason']}")
    return "\n".join(lines)


def _series_mismatch(local: dict[str, Any], baseline: dict[str, Any]) -> str | None:
    left = _series_by_key(local)
    right = _series_by_key(baseline)
    if set(left) != set(right):
        return "series_set"
    checked: set[tuple[str, str]] = set()
    for key in left:
        kind_frequency = key[:2]
        if kind_frequency in checked:
            continue
        checked.add(kind_frequency)
        left_fp = dict(left[key].get("fingerprint") or {})
        right_fp = dict(right[key].get("fingerprint") or {})
        if left_fp != right_fp:
            return f"sample_fingerprint:{kind_frequency[0]}/{kind_frequency[1]}"
    return None


def _compare_merged(
    local_windows: list[dict[str, Any]], baseline_windows: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    local = _merge_series(local_windows)
    baseline = _merge_series(baseline_windows)
    result: list[dict[str, Any]] = []
    for key in sorted(set(local) & set(baseline)):
        left = _histogram_payload(baseline[key])
        right = _histogram_payload(local[key])
        result.append(
            {
                "kind": key[0],
                "frequency": key[1],
                "stage": key[2],
                "baseline": left,
                "candidate": right,
                "p95_delta_ms": _subtract(right["p95_ms"], left["p95_ms"]),
                "p99_delta_ms": _subtract(right["p99_ms"], left["p99_ms"]),
                "p95_ratio": _divide(right["p95_ms"], left["p95_ms"]),
            }
        )
    return result


def _series_by_key(window: dict[str, Any]) -> dict[tuple[str, str, str], dict[str, Any]]:
    return {
        (
            str(value.get("kind") or ""),
            str(value.get("frequency") or ""),
            str(value.get("stage") or ""),
        ): dict(value)
        for value in (dict(item) for item in window.get("series") or ())
    }


def _merge_series(
    windows: Iterable[dict[str, Any]],
) -> dict[tuple[str, str, str], dict[str, Any]]:
    merged: dict[tuple[str, str, str], dict[str, Any]] = {}
    for window in windows:
        for key, value in _series_by_key(window).items():
            target = merged.setdefault(
                key, {"count": 0, "sum_ms": 0.0, "max_ms": 0.0, "bins": defaultdict(int)}
            )
            target["count"] += int(value.get("count") or 0)
            target["sum_ms"] += float(value.get("sum_ms") or 0.0)
            target["max_ms"] = max(
                float(target["max_ms"]), float(value.get("max_ms") or 0.0)
            )
            for index, count in dict(value.get("histogram") or {}).get("bins") or ():
                target["bins"][int(index)] += int(count)
    return merged


def _histogram_payload(value: dict[str, Any]) -> dict[str, Any]:
    count = int(value.get("count") or 0)
    bins = sorted(dict(value.get("bins") or {}).items())
    return {
        "count": count,
        "mean_ms": None if not count else float(value.get("sum_ms") or 0.0) / count,
        "p50_ms": _histogram_percentile(bins, count, 50),
        "p95_ms": _histogram_percentile(bins, count, 95),
        "p99_ms": _histogram_percentile(bins, count, 99),
        "max_ms": float(value.get("max_ms") or 0.0) if count else None,
    }


def _histogram_percentile(
    bins: list[tuple[int, int]], count: int, percentile: int
) -> float | None:
    if count <= 0:
        return None
    rank = max(1, math.ceil(count * percentile / 100.0))
    cumulative = 0
    for index, value in bins:
        cumulative += value
        if cumulative >= rank:
            return histogram_bin_value_ms(index)
    return histogram_bin_value_ms(bins[-1][0]) if bins else None


def _subtract(left: Any, right: Any) -> float | None:
    return None if left is None or right is None else float(left) - float(right)


def _divide(left: Any, right: Any) -> float | None:
    if left is None or right is None or float(right) == 0:
        return None
    return float(left) / float(right)


def _display(value: Any) -> str:
    return "-" if value is None else f"{float(value):.3f}ms"


def _ratio(left: Any, right: Any) -> str:
    value = _divide(left, right)
    return "-" if value is None else f"{value:.2f}x"
