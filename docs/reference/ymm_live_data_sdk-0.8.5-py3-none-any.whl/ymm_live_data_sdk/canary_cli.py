from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import threading
import time
from typing import Any

from .canary_compare import (
    compare_canary_windows,
    format_comparison,
    select_complete_windows,
)
from .dual_client import LiveMarketDataClient
from .exceptions import YMMMessageHubTokenInUseError


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run a YMM FeedHub Canary")
    subparsers = parser.add_subparsers(dest="command", required=True)
    probe = subparsers.add_parser("probe")
    probe.add_argument("--channels-file", required=True)
    compare = subparsers.add_parser("compare")
    for value in (probe, compare):
        value.add_argument("--duration-seconds", type=int, default=600)
        value.add_argument("--json-out")
        value.add_argument("--token-file")
        value.add_argument("--mode", choices=("lan", "local", "TS"), default="lan")
        value.add_argument("--server-url")
        value.add_argument("--ca-file")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    duration = int(args.duration_seconds)
    if args.command == "compare" and (
        duration < 60 or duration > 1800 or duration % 15
    ):
        raise SystemExit("compare duration must be 60-1800 seconds in 15-second units")
    channels = (
        _load_channels(Path(args.channels_file))
        if args.command == "probe"
        else []
    )
    token = _load_token(args.token_file)
    try:
        client = LiveMarketDataClient(
            token=token,
            mode=args.mode,
            server_url=args.server_url,
            ca_file=args.ca_file,
        )
    except YMMMessageHubTokenInUseError as exc:
        if args.command == "compare":
            print(f"CANARY_ERROR {exc}")
            raise SystemExit(4) from exc
        raise SystemExit(
            f"{exc}\nUse client.start_canary() in the running strategy or "
            "use a dedicated test Token."
        ) from exc
    roster: dict[str, Any] = {}
    if args.command == "compare":
        try:
            roster = client._canary_roster_get()
        except Exception as exc:
            client.close()
            print(f"BASELINE_UNAVAILABLE {exc}")
            raise SystemExit(2) from exc
        if not roster.get("baseline_available"):
            client.close()
            print("BASELINE_UNAVAILABLE administrator Canary heartbeat is stale")
            raise SystemExit(2)
        channels = [str(value) for value in roster.get("channels") or ()]
        if len(channels) != 192 or len(set(channels)) != 192:
            client.close()
            raise SystemExit(4)
        handle = client._start_comparison_canary(duration_seconds=duration)
    else:
        handle = client.start_canary(
            duration_seconds=duration,
            output="console",
        )
    client.subscribe(channels)

    def stop_after_probe() -> None:
        handle.wait()
        client.close()

    closer = threading.Thread(
        target=stop_after_probe,
        name="ymm-live-data-canary-stop",
        daemon=True,
    )
    closer.start()
    try:
        client.listen(
            tick_handler=(lambda _batch: None)
            if any(channel.startswith("tick_") for channel in channels)
            else None,
            bar_handler=(lambda _batch: None)
            if any(channel.startswith("bar_") for channel in channels)
            else None,
        )
    finally:
        report = handle.stop()
        client.close()
        closer.join(timeout=1.0)
    local_sequence_gaps = sum(
        int(dict(value).get("sequence_gap_frames") or 0)
        for value in dict(client.delivery_metrics.get("lanes") or {}).values()
    )
    output_report: dict[str, Any] = report
    exit_code = 0
    if args.command == "compare":
        try:
            local_windows = select_complete_windows(
                report, duration_seconds=duration
            )
            local_windows = tuple(
                {**value, "sequence_gap_frames": local_sequence_gaps}
                for value in local_windows
            )
            start = int(local_windows[0]["window_start_epoch_seconds"])
            end = int(local_windows[-1]["window_end_epoch_seconds"])
            deadline = time.monotonic() + 30.0
            baseline: dict[str, Any] = {}
            baseline_client = _reconnect_for_baseline(args, token)
            try:
                while time.monotonic() < deadline:
                    baseline = baseline_client._canary_baseline_get(
                        revision=str(roster["revision"]),
                        window_start_epoch_seconds=start,
                        window_end_epoch_seconds=end,
                    )
                    if len(baseline.get("windows") or ()) >= len(local_windows):
                        break
                    time.sleep(1.0)
            finally:
                baseline_client.close()
            comparison = compare_canary_windows(
                local_windows,
                baseline,
                roster_revision=str(roster["revision"]),
            )
            output_report = {
                "schema_version": 1,
                "roster": {
                    "operational_date": roster.get("operational_date"),
                    "revision": roster.get("revision"),
                },
                "local": report,
                "baseline": baseline,
                "comparison": comparison,
            }
            print(format_comparison(comparison))
            exit_code = 0 if comparison.get("comparable") else 3
        except Exception as exc:
            print(f"BASELINE_UNAVAILABLE {type(exc).__name__}: {exc}")
            exit_code = 2
    if args.json_out:
        target = Path(args.json_out)
        target.write_text(
            json.dumps(output_report, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        print(f"CANARY_REPORT {target.resolve()}")
    if exit_code:
        raise SystemExit(exit_code)


def _load_channels(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8")
    try:
        parsed: Any = json.loads(text)
    except json.JSONDecodeError:
        values = [
            line.strip()
            for line in text.splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        ]
    else:
        if not isinstance(parsed, list):
            raise SystemExit("channels file JSON must be a list")
        values = [str(value).strip() for value in parsed if str(value).strip()]
    unique = list(dict.fromkeys(values))
    if not unique:
        raise SystemExit("channels file contains no channels")
    if len(unique) > 512:
        raise SystemExit("Canary probe accepts at most 512 channels")
    return unique


def _load_token(token_file: str | None) -> str | None:
    if token_file:
        return Path(token_file).read_text(encoding="utf-8").strip()
    return os.environ.get("YMM_LIVE_DATA_TOKEN")


def _reconnect_for_baseline(
    args: argparse.Namespace, token: str | None
) -> LiveMarketDataClient:
    deadline = time.monotonic() + 5.0
    while True:
        try:
            return LiveMarketDataClient(
                token=token,
                mode=args.mode,
                server_url=args.server_url,
                ca_file=args.ca_file,
            )
        except YMMMessageHubTokenInUseError:
            if time.monotonic() >= deadline:
                raise
            time.sleep(0.1)
