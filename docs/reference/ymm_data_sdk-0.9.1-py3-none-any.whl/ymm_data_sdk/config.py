from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Literal

from .exceptions import YMMDataSDKNotInitializedError


LAN_SERVER_URL = "http://192.168.11.172:18080"
LOCAL_SERVER_URL = "http://127.0.0.1:18080"
TAILSCALE_SERVER_URL = "http://100.96.143.111:18080"
DEFAULT_SERVER_URL = LAN_SERVER_URL
ServerMode = Literal["lan", "local", "TS"]

_SERVER_URLS_BY_MODE = {
    "lan": LAN_SERVER_URL,
    "local": LOCAL_SERVER_URL,
    "ts": TAILSCALE_SERVER_URL,
}


@dataclass(frozen=True)
class ClickHouseConfig:
    host: str
    port: int = 9000
    http_port: int = 8123
    database: str = "market_data_RQ"
    username: str = "default"
    password: str = ""
    secure: bool = False


@dataclass(frozen=True)
class PostgreSQLConfig:
    host: str
    port: int = 5432
    database: str = "market_meta_RQ"
    username: str = "postgres"
    password: str = ""
    schema: str = "public"


@dataclass(frozen=True)
class SessionConfig:
    token: str
    server_url: str
    proxy_endpoint: str
    clickhouse: ClickHouseConfig
    postgresql: PostgreSQLConfig
    user: str | None = None
    allowed_methods: tuple[str, ...] = ()
    local_pool_size: int = 2


_SESSION: SessionConfig | None = None


def get_session() -> SessionConfig:
    if _SESSION is None:
        raise YMMDataSDKNotInitializedError("ymm_data_sdk is not initialized; call ymm_data_sdk.init(token=...) first")
    return _SESSION


def set_session(session: SessionConfig) -> None:
    global _SESSION
    previous = _SESSION
    if previous is not None and previous != session:
        from .local_pool import close_local_pool

        close_local_pool(previous)
    _SESSION = session


def clear_session() -> None:
    global _SESSION
    previous = _SESSION
    _SESSION = None
    if previous is not None:
        from .local_pool import close_local_pool

        close_local_pool(previous)


def normalize_server_mode(mode: ServerMode | str | None) -> str | None:
    if mode is None:
        return None
    if not isinstance(mode, str) or not mode.strip():
        raise ValueError("mode must be one of: 'lan', 'local', 'TS'")
    normalized = mode.strip().lower()
    if normalized not in _SERVER_URLS_BY_MODE:
        raise ValueError("mode must be one of: 'lan', 'local', 'TS'")
    return normalized


def server_url_from_env(
    value: str | None = None,
    mode: ServerMode | str | None = None,
) -> str:
    normalized_mode = normalize_server_mode(mode)
    return (
        value
        or (_SERVER_URLS_BY_MODE[normalized_mode] if normalized_mode else None)
        or os.environ.get("YMM_DATA_SDK_SERVER_URL")
        or DEFAULT_SERVER_URL
    ).rstrip("/")


def session_from_auth_payload(token: str, server_url: str, payload: dict[str, Any]) -> SessionConfig:
    ch = payload.get("clickhouse") or {}
    pg = payload.get("postgresql") or {}
    proxy_endpoint = str(payload.get("proxy_endpoint") or f"{server_url.rstrip('/')}/rqdatac/call")
    if proxy_endpoint.startswith("/"):
        proxy_endpoint = f"{server_url.rstrip('/')}{proxy_endpoint}"
    return SessionConfig(
        token=token,
        server_url=server_url.rstrip("/"),
        proxy_endpoint=proxy_endpoint,
        user=payload.get("user"),
        allowed_methods=tuple(payload.get("allowed_methods") or ()),
        clickhouse=ClickHouseConfig(
            host=str(ch["host"]),
            port=int(ch.get("port", 9000)),
            http_port=int(ch.get("http_port", 8123)),
            database=str(ch.get("database", "market_data_RQ")),
            username=str(ch.get("username", "default")),
            password=str(ch.get("password", "")),
            secure=bool(ch.get("secure", False)),
        ),
        postgresql=PostgreSQLConfig(
            host=str(pg["host"]),
            port=int(pg.get("port", 5432)),
            database=str(pg.get("database", "market_meta_RQ")),
            username=str(pg.get("username", "postgres")),
            password=str(pg.get("password", "")),
            schema=str(pg.get("schema", "public")),
        ),
    )
