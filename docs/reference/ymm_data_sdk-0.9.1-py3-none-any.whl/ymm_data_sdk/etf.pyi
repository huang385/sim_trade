import datetime as dt
from typing import Any, Sequence

def get_components(
    order_book_ids: str | Sequence[str],
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...

def get_cash_components(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
