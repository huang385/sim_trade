from __future__ import annotations

import json
import urllib.error
import urllib.request
import warnings
from typing import Any

from .config import (
    ServerMode,
    SessionConfig,
    normalize_server_mode,
    server_url_from_env,
    session_from_auth_payload,
)
from .exceptions import YMMDataSDKAuthError, YMMDataSDKRemoteError
from .serializers import (
    PICKLE_ZSTD_MEDIA_TYPE,
    PROXY_ENVELOPE_KEY,
    PROXY_PROTOCOL_VERSION,
    dumps_object,
    loads_object,
)


JSON_MEDIA_TYPE = "application/json"


def create_session(
    token: str,
    server_url: str | None = None,
    mode: ServerMode | str | None = None,
) -> SessionConfig:
    base_url = server_url_from_env(server_url, mode=mode)
    if not token and normalize_server_mode(mode) != "local":
        raise YMMDataSDKAuthError("token cannot be empty unless mode='local'")
    payload = _post_json(
        f"{base_url}/auth/session",
        {"token": token},
    )
    if not isinstance(payload, dict):
        raise YMMDataSDKAuthError("invalid /auth/session response: expected JSON object")
    return session_from_auth_payload(token=token, server_url=base_url, payload=payload)


def warmup_proxy(session: SessionConfig) -> dict[str, Any]:
    payload = _post_json(
        f"{session.server_url}/auth/warmup",
        {"token": session.token},
    )
    if not isinstance(payload, dict) or payload.get("rqdatac") != "ok":
        raise YMMDataSDKAuthError("invalid /auth/warmup response")
    return payload


def call_proxy(session: SessionConfig, method: str, args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
    result, _ = call_proxy_with_diagnostics(session, method, args, kwargs)
    return result


def call_proxy_with_diagnostics(
    session: SessionConfig,
    method: str,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> tuple[Any, dict[str, Any]]:
    response = _post_pickle(
        session.proxy_endpoint,
        {
            "version": PROXY_PROTOCOL_VERSION,
            "method": method,
            "args": args,
            "kwargs": kwargs,
        },
        token=session.token,
    )
    if isinstance(response, dict) and response.get(PROXY_ENVELOPE_KEY) == PROXY_PROTOCOL_VERSION:
        _emit_remote_warnings(response.get("warnings", []))
        diagnostics = {
            "server_rqdatac_elapsed_seconds": response.get("server_rqdatac_elapsed_seconds"),
        }
        return response.get("result"), diagnostics
    raise YMMDataSDKRemoteError("ProtocolError", "proxy response is missing the versioned result envelope")


def _post_pickle(url: str, payload: dict[str, Any], *, token: str) -> Any:
    data = dumps_object(payload)
    headers = {
        "Content-Type": PICKLE_ZSTD_MEDIA_TYPE,
        "Accept": PICKLE_ZSTD_MEDIA_TYPE,
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    body, content_type = _open_request(url, data=data, headers=headers)
    if content_type == PICKLE_ZSTD_MEDIA_TYPE:
        return loads_object(body)
    if content_type == JSON_MEDIA_TYPE:
        parsed = json.loads(body.decode("utf-8")) if body else None
        if isinstance(parsed, dict) and parsed.get("ok") is False:
            _raise_remote_error(parsed)
        return parsed
    raise YMMDataSDKRemoteError("UnexpectedContentType", f"{url} returned {content_type!r}")


def _post_json(url: str, payload: dict[str, Any]) -> Any:
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = {"Content-Type": JSON_MEDIA_TYPE}
    body, content_type = _open_request(url, data=data, headers=headers)
    if content_type == JSON_MEDIA_TYPE or not body:
        parsed = json.loads(body.decode("utf-8")) if body else None
        if isinstance(parsed, dict) and parsed.get("ok") is False:
            _raise_remote_error(parsed)
        return parsed
    raise YMMDataSDKRemoteError("UnexpectedContentType", f"{url} returned {content_type!r}")


def _open_request(url: str, *, data: bytes, headers: dict[str, str]) -> tuple[bytes, str]:
    request = urllib.request.Request(url, data=data, headers=headers, method="POST")
    # ymm_data_sdk proxy endpoints are LAN services. Bypass OS/IDE proxies so local
    # addresses such as 192.168.x.x are not accidentally routed to Codex/VSCode
    # HTTP proxy settings on Windows clients.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(request, timeout=120) as response:
            body = response.read()
            content_type = response.headers.get("content-type", "").split(";", 1)[0].lower()
    except urllib.error.HTTPError as exc:
        body = exc.read()
        try:
            error = json.loads(body.decode("utf-8"))
        except Exception:
            raise YMMDataSDKRemoteError(type(exc).__name__, str(exc)) from exc
        if isinstance(error, dict) and isinstance(error.get("detail"), dict):
            error = error["detail"]
        _raise_remote_error(error, fallback_type=str(exc.code), fallback_message=str(exc.reason), cause=exc)
    except urllib.error.URLError as exc:
        raise YMMDataSDKRemoteError(type(exc).__name__, str(exc.reason)) from exc

    return body, content_type


_BUILTIN_REMOTE_ERRORS: dict[str, type[Exception]] = {
    "ValueError": ValueError,
    "TypeError": TypeError,
    "KeyError": KeyError,
    "IndexError": IndexError,
    "AssertionError": AssertionError,
    "RuntimeError": RuntimeError,
    "NotImplementedError": NotImplementedError,
}


def _raise_remote_error(
    error: Any,
    *,
    fallback_type: str = "RemoteError",
    fallback_message: str = "",
    cause: BaseException | None = None,
) -> None:
    if isinstance(error, dict) and isinstance(error.get("detail"), dict):
        error = error["detail"]
    if not isinstance(error, dict):
        raise YMMDataSDKRemoteError(fallback_type, fallback_message) from cause

    error_type = str(error.get("error_type") or fallback_type)
    message = str(error.get("error_message") or error.get("detail") or fallback_message)
    exception_class = _BUILTIN_REMOTE_ERRORS.get(error_type)
    if exception_class is not None:
        args = error.get("error_args")
        if not isinstance(args, list) or not all(_is_safe_error_arg(item) for item in args):
            args = [message]
        raise exception_class(*args) from cause
    raise YMMDataSDKRemoteError(error_type, message, error.get("traceback")) from cause


def _is_safe_error_arg(value: Any) -> bool:
    return value is None or isinstance(value, (bool, int, float, str))


def _emit_remote_warnings(records: Any) -> None:
    if not isinstance(records, list):
        return
    categories: dict[str, type[Warning]] = {
        "Warning": Warning,
        "UserWarning": UserWarning,
        "DeprecationWarning": DeprecationWarning,
        "FutureWarning": FutureWarning,
        "RuntimeWarning": RuntimeWarning,
        "PendingDeprecationWarning": PendingDeprecationWarning,
        "SyntaxWarning": SyntaxWarning,
    }
    for record in records:
        if not isinstance(record, dict):
            continue
        category = categories.get(str(record.get("category")), UserWarning)
        warnings.warn(str(record.get("message", "")), category, stacklevel=3)
