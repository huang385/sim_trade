from __future__ import annotations

from typing import Literal


Backend = Literal["local", "proxy", "disabled"]


LOCAL_METHODS: dict[str, str] = {
    "all_instruments": "all_instruments",
    "get_ex_factor": "get_ex_factor",
    "get_open_auction_info": "get_open_auction_info",
    "get_price": "get_price",
    "get_update_status": "get_update_status",
    "get_price_change_rate": "get_price_change_rate",
    "get_split": "get_split",
    "get_vwap": "get_vwap",
    "instruments": "instruments",
    "industry": "industry",
    "get_night_trading_dates": "get_night_trading_dates",
    "get_next_trading_date": "get_next_trading_date",
    "get_latest_trading_date": "get_latest_trading_date",
    "get_future_latest_trading_date": "get_future_latest_trading_date",
    "get_previous_trading_date": "get_previous_trading_date",
    "get_trading_dates": "get_trading_dates",
    "get_trading_periods": "get_trading_periods",
    "is_st_stock": "is_st_stock",
    "is_suspended": "is_suspended",
    "sector": "sector",
    "convertible.is_suspended": "convertible.is_suspended",
    "convertible.all_instruments": "convertible.all_instruments",
    "convertible.instruments": "convertible.instruments",
    "convertible.get_conversion_price": "convertible.get_conversion_price",
    "convertible.get_conversion_info": "convertible.get_conversion_info",
    "convertible.get_call_info": "convertible.get_call_info",
    "convertible.get_put_info": "convertible.get_put_info",
    "convertible.get_cash_flow": "convertible.get_cash_flow",
    "convertible.get_instrument_industry": "convertible.get_instrument_industry",
    "convertible.get_industry": "convertible.get_industry",
    "convertible.get_accrued_interest_eod": "convertible.get_accrued_interest_eod",
    "convertible.get_call_announcement": "convertible.get_call_announcement",
    "convertible.get_close_price": "convertible.get_close_price",
    "convertible.get_indicators": "convertible.get_indicators",
    "convertible.get_credit_rating": "convertible.get_credit_rating",
    "convertible.get_std_discount": "convertible.get_std_discount",
    "futures.get_dominant": "futures.get_dominant",
    "futures.get_dominant_batch": "futures.get_dominant_batch",
    "futures.get_contracts": "futures.get_contracts",
    "futures.get_contracts_batch": "futures.get_contracts_batch",
    "futures.get_ex_factor": "futures.get_ex_factor",
    "futures.get_dominant_price": "futures.get_dominant_price",
    "futures.get_contract_multiplier": "futures.get_contract_multiplier",
    "futures.get_exchange_daily": "futures.get_exchange_daily",
    "futures.get_continuous_contracts": "futures.get_continuous_contracts",
    "futures.get_trading_parameters": "futures.get_trading_parameters",
    "options.get_contracts": "options.get_contracts",
    "options.get_contracts_batch": "options.get_contracts_batch",
    "options.get_contract_property": "options.get_contract_property",
    "options.get_dominant_month": "options.get_dominant_month",
    "options.get_dominant_month_batch": "options.get_dominant_month_batch",
    "options.get_greeks": "options.get_greeks",
    "options.get_indicators": "options.get_indicators",
}


# Public local facades do not all have their own materialization job.  This
# mapping resolves each facade to the public updater status(es) that make its
# local result current.  An empty tuple marks a control method with no data
# materialization of its own.
LOCAL_UPDATE_SOURCES: dict[str, tuple[str, ...]] = {
    method: (method,) for method in LOCAL_METHODS
}
LOCAL_UPDATE_SOURCES.update({
    "get_update_status": (),
    "get_open_auction_info": ("get_price",),
    "get_price_change_rate": ("get_price",),
    "get_vwap": ("get_price",),
    "get_night_trading_dates": ("get_trading_dates",),
    "get_next_trading_date": ("get_trading_dates",),
    "get_latest_trading_date": ("get_trading_dates",),
    "get_future_latest_trading_date": ("get_trading_dates",),
    "get_previous_trading_date": ("get_trading_dates",),
    "sector": ("instruments",),
    "convertible.get_instrument_industry": ("convertible.get_industry",),
    "convertible.get_accrued_interest_eod": ("convertible.get_call_info",),
    "convertible.get_close_price": ("convertible.get_call_info", "get_price"),
    "futures.get_dominant_batch": ("futures.get_dominant",),
    "futures.get_contracts": ("instruments",),
    "futures.get_contracts_batch": ("instruments",),
    "futures.get_dominant_price": (
        "futures.get_dominant",
        "futures.get_ex_factor",
        "get_price",
        "instruments",
    ),
    "futures.get_exchange_daily": ("get_price",),
    "options.get_contracts": ("instruments",),
    "options.get_contracts_batch": ("instruments",),
    "options.get_dominant_month_batch": ("options.get_dominant_month",),
})

if set(LOCAL_UPDATE_SOURCES) != set(LOCAL_METHODS):
    raise RuntimeError("local update-source mapping must cover every local method")

PROXY_METHODS: set[str] = {
    "current_performance",
    "current_stock_connect_quota",
    "get_pit_financials_ex",
    "get_auction_info",
    "get_abnormal_stocks",
    "get_abnormal_stocks_detail",
    "get_allotment",
    "get_announcement",
    "get_audit_opinion",
    "get_block_trade",
    "get_buy_back",
    "get_capital_flow",
    "get_concept",
    "get_concept_list",
    "get_dividend",
    "get_dividend_amount",
    "get_dividend_info",
    "get_eligible_securities_margin",
    "get_factor",
    "get_all_factor_names",
    "get_industry",
    "get_industry_change",
    "get_industry_mapping",
    "get_incentive_plan",
    "get_investor_qa",
    "get_investor_ra",
    "get_instrument_industry",
    "get_holder_number",
    "get_main_shareholder",
    "get_forecast_report_date",
    "get_leader_shares_change",
    "get_margin_haircut",
    "get_margin_stocks",
    "get_private_placement",
    "get_restricted_shares",
    "get_securities_margin",
    "get_share_transformation",
    "get_shares",
    "get_special_treatment_info",
    "get_symbol_change_info",
    "get_stock_connect",
    "get_stock_connect_quota",
    "get_staff_count",
    "get_turnover_rate",
    "get_yield_curve",
    "id_convert",
    "index_indicator",
    "index_components",
    "index_weights",
    "index_weights_ex",
    "performance_forecast",
    "futures.get_member_rank",
    "futures.get_warehouse_stocks",
    "futures.get_basis",
    "futures.get_roll_yield",
    "futures.get_predicted_dividend_point",
    "etf.get_components",
    "etf.get_cash_components",
}

DISABLED_METHODS: set[str] = {
    "current_capital_flow_minute",
    "current_freefloat_turnover",
    "current_minute",
    "current_snapshot",
    "get_live_minute_price_change_rate",
    "is_data_ready",
    "futures.get_current_basis",
}


def backend_for(method: str) -> Backend:
    if method in DISABLED_METHODS:
        return "disabled"
    if method in LOCAL_METHODS:
        return "local"
    if method in PROXY_METHODS:
        return "proxy"
    return "disabled"
