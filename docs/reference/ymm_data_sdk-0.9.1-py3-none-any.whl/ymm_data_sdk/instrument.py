from __future__ import annotations

import datetime as dt
from decimal import Decimal
from typing import Any, Callable, Iterable, Mapping


_DATE_FIELDS = {
    "base_date",
    "de_listed_date",
    "end_delivery_date",
    "establishment_date",
    "listed_date",
    "maturity_date",
    "split_end_date",
    "start_delivery_date",
}

_RESERVED_ATTRS = {
    "days_from_listed",
    "days_to_expire",
    "get",
    "items",
    "keys",
    "tick_size",
    "citics_industry",
    "has_citics_info",
    "to_dict",
}


class Instrument:
    """Lightweight rqdatac-compatible instrument object.

    The object intentionally keeps a dynamic field set because different
    instrument types expose different metadata fields.
    """

    def __init__(
        self,
        data: Mapping[str, Any],
        *,
        citics_resolver: Callable[[str, Any, Any], dict[str, str] | None] | None = None,
    ) -> None:
        self._citics_resolver = citics_resolver
        self._data: dict[str, Any] = {
            str(key): _normalize_value(str(key), value)
            for key, value in data.items()
        }
        for key, value in self._data.items():
            if key.isidentifier() and not key.startswith("_") and key not in _RESERVED_ATTRS:
                object.__setattr__(self, key, value)

    def __repr__(self) -> str:
        fields = ", ".join(f"{key}={value!r}" for key, value in self._data.items())
        return f"Instrument({fields})"

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __contains__(self, key: object) -> bool:
        return key in self._data

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def keys(self) -> Iterable[str]:
        return self._data.keys()

    def items(self) -> Iterable[tuple[str, Any]]:
        return self._data.items()

    def to_dict(self) -> dict[str, Any]:
        return dict(self._data)

    def tick_size(self, price: float | None = None) -> float | int | None:
        rq_type = self._data.get("type")
        exchange = self._data.get("exchange")
        if exchange == "XHKG":
            if not isinstance(price, (int, float)):
                raise TypeError("price should be int or float")
            sections = (0.25, 0.5, 10, 20, 100, 200, 500, 1000, 2000, 5000)
            sizes = (0.001, 0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1, 2, 5)
            import bisect

            return sizes[bisect.bisect_left(sections, price)]
        value = self._data.get("tick_size")
        if value is not None:
            return float(value)
        if rq_type in {"CS", "INDX"}:
            return 0.01
        if rq_type in {"ETF", "LOF", "REITs", "FUND", "FenjiB", "FenjiA", "FenjiMu", "PublicFund"}:
            return 0.001
        if rq_type == "Convertible":
            return 0.001
        if rq_type not in {"Future", "Option", "Spot"}:
            return -1
        return None

    def has_citics_info(self) -> bool:
        return self._data.get("type") == "CS" and self._data.get("exchange") in {"XSHE", "XSHG"}

    def citics_industry(self, date: Any = None) -> dict[str, str] | tuple[str | None, str | None] | None:
        if not self.has_citics_info():
            return None
        if date is None and hasattr(self, "_citics_industry_code"):
            return (self._citics_industry_code, self._citics_industry_name)
        if self._citics_resolver is None:
            return None
        result = self._citics_resolver(
            str(self._data["order_book_id"]), date, self._data.get("de_listed_date")
        )
        if result is None:
            self._citics_industry_code = None
            self._citics_industry_name = None
            return None
        self._citics_industry_code = result["code"]
        self._citics_industry_name = result["name"]
        return result

    @property
    def citics_industry_code(self) -> str | None:
        if not self.has_citics_info():
            return None
        if not hasattr(self, "_citics_industry_code"):
            self.citics_industry()
        return self._citics_industry_code

    @property
    def citics_industry_name(self) -> str | None:
        if not self.has_citics_info():
            return None
        if not hasattr(self, "_citics_industry_name"):
            self.citics_industry()
        return self._citics_industry_name

    def days_from_listed(self, date: str | int | dt.date | dt.datetime | None = None) -> int:
        listed = _parse_optional_date(self._data.get("listed_date"))
        target = _parse_date_arg(date)
        if listed is None or target < listed or _is_after_delisted(target, self._data.get("de_listed_date")):
            return -1
        return (target - listed).days

    def days_to_expire(self, date: str | int | dt.date | dt.datetime | None = None) -> int:
        maturity = _parse_optional_date(self._data.get("maturity_date"))
        target = _parse_date_arg(date)
        listed = _parse_optional_date(self._data.get("listed_date"))
        if maturity is None:
            return -1
        if listed is not None and target < listed:
            return -1
        if target > maturity:
            return -1
        return (maturity - target).days


def _normalize_value(key: str, value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, dt.datetime):
        if key in _DATE_FIELDS:
            return value.date().isoformat()
        return value
    if isinstance(value, dt.date):
        return value.isoformat()
    if isinstance(value, Decimal):
        if value.is_nan():
            return float("nan")
        if value == value.to_integral_value():
            return int(value)
        return float(value)
    return value


def _parse_date_arg(value: str | int | dt.date | dt.datetime | None) -> dt.date:
    if value is None:
        return dt.date.today()
    parsed = _parse_optional_date(value)
    if parsed is None:
        raise ValueError(f"invalid date: {value!r}")
    return parsed


def _parse_optional_date(value: Any) -> dt.date | None:
    if value is None:
        return None
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    text = str(value).strip()
    if not text or text in {"0000-00-00", "2999-12-31", "NaT", "nan", "None"}:
        return None
    if text.isdigit() and len(text) == 8:
        return dt.date(int(text[:4]), int(text[4:6]), int(text[6:8]))
    return dt.date.fromisoformat(text[:10])


def _is_after_delisted(target: dt.date, value: Any) -> bool:
    delisted = _parse_optional_date(value)
    return delisted is not None and target > delisted
