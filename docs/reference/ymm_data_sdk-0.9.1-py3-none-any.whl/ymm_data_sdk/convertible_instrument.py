from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any


class ConvertibleInstrument:
    """Lightweight local counterpart of rqdatac's convertible Instrument."""

    def __init__(self, attrs: Mapping[str, Any], client: Any | None = None) -> None:
        self.__dict__.update(attrs)
        self._client = client
        self._coupon_rate_cache: Any = _MISSING

    def __str__(self) -> str:
        values = ",\n".join(
            f"{key}={value!r}" for key, value in self.items() if not key.startswith("_")
        )
        return f"Instrument(\n{values}\n)"

    __repr__ = __str__

    def __setitem__(self, key: str, value: Any) -> None:
        self.__dict__[key] = value

    def __getitem__(self, key: str) -> Any:
        return self.__dict__[key]

    def get(self, key: str, default: Any = None) -> Any:
        return self.__dict__.get(key, default)

    def items(self) -> Iterable[tuple[str, Any]]:
        return ((key, value) for key, value in self.__dict__.items() if not key.startswith("_"))

    def keys(self) -> Iterable[str]:
        return (key for key in self.__dict__ if not key.startswith("_"))

    def values(self) -> Iterable[Any]:
        return (value for key, value in self.__dict__.items() if not key.startswith("_"))

    def coupon_rate_table(self) -> Any:
        if self._coupon_rate_cache is _MISSING:
            self._require_client()
            from .local.convertible_reference_data import coupon_rate_table

            self._coupon_rate_cache = coupon_rate_table(self._client, self.order_book_id)
        return self._coupon_rate_cache

    def option(self, option_type: int | None = None) -> Any:
        self._require_client()
        from .local.convertible_reference_data import option

        return option(self._client, self.order_book_id, option_type=option_type)

    def _require_client(self) -> None:
        if self._client is None:
            raise RuntimeError("convertible Instrument is not attached to a local database client")


_MISSING = object()
