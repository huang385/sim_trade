from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from .config import SessionConfig, get_session
from .local_pool import lease_local_client, local_pool_stats


def all_instruments(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.all_instruments(*args, **kwargs)


def get_ex_factor(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_ex_factor(*args, **kwargs)


def get_open_auction_info(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_open_auction_info(*args, **kwargs)


def get_price(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_price(*args, **kwargs)


def get_update_status(
    *,
    method: str | Sequence[str],
    session: SessionConfig | None = None,
) -> Any:
    with _client(session) as client:
        return client.get_update_status(method=method)


def _get_update_status_watch_baseline(
    *,
    method: str | Sequence[str],
    session: SessionConfig,
) -> tuple[int, Any]:
    """Read an event cursor and status from one repeatable-read snapshot."""

    with _client(session) as client:
        connection = client._get_pg_connection()
        with connection.transaction():
            with connection.cursor() as cursor:
                cursor.execute(
                    "SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY"
                )
                cursor.execute(
                    "SELECT COALESCE(max(event_id), 0) FROM public.sdk_update_events"
                )
                event_id = int(cursor.fetchone()[0])
            status = client.get_update_status(method=method)
        return event_id, status


def get_price_change_rate(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_price_change_rate(*args, **kwargs)


def get_split(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_split(*args, **kwargs)


def get_vwap(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_vwap(*args, **kwargs)


def instruments(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.instruments(*args, **kwargs)


def industry(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.industry(*args, **kwargs)


def get_night_trading_dates(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_night_trading_dates(*args, **kwargs)


def get_next_trading_date(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_next_trading_date(*args, **kwargs)


def get_latest_trading_date(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_latest_trading_date(*args, **kwargs)


def get_future_latest_trading_date(
    *args: Any, session: SessionConfig | None = None, **kwargs: Any
) -> Any:
    with _client(session) as client:
        return client.get_future_latest_trading_date(*args, **kwargs)


def get_previous_trading_date(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_previous_trading_date(*args, **kwargs)


def get_trading_dates(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_trading_dates(*args, **kwargs)


def get_trading_periods(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_trading_periods(*args, **kwargs)


def is_suspended(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.is_suspended(*args, **kwargs)


def is_st_stock(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.is_st_stock(*args, **kwargs)


def sector(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.sector(*args, **kwargs)


def convertible_is_suspended(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.convertible_is_suspended(*args, **kwargs)


def convertible_all_instruments(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.convertible_all_instruments(*args, **kwargs)


def convertible_instruments(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.convertible_instruments(*args, **kwargs)


def _convertible_call(name: str, args: tuple[Any, ...], kwargs: dict[str, Any], session: SessionConfig | None) -> Any:
    with _client(session) as client:
        return getattr(client, f"convertible_{name}")(*args, **kwargs)


def convertible_get_conversion_price(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    return _convertible_call("get_conversion_price", args, kwargs, session)


def convertible_get_conversion_info(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    return _convertible_call("get_conversion_info", args, kwargs, session)


def convertible_get_call_info(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    return _convertible_call("get_call_info", args, kwargs, session)


def convertible_get_put_info(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    return _convertible_call("get_put_info", args, kwargs, session)


def convertible_get_cash_flow(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    return _convertible_call("get_cash_flow", args, kwargs, session)


def convertible_get_instrument_industry(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    return _convertible_call("get_instrument_industry", args, kwargs, session)


def convertible_get_industry(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    return _convertible_call("get_industry", args, kwargs, session)


def convertible_get_accrued_interest_eod(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    return _convertible_call("get_accrued_interest_eod", args, kwargs, session)


def convertible_get_call_announcement(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    return _convertible_call("get_call_announcement", args, kwargs, session)


def convertible_get_close_price(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    return _convertible_call("get_close_price", args, kwargs, session)


def convertible_get_indicators(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    return _convertible_call("get_indicators", args, kwargs, session)


def convertible_get_credit_rating(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    return _convertible_call("get_credit_rating", args, kwargs, session)


def convertible_get_std_discount(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    return _convertible_call("get_std_discount", args, kwargs, session)


def get_dominant(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_dominant(*args, **kwargs)


def get_dominant_batch(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_dominant_batch(*args, **kwargs)


def get_contracts(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_contracts(*args, **kwargs)


def get_contracts_batch(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_contracts_batch(*args, **kwargs)


def get_future_ex_factor(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_future_ex_factor(*args, **kwargs)


def get_dominant_price(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_dominant_price(*args, **kwargs)


def get_contract_multiplier(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_contract_multiplier(*args, **kwargs)


def get_exchange_daily(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_exchange_daily(*args, **kwargs)


def get_continuous_contracts(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_continuous_contracts(*args, **kwargs)


def get_trading_parameters(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_trading_parameters(*args, **kwargs)


def get_option_contracts(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_option_contracts(*args, **kwargs)


def get_option_contracts_batch(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_option_contracts_batch(*args, **kwargs)


def get_option_contract_property(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_option_contract_property(*args, **kwargs)


def get_option_dominant_month(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_option_dominant_month(*args, **kwargs)


def get_option_dominant_month_batch(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_option_dominant_month_batch(*args, **kwargs)


def get_option_greeks(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_option_greeks(*args, **kwargs)


def get_option_indicators(*args: Any, session: SessionConfig | None = None, **kwargs: Any) -> Any:
    with _client(session) as client:
        return client.get_option_indicators(*args, **kwargs)


def _client(session: SessionConfig | None = None):
    session = session or get_session()
    return lease_local_client(session)


def warmup(session: SessionConfig | None = None) -> dict[str, Any]:
    session = session or get_session()
    with _client(session) as client:
        report = client.warmup()
    report["pool"] = local_pool_stats(session)
    return report
