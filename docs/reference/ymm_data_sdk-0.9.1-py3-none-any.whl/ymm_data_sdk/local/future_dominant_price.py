from __future__ import annotations

import datetime as dt
import warnings
from dataclasses import dataclass
from typing import Any, Sequence, TYPE_CHECKING

if TYPE_CHECKING:
    from .market_data import RQMarketDataClient


VALID_ADJUST_METHODS = ("prev_close_spread", "open_spread", "prev_close_ratio", "open_ratio")
VALID_ADJUST_TYPES = ("none", "pre", "post")
SUPPORTED_FREQUENCIES = ("1d", "1m", "5m", "15m", "30m", "60m", "120m", "240m", "tick")
INDEX_FUTURES = {"IC", "IF", "IH", "IM"}

DEFAULT_FIELDS = {
    "d": [
        "open", "close", "high", "low", "total_turnover", "volume", "prev_close",
        "settlement", "prev_settlement", "open_interest", "limit_up", "limit_down",
        "day_session_open",
    ],
    "m": ["trading_date", "open", "close", "high", "low", "total_turnover", "volume", "open_interest"],
    "tick": [
        "trading_date", "open", "last", "high", "low", "prev_close", "volume",
        "total_turnover", "limit_up", "limit_down", "a1", "a2", "a3", "a4", "a5",
        "b1", "b2", "b3", "b4", "b5", "a1_v", "a2_v", "a3_v", "a4_v",
        "a5_v", "b1_v", "b2_v", "b3_v", "b4_v", "b5_v", "change_rate",
        "open_interest", "prev_settlement",
    ],
}
ADJUST_FIELDS = {
    "open", "high", "low", "close", "last", "limit_up", "limit_down", "settlement",
    "prev_settlement", "prev_close", "day_session_open", "a1", "a2", "a3", "a4", "a5",
    "b1", "b2", "b3", "b4", "b5",
}
TICK_DAILY_FIELDS = {"open", "prev_settlement", "limit_up", "limit_down", "change_rate"}


@dataclass(frozen=True)
class Request:
    symbols: list[str]
    start: dt.date
    end: dt.date
    frequency: str
    fields: list[str]
    adjust_type: str
    adjust_method: str
    rule: int
    rank: int
    time_slice: tuple[int, int] | None


def get_dominant_price(
    client: "RQMarketDataClient",
    underlying_symbols: str | list[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    frequency: str = "1d",
    fields: str | list[str] | None = None,
    adjust_type: str = "pre",
    adjust_method: str = "prev_close_spread",
    rule: int = 0,
    rank: int = 1,
    time_slice: tuple[str | dt.time, str | dt.time] | list[str | dt.time] | None = None,
):
    request = _normalize_request(
        client,
        underlying_symbols=underlying_symbols,
        start_date=start_date,
        end_date=end_date,
        frequency=frequency,
        fields=fields,
        adjust_type=adjust_type,
        adjust_method=adjust_method,
        rule=rule,
        rank=rank,
        time_slice=time_slice,
    )
    if request.adjust_type != "none":
        warnings.warn(
            "DataFrameGroupBy.apply operated on the grouping columns. This behavior is deprecated, "
            "and in a future version of pandas the grouping columns will be excluded from the operation. "
            "Either pass `include_groups=False` to exclude the groupings or explicitly select the grouping "
            "columns after groupby to silence this warning.",
            FutureWarning,
            stacklevel=2,
        )
    mapping = _load_mapping(client, request)
    if not mapping:
        return None
    frame = _query_clickhouse(client, request, mapping)
    if frame.empty:
        return None
    return _format_result(client, frame, request)


def _normalize_request(
    client: "RQMarketDataClient",
    *,
    underlying_symbols: str | list[str],
    start_date: Any,
    end_date: Any,
    frequency: str,
    fields: str | list[str] | None,
    adjust_type: str,
    adjust_method: str,
    rule: int,
    rank: int,
    time_slice: Any,
) -> Request:
    if isinstance(underlying_symbols, str):
        symbols = [underlying_symbols]
    elif isinstance(underlying_symbols, list):
        symbols = underlying_symbols.copy()
    else:
        symbols = []
    if any(not isinstance(value, str) for value in symbols):
        symbols = []

    if not isinstance(frequency, str) or frequency not in SUPPORTED_FREQUENCIES:
        raise AssertionError(
            f"invalid frequency! local supported frequencies: {', '.join(SUPPORTED_FREQUENCIES)}"
        )
    if adjust_type not in VALID_ADJUST_TYPES:
        raise ValueError(f"adjust_type: got invalided value {adjust_type}, choose any in {list(VALID_ADJUST_TYPES)}")
    if adjust_method not in VALID_ADJUST_METHODS:
        raise ValueError(
            f"adjust_method: got invalided value {adjust_method}, choose any in {list(VALID_ADJUST_METHODS)}"
        )
    if rule not in {0, 1, 2, 3}:
        raise ValueError(f"rule: got invalided value {rule}, choose any in {[0, 1, 2, 3]}")
    if rank not in {1, 2, 3}:
        raise ValueError(f"order: got invalided value {rank}, choose any in {[1, 2, 3]}")

    frequency_kind = "tick" if frequency == "tick" else frequency[-1]
    allowed_fields = DEFAULT_FIELDS[frequency_kind]
    requested_fields = allowed_fields.copy() if fields is None else _normalize_fields(fields)
    invalid_fields = [field for field in requested_fields if field not in allowed_fields]
    if invalid_fields:
        raise ValueError(
            f"{frequency}: got invalided value {invalid_fields[0]}, choose any in {allowed_fields}"
        )

    slice_filter = None
    if time_slice:
        if frequency == "1d":
            warnings.warn("param [time_slice] only take effect when getting minbar or tick.", stacklevel=3)
        if not isinstance(time_slice, (tuple, list)) or len(time_slice) != 2:
            raise ValueError(
                "time_slice: invalid, expect tuple or list value like ('09:55', '10:11'), "
                f"got {time_slice}"
            )
        slice_filter = client._parse_time_slice(time_slice)

    start, end = _normalize_date_range(client, start_date, end_date)
    if start < dt.date(2010, 1, 4):
        raise ValueError(f"expect start_date >= 20100104, get {start:%Y%m%d}")
    return Request(
        symbols=symbols,
        start=start,
        end=end,
        frequency=frequency,
        fields=requested_fields,
        adjust_type=adjust_type,
        adjust_method=adjust_method,
        rule=rule,
        rank=rank,
        time_slice=slice_filter,
    )


def _normalize_fields(fields: str | Sequence[str]) -> list[str]:
    values = [fields] if isinstance(fields, str) else list(fields)
    if any(not isinstance(value, str) for value in values):
        bad = next(value for value in values if not isinstance(value, str))
        raise ValueError(f"expect string or list of string, got {bad!r}")
    return values


def _normalize_date_range(client: "RQMarketDataClient", start: Any, end: Any) -> tuple[dt.date, dt.date]:
    if start is None and end is None:
        end_value = dt.date.today()
        return client._shift_months(end_value, -3), end_value
    if start is None:
        end_value = dt.date.fromisoformat(client._parse_date_input(end))
        return client._shift_months(end_value, -3), end_value
    if end is None:
        start_value = dt.date.fromisoformat(client._parse_date_input(start))
        return start_value, client._shift_months(start_value, 3)
    start_value = dt.date.fromisoformat(client._parse_date_input(start))
    end_value = dt.date.fromisoformat(client._parse_date_input(end))
    if start_value > end_value:
        raise ValueError(f"invalid date range: [{start!r}, {end!r}]")
    return start_value, end_value


def _load_mapping(client: "RQMarketDataClient", request: Request) -> list[tuple[Any, ...]]:
    candidate = _synthetic_candidate_sql(request.rule, request.rank)
    table_dominant = client._pg_table("future_dominant")
    table_factor = client._pg_table("future_ex_factor")
    table_instruments = client._pg_table("instruments_future")
    sql = f"""
WITH dominant_rows AS (
    SELECT dominant."underlying_symbol", dominant."date", dominant."dominant"
    FROM unnest(%s::varchar[]) requested("underlying_symbol")
    JOIN {table_dominant} dominant
      ON dominant."underlying_symbol" = requested."underlying_symbol"
    WHERE dominant."rule" = %s
      AND dominant."rank" = %s
      AND dominant."date" >= %s
      AND dominant."date" <= %s
),
latest_factor AS (
    SELECT DISTINCT ON ("underlying_symbol")
        "underlying_symbol", "ex_cum_factor" AS "latest_cum_factor"
    FROM {table_factor}
    WHERE "underlying_symbol" = ANY(%s::varchar[])
      AND "rule" = %s
      AND "rank" = %s
      AND "adjust_method" = %s
    ORDER BY "underlying_symbol", "ex_date" DESC
),
mapped AS (
    SELECT dominant_rows.*, {candidate} AS "synthetic_candidate"
    FROM dominant_rows
)
SELECT
    mapped."underlying_symbol",
    mapped."date",
    COALESCE(synthetic."order_book_id", mapped."dominant") AS "source_order_book_id",
    mapped."dominant" AS "dominant_id",
    factor."ex_cum_factor",
    latest_factor."latest_cum_factor"
FROM mapped
LEFT JOIN {table_instruments} synthetic
  ON synthetic."order_book_id" = mapped."synthetic_candidate"
LEFT JOIN {table_factor} factor
  ON factor."underlying_symbol" = mapped."underlying_symbol"
 AND factor."rule" = %s
 AND factor."rank" = %s
 AND factor."adjust_method" = %s
 AND mapped."date" >= factor."ex_date"
 AND (factor."ex_end_date" IS NULL OR mapped."date" <= factor."ex_end_date")
LEFT JOIN latest_factor
  ON latest_factor."underlying_symbol" = mapped."underlying_symbol"
ORDER BY mapped."underlying_symbol", mapped."date";
"""
    params = (
        request.symbols,
        request.rule,
        request.rank,
        request.start,
        request.end,
        request.symbols,
        request.rule,
        request.rank,
        request.adjust_method,
        request.rule,
        request.rank,
        request.adjust_method,
    )
    rows = client._query_pg_rows(sql, params)
    if request.adjust_type != "none":
        missing = [row for row in rows if row[4] is None or row[5] is None]
        if missing:
            affected = sorted({str(row[0]) for row in missing})
            raise ValueError(
                f"Failed to get ex factor! underlying_symbols: {affected}, "
                f"adjust_type: {request.adjust_type}, adjust_method: {request.adjust_method}, "
                f"rule: {request.rule}, rank: {request.rank}"
            )
    return [
        (
            str(symbol),
            date_value,
            str(source_id),
            str(dominant_id),
            _adjustment_factor(cum_factor, latest_factor, request),
        )
        for symbol, date_value, source_id, dominant_id, cum_factor, latest_factor in rows
    ]


def _synthetic_candidate_sql(rule: int, rank: int) -> str:
    if rule == 0 and rank == 1:
        return '"underlying_symbol" || \'88\''
    if rule == 0 and rank == 2:
        return '"underlying_symbol" || \'88A2\''
    if rule == 1 and rank == 2:
        values = ", ".join(f"'{value}'" for value in sorted(INDEX_FUTURES))
        return f'CASE WHEN "underlying_symbol" IN ({values}) THEN "underlying_symbol" || \'88A2\' END'
    if rule == 1 and rank == 3:
        values = ", ".join(f"'{value}'" for value in sorted(INDEX_FUTURES))
        return f'CASE WHEN "underlying_symbol" IN ({values}) THEN "underlying_symbol" || \'88A3\' END'
    return "NULL::varchar"


def _adjustment_factor(cum_factor: Any, latest_factor: Any, request: Request) -> float:
    if request.adjust_type == "none":
        return 0.0 if request.adjust_method.endswith("spread") else 1.0
    cumulative = float(cum_factor)
    latest = float(latest_factor)
    if request.adjust_method.endswith("spread"):
        return cumulative - latest if request.adjust_type == "pre" else cumulative
    return cumulative / latest if request.adjust_type == "pre" else cumulative


def _query_clickhouse(
    client: "RQMarketDataClient",
    request: Request,
    mapping: list[tuple[Any, ...]],
):
    import pandas as pd

    if request.frequency == "tick":
        table_name = "future_tick"
    elif request.frequency == "1d":
        table_name = "future_daily_bar"
    else:
        table_name = f"future_{request.frequency}_bar"
    table = client._table(table_name)
    date_column = "date" if request.frequency == "1d" else "trading_date"
    index_column = "date" if request.frequency == "1d" else "datetime"
    source_ids = tuple(sorted({row[2] for row in mapping}))
    needs_daily = request.frequency == "tick" and bool(set(request.fields) & TICK_DAILY_FIELDS)

    select_parts = [
        "m.underlying_symbol AS underlying_symbol",
        f"b.{client._quote_identifier(index_column)} AS {client._quote_identifier(index_column)}",
        "m.dominant_id AS dominant_id",
    ]
    for field in request.fields:
        expression = _raw_expression(client, field, request.frequency)
        expression = _adjust_expression(expression, field, request)
        select_parts.append(f"{expression} AS {client._quote_identifier(field)}")

    joins = [
        "INNER JOIN dominant_price_map m",
        f"  ON b.order_book_id = m.source_order_book_id AND b.{client._quote_identifier(date_column)} = m.trading_date",
    ]
    if needs_daily:
        daily = client._table("future_daily_bar")
        joins.extend(
            [
                f"LEFT JOIN {daily} daily",
                "  ON daily.order_book_id = b.order_book_id AND daily.date = m.trading_date",
            ]
        )

    where = [
        "b.order_book_id IN %(source_ids)s",
        f"b.{client._quote_identifier(date_column)} >= toDate(%(start)s)",
        f"b.{client._quote_identifier(date_column)} <= toDate(%(end)s)",
    ]
    sql = f"""
SELECT {', '.join(select_parts)}
FROM {table} b
{' '.join(joins)}
WHERE {' AND '.join(where)}
ORDER BY m.underlying_symbol, b.{client._quote_identifier(index_column)}
"""
    params = {
        "source_ids": source_ids,
        "start": request.start.isoformat(),
        "end": request.end.isoformat(),
    }
    mapping_columns = [
        "underlying_symbol",
        "trading_date",
        "source_order_book_id",
        "dominant_id",
        "adjustment_factor",
    ]
    mapping_frame = pd.DataFrame(mapping, columns=mapping_columns)
    # Keep Python date objects: clickhouse-driver's numpy external-table path
    # otherwise promotes Date to datetime64 and sends the wrong wire type.
    mapping_frame["trading_date"] = mapping_frame["trading_date"].astype(object)
    external_tables = [
        {
            "name": "dominant_price_map",
            "structure": [
                ("underlying_symbol", "String"),
                ("trading_date", "Date"),
                ("source_order_book_id", "String"),
                ("dominant_id", "String"),
                ("adjustment_factor", "Float64"),
            ],
            "data": mapping_frame,
        }
    ]
    columns_data, columns_meta = client._get_client().execute(
        sql,
        params=params,
        external_tables=external_tables,
        columnar=True,
        with_column_types=True,
    )
    data = {
        name: client._normalize_clickhouse_column(column, type_name)
        for column, (name, type_name) in zip(columns_data, columns_meta)
    }
    return pd.DataFrame(data)


def _raw_expression(client: "RQMarketDataClient", field: str, frequency: str) -> str:
    quoted = client._quote_identifier(field)
    if frequency != "tick":
        return f"b.{quoted}"
    if field == "open":
        return "if(b.volume = 0, toFloat64(0), daily.open)"
    if field in {"prev_settlement", "limit_up", "limit_down"}:
        return f"daily.{quoted}"
    if field == "change_rate":
        return "b.last / daily.prev_settlement - 1"
    if field == "trading_date":
        return "m.trading_date"
    return f"b.{quoted}"


def _adjust_expression(expression: str, field: str, request: Request) -> str:
    if request.adjust_type != "none" and field == "total_turnover":
        return "toInt64(0)"
    if request.adjust_type == "none" or field not in ADJUST_FIELDS:
        return expression
    if request.adjust_method.endswith("spread"):
        return f"({expression}) + m.adjustment_factor"
    return f"({expression}) * m.adjustment_factor"


def _format_result(client: "RQMarketDataClient", frame: Any, request: Request):
    import pandas as pd

    frame = client._normalize_datetime_columns(frame)
    index_column = "date" if request.frequency == "1d" else "datetime"
    frame[index_column] = pd.to_datetime(frame[index_column])
    if "trading_date" in frame.columns:
        frame["trading_date"] = pd.to_datetime(frame["trading_date"])

    ordered = ["dominant_id"] + [field for field in request.fields if field != "trading_date"]
    if "trading_date" in request.fields:
        ordered.insert(0, "trading_date")
    result = frame.set_index(["underlying_symbol", index_column]).sort_index()
    if request.time_slice is not None and request.frequency != "1d":
        datetimes = result.index.get_level_values(index_column)
        hms = datetimes.hour * 10000 + datetimes.minute * 100 + datetimes.second
        start_hms, end_hms = request.time_slice
        if start_hms > end_hms:
            result = result[(hms >= start_hms) | (hms <= end_hms)]
        else:
            result = result[(hms >= start_hms) & (hms <= end_hms)]
    return result.loc[:, ordered]
