from __future__ import annotations

import datetime as dt
import warnings
from typing import TYPE_CHECKING, Sequence


if TYPE_CHECKING:
    from .market_data import RQMarketDataClient


GREEK_FIELDS = ("iv", "delta", "gamma", "vega", "theta", "rho")


def get_greeks(
    client: "RQMarketDataClient",
    order_book_ids,
    start_date=None,
    end_date=None,
    fields=None,
    model="implied_forward",
    price_type="close",
    frequency="1d",
    market="cn",
):
    client._require_cn_market(market)
    if start_date is None:
        raise ValueError("start_date is expected")
    if model != "implied_forward":
        raise NotImplementedError(
            "local options.get_greeks only supports model='implied_forward'"
        )
    if price_type != "close":
        raise NotImplementedError(
            "local options.get_greeks only supports price_type='close'"
        )
    if frequency not in {"1d", "1m"}:
        raise TypeError("frequency: expect value in ('1d', '1m')")

    ids = _normalize_option_ids(client, order_book_ids)
    selected = _normalize_fields(fields)
    start = client._parse_date_input(start_date)
    end = client._parse_date_input(end_date)
    client._validate_date_range(start, end)

    table = "option_greeks_daily" if frequency == "1d" else "option_greeks_1m"
    time_column = "trading_date" if frequency == "1d" else "datetime"
    unique_fields = list(dict.fromkeys(selected))
    select_columns = ["order_book_id", time_column, *unique_fields]
    select_sql = ", ".join(client._quote_identifier(value) for value in select_columns)
    where = ["order_book_id IN %(order_book_ids)s"]
    params = {"order_book_ids": tuple(ids)}
    if frequency == "1d":
        where.append("trading_date >= toDate(%(start)s)")
        params["start"] = start
        if end is not None:
            where.append("trading_date <= toDate(%(end)s)")
            params["end"] = end
    else:
        where.append("datetime >= toDateTime(%(start_dt)s, 'Asia/Shanghai')")
        params["start_dt"] = f"{start} 00:00:00"
        if end is not None:
            end_exclusive = dt.date.fromisoformat(end) + dt.timedelta(days=1)
            where.append("datetime < toDateTime(%(end_dt)s, 'Asia/Shanghai')")
            params["end_dt"] = f"{end_exclusive.isoformat()} 00:00:00"

    frame = client._query_dataframe(
        f"""
SELECT {select_sql}
FROM {client._table(table)}
WHERE {' AND '.join(where)}
ORDER BY order_book_id, {time_column}
""",
        params,
    )
    if frame.empty:
        return None

    import pandas as pd

    frame[time_column] = pd.to_datetime(frame[time_column]).astype("datetime64[ns]")
    order = {order_book_id: position for position, order_book_id in enumerate(ids)}
    frame["_request_order"] = frame["order_book_id"].map(order)
    frame.sort_values(["_request_order", time_column], inplace=True)
    frame.drop(columns="_request_order", inplace=True)
    result = frame.set_index(["order_book_id", time_column])
    result.index = result.index.set_names(["order_book_id", time_column])
    # .loc intentionally reproduces duplicate field requests from rqdatac.
    return result.loc[:, selected]


def _normalize_option_ids(client: "RQMarketDataClient", value) -> list[str]:
    if isinstance(value, str):
        requested = [value]
    else:
        try:
            requested = list(value)
        except TypeError as exc:
            raise TypeError("order_book_ids: expect a string or list of strings") from exc
    requested = [str(item) for item in requested]
    if not requested:
        raise ValueError("order_book_ids: at least one valid instrument expected, got none")

    rows = client._query_pg_rows(
        f"""
SELECT "order_book_id", "type"
FROM {client._pg_table('all_instruments')}
WHERE "order_book_id" = ANY(%s::varchar[])
""",
        (requested,),
    )
    valid_set = {str(order_book_id) for order_book_id, rq_type in rows if str(rq_type) == "Option"}
    valid: list[str] = []
    seen: set[str] = set()
    for order_book_id in requested:
        if order_book_id not in valid_set:
            warnings.warn(f"invalid order_book_id: {order_book_id}", stacklevel=3)
        elif order_book_id not in seen:
            valid.append(order_book_id)
            seen.add(order_book_id)
    if not valid:
        raise ValueError("order_book_ids: at least one valid instrument expected, got none")
    return valid


def _normalize_fields(value: str | Sequence[str] | None) -> list[str]:
    if value is None:
        fields = list(GREEK_FIELDS)
    elif isinstance(value, str):
        fields = [value]
    else:
        fields = list(value)
    for field in fields:
        if field not in GREEK_FIELDS:
            raise ValueError(
                f"Greeks: got invalided value {field}, choose any in {list(GREEK_FIELDS)}"
            )
    return fields
