from __future__ import annotations

import datetime as dt
import warnings
from typing import Any, Sequence, TYPE_CHECKING


if TYPE_CHECKING:
    from .market_data import RQMarketDataClient


EXCHANGE_DAILY_FIELDS = [
    "open",
    "close",
    "high",
    "low",
    "total_turnover",
    "volume",
    "settlement",
    "prev_settlement",
    "open_interest",
]
CONTINUOUS_CONTRACT_TYPES = ["front_month", "next_month", "current_quarter", "next_quarter"]
TRADING_PARAMETER_FIELDS = [
    "long_margin_ratio",
    "short_margin_ratio",
    "commission_type",
    "open_commission",
    "close_commission",
    "discount_rate",
    "close_commission_today",
    "non_member_limit_rate",
    "client_limit_rate",
    "non_member_limit",
    "client_limit",
    "min_order_quantity",
    "max_order_quantity",
    "min_margin_ratio",
    "trade_unit",
    "price_unit",
]
TRADING_PARAMETER_STRING_FIELDS = {"commission_type", "trade_unit", "price_unit"}
SYNTHETIC_FUTURE_SUFFIXES = ("88", "99", "888", "889", "88A2", "88A3")


def get_contract_multiplier(
    client: "RQMarketDataClient",
    underlying_symbols: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
):
    client._require_cn_market(market)
    symbols = _normalize_strings(underlying_symbols, "underlying_symbols")
    symbols = list(dict.fromkeys(symbols))
    if not symbols:
        return None

    start = client._parse_date_input(start_date)
    end = client._parse_date_input(end_date)
    if end is None:
        end = (dt.date.today() - dt.timedelta(days=1)).isoformat()

    table = client._pg_table("future_contract_multiplier")
    calendar = client._pg_table("trading_dates")
    sql = f"""
WITH ranges AS (
    SELECT
        "underlying_symbol", "effective_date", "cancel_date", "exchange", "contract_multiplier"
    FROM {table}
    WHERE "underlying_symbol" = ANY(%s::varchar[])
),
bounds AS (
    SELECT
        "underlying_symbol",
        GREATEST(min("effective_date"), COALESCE(%s::date, min("effective_date"))) AS "date_min",
        LEAST(max("cancel_date"), %s::date) AS "date_max"
    FROM ranges
    GROUP BY "underlying_symbol"
),
dates AS (
    SELECT bounds."underlying_symbol", calendar."date"
    FROM bounds
    JOIN {calendar} calendar
      ON calendar."is_trading"
     AND calendar."date" >= bounds."date_min"
     AND calendar."date" <= bounds."date_max"
    UNION
    SELECT ranges."underlying_symbol", ranges."effective_date" AS "date"
    FROM ranges
    JOIN bounds USING ("underlying_symbol")
    WHERE ranges."effective_date" >= bounds."date_min"
      AND ranges."effective_date" <= bounds."date_max"
),
expanded AS (
    SELECT
        dates."underlying_symbol",
        dates."date",
        active."exchange",
        active."contract_multiplier"
    FROM dates
    JOIN LATERAL (
        SELECT ranges."exchange", ranges."contract_multiplier"
        FROM ranges
        WHERE ranges."underlying_symbol" = dates."underlying_symbol"
          AND ranges."effective_date" <= dates."date"
        ORDER BY ranges."effective_date" DESC
        LIMIT 1
    ) active ON true
)
SELECT
    0::smallint AS "row_kind",
    bounds."underlying_symbol",
    NULL::date AS "date",
    NULL::varchar AS "exchange",
    NULL::double precision AS "contract_multiplier"
FROM bounds
UNION ALL
SELECT
    1::smallint AS "row_kind",
    expanded."underlying_symbol",
    expanded."date",
    expanded."exchange",
    expanded."contract_multiplier"
FROM expanded
ORDER BY "row_kind", "underlying_symbol", "date";
"""
    rows = client._query_pg_rows(sql, (symbols, start, end))
    valid_symbols = {str(row[1]) for row in rows if int(row[0]) == 0}
    if not valid_symbols:
        return None

    import pandas as pd

    data_rows = [row[1:] for row in rows if int(row[0]) == 1]
    if not data_rows:
        return _empty_contract_multiplier_frame()
    frame = pd.DataFrame(
        data_rows,
        columns=["underlying_symbol", "date", "exchange", "contract_multiplier"],
    )
    frame["date"] = pd.to_datetime(frame["date"])
    frame["exchange"] = frame["exchange"].astype("object")
    frame["contract_multiplier"] = frame["contract_multiplier"].astype("float64")
    return frame.set_index(["underlying_symbol", "date"]).sort_index().loc[
        :, ["exchange", "contract_multiplier"]
    ]


def get_exchange_daily(
    client: "RQMarketDataClient",
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
):
    client._require_cn_market(market)
    selected_fields = _normalize_exchange_daily_fields(fields)
    ids = _normalize_strings(order_book_ids, "order_book_ids")
    valid_ids, exchanges = _validate_future_ids(client, ids)

    start, end = _normalize_three_month_range(client, start_date, end_date)
    table = client._table("future_daily_bar")
    quoted = [client._quote_identifier("order_book_id"), client._quote_identifier("date")]
    quoted.extend(client._quote_identifier(field) for field in selected_fields)
    sql = f"""
SELECT {', '.join(quoted)}
FROM {table}
WHERE {client._quote_identifier('order_book_id')} IN %(order_book_ids)s
  AND {client._quote_identifier('date')} >= toDate(%(start)s)
  AND {client._quote_identifier('date')} <= toDate(%(end)s)
ORDER BY {client._quote_identifier('order_book_id')}, {client._quote_identifier('date')}
"""
    frame = client._query_dataframe(
        sql,
        {"order_book_ids": tuple(valid_ids), "start": start, "end": end},
    )
    if frame.empty:
        return None

    import pandas as pd

    frame = client._normalize_datetime_columns(frame)
    frame["date"] = pd.to_datetime(frame["date"])
    for field in selected_fields:
        frame[field] = frame[field].astype("float64")
    if "total_turnover" in selected_fields:
        dce = frame["order_book_id"].map(exchanges).eq("DCE")
        frame.loc[dce, "total_turnover"] = frame.loc[dce, "total_turnover"].round(-2)
    return frame.set_index(["order_book_id", "date"]).sort_index().loc[:, selected_fields]


def get_continuous_contracts(
    client: "RQMarketDataClient",
    underlying_symbol: Any,
    start_date: str | int | dt.date | dt.datetime | None,
    end_date: str | int | dt.date | dt.datetime | None,
    type: str = "front_month",
    market: str = "cn",
):
    client._require_cn_market(market)
    if type not in CONTINUOUS_CONTRACT_TYPES:
        raise ValueError(
            f"type: got invalided value {type}, choose any in {CONTINUOUS_CONTRACT_TYPES}"
        )
    start, end = _normalize_three_month_range(client, start_date, end_date)
    sql = f"""
SELECT "date", "order_book_id"
FROM {client._pg_table('future_continuous_contracts')}
WHERE "underlying_symbol" = %s::varchar
  AND "continuous_type" = %s
  AND "date" >= %s
  AND "date" <= %s
ORDER BY "date";
"""
    rows = client._query_pg_rows(sql, (underlying_symbol, type, start, end))

    import pandas as pd

    if not rows:
        result = pd.Series([], dtype="object", name="order_book_id")
        result.index.name = "date"
        return result
    result = pd.Series(
        [str(row[1]) for row in rows],
        index=pd.to_datetime([row[0] for row in rows]),
        dtype="object",
        name="order_book_id",
    )
    result.index.name = "date"
    return result


def get_trading_parameters(
    client: "RQMarketDataClient",
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
):
    client._require_cn_market(market)
    selected_fields = _normalize_trading_parameter_fields(fields)
    ids = _normalize_strings(order_book_ids, "order_book_ids")
    valid_ids, _ = _validate_future_ids(client, ids)
    valid_ids = [
        order_book_id
        for order_book_id in valid_ids
        if not order_book_id.endswith(SYNTHETIC_FUTURE_SUFFIXES)
    ]
    if not valid_ids:
        return None

    if (start_date is None) != (end_date is None):
        raise ValueError("start_date and end_date should be used together or not at the same time")
    current_trading_date = _current_trading_parameter_date(client)
    if start_date is None:
        start = end = current_trading_date.isoformat()
    else:
        start = client._parse_date_input(start_date)
        end = client._parse_date_input(end_date)
        client._validate_date_range(start, end)
        end = min(dt.date.fromisoformat(end), current_trading_date).isoformat()
        if dt.date.fromisoformat(end) < dt.date.fromisoformat(start):
            return None

    parameter_table = client._pg_table("future_trading_parameters")
    instrument_table = client._pg_table("instruments_future")
    calendar_table = client._pg_table("trading_dates")
    selected_sql = ""
    if selected_fields:
        selected_sql = ",\n    " + ",\n    ".join(
            f'active."{field}"' for field in selected_fields
        )
        active_columns = ", ".join(f'events."{field}"' for field in selected_fields)
        active_join = f"""
LEFT JOIN LATERAL (
    SELECT {active_columns}
    FROM events
    WHERE events."order_book_id" = dates."order_book_id"
      AND events."trading_date" <= dates."trading_date"
    ORDER BY events."trading_date" DESC
    LIMIT 1
) active ON true
"""
    else:
        active_join = ""

    sql = f"""
WITH requested AS (
    SELECT DISTINCT
        instruments."order_book_id",
        instruments."listed_date",
        instruments."de_listed_date"
    FROM {instrument_table} instruments
    WHERE instruments."order_book_id" = ANY(%s::varchar[])
      AND instruments."listed_date" <= %s::date
      AND instruments."de_listed_date" >= %s::date
),
events AS (
    SELECT parameters.*
    FROM {parameter_table} parameters
    WHERE parameters."order_book_id" = ANY(%s::varchar[])
),
dates AS (
    SELECT requested."order_book_id", calendar."date" AS "trading_date"
    FROM requested
    JOIN {calendar_table} calendar
      ON calendar."is_trading"
     AND calendar."date" >= %s::date
     AND calendar."date" <= %s::date
     AND calendar."date" >= requested."listed_date"
     AND calendar."date" <= requested."de_listed_date"
)
SELECT
    dates."order_book_id",
    dates."trading_date"{selected_sql}
FROM dates
{active_join}
WHERE EXISTS (SELECT 1 FROM events)
ORDER BY dates."order_book_id", dates."trading_date";
"""
    rows = client._query_pg_rows(sql, (valid_ids, end, start, valid_ids, start, end))
    if not rows:
        return None

    import pandas as pd

    frame = pd.DataFrame(rows, columns=["order_book_id", "trading_date", *selected_fields])
    frame["trading_date"] = pd.to_datetime(frame["trading_date"])
    for field in selected_fields:
        if field in TRADING_PARAMETER_STRING_FIELDS:
            frame[field] = frame[field].astype("object")
        else:
            frame[field] = frame[field].astype("float64")
    return frame.set_index(["order_book_id", "trading_date"]).sort_index().loc[
        :, selected_fields
    ]


def _normalize_strings(value: str | Sequence[str], name: str) -> list[str]:
    values = [value] if isinstance(value, str) else list(value)
    for item in values:
        if not isinstance(item, str):
            raise ValueError(f"expect string or list of string for {name}, got {item!r}")
    return values


def _normalize_exchange_daily_fields(fields: str | Sequence[str] | None) -> list[str]:
    if fields is None:
        return EXCHANGE_DAILY_FIELDS.copy()
    values = _normalize_strings(fields, "fields")
    invalid = [field for field in values if field not in EXCHANGE_DAILY_FIELDS]
    if invalid:
        raise ValueError(
            f"fields: got invalided value {invalid[0]}, choose any in {EXCHANGE_DAILY_FIELDS}"
        )
    # rqdatac intentionally de-duplicates explicitly requested fields via set.
    return list(set(values))


def _normalize_trading_parameter_fields(fields: str | Sequence[str] | None) -> list[str]:
    if fields is None:
        return TRADING_PARAMETER_FIELDS.copy()
    values = _normalize_strings(fields, "fields")
    invalid = [field for field in values if field not in TRADING_PARAMETER_FIELDS]
    if invalid:
        raise ValueError(
            f"fields: got invalided value {invalid[0]}, choose any in {TRADING_PARAMETER_FIELDS}"
        )
    requested = set(values)
    return [field for field in TRADING_PARAMETER_FIELDS if field in requested]


def _current_trading_parameter_date(client: "RQMarketDataClient") -> dt.date:
    now = dt.datetime.now()
    today = now.date()
    rows = client._query_pg_rows(
        f"""
SELECT "date", "is_trading"
FROM {client._pg_table('trading_dates')}
WHERE "date" = %s::date
   OR ("is_trading" AND "date" > %s::date)
ORDER BY "date";
""",
        (today, today),
    )
    is_today_trading = any(row[0] == today and bool(row[1]) for row in rows)
    if is_today_trading and now.hour < 18:
        return today
    next_dates = [row[0] for row in rows if row[0] > today and bool(row[1])]
    if not next_dates:
        raise RuntimeError("local trading calendar has no next trading date")
    return next_dates[0]


def _validate_future_ids(
    client: "RQMarketDataClient",
    order_book_ids: list[str],
) -> tuple[list[str], dict[str, str]]:
    unique_ids = list(dict.fromkeys(order_book_ids))
    sql = f"""
SELECT all_items."order_book_id", all_items."type", futures."exchange"
FROM {client._pg_table('all_instruments')} all_items
LEFT JOIN {client._pg_table('instruments_future')} futures
  ON futures."order_book_id" = all_items."order_book_id"
WHERE all_items."order_book_id" = ANY(%s::varchar[]);
"""
    found = {
        str(row[0]): (str(row[1]), str(row[2] or ""))
        for row in client._query_pg_rows(sql, (unique_ids,))
    }
    valid: list[str] = []
    exchanges: dict[str, str] = {}
    for order_book_id in unique_ids:
        metadata = found.get(order_book_id)
        if metadata is None:
            warnings.warn(f"invalid order_book_id: {order_book_id}", stacklevel=3)
            continue
        rq_type, exchange = metadata
        if rq_type != "Future":
            warnings.warn(
                f"expect ('Future',) instrument, got {rq_type}({order_book_id}), ignored",
                stacklevel=3,
            )
            continue
        valid.append(order_book_id)
        exchanges[order_book_id] = exchange
    if not valid:
        raise ValueError("order_book_ids: at least one valid instrument expected, got none")
    return valid, exchanges


def _normalize_three_month_range(
    client: "RQMarketDataClient",
    start_date: Any,
    end_date: Any,
) -> tuple[str, str]:
    if start_date is None and end_date is None:
        end = dt.date.today()
        return client._shift_months(end, -3).isoformat(), end.isoformat()
    if start_date is None:
        end = dt.date.fromisoformat(client._parse_date_input(end_date))
        return client._shift_months(end, -3).isoformat(), end.isoformat()
    if end_date is None:
        start = dt.date.fromisoformat(client._parse_date_input(start_date))
        return start.isoformat(), client._shift_months(start, 3).isoformat()
    start = client._parse_date_input(start_date)
    end = client._parse_date_input(end_date)
    if dt.date.fromisoformat(start) > dt.date.fromisoformat(end):
        raise ValueError(f"invalid date range: [{start_date!r}, {end_date!r}]")
    return start, end


def _empty_contract_multiplier_frame():
    import pandas as pd

    index = pd.MultiIndex.from_arrays(
        [pd.Index([], dtype="object"), pd.DatetimeIndex([])],
        names=["underlying_symbol", "date"],
    )
    return pd.DataFrame(
        {
            "exchange": pd.Series(dtype="object"),
            "contract_multiplier": pd.Series(dtype="float64"),
        },
        index=index,
    )
