from __future__ import annotations

import datetime as dt
from typing import TYPE_CHECKING, Sequence


if TYPE_CHECKING:
    from .market_data import RQMarketDataClient


VALID_FIELDS = ("VL_PCR", "OI_PCR", "AM_PCR", "skew", "iv_025_dela", "iv_minus_025_dela")


def get_indicators(
    client: "RQMarketDataClient",
    underlying_symbols,
    maturity,
    start_date=None,
    end_date=None,
    fields=None,
    market="cn",
):
    client._require_cn_market(market)
    symbols = _normalize_symbols(underlying_symbols)
    if isinstance(maturity, int) and not isinstance(maturity, bool):
        maturity = str(maturity)
    if not isinstance(maturity, str):
        raise ValueError(f"maturity: expect a string, got {maturity}")
    selected = _normalize_fields(fields)
    selected_set = set(selected)
    query_fields = list(dict.fromkeys(selected))
    start, end = _normalize_date_range(client, start_date, end_date)

    select_suffix = ", " + ", ".join(
        client._pg_quote_identifier(field) for field in query_fields
    ) if query_fields else ""
    rows = client._query_pg_rows(
        f"""
SELECT "underlying_symbol", "date", "field_order"{select_suffix}
FROM {client._pg_table('option_indicators')}
WHERE "underlying_symbol" = ANY(%s::varchar[])
  AND "maturity" = %s
  AND "date" >= %s::date
  AND "date" <= %s::date
ORDER BY "underlying_symbol", "date";
""",
        (symbols, maturity, start, end),
    )
    if not rows:
        return None

    import pandas as pd

    frame = pd.DataFrame(
        rows,
        columns=["underlying_symbol", "date", "_field_order", *query_fields],
    )
    frame["date"] = pd.to_datetime(frame["date"]).astype("datetime64[ns]")
    for field in query_fields:
        frame[field] = pd.to_numeric(frame[field], errors="coerce").astype("float64")
    output_fields: list[str] = []
    for value in frame["_field_order"]:
        for field in str(value).split(","):
            if field in selected_set and field not in output_fields:
                output_fields.append(field)
    frame.drop(columns="_field_order", inplace=True)
    result = frame.set_index(["underlying_symbol", "date"])
    result.index = result.index.set_names(["underlying_symbol", "date"])
    return result.loc[:, output_fields]


def _normalize_symbols(value) -> list[str]:
    if isinstance(value, str):
        return [value]
    values = list(value)
    for item in values:
        if not isinstance(item, str):
            raise ValueError(f"expect a string, got {item}")
    return values


def _normalize_fields(value: str | Sequence[str] | None) -> list[str]:
    if value is None:
        fields = list(VALID_FIELDS)
    elif isinstance(value, str):
        fields = [value]
    else:
        fields = list(value)
    for field in fields:
        if field not in VALID_FIELDS:
            raise ValueError(
                f"fields: got invalided value {field}, choose any in {list(VALID_FIELDS)}"
            )
    return list(dict.fromkeys(fields))


def _normalize_date_range(client: "RQMarketDataClient", start_date, end_date) -> tuple[str, str]:
    today = dt.date.today()
    start_text = client._parse_date_input(start_date)
    end_text = client._parse_date_input(end_date)
    if start_text is None and end_text is None:
        end = today
        start = client._shift_months(end, -3)
    elif start_text is None:
        end = dt.date.fromisoformat(end_text)
        start = client._shift_months(end, -3)
    elif end_text is None:
        start = dt.date.fromisoformat(start_text)
        end = client._shift_months(start, 3)
    else:
        start = dt.date.fromisoformat(start_text)
        end = dt.date.fromisoformat(end_text)
    if start > end:
        raise ValueError(f"invalid date range: [{start_date!r}, {end_date!r}]")
    return start.isoformat(), end.isoformat()
