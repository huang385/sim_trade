"""Local/LAN query client for ymm_data_sdk registered market-data methods.

This module targets the mirror tables under ``market_data_RQ`` and is packaged
inside ``ymm_data_sdk`` so installed clients do not depend on the server repository's
top-level scripts.
"""

from __future__ import annotations

import datetime as dt
import re
import time
import warnings
from collections.abc import Sequence
from dataclasses import dataclass, replace
from typing import Any, Literal
from zoneinfo import ZoneInfo

from clickhouse_driver import Client

from ..exceptions import YMMDataSchemaError
from ..instrument import Instrument
from .adjustments import (
    apply_adjustment,
    normalize_adjust_type,
    required_adjustment_columns,
)
from .suspensions import (
    apply_skip_suspended,
    required_suspension_columns,
)
from .trading_periods import get_trading_periods as query_trading_periods
from .update_status import UpdateStatusRouter

ConnectionMode = Literal["local", "lan"]
Frequency = Literal["tick", "1m", "5m", "15m", "30m", "60m", "120m", "240m", "1d"]

CH_TIMEZONE = "Asia/Shanghai"
SHANGHAI = ZoneInfo(CH_TIMEZONE)
FUTURE_TRADING_DATE_SWITCH = dt.time(20, 55)

_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_FUTURE_RE = re.compile(r"^[A-Za-z_]+\d+[A-Za-z]?$")
_FUTURE_OPTION_RE = re.compile(r"^[A-Za-z_]+\d{3,4}[-]?[CPcp][-]?\d+")
_ETF_OPTION_NUMERIC_RE = re.compile(r"^\d{8}(?:\.[A-Za-z]+)?$")
_PRICE_INDEX_COLUMNS = {"order_book_id", "date", "datetime"}


_CONNECTION_PRESETS: dict[ConnectionMode, dict[str, Any]] = {
    "local": {
        "ch_host": "127.0.0.1",
        "ch_port": 9000,
        "ch_http_port": 8123,
        "ch_database": "market_data_RQ",
        "ch_username": "default",
        "ch_password": "",
        "pg_host": "127.0.0.1",
        "pg_port": 5432,
        "pg_database": "market_meta_RQ",
        "pg_username": "postgres",
        "pg_password": "",
    },
    # Native-port LAN forwarding may differ by deployment. Override ch_port
    # explicitly if the production server exposes a different native port.
    "lan": {
        "ch_host": "192.168.11.172",
        "ch_port": 9000,
        "ch_http_port": 8123,
        "ch_database": "market_data_RQ",
        "ch_username": "",
        "ch_password": "",
        "pg_host": "192.168.11.172",
        "pg_port": 25432,
        "pg_database": "market_meta_RQ",
        "pg_username": "postgres",
        "pg_password": "",
    },
}

_RQ_TYPE_TO_ASSET = {
    "CS": "equity",
    "ETF": "equity",
    "LOF": "equity",
    "INDX": "equity",
    "Convertible": "equity",
    "FUND": "equity",
    "REITs": "equity",
    "Repo": "equity",
    "Spot": "equity",
    "Future": "future",
    "FutureArbitrage": "future",
}
_PRICE_CHANGE_RATE_TYPES = {"CS", "ETF", "LOF", "INDX", "Convertible", "Future"}


def _shanghai_now() -> dt.datetime:
    return dt.datetime.now(SHANGHAI)


@dataclass(frozen=True)
class ClickHouseRQConfig:
    host: str = "127.0.0.1"
    port: int = 9000
    http_port: int = 8123
    database: str = "market_data_RQ"
    username: str = "default"
    password: str = ""
    secure: bool = False


@dataclass(frozen=True)
class PostgreSQLRQConfig:
    host: str = "127.0.0.1"
    port: int = 5432
    database: str = "market_meta_RQ"
    username: str = "postgres"
    password: str = ""
    schema: str = "public"


@dataclass(frozen=True)
class _InstrumentLookup:
    order_book_id: str
    rq_type: str
    detail_table: str | None
    asset_type: str


@dataclass(frozen=True)
class _Route:
    table: str
    table_name: str
    asset_type: str
    frequency: str
    frequency_kind: str
    date_column: str
    datetime_column: str | None
    order_by: tuple[str, ...]


class RQMarketDataClient:
    """Query client for locally mirrored RQ market data.

    Public API deliberately starts close to ``rqdatac.get_price``:

    ``get_price(order_book_ids, start_date, end_date, frequency, fields, ...)``

    The current implementation covers the tables already designed/loaded:
    equity/future daily, 1m, and tick; commodity/ETF option daily and 1m. Option
    tick can be added by extending ``_resolve_table`` once those tables exist.
    """

    _BAR_FREQS = {"1m", "5m", "15m", "30m", "60m", "120m", "240m"}
    _FREQ_ALIASES = {
        "day": "1d",
        "daily": "1d",
        "d": "1d",
        "bar": "1m",
        "1min": "1m",
        "1minute": "1m",
        "m1": "1m",
    }
    _FIELD_GROUPS = {
        "bar_basic": (
            "datetime",
            "trading_date",
            "date",
            "open",
            "high",
            "low",
            "close",
            "volume",
            "total_turnover",
        ),
        "daily_basic": (
            "date",
            "open",
            "high",
            "low",
            "close",
            "volume",
            "total_turnover",
        ),
        "daily_plus": (
            "prev_close",
            "limit_up",
            "limit_down",
            "settlement",
            "prev_settlement",
            "open_interest",
            "day_session_open",
        ),
        "tick_basic": (
            "trading_date",
            "date",
            "time",
            "datetime",
            "last",
            "volume",
            "total_turnover",
            "open_interest",
        ),
        "quote": (
            "a1",
            "b1",
            "a1_v",
            "b1_v",
            "a2",
            "b2",
            "a2_v",
            "b2_v",
            "a3",
            "b3",
            "a3_v",
            "b3_v",
            "a4",
            "b4",
            "a4_v",
            "b4_v",
            "a5",
            "b5",
            "a5_v",
            "b5_v",
        ),
    }
    _DAYBAR_DEFAULT_FIELDS = {
        "common": ("open", "close", "high", "low", "total_turnover", "volume", "prev_close"),
        "future": ("settlement", "prev_settlement", "open_interest", "limit_up", "limit_down", "day_session_open"),
        "stock": ("limit_up", "limit_down", "num_trades"),
        "fund": ("limit_up", "limit_down", "num_trades", "iopv"),
        "spot": ("settlement", "prev_settlement", "open_interest", "limit_up", "limit_down"),
        "option": (
            "open_interest",
            "strike_price",
            "contract_multiplier",
            "prev_settlement",
            "settlement",
            "limit_up",
            "limit_down",
            "day_session_open",
        ),
        "convertible": ("limit_up", "limit_down", "num_trades"),
        "index": (),
        "repo": ("num_trades",),
    }
    _MINBAR_DEFAULT_FIELDS = {
        "common": ("open", "close", "high", "low", "total_turnover", "volume"),
        "future": ("trading_date", "open_interest"),
        "stock": ("num_trades",),
        "fund": ("num_trades", "iopv"),
        "spot": ("trading_date", "open_interest"),
        "option": ("trading_date", "open_interest"),
        "convertible": ("num_trades",),
        "index": (),
        "repo": (),
    }
    _EQUITY_TICK_COLUMNS = (
        "trading_date", "open", "last", "high", "low", "prev_close", "volume",
        "total_turnover", "limit_up", "limit_down", "a1", "a2", "a3", "a4",
        "a5", "b1", "b2", "b3", "b4", "b5", "a1_v", "a2_v", "a3_v",
        "a4_v", "a5_v", "b1_v", "b2_v", "b3_v", "b4_v", "b5_v",
        "change_rate", "num_trades",
    )
    _FUND_TICK_COLUMNS = _EQUITY_TICK_COLUMNS + ("iopv", "prev_iopv")
    _FUTURE_TICK_COLUMNS = (
        "trading_date", "open", "last", "high", "low", "prev_settlement",
        "prev_close", "volume", "open_interest", "total_turnover", "limit_up",
        "limit_down", "a1", "a2", "a3", "a4", "a5", "b1", "b2", "b3",
        "b4", "b5", "a1_v", "a2_v", "a3_v", "a4_v", "a5_v", "b1_v",
        "b2_v", "b3_v", "b4_v", "b5_v", "change_rate",
    )
    _ETF_OPTION_TICK_COLUMNS = _FUTURE_TICK_COLUMNS + ("num_trades",)
    _OPEN_AUCTION_FIELDS = (
        "last",
        "high",
        "low",
        "volume",
        "total_turnover",
        "open_interest",
        "a1",
        "a2",
        "a3",
        "a4",
        "a5",
        "b1",
        "b2",
        "b3",
        "b4",
        "b5",
        "a1_v",
        "a2_v",
        "a3_v",
        "a4_v",
        "a5_v",
        "b1_v",
        "b2_v",
        "b3_v",
        "b4_v",
        "b5_v",
    )

    def __init__(
        self,
        connection_mode: ConnectionMode = "local",
        *,
        ch_host: str | None = None,
        ch_port: int | None = None,
        ch_http_port: int | None = None,
        ch_database: str | None = None,
        ch_username: str | None = None,
        ch_password: str | None = None,
        pg_host: str | None = None,
        pg_port: int | None = None,
        pg_database: str | None = None,
        pg_username: str | None = None,
        pg_password: str | None = None,
        pg_schema: str = "public",
        pg_connection: Any | None = None,
        secure: bool = False,
        client: Client | None = None,
        arrow_client: Any | None = None,
        settings: dict[str, Any] | None = None,
    ) -> None:
        if connection_mode not in _CONNECTION_PRESETS:
            raise ValueError(f"unsupported connection_mode: {connection_mode!r}")
        preset = dict(_CONNECTION_PRESETS[connection_mode])
        self.config = ClickHouseRQConfig(
            host=str(ch_host if ch_host is not None else preset["ch_host"]),
            port=int(ch_port if ch_port is not None else preset["ch_port"]),
            http_port=int(ch_http_port if ch_http_port is not None else preset["ch_http_port"]),
            database=str(ch_database if ch_database is not None else preset["ch_database"]),
            username=str(ch_username if ch_username is not None else preset["ch_username"]),
            password=str(ch_password if ch_password is not None else preset["ch_password"]),
            secure=secure,
        )
        self.pg_config = PostgreSQLRQConfig(
            host=str(pg_host if pg_host is not None else preset["pg_host"]),
            port=int(pg_port if pg_port is not None else preset["pg_port"]),
            database=str(pg_database if pg_database is not None else preset["pg_database"]),
            username=str(pg_username if pg_username is not None else preset["pg_username"]),
            password=str(pg_password if pg_password is not None else preset["pg_password"]),
            schema=pg_schema,
        )
        self.client = client
        self._external_client = client is not None
        self.arrow_client = arrow_client
        self._external_arrow_client = arrow_client is not None
        self._arrow_pool_manager = None
        self.pg_connection = pg_connection
        self._external_pg_connection = pg_connection is not None
        self.settings = dict(settings or {})
        self._schema_cache: dict[str, dict[str, str]] = {}
        self._schema_signature_cache: dict[str, tuple[tuple[str, ...], ...]] = {}
        self._pg_schema_cache: dict[str, tuple[str, ...]] = {}
        self._instrument_lookup_cache: dict[str, _InstrumentLookup] = {}
        self._status_router: UpdateStatusRouter | None = None
        self.futures = _ClientFuturesNamespace(self)

    def close(self) -> None:
        if self.client is not None and not self._external_client:
            try:
                self.client.disconnect()
            except Exception:
                pass
            self.client = None
        if self.arrow_client is not None and not self._external_arrow_client:
            try:
                self.arrow_client.close()
            except Exception:
                pass
            self.arrow_client = None
        if self._arrow_pool_manager is not None:
            try:
                self._arrow_pool_manager.clear()
            except Exception:
                pass
            self._arrow_pool_manager = None
        if self.pg_connection is not None and not self._external_pg_connection:
            try:
                self.pg_connection.close()
            except Exception:
                pass
            self.pg_connection = None

    def warmup(self) -> dict[str, Any]:
        """Open local connections and cache schemas used by common queries."""
        started = time.perf_counter()
        import numpy  # noqa: F401
        import pandas  # noqa: F401

        imports_elapsed = time.perf_counter() - started

        ch_started = time.perf_counter()
        self._get_arrow_client().command("SELECT 1")
        for table in ("equity_daily_bar", "equity_1m_bar"):
            self._describe_table(table)
        ch_elapsed = time.perf_counter() - ch_started

        pg_started = time.perf_counter()
        with self._get_pg_connection().cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
        for table in ("all_instruments", "trading_dates"):
            self._pg_columns(table)
        pg_elapsed = time.perf_counter() - pg_started

        return {
            "imports_seconds": round(imports_elapsed, 6),
            "clickhouse_seconds": round(ch_elapsed, 6),
            "postgresql_seconds": round(pg_elapsed, 6),
            "total_seconds": round(time.perf_counter() - started, 6),
            "clickhouse": "ok",
            "postgresql": "ok",
        }

    def __enter__(self) -> "RQMarketDataClient":
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def get_price(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        frequency: str = "1d",
        fields: str | Sequence[str] | None = None,
        adjust_type: str = "pre",
        skip_suspended: bool = False,
        expect_df: bool = True,
        time_slice: tuple[str | dt.time, str | dt.time] | None = None,
        market: str = "cn",
        **kwargs: Any,
    ):
        """Query local RQ market data.

        Parameters mostly follow ``rqdatac.get_price``. Differences:
        - ``order_book_id`` is the canonical identifier column in the returned data.
        - ``start_date`` and ``end_date`` are trading-date boundaries. If a
          datetime-like value is passed, the time component is ignored. Use
          ``time_slice`` for intraday time windows.
        - ``adjust_type`` is applied dynamically from local RQ factor tables;
          the ClickHouse mirror tables stay raw/none.
        - ``skip_suspended`` filters CS and Convertible rows whose trading date
          is present in local suspension tables.
        - By default routing is based on ``market_meta_RQ.public.all_instruments``.
        """
        if market != "cn":
            raise ValueError("only market='cn' is supported")
        if not isinstance(skip_suspended, bool):
            raise AssertionError("'skip_suspended' should be a bool")
        if not isinstance(expect_df, bool):
            raise AssertionError("'expect_df' should be a bool")
        if expect_df is False:
            warnings.warn(
                "'expect_df=False' is deprecated, and will be removed in future",
                category=DeprecationWarning,
                stacklevel=2,
            )
        if "adjusted" in kwargs:
            adjust_type = "pre" if kwargs.pop("adjusted") else "none"
        if kwargs:
            raise ValueError(f"unknown kwargs: {kwargs}")
        normalized_adjust_type = normalize_adjust_type(adjust_type)

        ids = self._normalize_order_book_ids(order_book_ids)
        freq = self._normalize_frequency(frequency)
        start = self._parse_date_input(start_date)
        end = self._parse_date_input(end_date)
        if time_slice and freq == "1d":
            warnings.warn("param [time_slice] only take effect when getting minbar or tick.", stacklevel=2)
            slice_filter = None
        else:
            slice_filter = self._parse_time_slice(time_slice)

        route_to_ids: dict[_Route, list[str]] = {}
        lookups = self.get_instrument_types(ids)
        for order_book_id in ids:
            lookup = lookups.get(order_book_id)
            route = self._resolve_route(order_book_id, freq, lookup)
            route_to_ids.setdefault(route, []).append(order_book_id)

        frames = []
        empty_frames = []
        source_segments: list[dict[str, Any]] = []
        source_warnings: list[str] = []
        visible_columns: list[str] = []
        for route, route_ids in route_to_ids.items():
            table_columns = self._describe_table(route.table)
            extra_fields = required_adjustment_columns(
                adjust_type=normalized_adjust_type,
                frequency=freq,
                instrument_types=[lookups[order_book_id].get("type") for order_book_id in route_ids],
                available_columns=table_columns,
            )
            for column in required_suspension_columns(
                skip_suspended=skip_suspended,
                frequency=freq,
                instrument_types=[lookups[order_book_id].get("type") for order_book_id in route_ids],
                available_columns=table_columns,
            ):
                if column not in extra_fields:
                    extra_fields.append(column)
            segments = self._get_status_router().segments(
                asset_type=route.asset_type,
                frequency=route.frequency,
                start_date=start,
                end_date=end,
            )
            for segment in segments:
                segment_route = route
                segment_columns = table_columns
                if segment.source == "live":
                    live_table = self._table(route.table_name, database="live_market_data_RQ")
                    self._ensure_live_compatible(route.table, live_table)
                    segment_route = replace(route, table=live_table)
                    segment_columns = self._describe_table(live_table)
                sql, params, route_visible_columns = self._build_price_sql(
                    route=segment_route,
                    order_book_ids=route_ids,
                    fields=fields,
                    instrument_types=[
                        lookups[order_book_id].get("type") for order_book_id in route_ids
                    ],
                    start=segment.start_date,
                    end=segment.end_date,
                    time_slice=slice_filter,
                    table_columns=segment_columns,
                    extra_fields=extra_fields,
                )
                for column in route_visible_columns:
                    if column not in visible_columns:
                        visible_columns.append(column)
                if segment.source == "none":
                    empty_frames.append(
                        self._query_dataframe(
                            f"SELECT * FROM ({sql}) AS pending_daily_schema LIMIT 0",
                            params,
                        )
                    )
                else:
                    frames.append(self._query_dataframe(sql, params))
                source_segments.append(
                    {
                        **segment.as_dict(),
                        "asset_type": route.asset_type,
                        "frequency": route.frequency,
                        "dataset": f"{route.asset_type}_{route.frequency}",
                    }
                )
                if segment.warning and segment.warning not in source_warnings:
                    source_warnings.append(segment.warning)

        import pandas as pd

        if len(frames) == 1:
            result_df = frames[0]
        elif frames:
            result_df = pd.concat(frames, ignore_index=True, sort=False)
        elif len(empty_frames) == 1:
            result_df = empty_frames[0]
        elif empty_frames:
            result_df = pd.concat(empty_frames, ignore_index=True, sort=False)
        else:
            result_df = pd.DataFrame(columns=visible_columns)
        result_df = self._normalize_datetime_columns(result_df)
        result_df = apply_adjustment(
            result_df,
            adjust_type=normalized_adjust_type,
            frequency=freq,
            instrument_lookup=lookups,
            end_date=end,
            pg_connection=self._get_pg_connection(),
            pg_schema=self.pg_config.schema,
        )
        result_df = apply_skip_suspended(
            result_df,
            skip_suspended=skip_suspended,
            frequency=freq,
            instrument_lookup=lookups,
            pg_connection=self._get_pg_connection(),
            pg_schema=self.pg_config.schema,
        )
        result_df = self._format_price_result(
            result_df,
            frequency=freq,
            visible_columns=visible_columns,
            sort_index=len(frames) > 1,
        )
        result_df.attrs["ymm_data_sdk"] = {
            "schema_version": 1,
            "source_segments": source_segments,
            "warnings": source_warnings,
        }
        for message in source_warnings:
            warnings.warn(message, RuntimeWarning, stacklevel=2)
        if expect_df:
            return result_df

        if len(ids) != 1:
            raise RuntimeError(
                "Panel has been removed since pandas's version >= 0.25, "
                "you could set 'expect_df=True' and then get a MultiIndex DataFrame"
            )
        index_name = "date" if freq == "1d" else "datetime"
        try:
            result = result_df.xs(ids[0], level="order_book_id", drop_level=True)
            return result.iloc[:, 0] if len(result.columns) == 1 else result
        except KeyError:
            empty_index = pd.Index([], name=index_name)
            if len(result_df.columns) == 1:
                return pd.Series(index=empty_index, name=result_df.columns[0], dtype=result_df.dtypes.iloc[0])
            return pd.DataFrame(columns=list(result_df.columns), index=empty_index)

    def get_price_change_rate(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        expect_df: bool = True,
        market: str = "cn",
    ):
        """Return daily close-to-close change rates for supported local assets."""
        self._require_cn_market(market)
        ids = self._normalize_order_book_ids(order_book_ids)
        lookups = self.get_instrument_types(ids)
        supported_ids = [
            order_book_id
            for order_book_id in ids
            if lookups.get(order_book_id, {}).get("type") in _PRICE_CHANGE_RATE_TYPES
        ]
        if not supported_ids:
            return None

        start = self._parse_date_input(start_date)
        end = self._parse_date_input(end_date)
        if start is None and end is None:
            today = dt.date.today()
            end = today.isoformat()
            start = (today - dt.timedelta(days=92)).isoformat()
        elif start is None:
            end_date_obj = dt.date.fromisoformat(end)  # type: ignore[arg-type]
            start = (end_date_obj - dt.timedelta(days=92)).isoformat()
        elif end is None:
            end = start
        self._validate_date_range(start, end)

        query_start = (dt.date.fromisoformat(start) - dt.timedelta(days=92)).isoformat()
        price_df = self.get_price(
            supported_ids,
            start_date=query_start,
            end_date=end,
            frequency="1d",
            fields=["close"],
            adjust_type="post",
            skip_suspended=False,
            expect_df=True,
            market=market,
        )

        import pandas as pd

        if price_df is None or price_df.empty:
            return None
        frame = price_df.reset_index()
        frame["date"] = pd.to_datetime(frame["date"], errors="coerce").dt.normalize()
        pivot = (
            frame.dropna(subset=["date"])
            .pivot_table(index="date", columns="order_book_id", values="close", aggfunc="last")
            .sort_index()
        )
        pivot = pivot.reindex(columns=supported_ids)
        rates = pivot.pct_change(fill_method=None)
        result = rates.loc[
            (rates.index >= pd.Timestamp(start))
            & (rates.index <= pd.Timestamp(end))
        ]
        result.index.name = "date"
        result.columns.name = "order_book_id"
        result = result.dropna(axis=1, how="all")
        if result.empty or result.shape[1] == 0:
            return None
        if expect_df:
            return result
        if result.shape[1] == 1:
            return result.iloc[:, 0].rename(str(result.columns[0]))
        return result

    def get_vwap(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        frequency: str = "1d",
    ):
        """Return volume weighted average price from local bar tables."""
        price_df = self.get_price(
            order_book_ids,
            start_date=start_date,
            end_date=end_date,
            frequency=frequency,
            fields=["total_turnover", "volume"],
            adjust_type="none",
            skip_suspended=False,
            expect_df=True,
            market="cn",
        )

        import numpy as np
        import pandas as pd

        if price_df is None or price_df.empty:
            empty_index = price_df.index if price_df is not None else None
            return pd.Series(dtype="float64", name="vwap", index=empty_index)
        turnover = pd.to_numeric(price_df["total_turnover"], errors="coerce")
        volume = pd.to_numeric(price_df["volume"], errors="coerce")
        turnover_values = turnover.to_numpy(dtype="float64")
        volume_values = volume.to_numpy(dtype="float64")
        values = np.full_like(turnover_values, np.nan, dtype="float64")
        np.divide(turnover_values, volume_values, out=values, where=volume_values != 0)
        series = pd.Series(values, index=price_df.index, name="vwap").sort_index()
        multipliers = self._contract_multipliers(self._normalize_order_book_ids(order_book_ids))
        if multipliers:
            order_ids = series.index.get_level_values("order_book_id").astype(str)
            divisor = np.array([multipliers.get(order_book_id, 1.0) for order_book_id in order_ids], dtype="float64")
            adjusted = np.full_like(series.to_numpy(dtype="float64"), np.nan, dtype="float64")
            np.divide(series.to_numpy(dtype="float64"), divisor, out=adjusted, where=divisor != 0)
            series = pd.Series(adjusted, index=series.index, name="vwap")
        return series.sort_index()

    def get_open_auction_info(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        fields: str | Sequence[str] | None = None,
        market: str = "cn",
    ):
        """Return opening auction snapshots from local raw equity tick data."""
        self._require_cn_market(market)
        ids = self._normalize_order_book_ids(order_book_ids)
        start = self._parse_date_input(start_date)
        if start is None:
            start = dt.date.today().isoformat()
        end = self._parse_date_input(end_date) or start
        self._validate_date_range(start, end)

        table = self._table("equity_tick")
        table_columns = self._describe_table(table)
        selected = self._resolve_open_auction_fields(fields, table_columns)
        params: dict[str, Any] = {
            "order_book_ids": tuple(ids),
            "start": start,
            "end": end,
        }
        field_exprs = [
            f"argMax({self._quote_identifier(column)}, time) AS {self._quote_identifier(column)}"
            for column in selected
        ]
        sql = f"""
SELECT
    order_book_id,
    argMax(datetime, time) AS datetime,
    {", ".join(field_exprs)}
FROM {table}
WHERE order_book_id IN %(order_book_ids)s
  AND trading_date >= toDate(%(start)s)
  AND trading_date <= toDate(%(end)s)
  AND time >= 92500000
  AND time < 93000000
GROUP BY
    order_book_id,
    trading_date
ORDER BY
    order_book_id,
    datetime
"""
        df = self._query_dataframe(sql.strip(), params)
        df = self._normalize_datetime_columns(df)
        if df.empty:
            import pandas as pd

            empty = pd.DataFrame(columns=selected)
            empty.index = pd.MultiIndex.from_arrays([[], []], names=["order_book_id", "datetime"])
            return empty

        if "open_interest" in df.columns:
            # rqdatac represents the non-applicable equity auction value as 0,
            # while the H5 mirror stores it as NaN.
            df["open_interest"] = df["open_interest"].fillna(0.0)
        df = df.set_index(["order_book_id", "datetime"]).sort_index()
        return df.loc[:, selected]

    def describe_table(self, table_name: str) -> dict[str, str]:
        return self._describe_table(self._table(table_name))

    def get_instrument_types(self, order_book_ids: str | Sequence[str]) -> dict[str, dict[str, str | None]]:
        ids = self._normalize_order_book_ids(order_book_ids)
        return self._lookup_instruments(ids)

    def all_instruments(
        self,
        type: str | Sequence[str] | None = None,
        date: str | int | dt.date | dt.datetime | None = None,
        market: str = "cn",
        **kwargs: Any,
    ):
        """Return the local all-instruments lookup table as a pandas DataFrame."""
        if "country" in kwargs:
            market = kwargs.pop("country")
        self._require_cn_market(market)
        types = self._normalize_instrument_types(type)
        date_value = self._parse_date_input(date)
        columns = self._pg_columns("all_instruments")
        preferred = ("order_book_id", "symbol", "abbrev_symbol", "type", "listed_date", "de_listed_date")
        hidden = {"detail_table", "has_detail_table", "created_at", "updated_at"}
        selected = [col for col in preferred if col in columns]
        selected.extend(col for col in columns if col not in selected and col not in hidden)
        if not selected:
            raise ValueError("public.all_instruments has no queryable columns")

        where: list[str] = []
        params: list[Any] = []
        if types is not None:
            where.append('"type" = ANY(%s::varchar[])')
            params.append(types)
        if date_value is not None:
            if "listed_date" in columns:
                # rqdatac excludes failed/unlisted issues (NULL listed_date)
                # when a historical lifecycle date is requested.
                where.append('("listed_date" IS NOT NULL AND "listed_date" <= %s)')
                params.append(date_value)
            if "de_listed_date" in columns:
                where.append(
                    '("de_listed_date" IS NULL '
                    'OR ("type" = ANY(%s::varchar[]) AND "de_listed_date" >= %s) '
                    'OR (NOT ("type" = ANY(%s::varchar[])) AND "de_listed_date" > %s))'
                )
                date_inclusive_types = ["Future", "Option"]
                params.extend([date_inclusive_types, date_value, date_inclusive_types, date_value])

        sql = f"""
SELECT {self._pg_select_list(selected)}
FROM {self._pg_table("all_instruments")}
{self._pg_where(where)}
ORDER BY "order_book_id";
"""
        return self._query_pg_dataframe(sql, tuple(params))

    def instruments(
        self,
        order_book_ids: str | Sequence[str],
        market: str = "cn",
    ) -> Instrument | list[Instrument]:
        """Return one local Instrument object or a list of Instrument objects."""
        self._require_cn_market(market)
        scalar_input = isinstance(order_book_ids, str)
        ids = self._normalize_order_book_ids(order_book_ids)
        lookup = self._lookup_instruments(ids)

        grouped: dict[str, list[str]] = {}
        for order_book_id in ids:
            detail_table = lookup[order_book_id].get("detail_table")
            if not detail_table:
                rq_type = lookup[order_book_id].get("type")
                raise ValueError(
                    f"{order_book_id!r} has type {rq_type!r}, but no local instrument detail table is available"
                )
            grouped.setdefault(str(detail_table), []).append(order_book_id)

        hidden = {"created_at", "updated_at"}
        by_id: dict[str, Instrument] = {}
        for table_name, group_ids in grouped.items():
            columns = [col for col in self._pg_columns(table_name) if col not in hidden]
            if "order_book_id" not in columns:
                raise ValueError(f"{self.pg_config.schema}.{table_name} is missing order_book_id")
            sql = f"""
SELECT {self._pg_select_list(columns)}
FROM {self._pg_table(table_name)}
WHERE "order_book_id" = ANY(%s::varchar[])
ORDER BY "order_book_id";
"""
            rows, row_columns = self._query_pg_rows_with_columns(sql, (list(dict.fromkeys(group_ids)),))
            for row in rows:
                data = dict(zip(row_columns, row))
                by_id[str(data["order_book_id"])] = Instrument(
                    data,
                    citics_resolver=self._resolve_citics_industry,
                )

        missing = [order_book_id for order_book_id in ids if order_book_id not in by_id]
        if missing:
            preview = ", ".join(missing[:5])
            raise ValueError(f"instrument detail not found: {preview}{' ...' if len(missing) > 5 else ''}")

        result = [by_id[order_book_id] for order_book_id in ids]
        return result[0] if scalar_input else result

    def _resolve_citics_industry(
        self,
        order_book_id: str,
        date: Any,
        de_listed_date: Any,
    ) -> dict[str, str] | None:
        target = self._parse_date_input(date)
        delisted = self._parse_date_input(de_listed_date)
        if delisted is not None:
            # rqdatac deliberately resolves delisted stocks at the final
            # trading date, irrespective of the requested date argument.
            rows = self._query_pg_rows(
                f'''SELECT "date" FROM {self._pg_table("trading_dates")}
                    WHERE "is_trading" AND "date" < %s
                    ORDER BY "date" DESC LIMIT 1''',
                (delisted,),
            )
            if not rows:
                return None
            target = self._coerce_date(rows[0][0]).isoformat()

        where = ['"order_book_id" = %s']
        params: list[Any] = [order_book_id]
        if target is not None:
            where.extend(['"start_date" <= %s', '"cancel_date" > %s'])
            params.extend([target, target])
        sql = f'''
SELECT "first_industry_code", "first_industry_name"
FROM {self._pg_table("cs_citics_industry_history")}
{self._pg_where(where)}
ORDER BY "start_date" DESC
LIMIT 1;
'''
        rows = self._query_pg_rows(sql, tuple(params))
        if not rows:
            return None
        return {"code": str(rows[0][0]), "name": str(rows[0][1])}

    def sector(self, code: str, market: str = "cn") -> list[str]:
        """Return stock order-book IDs in the requested sector."""
        self._require_cn_market(market)
        code_value = self._normalize_classification_code(code, "code")
        rows = self._query_pg_rows(
            f"""
SELECT "order_book_id"
FROM {self._pg_table("instruments_cs")}
WHERE lower("sector_code") = lower(%s)
   OR "sector_code_name" = %s
ORDER BY "order_book_id";
""",
            (code_value, code_value),
        )
        return [str(row[0]) for row in rows]

    def industry(self, code: str, market: str = "cn") -> list[str]:
        """Return stock order-book IDs in the requested industry."""
        self._require_cn_market(market)
        code_value = self._normalize_classification_code(code, "code")
        rows = self._query_pg_rows(
            f"""
SELECT "order_book_id"
FROM {self._pg_table("instruments_cs")}
WHERE "industry_code" = %s
   OR "industry_name" = %s
ORDER BY "order_book_id";
""",
            (code_value, code_value),
        )
        return [str(row[0]) for row in rows]

    def _contract_multipliers(self, order_book_ids: Sequence[str]) -> dict[str, float]:
        import numpy as np

        lookups = self.get_instrument_types(order_book_ids)
        target_ids = [
            order_book_id
            for order_book_id in order_book_ids
            if lookups.get(order_book_id, {}).get("type") in {"Future", "FutureArbitrage", "Option", "Spot"}
        ]
        if not target_ids:
            return {}
        instruments = self.instruments(target_ids)
        values = instruments if isinstance(instruments, list) else [instruments]
        out: dict[str, float] = {}
        for instrument in values:
            order_book_id = str(getattr(instrument, "order_book_id"))
            multiplier = getattr(instrument, "contract_multiplier", None)
            try:
                multiplier_value = float(multiplier)
            except (TypeError, ValueError):
                continue
            if multiplier_value > 0 and np.isfinite(multiplier_value) and multiplier_value != 1.0:
                out[order_book_id] = multiplier_value
        return out

    def get_trading_dates(
        self,
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        market: str = "cn",
    ) -> list[dt.date]:
        """Return dates where the local calendar marks ``is_trading = true``."""
        return self._get_calendar_dates(
            flag_column="is_trading",
            start_date=start_date,
            end_date=end_date,
            market=market,
        )

    def get_trading_periods(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        frequency: str = "1m",
        market: str = "cn",
    ):
        return query_trading_periods(
            self,
            order_book_ids,
            start_date=start_date,
            end_date=end_date,
            frequency=frequency,
            market=market,
        )

    def get_night_trading_dates(
        self,
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        market: str = "cn",
    ) -> list[dt.date]:
        """Return dates where the local calendar marks ``has_night_session = true``."""
        return self._get_calendar_dates(
            flag_column="has_night_session",
            start_date=start_date,
            end_date=end_date,
            market=market,
        )

    def get_previous_trading_date(
        self,
        date: str | int | dt.date | dt.datetime,
        n: int = 1,
        market: str = "cn",
    ) -> dt.date:
        """Return the n-th trading date strictly before ``date``."""
        return self._get_relative_trading_date(date=date, n=n, direction="previous", market=market)

    def get_next_trading_date(
        self,
        date: str | int | dt.date | dt.datetime,
        n: int = 1,
        market: str = "cn",
    ) -> dt.date:
        """Return the n-th trading date strictly after ``date``."""
        return self._get_relative_trading_date(date=date, n=n, direction="next", market=market)

    def get_latest_trading_date(self, market: str = "cn") -> dt.date:
        """Return today's trading date, or the preceding one on a non-trading day."""
        self._require_cn_market(market)
        now = _shanghai_now()
        return self._latest_trading_date_for(now.date(), market=market)

    def get_future_latest_trading_date(self, market: str = "cn") -> dt.date:
        """Return the futures trading date using RQData's 20:55 switch."""
        self._require_cn_market(market)
        now = _shanghai_now()
        latest = self._latest_trading_date_for(now.date(), market=market)
        switch = dt.datetime.combine(latest, FUTURE_TRADING_DATE_SWITCH, tzinfo=SHANGHAI)
        if now < switch:
            return latest
        return self.get_next_trading_date(latest, market=market)

    def _latest_trading_date_for(self, today: dt.date, *, market: str) -> dt.date:
        return self.get_previous_trading_date(
            today + dt.timedelta(days=1),
            market=market,
        )

    def get_ex_factor(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        market: str = "cn",
    ):
        self._require_cn_market(market)
        frame = self._query_factor_table(
            table_name="ex_factor",
            order_book_ids=order_book_ids,
            date_column="ex_date",
            start_date=start_date,
            end_date=end_date,
        )
        if frame.empty:
            return None

        import pandas as pd

        for column in ("ex_date", "announcement_date", "ex_end_date"):
            frame[column] = pd.to_datetime(frame[column], errors="coerce")
        columns = ["order_book_id", "announcement_date", "ex_cum_factor", "ex_end_date", "ex_factor"]
        return frame.sort_values(["order_book_id", "ex_date"]).set_index("ex_date").loc[:, columns]

    def get_split(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        market: str = "cn",
    ):
        self._require_cn_market(market)
        ids = self._normalize_order_book_ids(order_book_ids)
        frame = self._query_factor_table(
            table_name="split",
            order_book_ids=ids,
            date_column="ex_dividend_date",
            start_date=start_date,
            end_date=end_date,
        )
        if frame.empty:
            return None

        import numpy as np
        import pandas as pd

        for column in ("ex_dividend_date", "book_closure_date", "payable_date"):
            frame[column] = pd.to_datetime(frame[column], errors="coerce")
        frame = frame.sort_values(["order_book_id", "ex_dividend_date"])
        split_factor = (
            frame["split_coefficient_to"].astype("float64")
            / frame["split_coefficient_from"].astype("float64")
        )
        frame["cum_factor"] = split_factor.groupby(frame["order_book_id"]).cumprod()
        if np.all(np.isfinite(frame["split_coefficient_from"])) and np.all(
            frame["split_coefficient_from"] == np.floor(frame["split_coefficient_from"])
        ):
            frame["split_coefficient_from"] = frame["split_coefficient_from"].astype("int64")
        columns = [
            "book_closure_date",
            "order_book_id",
            "split_coefficient_to",
            "payable_date",
            "split_coefficient_from",
            "cum_factor",
        ]
        if len(ids) == 1:
            return frame.set_index("ex_dividend_date").loc[:, columns]
        columns.remove("order_book_id")
        return frame.set_index(["order_book_id", "ex_dividend_date"]).sort_index().loc[:, columns]

    def is_suspended(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        market: str = "cn",
    ):
        """Return a date-indexed boolean suspension matrix for local CS data."""
        ids = self._normalize_order_book_ids(order_book_ids)
        start, end = self._resolve_stock_suspension_range(
            ids,
            start_date=start_date,
            end_date=end_date,
            market=market,
        )
        if start is None:
            return None
        return self._is_suspended_from_table(
            table_name="is_suspended",
            order_book_ids=ids,
            start_date=start,
            end_date=end,
            market=market,
        )

    def is_st_stock(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        market: str = "cn",
    ):
        """Return a date-indexed boolean ST-status matrix for local CS data."""
        ids = self._normalize_order_book_ids(order_book_ids)
        start, end = self._resolve_stock_suspension_range(
            ids,
            start_date=start_date,
            end_date=end_date,
            market=market,
        )
        if start is None:
            return None
        return self._boolean_status_from_table(
            table_name="is_st_stock",
            flag_column="is_st_stock",
            order_book_ids=ids,
            start_date=start,
            end_date=end,
            market=market,
        )

    def _resolve_stock_suspension_range(
        self,
        order_book_ids: Sequence[str],
        *,
        start_date: str | int | dt.date | dt.datetime | None,
        end_date: str | int | dt.date | dt.datetime | None,
        market: str,
    ) -> tuple[str | None, str | None]:
        self._require_cn_market(market)
        start = self._parse_date_input(start_date)
        end = self._parse_date_input(end_date)

        if len(order_book_ids) != 1:
            today = dt.date.today()
            end_date_value = dt.date.fromisoformat(end) if end is not None else today
            if start is None:
                start_date_value = self._shift_months(end_date_value, -3)
            else:
                start_date_value = dt.date.fromisoformat(start)
            self._validate_date_range(start_date_value.isoformat(), end_date_value.isoformat())
            return start_date_value.isoformat(), end_date_value.isoformat()

        instrument = self.instruments(order_book_ids[0], market=market)
        if getattr(instrument, "type", None) != "CS":
            raise ValueError(f"is_suspended only supports CS instruments, got {getattr(instrument, 'type', None)!r}")
        listed = self._coerce_date(instrument.listed_date)
        de_listed_raw = getattr(instrument, "de_listed_date", None)
        de_listed = self._coerce_date(de_listed_raw) if de_listed_raw is not None else None

        start_value = dt.date.fromisoformat(start) if start is not None else listed
        if start_value < listed:
            start_value = listed
        if de_listed is not None and start_value >= de_listed:
            warnings.warn(f"{order_book_ids[0]} has been delisted on {de_listed.isoformat()}", stacklevel=2)
            return None, None

        if end is None:
            end_value = (
                self.get_previous_trading_date(de_listed, market=market)
                if de_listed is not None
                else self._latest_local_trading_date()
            )
        else:
            end_value = dt.date.fromisoformat(end)
            if de_listed is not None and end_value >= de_listed:
                warnings.warn(f"{order_book_ids[0]} has been delisted on {de_listed.isoformat()}", stacklevel=2)
                end_value = self.get_previous_trading_date(de_listed, market=market)
        self._validate_date_range(start_value.isoformat(), end_value.isoformat())
        return start_value.isoformat(), end_value.isoformat()

    def convertible_is_suspended(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
    ):
        """Return a date-indexed boolean suspension matrix for local convertibles."""
        ids = self._normalize_order_book_ids(order_book_ids)
        start, end = self._resolve_convertible_suspension_range(
            ids,
            start_date=start_date,
            end_date=end_date,
        )
        if start is None:
            return None
        return self._is_suspended_from_table(
            table_name="convertible_is_suspended",
            order_book_ids=ids,
            start_date=start,
            end_date=end,
            market="cn",
        )

    def convertible_all_instruments(
        self,
        date: str | int | dt.date | dt.datetime | None = None,
        market: str = "cn",
    ):
        from .convertible_reference_data import all_instruments

        return all_instruments(self, date=date, market=market)

    def convertible_instruments(
        self,
        order_book_ids: str | Sequence[str],
        market: str = "cn",
    ):
        from .convertible_reference_data import instruments

        return instruments(self, order_book_ids, market=market)

    def convertible_get_conversion_price(self, order_book_ids, start_date=None, end_date=None, market="cn"):
        from .convertible_data import get_event
        return get_event(self, "conversion_price", order_book_ids, start_date, end_date, market)

    def convertible_get_conversion_info(self, order_book_ids, start_date=None, end_date=None, market="cn"):
        from .convertible_data import get_event
        return get_event(self, "conversion_info", order_book_ids, start_date, end_date, market)

    def convertible_get_call_info(self, order_book_ids, start_date=None, end_date=None, market="cn"):
        from .convertible_data import get_event
        return get_event(self, "call_info", order_book_ids, start_date, end_date, market)

    def convertible_get_put_info(self, order_book_ids, start_date=None, end_date=None, market="cn"):
        from .convertible_data import get_event
        return get_event(self, "put_info", order_book_ids, start_date, end_date, market)

    def convertible_get_cash_flow(self, order_book_ids, start_date=None, end_date=None, market="cn"):
        from .convertible_data import get_event
        return get_event(self, "cash_flow", order_book_ids, start_date, end_date, market)

    def convertible_get_instrument_industry(self, order_book_ids, source="citics", level=1, date=None, market="cn"):
        from .convertible_data import get_instrument_industry
        return get_instrument_industry(self, order_book_ids, source, level, date, market)

    def convertible_get_industry(self, industry, source="citics", date=None, market="cn"):
        from .convertible_data import get_industry
        return get_industry(self, industry, source, date, market)

    def convertible_get_accrued_interest_eod(self, order_book_ids, start_date=None, end_date=None):
        from .convertible_data import get_accrued_interest_eod
        return get_accrued_interest_eod(self, order_book_ids, start_date, end_date)

    def convertible_get_call_announcement(self, order_book_ids, start_date=None, end_date=None, market="cn"):
        from .convertible_data import get_event
        return get_event(self, "call_announcement", order_book_ids, start_date, end_date, market)

    def convertible_get_close_price(self, order_book_ids, start_date=None, end_date=None, fields=None, market="cn"):
        from .convertible_data import get_close_price
        return get_close_price(self, order_book_ids, start_date, end_date, fields, market)

    def convertible_get_indicators(self, order_book_ids, start_date=None, end_date=None, fields=None):
        from .convertible_data import get_indicators
        return get_indicators(self, order_book_ids, start_date, end_date, fields)

    def convertible_get_credit_rating(self, order_book_ids, start_date=None, end_date=None, institutions=None, market="cn"):
        from .convertible_data import get_event
        return get_event(
            self, "credit_rating", order_book_ids, start_date, end_date, market, institutions
        )

    def convertible_get_std_discount(self, order_book_ids, start_date=None, end_date=None, market="cn"):
        from .convertible_data import get_std_discount
        return get_std_discount(self, order_book_ids, start_date, end_date, market)

    def _resolve_convertible_suspension_range(
        self,
        order_book_ids: Sequence[str],
        *,
        start_date: str | int | dt.date | dt.datetime | None,
        end_date: str | int | dt.date | dt.datetime | None,
    ) -> tuple[str | None, str | None]:
        start = self._parse_date_input(start_date)
        end = self._parse_date_input(end_date)

        if len(order_book_ids) == 1:
            instrument = self.instruments(order_book_ids[0], market="cn")
            if getattr(instrument, "type", None) != "Convertible":
                raise ValueError(
                    "convertible.is_suspended only supports Convertible instruments, "
                    f"got {getattr(instrument, 'type', None)!r}"
                )
            listed = self._coerce_date(instrument.listed_date)
            if listed > dt.date.today():
                warnings.warn(f"instrument {order_book_ids[0]} is not listed yet", stacklevel=2)
                return None, None
            de_listed_raw = getattr(instrument, "de_listed_date", None)
            de_listed = self._coerce_date(de_listed_raw) if de_listed_raw is not None else None

            start_value = dt.date.fromisoformat(start) if start is not None else listed
            if start_value < listed:
                start_value = listed
            if de_listed is not None and start_value >= de_listed:
                warnings.warn(
                    f"{order_book_ids[0]} has been delisted on {de_listed.isoformat()} 00:00:00",
                    stacklevel=2,
                )
                return None, None

            if end is None:
                end_value = (
                    self.get_previous_trading_date(de_listed, market="cn")
                    if de_listed is not None
                    else self._latest_local_trading_date()
                )
            else:
                end_value = dt.date.fromisoformat(end)
                if de_listed is not None and end_value >= de_listed:
                    warnings.warn(
                        f"{order_book_ids[0]} has been delisted on {de_listed.isoformat()} 00:00:00",
                        stacklevel=2,
                    )
                    end_value = self.get_previous_trading_date(de_listed, market="cn")
            start, end = start_value.isoformat(), end_value.isoformat()

        if start is None and end is None:
            end_value = dt.date.today()
            start_value = self._shift_months(end_value, -3)
        elif start is None:
            end_value = dt.date.fromisoformat(end)
            start_value = self._shift_months(end_value, -3)
        elif end is None:
            start_value = dt.date.fromisoformat(start)
            end_value = self._shift_months(start_value, 3)
        else:
            start_value = dt.date.fromisoformat(start)
            end_value = dt.date.fromisoformat(end)
        self._validate_date_range(start_value.isoformat(), end_value.isoformat())
        return start_value.isoformat(), end_value.isoformat()

    def _is_suspended_from_table(
        self,
        *,
        table_name: str,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None,
        end_date: str | int | dt.date | dt.datetime | None,
        market: str,
    ):
        return self._boolean_status_from_table(
            table_name=table_name,
            flag_column="is_suspended",
            order_book_ids=order_book_ids,
            start_date=start_date,
            end_date=end_date,
            market=market,
        )

    def _boolean_status_from_table(
        self,
        *,
        table_name: str,
        flag_column: str,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None,
        end_date: str | int | dt.date | dt.datetime | None,
        market: str,
    ):
        self._require_cn_market(market)
        ids = self._normalize_order_book_ids(order_book_ids)
        start = self._parse_date_input(start_date)
        end = self._parse_date_input(end_date)
        if start is None and end is None:
            start, end = self._suspension_date_bounds(ids, table_name=table_name)
        self._validate_date_range(start, end)

        import pandas as pd

        dates = self.get_trading_dates(start_date=start, end_date=end, market=market) if start and end else []
        frame = pd.DataFrame(False, index=pd.to_datetime(dates), columns=ids)
        frame.index.name = "date"
        if not dates:
            return frame

        sql = f"""
SELECT "order_book_id", "date"
FROM {self._pg_table(table_name)}
WHERE "order_book_id" = ANY(%s::varchar[])
  AND "date" >= %s
  AND "date" <= %s
  AND {self._pg_quote_identifier(flag_column)};
"""
        rows = self._query_pg_rows(sql, (ids, start, end))
        for order_book_id, date_value in rows:
            date_key = pd.Timestamp(self._coerce_date(date_value))
            if str(order_book_id) in frame.columns and date_key in frame.index:
                frame.loc[date_key, str(order_book_id)] = True
        return frame

    def get_dominant(
        self,
        underlying_symbol: str,
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        rule: int = 0,
        rank: int = 1,
        market: str = "cn",
    ):
        """Return local futures dominant contracts as a rqdatac-like Series."""
        if market != "cn":
            raise ValueError("only market='cn' is supported")
        if not isinstance(underlying_symbol, str) or not underlying_symbol.strip():
            raise ValueError(f"invalid underlying_symbol: {underlying_symbol!r}")
        if rule not in {0, 1, 2, 3}:
            raise ValueError("rule must be one of 0, 1, 2, 3")
        if rank not in {1, 2, 3}:
            raise ValueError("rank must be one of 1, 2, 3")

        symbol = underlying_symbol.strip().upper()
        start = self._parse_date_input(start_date)
        end = self._parse_date_input(end_date)
        if start is not None and end is None:
            end = start
        if start is not None and end is not None and dt.date.fromisoformat(start) > dt.date.fromisoformat(end):
            raise ValueError(f"invalid date range: [{start!r}, {end!r}]")

        where = ['"underlying_symbol" = %s', '"rule" = %s', '"rank" = %s']
        params: list[Any] = [symbol, int(rule), int(rank)]
        if start is not None:
            where.append('"date" >= %s')
            params.append(start)
        if end is not None:
            where.append('"date" <= %s')
            params.append(end)

        sql = f"""
SELECT "date", "dominant"
FROM {self._pg_table("future_dominant")}
WHERE {' AND '.join(where)}
ORDER BY "date";
"""
        with self._get_pg_connection().cursor() as cursor:
            cursor.execute(sql, tuple(params))
            rows = cursor.fetchall()
        if not rows:
            return None

        import pandas as pd

        df = pd.DataFrame(rows, columns=["date", "dominant"])
        df["date"] = pd.to_datetime(df["date"], errors="coerce").astype("datetime64[ns]")
        series = df.set_index("date").sort_index()["dominant"]
        series.index.name = "date"
        series.name = "dominant"
        return series

    def get_dominant_batch(
        self,
        underlying_symbol_list: Sequence[str],
        start_date: str | int | dt.date | dt.datetime,
        end_date: str | int | dt.date | dt.datetime,
        rule: int = 0,
        rank: int = 1,
        market: str = "cn",
    ):
        """Return dominant contracts for multiple underlyings and trading dates."""
        self._require_cn_market(market)
        if isinstance(underlying_symbol_list, str):
            raise TypeError("underlying_symbol_list must be a sequence of strings, not a string")
        if rule not in {0, 1, 2, 3}:
            raise ValueError("rule must be one of 0, 1, 2, 3")
        if rank not in {1, 2, 3}:
            raise ValueError("rank must be one of 1, 2, 3")

        symbols: list[str] = []
        seen: set[str] = set()
        for value in underlying_symbol_list:
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"invalid underlying_symbol: {value!r}")
            symbol = value.strip().upper()
            if symbol not in seen:
                symbols.append(symbol)
                seen.add(symbol)
        if not symbols:
            raise ValueError("underlying_symbol_list cannot be empty")

        start = self._parse_date_input(start_date)
        end = self._parse_date_input(end_date)
        if start is None or end is None:
            raise ValueError("start_date and end_date are required")
        self._validate_date_range(start, end)

        sql = f"""
WITH requested_symbols AS (
    SELECT "underlying_symbol", "symbol_order"
    FROM unnest(%s::varchar[]) WITH ORDINALITY
         AS requested("underlying_symbol", "symbol_order")
),
trading_days AS (
    SELECT "date"
    FROM {self._pg_table("trading_dates")}
    WHERE "is_trading"
      AND "date" >= %s
      AND "date" <= %s
)
SELECT
    requested_symbols."underlying_symbol",
    trading_days."date",
    future_dominant."dominant"
FROM requested_symbols
CROSS JOIN trading_days
LEFT JOIN {self._pg_table("future_dominant")} AS future_dominant
  ON future_dominant."underlying_symbol" = requested_symbols."underlying_symbol"
 AND future_dominant."date" = trading_days."date"
 AND future_dominant."rule" = %s
 AND future_dominant."rank" = %s
ORDER BY requested_symbols."symbol_order", trading_days."date";
"""
        rows = self._query_pg_rows(sql, (symbols, start, end, int(rule), int(rank)))

        import pandas as pd

        result = pd.DataFrame(rows, columns=["underlying_symbol", "date", "dominant"])
        result["date"] = pd.to_datetime(result["date"]).astype("datetime64[ns]")
        # pandas 3 may coerce missing string values to NaN; the public batch
        # contract uses Python None for a trading day without a dominant mapping.
        result["dominant"] = pd.Series([row[2] for row in rows], dtype=object)
        return result

    def get_contracts(
        self,
        underlying_symbol: str,
        date: str | int | dt.date | dt.datetime | None = None,
        market: str = "cn",
    ) -> list[str]:
        """Return contracts listed on ``date`` for a futures underlying."""
        self._require_cn_market(market)
        query_date = self._parse_date_input(date) or dt.date.today().isoformat()
        sql = f"""
SELECT "order_book_id"
FROM {self._pg_table("instruments_future")}
WHERE "underlying_symbol" = %s
  AND "listed_date" IS NOT NULL
  AND "listed_date" <= %s
  AND "de_listed_date" IS NOT NULL
  AND "de_listed_date" >= %s
ORDER BY "order_book_id";
"""
        rows = self._query_pg_rows(sql, (underlying_symbol, query_date, query_date))
        return [str(order_book_id) for (order_book_id,) in rows]

    def get_contracts_batch(
        self,
        underlying_symbol_list: Sequence[str],
        start_date: str | int | dt.date | dt.datetime,
        end_date: str | int | dt.date | dt.datetime,
        market: str = "cn",
    ):
        """Return futures chains for multiple underlyings and trading dates."""
        self._require_cn_market(market)
        if isinstance(underlying_symbol_list, str):
            raise TypeError("underlying_symbol_list must be a sequence of strings, not a string")
        symbols: list[str] = []
        seen: set[str] = set()
        for value in underlying_symbol_list:
            if not isinstance(value, str) or not value:
                raise ValueError(f"invalid underlying_symbol: {value!r}")
            if value not in seen:
                symbols.append(value)
                seen.add(value)
        if not symbols:
            raise ValueError("underlying_symbol_list cannot be empty")

        start = self._parse_date_input(start_date)
        end = self._parse_date_input(end_date)
        if start is None or end is None:
            raise ValueError("start_date and end_date are required")
        self._validate_date_range(start, end)

        sql = f"""
WITH requested_symbols AS (
    SELECT "underlying_symbol", "symbol_order"
    FROM unnest(%s::varchar[]) WITH ORDINALITY
         AS requested("underlying_symbol", "symbol_order")
),
trading_days AS (
    SELECT "date"
    FROM {self._pg_table("trading_dates")}
    WHERE "is_trading"
      AND "date" >= %s
      AND "date" <= %s
),
eligible_contracts AS (
    SELECT "order_book_id", "underlying_symbol", "listed_date", "de_listed_date"
    FROM {self._pg_table("instruments_future")}
    WHERE "underlying_symbol" = ANY(%s::varchar[])
      AND "listed_date" IS NOT NULL
      AND "listed_date" <= %s
      AND "de_listed_date" IS NOT NULL
      AND "de_listed_date" >= %s
)
SELECT
    requested_symbols."underlying_symbol",
    trading_days."date",
    COALESCE(
        array_agg(eligible_contracts."order_book_id" ORDER BY eligible_contracts."order_book_id")
            FILTER (WHERE eligible_contracts."order_book_id" IS NOT NULL),
        ARRAY[]::varchar[]
    ) AS "future_chain"
FROM requested_symbols
CROSS JOIN trading_days
LEFT JOIN eligible_contracts
  ON eligible_contracts."underlying_symbol" = requested_symbols."underlying_symbol"
 AND eligible_contracts."listed_date" <= trading_days."date"
 AND eligible_contracts."de_listed_date" >= trading_days."date"
GROUP BY
    requested_symbols."symbol_order",
    requested_symbols."underlying_symbol",
    trading_days."date"
ORDER BY requested_symbols."symbol_order", trading_days."date";
"""
        rows = self._query_pg_rows(sql, (symbols, start, end, symbols, end, start))

        import pandas as pd

        result = pd.DataFrame(rows, columns=["underlying_symbol", "date", "future_chain"])
        result["date"] = pd.to_datetime(result["date"]).astype("datetime64[ns]")
        return result

    def get_future_ex_factor(
        self,
        underlying_symbols: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        adjust_method: str = "prev_close_spread",
        rule: int = 0,
        rank: int = 1,
        market: str = "cn",
    ):
        """Return locally stored futures continuous-contract adjustment factors."""
        self._require_cn_market(market)
        if rule not in {0, 1, 2, 3}:
            raise ValueError(f"rule: got invalided value {rule}, choose any in {[0, 1, 2, 3]}")
        if rank not in {1, 2, 3}:
            raise ValueError(f"order: got invalided value {rank}, choose any in {[1, 2, 3]}")
        methods = {"prev_close_spread", "open_spread", "prev_close_ratio", "open_ratio"}
        if adjust_method not in methods:
            raise ValueError(f"adjust_method: got invalided value {adjust_method}, choose any in {sorted(methods)}")

        if isinstance(underlying_symbols, str):
            symbols = [underlying_symbols]
        else:
            symbols = list(underlying_symbols)
        if not symbols or any(not isinstance(value, str) or not value for value in symbols):
            raise ValueError(f"invalid underlying_symbols: {underlying_symbols!r}")
        symbols = list(dict.fromkeys(symbols))

        valid_sql = f"""
SELECT DISTINCT "underlying_symbol"
FROM {self._pg_table("future_ex_factor")}
WHERE "rule" = %s AND "rank" = %s
ORDER BY "underlying_symbol";
"""
        valid_symbols = [str(row[0]) for row in self._query_pg_rows(valid_sql, (rule, rank))]
        invalid = [symbol for symbol in symbols if symbol not in set(valid_symbols)]
        if invalid:
            invalid_value = invalid[0] if len(invalid) == 1 else invalid
            raise ValueError(
                f"underlying_symbols: got invalided value {invalid_value}, choose any in {valid_symbols}"
            )

        warnings.warn(
            "DataFrameGroupBy.apply operated on the grouping columns. This behavior is deprecated, "
            "and in a future version of pandas the grouping columns will be excluded from the operation. "
            "Either pass `include_groups=False` to exclude the groupings or explicitly select the grouping "
            "columns after groupby to silence this warning.",
            FutureWarning,
            stacklevel=2,
        )

        where = [
            '"underlying_symbol" = ANY(%s::varchar[])',
            '"rule" = %s',
            '"rank" = %s',
            '"adjust_method" = %s',
        ]
        params: list[Any] = [symbols, rule, rank, adjust_method]
        # rqdatac only applies the event-date filter when both boundaries are supplied.
        if start_date is not None and end_date is not None:
            start = self._parse_date_input(start_date)
            end = self._parse_date_input(end_date)
            where.extend(['"ex_date" >= %s', '"ex_date" <= %s'])
            params.extend([start, end])
        sql = f"""
SELECT "underlying_symbol", "ex_date", "ex_factor", "ex_end_date", "ex_cum_factor"
FROM {self._pg_table("future_ex_factor")}
WHERE {' AND '.join(where)}
ORDER BY "underlying_symbol", "ex_date";
"""
        rows = self._query_pg_rows(sql, tuple(params))

        import pandas as pd

        if not rows:
            empty = pd.DataFrame(
                {
                    "underlying_symbol": pd.Series(dtype="object"),
                    "ex_factor": pd.Series(dtype="float64"),
                    "ex_end_date": pd.Series(dtype="datetime64[ns]"),
                    "ex_cum_factor": pd.Series(dtype="float64"),
                },
                index=pd.DatetimeIndex([], name="ex_date"),
            )
            return empty
        frame = pd.DataFrame(
            rows,
            columns=["underlying_symbol", "ex_date", "ex_factor", "ex_end_date", "ex_cum_factor"],
        )
        frame["ex_date"] = pd.to_datetime(frame["ex_date"])
        frame["ex_end_date"] = pd.to_datetime(frame["ex_end_date"])
        frame["ex_factor"] = frame["ex_factor"].astype("float64")
        frame["ex_cum_factor"] = frame["ex_cum_factor"].astype("float64")
        return frame.set_index("ex_date").loc[
            :, ["underlying_symbol", "ex_factor", "ex_end_date", "ex_cum_factor"]
        ]

    def get_dominant_price(
        self,
        underlying_symbols: str | list[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        frequency: str = "1d",
        fields: str | list[str] | None = None,
        adjust_type: str = "pre",
        adjust_method: str = "prev_close_spread",
        rule: int = 0,
        rank: int = 1,
        time_slice: tuple[str | dt.time, str | dt.time] | list[str | dt.time] | None = None,
    ):
        """Return local futures dominant continuous-contract prices."""
        from .future_dominant_price import get_dominant_price

        return get_dominant_price(
            self,
            underlying_symbols,
            start_date=start_date,
            end_date=end_date,
            frequency=frequency,
            fields=fields,
            adjust_type=adjust_type,
            adjust_method=adjust_method,
            rule=rule,
            rank=rank,
            time_slice=time_slice,
        )

    def get_contract_multiplier(
        self,
        underlying_symbols: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        market: str = "cn",
    ):
        from .future_reference_data import get_contract_multiplier

        return get_contract_multiplier(
            self,
            underlying_symbols,
            start_date=start_date,
            end_date=end_date,
            market=market,
        )

    def get_exchange_daily(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        fields: str | Sequence[str] | None = None,
        market: str = "cn",
    ):
        from .future_reference_data import get_exchange_daily

        return get_exchange_daily(
            self,
            order_book_ids,
            start_date=start_date,
            end_date=end_date,
            fields=fields,
            market=market,
        )

    def get_continuous_contracts(
        self,
        underlying_symbol: Any,
        start_date: str | int | dt.date | dt.datetime | None,
        end_date: str | int | dt.date | dt.datetime | None,
        type: str = "front_month",
        market: str = "cn",
    ):
        from .future_reference_data import get_continuous_contracts

        return get_continuous_contracts(
            self,
            underlying_symbol,
            start_date,
            end_date,
            type=type,
            market=market,
        )

    def get_trading_parameters(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        fields: str | Sequence[str] | None = None,
        market: str = "cn",
    ):
        from .future_reference_data import get_trading_parameters

        return get_trading_parameters(
            self,
            order_book_ids,
            start_date=start_date,
            end_date=end_date,
            fields=fields,
            market=market,
        )

    def get_option_contracts(
        self,
        underlying: str,
        option_type: str | None = None,
        maturity: str | int | None = None,
        strike: float | None = None,
        trading_date: str | int | dt.date | dt.datetime | None = None,
    ) -> list[str]:
        from .option_reference_data import get_contracts

        return get_contracts(
            self,
            underlying,
            option_type=option_type,
            maturity=maturity,
            strike=strike,
            trading_date=trading_date,
        )

    def get_option_contracts_batch(
        self,
        underlying_list: Sequence[str],
        start_date: str | int | dt.date | dt.datetime,
        end_date: str | int | dt.date | dt.datetime,
        option_type: str | None = None,
        maturity: str | int | None = None,
        strike: float | None = None,
    ):
        from .option_reference_data import get_contracts_batch

        return get_contracts_batch(
            self,
            underlying_list,
            start_date,
            end_date,
            option_type=option_type,
            maturity=maturity,
            strike=strike,
        )

    def get_option_greeks(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        fields: str | Sequence[str] | None = None,
        model: str = "implied_forward",
        price_type: str = "close",
        frequency: str = "1d",
        market: str = "cn",
    ):
        from .option_greeks import get_greeks

        return get_greeks(
            self,
            order_book_ids,
            start_date=start_date,
            end_date=end_date,
            fields=fields,
            model=model,
            price_type=price_type,
            frequency=frequency,
            market=market,
        )

    def get_option_contract_property(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        fields: str | Sequence[str] | None = None,
        market: str = "cn",
    ):
        from .option_contract_property import get_contract_property

        return get_contract_property(
            self,
            order_book_ids,
            start_date=start_date,
            end_date=end_date,
            fields=fields,
            market=market,
        )

    def get_option_dominant_month(
        self,
        underlying_symbol: str,
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        rule: int = 0,
        rank: int = 1,
        market: str = "cn",
    ):
        from .option_dominant_month import get_dominant_month

        return get_dominant_month(
            self,
            underlying_symbol,
            start_date=start_date,
            end_date=end_date,
            rule=rule,
            rank=rank,
            market=market,
        )

    def get_option_dominant_month_batch(
        self,
        underlying_symbol_list: Sequence[str],
        start_date: str | int | dt.date | dt.datetime,
        end_date: str | int | dt.date | dt.datetime,
        rule: int = 0,
        rank: int = 1,
        market: str = "cn",
    ):
        from .option_dominant_month import get_dominant_month_batch

        return get_dominant_month_batch(
            self,
            underlying_symbol_list,
            start_date,
            end_date,
            rule=rule,
            rank=rank,
            market=market,
        )

    def get_option_indicators(
        self,
        underlying_symbols: str | Sequence[str],
        maturity: str | int,
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        fields: str | Sequence[str] | None = None,
        market: str = "cn",
    ):
        from .option_indicators import get_indicators

        return get_indicators(
            self,
            underlying_symbols,
            maturity,
            start_date=start_date,
            end_date=end_date,
            fields=fields,
            market=market,
        )

    # ------------------------------------------------------------------
    # SQL construction
    # ------------------------------------------------------------------

    def _build_price_sql(
        self,
        *,
        route: _Route,
        order_book_ids: Sequence[str],
        fields: str | Sequence[str] | None,
        instrument_types: Sequence[str | None],
        start: str | None,
        end: str | None,
        time_slice: tuple[int, int] | None,
        table_columns: dict[str, str] | None = None,
        extra_fields: Sequence[str] | None = None,
    ) -> tuple[str, dict[str, Any], list[str]]:
        if table_columns is None:
            table_columns = self._describe_table(route.table)
        selected = self._resolve_fields(route, table_columns, fields, instrument_types=instrument_types)
        index_column = "date" if route.frequency_kind == "daily" else "datetime"
        visible_selected = [
            column for column in selected
            if column not in {"order_book_id", index_column}
        ]
        for column in ("order_book_id", index_column):
            if column in table_columns and column not in selected:
                selected.append(column)
        for column in extra_fields or ():
            if column in table_columns and column not in selected:
                selected.append(column)
        select_clause = ", ".join(self._quote_identifier(col) for col in selected)
        params: dict[str, Any] = {"order_book_ids": tuple(order_book_ids)}
        where = ["order_book_id IN %(order_book_ids)s"]

        self._append_date_bound(where, params, route, "start", start, ">=")
        self._append_date_bound(where, params, route, "end", end, "<=")

        if time_slice is not None:
            if route.datetime_column is None:
                raise ValueError("daily frequency does not support time_slice")
            start_hms, end_hms = time_slice
            params["slice_start"] = start_hms
            params["slice_end"] = end_hms
            expr = f"toUInt32(formatDateTime({self._quote_identifier(route.datetime_column)}, '%%H%%i%%S'))"
            if start_hms <= end_hms:
                where.append(f"{expr} >= %(slice_start)s AND {expr} <= %(slice_end)s")
            else:
                where.append(f"({expr} >= %(slice_start)s OR {expr} <= %(slice_end)s)")

        order_by = ", ".join(self._quote_identifier(col) for col in route.order_by if col in table_columns)
        sql = f"""
SELECT {select_clause}
FROM {route.table}
WHERE {' AND '.join(where)}
ORDER BY {order_by}
"""
        return sql.strip(), params, visible_selected

    def _resolve_fields(
        self,
        route: _Route,
        table_columns: dict[str, str],
        fields: str | Sequence[str] | None,
        *,
        instrument_types: Sequence[str | None],
    ) -> list[str]:
        available = set(table_columns)
        valid_fields = self._rqdatac_valid_fields(
            route=route,
            instrument_types=instrument_types,
            table_columns=table_columns,
        )
        if fields is None:
            out = [field for field in valid_fields if field in available]
            if not out:
                raise ValueError(f"default fields resolved to empty for table {route.table}")
            return out
        elif isinstance(fields, str):
            tokens = (fields,)
        else:
            tokens = tuple(fields)
            if not tokens:
                raise ValueError("fields cannot be empty; use None")

        out: list[str] = []
        seen = set()
        if len(set(tokens)) < len(tokens):
            warnings.warn(
                "duplicated fields: %s" % [field for field in tokens if tokens.count(field) > 1],
                stacklevel=2,
            )
        for token in tokens:
            if not isinstance(token, str) or not token:
                raise ValueError(f"invalid field token: {token!r}")
            if token in seen:
                continue
            seen.add(token)
            if token in _PRICE_INDEX_COLUMNS:
                raise ValueError(
                    f"field {token!r} is used as the result index; "
                    "request data fields only"
                )
            if token not in valid_fields:
                raise ValueError(
                    f"fields: got invalided value {token}, choose any in {set(valid_fields)}"
                )
            if token not in available:
                raise ValueError(f"field {token!r} does not exist in {route.table}")
            out.append(token)

        if "order_book_id" in available and "order_book_id" not in out:
            out.insert(0, "order_book_id")
        if not out:
            raise ValueError(f"fields resolved to empty for table {route.table}")
        return out

    def _rqdatac_valid_fields(
        self,
        *,
        route: _Route,
        instrument_types: Sequence[str | None],
        table_columns: dict[str, str],
    ) -> list[str]:
        categories = {self._rqdatac_field_category(value) for value in instrument_types}
        categories.discard(None)
        if route.frequency_kind == "tick":
            fields = self._rqdatac_tick_fields(route=route, categories=categories)
        else:
            field_sets = self._DAYBAR_DEFAULT_FIELDS if route.frequency_kind == "daily" else self._MINBAR_DEFAULT_FIELDS
            fields_set = set(field_sets["common"])
            for category in ("future", "stock", "fund", "spot", "option", "convertible", "index", "repo"):
                if category in categories:
                    fields_set.update(field_sets[category])
            fields = list(fields_set)
        return self._unique(fields)

    def _rqdatac_tick_fields(self, *, route: _Route, categories: set[str]) -> list[str]:
        table_name = route.table.replace("`", "").split(".")[-1]
        if table_name == "etf_option_tick":
            return list(self._ETF_OPTION_TICK_COLUMNS)
        if "future" in categories or "option" in categories or "spot" in categories:
            return list(self._FUTURE_TICK_COLUMNS)
        if "fund" in categories:
            return list(self._FUND_TICK_COLUMNS)
        return list(self._EQUITY_TICK_COLUMNS)

    @staticmethod
    def _rqdatac_field_category(rq_type: str | None) -> str | None:
        if rq_type == "CS":
            return "stock"
        if rq_type in {"ETF", "LOF", "SF", "FUND", "REITs"}:
            return "fund"
        if rq_type == "INDX":
            return "index"
        if rq_type in {"Future", "FutureArbitrage"}:
            return "future"
        if rq_type == "Spot":
            return "spot"
        if rq_type == "Option":
            return "option"
        if rq_type == "Convertible":
            return "convertible"
        if rq_type == "Repo":
            return "repo"
        return None

    @staticmethod
    def _unique(values: Sequence[str]) -> list[str]:
        out: list[str] = []
        for value in values:
            if value not in out:
                out.append(value)
        return out

    @staticmethod
    def _format_price_result(
        result_df,
        *,
        frequency: Frequency,
        visible_columns: Sequence[str],
        sort_index: bool = True,
    ):
        import pandas as pd

        index_column = "date" if frequency == "1d" else "datetime"
        data_columns = [
            column for column in visible_columns
            if column in result_df.columns and column not in {"order_book_id", index_column}
        ]
        index_names = ["order_book_id", index_column]

        if result_df.empty:
            index = pd.MultiIndex.from_arrays([[], []], names=index_names)
            empty = result_df.loc[:, data_columns].copy()
            empty.index = index
            return empty

        missing = [column for column in index_names if column not in result_df.columns]
        if missing:
            raise ValueError(f"missing index columns in query result: {missing}")

        result_df.set_index(index_names, inplace=True)
        if list(result_df.columns) != data_columns:
            result_df = result_df.loc[:, data_columns]
        return result_df.sort_index() if sort_index else result_df

    def _resolve_open_auction_fields(
        self,
        fields: str | Sequence[str] | None,
        table_columns: dict[str, str],
    ) -> list[str]:
        available = set(table_columns)
        default = [column for column in self._OPEN_AUCTION_FIELDS if column in available]
        if fields is None:
            return default

        tokens = [fields] if isinstance(fields, str) else list(fields)
        if not tokens:
            raise ValueError("fields cannot be empty")

        out: list[str] = []
        for token in tokens:
            if not isinstance(token, str) or not token:
                raise ValueError(f"invalid field token: {token!r}")
            if token.lower() == "all":
                for column in default:
                    if column not in out:
                        out.append(column)
                continue
            if token not in available or token in {"order_book_id", "datetime", "trading_date", "date", "time"}:
                raise ValueError(
                    f"field {token!r} is not available in local get_open_auction_info; "
                    f"available fields: {', '.join(default)}"
                )
            if token not in out:
                out.append(token)

        if not out:
            raise ValueError("no requested open auction fields are available")
        return out

    def _append_date_bound(
        self,
        where: list[str],
        params: dict[str, Any],
        route: _Route,
        key: str,
        bound: str | None,
        op: str,
    ) -> None:
        if bound is None:
            return
        params[key] = bound
        col = self._quote_identifier(route.date_column)
        if route.datetime_column == route.date_column:
            day = dt.date.fromisoformat(bound)
            if op == ">=":
                params[key] = f"{day.isoformat()} 00:00:00.000"
                where.append(f"{col} >= toDateTime64(%({key})s, 3, '{CH_TIMEZONE}')")
            elif op == "<=":
                next_day = day + dt.timedelta(days=1)
                params[key] = f"{next_day.isoformat()} 00:00:00.000"
                where.append(f"{col} < toDateTime64(%({key})s, 3, '{CH_TIMEZONE}')")
            else:
                raise ValueError(f"unsupported datetime date-bound operator: {op}")
            return
        where.append(f"{col} {op} toDate(%({key})s)")

    def _resolve_route(
        self,
        order_book_id: str,
        frequency: Frequency,
        lookup: dict[str, str | None] | None = None,
    ) -> _Route:
        route_asset = self._normalize_asset_type(order_book_id, lookup)
        if route_asset == "option":
            route_asset = self._infer_option_subtype(order_book_id)

        table = self._resolve_table(route_asset, frequency)
        columns = self._describe_table(table)
        if frequency == "1d":
            return _Route(
                table=table,
                table_name=table.rsplit(".", 1)[-1].strip("`"),
                asset_type=route_asset,
                frequency=frequency,
                frequency_kind="daily",
                date_column="date",
                datetime_column=None,
                order_by=("order_book_id", "date"),
            )
        if frequency == "tick":
            return _Route(
                table=table,
                table_name=table.rsplit(".", 1)[-1].strip("`"),
                asset_type=route_asset,
                frequency=frequency,
                frequency_kind="tick",
                date_column="trading_date" if "trading_date" in columns else "date",
                datetime_column="datetime",
                order_by=("order_book_id", "trading_date", "datetime"),
            )
        return _Route(
            table=table,
            table_name=table.rsplit(".", 1)[-1].strip("`"),
            asset_type=route_asset,
            frequency=frequency,
            frequency_kind="bar",
            date_column="trading_date" if "trading_date" in columns else "datetime",
            datetime_column="datetime",
            order_by=("order_book_id", "trading_date", "datetime")
            if "trading_date" in columns
            else ("order_book_id", "datetime"),
        )

    def _resolve_table(self, asset_type: str, frequency: Frequency) -> str:
        if frequency == "1d":
            suffix = "daily_bar"
        elif frequency == "tick":
            suffix = "tick"
        else:
            suffix = f"{frequency}_bar"

        if asset_type == "equity":
            table_name = f"equity_{suffix}"
        elif asset_type == "future":
            table_name = f"future_{suffix}"
        elif asset_type == "commodity_option":
            table_name = f"commodity_option_{suffix}"
        elif asset_type == "etf_option":
            table_name = f"etf_option_{suffix}"
        else:
            raise ValueError(f"unsupported asset_type: {asset_type!r}")
        return self._table(table_name)

    # ------------------------------------------------------------------
    # Routing and normalization
    # ------------------------------------------------------------------

    def _normalize_asset_type(
        self,
        order_book_id: str,
        lookup: dict[str, str | None] | None,
    ) -> str:
        if lookup is not None:
            asset_type = lookup.get("asset_type")
            if asset_type:
                return str(asset_type)
            rq_type = lookup.get("type")
            raise ValueError(f"all_instruments type {rq_type!r} for {order_book_id!r} is not routable")
        if _ETF_OPTION_NUMERIC_RE.match(order_book_id):
            return "etf_option"
        if _FUTURE_OPTION_RE.match(order_book_id):
            return "commodity_option"
        if "." in order_book_id:
            return "equity"
        if _FUTURE_RE.match(order_book_id):
            return "future"
        raise ValueError(f"cannot infer ClickHouse market-data table for {order_book_id!r}")

    def _lookup_instruments(self, order_book_ids: Sequence[str]) -> dict[str, dict[str, str | None]]:
        missing_ids = [oid for oid in order_book_ids if oid not in self._instrument_lookup_cache]
        if missing_ids:
            rows = self._query_instrument_lookup(missing_ids)
            for order_book_id, rq_type, detail_table in rows:
                self._instrument_lookup_cache[order_book_id] = _InstrumentLookup(
                    order_book_id=order_book_id,
                    rq_type=rq_type,
                    detail_table=detail_table or None,
                    asset_type=self._asset_type_from_metadata(
                        order_book_id=order_book_id,
                        rq_type=rq_type,
                    ),
                )
            unresolved = [oid for oid in missing_ids if oid not in self._instrument_lookup_cache]
            if unresolved:
                preview = ", ".join(unresolved[:5])
                raise ValueError(
                    "order_book_id not found in market_meta_RQ.public.all_instruments: "
                    f"{preview}{' ...' if len(unresolved) > 5 else ''}"
                )

        return {
            order_book_id: {
                "type": self._instrument_lookup_cache[order_book_id].rq_type,
                "detail_table": self._instrument_lookup_cache[order_book_id].detail_table,
                "asset_type": self._instrument_lookup_cache[order_book_id].asset_type,
            }
            for order_book_id in order_book_ids
        }

    def _query_instrument_lookup(self, order_book_ids: Sequence[str]) -> list[tuple[str, str, str]]:
        sql = f"""
SELECT
    "order_book_id",
    "type",
    COALESCE("detail_table", '')
FROM {self._pg_table("all_instruments")}
WHERE "order_book_id" = ANY(%s::varchar[])
ORDER BY "order_book_id";
"""
        with self._get_pg_connection().cursor() as cursor:
            cursor.execute(sql, (list(order_book_ids),))
            return [
                (
                    str(order_book_id),
                    str(rq_type),
                    str(detail_table or ""),
                )
                for order_book_id, rq_type, detail_table in cursor.fetchall()
            ]

    @staticmethod
    def _asset_type_from_metadata(
        *,
        order_book_id: str,
        rq_type: str,
    ) -> str:
        if rq_type == "Option":
            bare = order_book_id.split(".", 1)[0]
            if bare.isdigit():
                return "etf_option"
            if bare and bare[0].isalpha():
                return "commodity_option"
            raise ValueError(f"cannot infer option subtype from order_book_id {order_book_id!r}")
        if rq_type in _RQ_TYPE_TO_ASSET:
            return _RQ_TYPE_TO_ASSET[rq_type]
        raise ValueError(
            f"all_instruments type {rq_type!r} for {order_book_id!r} "
            "does not map to a maintained ClickHouse market-data table"
        )

    @staticmethod
    def _infer_option_subtype(order_book_id: str) -> str:
        bare = order_book_id.split(".", 1)[0]
        if bare.isdigit():
            return "etf_option"
        if bare and bare[0].isalpha():
            return "commodity_option"
        raise ValueError(f"cannot infer option subtype from order_book_id {order_book_id!r}")

    @staticmethod
    def _normalize_order_book_ids(order_book_ids: str | Sequence[str]) -> list[str]:
        if isinstance(order_book_ids, str):
            ids = [order_book_ids]
        else:
            ids = list(order_book_ids)
        if not ids:
            raise ValueError("order_book_ids cannot be empty")
        out: list[str] = []
        for value in ids:
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"invalid order_book_id: {value!r}")
            out.append(value.strip())
        return out

    @classmethod
    def _normalize_frequency(cls, frequency: str) -> Frequency:
        freq = cls._FREQ_ALIASES.get(str(frequency).lower(), str(frequency).lower())
        allowed = {"tick", "1m", "5m", "15m", "30m", "60m", "120m", "240m", "1d"}
        if freq not in allowed:
            raise ValueError(f"unsupported frequency: {frequency!r}; allowed={sorted(allowed)}")
        return freq  # type: ignore[return-value]

    @staticmethod
    def _parse_date_input(value: str | int | dt.date | dt.datetime | None) -> str | None:
        if value is None:
            return None
        import pandas as pd

        if isinstance(value, int) and not isinstance(value, bool):
            text = str(value)
            if len(text) == 8:
                ts = pd.to_datetime(text, format="%Y%m%d")
                return ts.strftime("%Y-%m-%d")
            ts = pd.to_datetime(text)
            return ts.strftime("%Y-%m-%d")
        if isinstance(value, dt.date) and not isinstance(value, dt.datetime):
            return value.strftime("%Y-%m-%d")
        if isinstance(value, dt.datetime):
            ts = pd.Timestamp(value)
            return ts.strftime("%Y-%m-%d")
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                raise ValueError("date string cannot be empty")
            if stripped.isdigit() and len(stripped) == 8:
                ts = pd.to_datetime(stripped, format="%Y%m%d")
                return ts.strftime("%Y-%m-%d")
            ts = pd.to_datetime(stripped)
            return ts.strftime("%Y-%m-%d")
        raise TypeError(f"unsupported date type: {type(value).__name__}")

    @staticmethod
    def _parse_time_slice(
        value: tuple[str | dt.time, str | dt.time] | list[str | dt.time] | None,
    ) -> tuple[int, int] | None:
        if value is None:
            return None
        if not isinstance(value, (tuple, list)) or len(value) != 2:
            raise ValueError(f"time_slice: invalid, expect tuple or list value like ('09:55', '10:11'), got {value}")

        def norm(item: str | dt.time) -> int:
            if isinstance(item, dt.time):
                return item.hour * 10000 + item.minute * 100 + item.second
            if isinstance(item, str):
                parts = [int(part) for part in item.strip().split(":")]
                if len(parts) == 2:
                    parts.append(0)
                if len(parts) != 3:
                    raise ValueError(f"invalid time string: {item!r}")
                return parts[0] * 10000 + parts[1] * 100 + parts[2]
            raise TypeError(f"invalid time_slice item: {item!r}")

        return norm(value[0]), norm(value[1])

    @staticmethod
    def _normalize_datetime_columns(df):
        if df is None or df.empty:
            return df
        import pandas as pd

        for col in ("datetime", "date", "trading_date"):
            if col not in df.columns:
                continue
            s = df[col]
            if isinstance(s.dtype, pd.DatetimeTZDtype):
                converted = s.dt.tz_localize(None)
            elif col == "datetime" and pd.api.types.is_numeric_dtype(s.dtype):
                converted = (
                    pd.to_datetime(s, unit="s", utc=True, errors="coerce")
                    .dt.tz_convert(CH_TIMEZONE)
                    .dt.tz_localize(None)
                )
            elif getattr(s.dtype, "kind", None) == "M" and str(s.dtype) == "datetime64[ns]":
                continue
            elif getattr(s.dtype, "kind", None) != "M":
                converted = pd.to_datetime(s, errors="coerce")
            else:
                converted = pd.to_datetime(s, errors="coerce")
            df[col] = converted.astype("datetime64[ns]")
        return df

    # ------------------------------------------------------------------
    # ClickHouse helpers
    # ------------------------------------------------------------------

    def _get_client(self) -> Client:
        if self.client is None:
            self.client = Client(
                host=self.config.host,
                port=self.config.port,
                user=self.config.username,
                password=self.config.password,
                database=self.config.database,
                secure=self.config.secure,
                compression="lz4",
                settings={"use_numpy": True, **self.settings},
            )
        return self.client

    def _get_arrow_client(self):
        if self.arrow_client is None:
            import clickhouse_connect
            from clickhouse_connect.driver.httputil import get_pool_manager

            # Database LAN traffic must not inherit IDE/system HTTP proxies.
            self._arrow_pool_manager = get_pool_manager()
            query_settings = {
                key: value
                for key, value in self.settings.items()
                if key != "use_numpy"
            }
            self.arrow_client = clickhouse_connect.get_client(
                host=self.config.host,
                port=self.config.http_port,
                username=self.config.username,
                password=self.config.password,
                database=self.config.database,
                secure=self.config.secure,
                settings=query_settings or None,
                compression="lz4",
                query_limit=0,
                autogenerate_session_id=False,
                pool_mgr=self._arrow_pool_manager,
            )
        return self.arrow_client

    def _get_pg_connection(self):
        if self.pg_connection is not None:
            return self.pg_connection
        try:
            import psycopg
        except ImportError as exc:
            raise ImportError("缺少 psycopg，请先安装: uv add 'psycopg[binary]'") from exc

        self.pg_connection = psycopg.connect(
            host=self.pg_config.host,
            port=self.pg_config.port,
            dbname=self.pg_config.database,
            user=self.pg_config.username,
            password=self.pg_config.password,
            autocommit=True,
        )
        return self.pg_connection

    def _query_pg_dataframe(self, sql: str, params: tuple[Any, ...] = ()):
        import pandas as pd

        with self._get_pg_connection().cursor() as cursor:
            cursor.execute(sql, params)
            rows = cursor.fetchall()
            columns = [desc.name for desc in cursor.description or ()]
        return pd.DataFrame(rows, columns=columns)

    def _query_pg_rows(self, sql: str, params: tuple[Any, ...] = ()) -> list[tuple[Any, ...]]:
        with self._get_pg_connection().cursor() as cursor:
            cursor.execute(sql, params)
            return list(cursor.fetchall())

    def _query_pg_rows_with_columns(
        self,
        sql: str,
        params: tuple[Any, ...] = (),
    ) -> tuple[list[tuple[Any, ...]], list[str]]:
        with self._get_pg_connection().cursor() as cursor:
            cursor.execute(sql, params)
            rows = list(cursor.fetchall())
            columns = [desc.name for desc in cursor.description or ()]
        return rows, columns

    def _pg_columns(self, table_name: str) -> tuple[str, ...]:
        cached = self._pg_schema_cache.get(table_name)
        if cached is not None:
            return cached
        sql = """
SELECT column_name
FROM information_schema.columns
WHERE table_schema = %s
  AND table_name = %s
ORDER BY ordinal_position;
"""
        rows = self._query_pg_rows(sql, (self.pg_config.schema, table_name))
        columns = tuple(str(row[0]) for row in rows)
        if not columns:
            raise ValueError(f"PostgreSQL table not found or has no columns: {self.pg_config.schema}.{table_name}")
        self._pg_schema_cache[table_name] = columns
        return columns

    def _first_pg_column(self, table_name: str, candidates: Sequence[str]) -> str:
        columns = set(self._pg_columns(table_name))
        for candidate in candidates:
            if candidate in columns:
                return candidate
        raise ValueError(f"{self.pg_config.schema}.{table_name} has none of columns {tuple(candidates)!r}")

    def _query_factor_table(
        self,
        *,
        table_name: str,
        order_book_ids: str | Sequence[str],
        date_column: str,
        start_date: str | int | dt.date | dt.datetime | None,
        end_date: str | int | dt.date | dt.datetime | None,
    ):
        ids = self._normalize_order_book_ids(order_book_ids)
        start = self._parse_date_input(start_date)
        end = self._parse_date_input(end_date)
        self._validate_date_range(start, end)
        columns = [col for col in self._pg_columns(table_name) if col not in {"created_at", "updated_at"}]
        if "order_book_id" not in columns or date_column not in columns:
            raise ValueError(f"{self.pg_config.schema}.{table_name} is missing order_book_id/{date_column}")

        where = ['"order_book_id" = ANY(%s::varchar[])']
        params: list[Any] = [ids]
        if start is not None:
            where.append(f'{self._pg_quote_identifier(date_column)} >= %s')
            params.append(start)
        if end is not None:
            where.append(f'{self._pg_quote_identifier(date_column)} <= %s')
            params.append(end)
        sql = f"""
SELECT {self._pg_select_list(columns)}
FROM {self._pg_table(table_name)}
{self._pg_where(where)}
ORDER BY "order_book_id", {self._pg_quote_identifier(date_column)};
"""
        return self._query_pg_dataframe(sql, tuple(params))

    def _get_calendar_dates(
        self,
        *,
        flag_column: str,
        start_date: str | int | dt.date | dt.datetime | None,
        end_date: str | int | dt.date | dt.datetime | None,
        market: str,
    ) -> list[dt.date]:
        self._require_cn_market(market)
        start = self._parse_date_input(start_date)
        end = self._parse_date_input(end_date)
        self._validate_date_range(start, end)
        columns = set(self._pg_columns("trading_dates"))
        date_col = self._first_pg_column("trading_dates", ("trading_date", "date"))
        if flag_column not in columns:
            raise ValueError(f"{self.pg_config.schema}.trading_dates is missing required column {flag_column!r}")

        where = [f"{self._pg_quote_identifier(flag_column)}"]
        params: list[Any] = []
        if start is not None:
            where.append(f'{self._pg_quote_identifier(date_col)} >= %s')
            params.append(start)
        if end is not None:
            where.append(f'{self._pg_quote_identifier(date_col)} <= %s')
            params.append(end)
        sql = f"""
SELECT {self._pg_quote_identifier(date_col)}
FROM {self._pg_table("trading_dates")}
{self._pg_where(where)}
ORDER BY {self._pg_quote_identifier(date_col)};
"""
        rows = self._query_pg_rows(sql, tuple(params))
        return [self._coerce_date(row[0]) for row in rows]

    def _get_relative_trading_date(
        self,
        *,
        date: str | int | dt.date | dt.datetime,
        n: int,
        direction: Literal["previous", "next"],
        market: str,
    ) -> dt.date:
        self._require_cn_market(market)
        if not isinstance(n, int) or isinstance(n, bool) or n < 1:
            raise ValueError("n must be a positive integer")
        target = self._parse_date_input(date)
        if target is None:
            raise ValueError("date is required")

        columns = set(self._pg_columns("trading_dates"))
        if "is_trading" not in columns:
            raise ValueError(f"{self.pg_config.schema}.trading_dates is missing required column 'is_trading'")
        date_col = self._first_pg_column("trading_dates", ("trading_date", "date"))
        operator = "<" if direction == "previous" else ">"
        ordering = "DESC" if direction == "previous" else "ASC"
        sql = f"""
SELECT {self._pg_quote_identifier(date_col)}
FROM {self._pg_table("trading_dates")}
WHERE "is_trading"
  AND {self._pg_quote_identifier(date_col)} {operator} %s
ORDER BY {self._pg_quote_identifier(date_col)} {ordering}
OFFSET %s
LIMIT 1;
"""
        rows = self._query_pg_rows(sql, (target, n - 1))
        if not rows:
            raise ValueError(f"no {direction} trading date found for date={target!r}, n={n}")
        return self._coerce_date(rows[0][0])

    def _suspension_date_bounds(
        self,
        order_book_ids: Sequence[str],
        *,
        table_name: str = "is_suspended",
    ) -> tuple[str | None, str | None]:
        sql = f"""
SELECT min("date"), max("date")
FROM {self._pg_table(table_name)}
WHERE "order_book_id" = ANY(%s::varchar[]);
"""
        rows = self._query_pg_rows(sql, (list(order_book_ids),))
        if not rows or rows[0][0] is None or rows[0][1] is None:
            return None, None
        return self._coerce_date(rows[0][0]).isoformat(), self._coerce_date(rows[0][1]).isoformat()

    @staticmethod
    def _normalize_optional_strings(value: str | Sequence[str] | None, name: str) -> list[str] | None:
        if value is None:
            return None
        values = [value] if isinstance(value, str) else list(value)
        if not values:
            raise ValueError(f"{name} cannot be empty")
        out: list[str] = []
        for item in values:
            if not isinstance(item, str) or not item.strip():
                raise ValueError(f"invalid {name}: {item!r}")
            out.append(item.strip())
        return out

    @classmethod
    def _normalize_instrument_types(cls, value: str | Sequence[str] | None) -> list[str] | None:
        values = cls._normalize_optional_strings(value, "type")
        if values is None:
            return None
        valid = {
            "CS", "ETF", "LOF", "INDX", "Future", "Spot", "Option",
            "Convertible", "Repo", "REITs", "FUND",
        }
        normalized: set[str] = set()
        for item in values:
            if item.upper() == "STOCK":
                normalized.add("CS")
            elif item.upper() == "FUND":
                normalized.update({"ETF", "LOF", "REITs", "FUND"})
            elif item.upper() == "INDEX":
                normalized.add("INDX")
            elif item not in valid:
                raise ValueError(f"invalid type: {values}, chose any in {sorted(valid)}")
            else:
                normalized.add(item)
        return sorted(normalized)

    @staticmethod
    def _normalize_classification_code(value: str, name: str) -> str:
        if not isinstance(value, str):
            raise ValueError(f"{name}: expected str, got {type(value).__name__}")
        return value.strip()

    @staticmethod
    def _shift_months(value: dt.date, months: int) -> dt.date:
        import calendar

        month_index = value.year * 12 + value.month - 1 + months
        year, zero_based_month = divmod(month_index, 12)
        month = zero_based_month + 1
        day = min(value.day, calendar.monthrange(year, month)[1])
        return dt.date(year, month, day)

    def _latest_local_trading_date(self) -> dt.date:
        date_column = self._first_pg_column("trading_dates", ("trading_date", "date"))
        rows = self._query_pg_rows(
            f"""
SELECT max({self._pg_quote_identifier(date_column)})
FROM {self._pg_table("trading_dates")}
WHERE "is_trading"
  AND {self._pg_quote_identifier(date_column)} <= %s;
""",
            (dt.date.today().isoformat(),),
        )
        if not rows or rows[0][0] is None:
            raise ValueError("local trading calendar has no trading date on or before today")
        return self._coerce_date(rows[0][0])

    @staticmethod
    def _coerce_date(value: Any) -> dt.date:
        if isinstance(value, dt.datetime):
            return value.date()
        if isinstance(value, dt.date):
            return value
        return dt.date.fromisoformat(str(value)[:10])

    @staticmethod
    def _validate_date_range(start: str | None, end: str | None) -> None:
        if start is not None and end is not None and dt.date.fromisoformat(start) > dt.date.fromisoformat(end):
            raise ValueError(f"invalid date range: [{start!r}, {end!r}]")

    @staticmethod
    def _pg_where(where: Sequence[str]) -> str:
        return f"WHERE {' AND '.join(where)}" if where else ""

    def _pg_select_list(self, columns: Sequence[str]) -> str:
        return ", ".join(self._pg_quote_identifier(column) for column in columns)

    @staticmethod
    def _require_cn_market(market: str) -> None:
        if market != "cn":
            raise ValueError("only market='cn' is supported")

    def preload_instrument_lookup(self) -> None:
        """Load the full all_instruments routing table into memory.

        This is optional. Normal ``get_price`` calls lazily fetch only missing
        ``order_book_id`` values, but preloading removes the PostgreSQL round
        trip from later queries in long-running research sessions.
        """
        sql = f"""
SELECT
    "order_book_id",
    "type",
    COALESCE("detail_table", '')
FROM {self._pg_table("all_instruments")};
"""
        with self._get_pg_connection().cursor() as cursor:
            cursor.execute(sql)
            for order_book_id, rq_type, detail_table in cursor.fetchall():
                self._instrument_lookup_cache[str(order_book_id)] = _InstrumentLookup(
                    order_book_id=str(order_book_id),
                    rq_type=str(rq_type),
                    detail_table=str(detail_table) if detail_table else None,
                    asset_type=self._asset_type_from_metadata(
                        order_book_id=str(order_book_id),
                        rq_type=str(rq_type),
                    ),
                )

    def warmup_instrument_lookup(self, order_book_ids: str | Sequence[str] | None = None) -> None:
        """Preload all or selected instrument routing records."""
        if order_book_ids is None:
            self.preload_instrument_lookup()
            return
        self._lookup_instruments(self._normalize_order_book_ids(order_book_ids))

    def _query_dataframe(self, sql: str, params: dict[str, Any]):
        sql = sql.strip().rstrip(";")
        table = self._get_arrow_client().query_arrow(
            sql,
            parameters=params,
        )
        frame = table.to_pandas(use_threads=True)
        return self._normalize_datetime_columns(frame)

    @staticmethod
    def _normalize_clickhouse_column(column: Any, type_str: str) -> Any:
        """Return pandas-friendly columns with ClickHouse time zones preserved.

        ``clickhouse-driver`` with ``use_numpy=True`` returns DateTime columns as
        UTC-like ``datetime64`` arrays while stripping the ClickHouse column time
        zone. We keep the fast numpy path, then explicitly convert those arrays
        back to Asia/Shanghai and drop the timezone to match rqdatac-style
        tz-naive timestamps.
        """
        if not str(type_str).startswith("DateTime"):
            return column

        import pandas as pd

        series = pd.Series(column)
        dtype = series.dtype
        if isinstance(dtype, pd.DatetimeTZDtype):
            return series.dt.tz_convert(CH_TIMEZONE).dt.tz_localize(None)
        if getattr(dtype, "kind", None) == "M":
            return pd.to_datetime(series, utc=True).dt.tz_convert(CH_TIMEZONE).dt.tz_localize(None)

        converted = pd.to_datetime(series, errors="coerce")
        if isinstance(converted.dtype, pd.DatetimeTZDtype):
            return converted.dt.tz_convert(CH_TIMEZONE).dt.tz_localize(None)
        return converted

    def _describe_table(self, table: str) -> dict[str, str]:
        cached = self._schema_cache.get(table)
        if cached is not None:
            return cached
        rows = self._get_arrow_client().query(f"DESCRIBE TABLE {table}").result_rows
        result = {str(row[0]): str(row[1]) for row in rows}
        self._schema_cache[table] = result
        return result

    def _describe_table_signature(self, table: str) -> tuple[tuple[str, ...], ...]:
        cached = self._schema_signature_cache.get(table)
        if cached is not None:
            return cached
        rows = self._get_arrow_client().query(f"DESCRIBE TABLE {table}").result_rows
        # name, type, default_type and default_expression define the read contract.
        result = tuple(tuple(str(value or "") for value in row[:4]) for row in rows)
        self._schema_signature_cache[table] = result
        return result

    def _ensure_live_compatible(self, historical: str, live: str) -> None:
        if self._describe_table_signature(historical) != self._describe_table_signature(live):
            raise YMMDataSchemaError(
                f"live table schema is incompatible with historical table: {live} != {historical}"
            )

    def _get_status_router(self) -> UpdateStatusRouter:
        if self._status_router is None:
            self._status_router = UpdateStatusRouter(self._get_pg_connection(), cache_seconds=30.0)
        return self._status_router

    def invalidate_update_status_cache(self) -> None:
        if self._status_router is not None:
            self._status_router.invalidate()

    def get_update_status(self, *, method: str | Sequence[str]):
        """Return the latest successful local materialization time for a method."""
        return self._get_status_router().get_update_status(method=method)

    def _table(self, table_name: str, *, database: str | None = None) -> str:
        selected = database or self.config.database
        return f"{self._quote_identifier(selected)}.{self._quote_identifier(table_name)}"

    def _pg_table(self, table_name: str) -> str:
        return f"{self._pg_quote_identifier(self.pg_config.schema)}.{self._pg_quote_identifier(table_name)}"

    @staticmethod
    def _quote_identifier(identifier: str) -> str:
        if not _IDENT_RE.match(identifier):
            raise ValueError(f"unsafe identifier: {identifier!r}")
        return f"`{identifier}`"

    @staticmethod
    def _pg_quote_identifier(identifier: str) -> str:
        if not _IDENT_RE.match(identifier):
            raise ValueError(f"unsafe identifier: {identifier!r}")
        return '"' + identifier.replace('"', '""') + '"'


class _ClientFuturesNamespace:
    def __init__(self, client: RQMarketDataClient) -> None:
        self._client = client

    def get_dominant(
        self,
        underlying_symbol: str,
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        rule: int = 0,
        rank: int = 1,
        market: str = "cn",
    ):
        return self._client.get_dominant(
            underlying_symbol,
            start_date=start_date,
            end_date=end_date,
            rule=rule,
            rank=rank,
            market=market,
        )

    def get_dominant_batch(
        self,
        underlying_symbol_list: Sequence[str],
        start_date: str | int | dt.date | dt.datetime,
        end_date: str | int | dt.date | dt.datetime,
        rule: int = 0,
        rank: int = 1,
        market: str = "cn",
    ):
        return self._client.get_dominant_batch(
            underlying_symbol_list,
            start_date=start_date,
            end_date=end_date,
            rule=rule,
            rank=rank,
            market=market,
        )

    def get_contracts(
        self,
        underlying_symbol: str,
        date: str | int | dt.date | dt.datetime | None = None,
        market: str = "cn",
    ) -> list[str]:
        return self._client.get_contracts(
            underlying_symbol,
            date=date,
            market=market,
        )

    def get_contracts_batch(
        self,
        underlying_symbol_list: Sequence[str],
        start_date: str | int | dt.date | dt.datetime,
        end_date: str | int | dt.date | dt.datetime,
        market: str = "cn",
    ):
        return self._client.get_contracts_batch(
            underlying_symbol_list,
            start_date=start_date,
            end_date=end_date,
            market=market,
        )

    def get_ex_factor(
        self,
        underlying_symbols: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        adjust_method: str = "prev_close_spread",
        rule: int = 0,
        rank: int = 1,
        market: str = "cn",
    ):
        return self._client.get_future_ex_factor(
            underlying_symbols,
            start_date=start_date,
            end_date=end_date,
            adjust_method=adjust_method,
            rule=rule,
            rank=rank,
            market=market,
        )

    def get_dominant_price(
        self,
        underlying_symbols: str | list[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        frequency: str = "1d",
        fields: str | list[str] | None = None,
        adjust_type: str = "pre",
        adjust_method: str = "prev_close_spread",
        rule: int = 0,
        rank: int = 1,
        time_slice: tuple[str | dt.time, str | dt.time] | list[str | dt.time] | None = None,
    ):
        return self._client.get_dominant_price(
            underlying_symbols,
            start_date=start_date,
            end_date=end_date,
            frequency=frequency,
            fields=fields,
            adjust_type=adjust_type,
            adjust_method=adjust_method,
            rule=rule,
            rank=rank,
            time_slice=time_slice,
        )

    def get_contract_multiplier(
        self,
        underlying_symbols: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        market: str = "cn",
    ):
        return self._client.get_contract_multiplier(
            underlying_symbols,
            start_date=start_date,
            end_date=end_date,
            market=market,
        )

    def get_exchange_daily(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        fields: str | Sequence[str] | None = None,
        market: str = "cn",
    ):
        return self._client.get_exchange_daily(
            order_book_ids,
            start_date=start_date,
            end_date=end_date,
            fields=fields,
            market=market,
        )

    def get_continuous_contracts(
        self,
        underlying_symbol: Any,
        start_date: str | int | dt.date | dt.datetime | None,
        end_date: str | int | dt.date | dt.datetime | None,
        type: str = "front_month",
        market: str = "cn",
    ):
        return self._client.get_continuous_contracts(
            underlying_symbol,
            start_date,
            end_date,
            type=type,
            market=market,
        )

    def get_trading_parameters(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        fields: str | Sequence[str] | None = None,
        market: str = "cn",
    ):
        return self._client.get_trading_parameters(
            order_book_ids,
            start_date=start_date,
            end_date=end_date,
            fields=fields,
            market=market,
        )


def _extract_client_kwargs(kwargs: dict[str, Any]) -> dict[str, Any]:
    client_keys = {
        "connection_mode",
        "ch_host",
        "ch_port",
        "ch_http_port",
        "ch_database",
        "ch_username",
        "ch_password",
        "pg_host",
        "pg_port",
        "pg_database",
        "pg_username",
        "pg_password",
        "pg_schema",
        "pg_connection",
        "secure",
        "client",
        "arrow_client",
        "settings",
    }
    return {key: kwargs.pop(key) for key in list(kwargs) if key in client_keys}


def get_price(*args: Any, **kwargs: Any):
    """Convenience one-shot wrapper around :class:`RQMarketDataClient`.

    Connection kwargs such as ``connection_mode='lan'`` or ``ch_host=...`` are
    consumed by the client constructor; the remaining kwargs are passed to
    :meth:`RQMarketDataClient.get_price`.
    """
    client_kwargs = _extract_client_kwargs(kwargs)
    with RQMarketDataClient(**client_kwargs) as client:
        return client.get_price(*args, **kwargs)


def get_update_status(*, method: str | Sequence[str]):
    with RQMarketDataClient() as client:
        return client.get_update_status(method=method)


def get_dominant(
    underlying_symbol: str,
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    rule: int = 0,
    rank: int = 1,
    market: str = "cn",
    **kwargs: Any,
):
    """Convenience one-shot wrapper for local futures.get_dominant."""
    client_kwargs = _extract_client_kwargs(kwargs)
    if kwargs:
        unexpected = ", ".join(sorted(kwargs))
        raise TypeError(f"unexpected keyword argument(s): {unexpected}")
    with RQMarketDataClient(**client_kwargs) as client:
        return client.get_dominant(
            underlying_symbol,
            start_date=start_date,
            end_date=end_date,
            rule=rule,
            rank=rank,
            market=market,
        )


def get_dominant_future(*args: Any, **kwargs: Any):
    """Deprecated rqdatac-compatible alias for get_dominant."""
    return get_dominant(*args, **kwargs)


def get_dominant_batch(
    underlying_symbol_list: Sequence[str],
    start_date: str | int | dt.date | dt.datetime,
    end_date: str | int | dt.date | dt.datetime,
    rule: int = 0,
    rank: int = 1,
    market: str = "cn",
    **kwargs: Any,
):
    """Convenience one-shot wrapper for local futures.get_dominant_batch."""
    client_kwargs = _extract_client_kwargs(kwargs)
    if kwargs:
        unexpected = ", ".join(sorted(kwargs))
        raise TypeError(f"unexpected keyword argument(s): {unexpected}")
    with RQMarketDataClient(**client_kwargs) as client:
        return client.get_dominant_batch(
            underlying_symbol_list,
            start_date=start_date,
            end_date=end_date,
            rule=rule,
            rank=rank,
            market=market,
        )


def get_contracts(
    underlying_symbol: str,
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
    **kwargs: Any,
) -> list[str]:
    """Convenience one-shot wrapper for local futures.get_contracts."""
    client_kwargs = _extract_client_kwargs(kwargs)
    if kwargs:
        unexpected = ", ".join(sorted(kwargs))
        raise TypeError(f"unexpected keyword argument(s): {unexpected}")
    with RQMarketDataClient(**client_kwargs) as client:
        return client.get_contracts(
            underlying_symbol,
            date=date,
            market=market,
        )


def get_contracts_batch(
    underlying_symbol_list: Sequence[str],
    start_date: str | int | dt.date | dt.datetime,
    end_date: str | int | dt.date | dt.datetime,
    market: str = "cn",
    **kwargs: Any,
):
    """Convenience one-shot wrapper for local futures.get_contracts_batch."""
    client_kwargs = _extract_client_kwargs(kwargs)
    if kwargs:
        unexpected = ", ".join(sorted(kwargs))
        raise TypeError(f"unexpected keyword argument(s): {unexpected}")
    with RQMarketDataClient(**client_kwargs) as client:
        return client.get_contracts_batch(
            underlying_symbol_list,
            start_date=start_date,
            end_date=end_date,
            market=market,
        )


def get_future_ex_factor(
    underlying_symbols: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    adjust_method: str = "prev_close_spread",
    rule: int = 0,
    rank: int = 1,
    market: str = "cn",
    **kwargs: Any,
):
    """Convenience one-shot wrapper for local futures.get_ex_factor."""
    client_kwargs = _extract_client_kwargs(kwargs)
    if kwargs:
        unexpected = ", ".join(sorted(kwargs))
        raise TypeError(f"unexpected keyword argument(s): {unexpected}")
    with RQMarketDataClient(**client_kwargs) as client:
        return client.get_future_ex_factor(
            underlying_symbols,
            start_date=start_date,
            end_date=end_date,
            adjust_method=adjust_method,
            rule=rule,
            rank=rank,
            market=market,
        )


def get_future_dominant_price(
    underlying_symbols: str | list[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    frequency: str = "1d",
    fields: str | list[str] | None = None,
    adjust_type: str = "pre",
    adjust_method: str = "prev_close_spread",
    rule: int = 0,
    rank: int = 1,
    time_slice: tuple[str | dt.time, str | dt.time] | list[str | dt.time] | None = None,
    **kwargs: Any,
):
    """Convenience one-shot wrapper for local futures.get_dominant_price."""
    client_kwargs = _extract_client_kwargs(kwargs)
    if kwargs:
        unexpected = ", ".join(sorted(kwargs))
        raise TypeError(f"unexpected keyword argument(s): {unexpected}")
    with RQMarketDataClient(**client_kwargs) as client:
        return client.get_dominant_price(
            underlying_symbols,
            start_date=start_date,
            end_date=end_date,
            frequency=frequency,
            fields=fields,
            adjust_type=adjust_type,
            adjust_method=adjust_method,
            rule=rule,
            rank=rank,
            time_slice=time_slice,
        )


def get_future_contract_multiplier(
    underlying_symbols: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
    **kwargs: Any,
):
    client_kwargs = _extract_client_kwargs(kwargs)
    if kwargs:
        unexpected = ", ".join(sorted(kwargs))
        raise TypeError(f"unexpected keyword argument(s): {unexpected}")
    with RQMarketDataClient(**client_kwargs) as client:
        return client.get_contract_multiplier(
            underlying_symbols,
            start_date=start_date,
            end_date=end_date,
            market=market,
        )


def get_future_exchange_daily(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
    **kwargs: Any,
):
    client_kwargs = _extract_client_kwargs(kwargs)
    if kwargs:
        unexpected = ", ".join(sorted(kwargs))
        raise TypeError(f"unexpected keyword argument(s): {unexpected}")
    with RQMarketDataClient(**client_kwargs) as client:
        return client.get_exchange_daily(
            order_book_ids,
            start_date=start_date,
            end_date=end_date,
            fields=fields,
            market=market,
        )


def get_future_continuous_contracts(
    underlying_symbol: Any,
    start_date: str | int | dt.date | dt.datetime | None,
    end_date: str | int | dt.date | dt.datetime | None,
    type: str = "front_month",
    market: str = "cn",
    **kwargs: Any,
):
    client_kwargs = _extract_client_kwargs(kwargs)
    if kwargs:
        unexpected = ", ".join(sorted(kwargs))
        raise TypeError(f"unexpected keyword argument(s): {unexpected}")
    with RQMarketDataClient(**client_kwargs) as client:
        return client.get_continuous_contracts(
            underlying_symbol,
            start_date,
            end_date,
            type=type,
            market=market,
        )


def get_future_trading_parameters(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
    **kwargs: Any,
):
    client_kwargs = _extract_client_kwargs(kwargs)
    if kwargs:
        unexpected = ", ".join(sorted(kwargs))
        raise TypeError(f"unexpected keyword argument(s): {unexpected}")
    with RQMarketDataClient(**client_kwargs) as client:
        return client.get_trading_parameters(
            order_book_ids,
            start_date=start_date,
            end_date=end_date,
            fields=fields,
            market=market,
        )


class _FuturesNamespace:
    def get_dominant(
        self,
        underlying_symbol: str,
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        rule: int = 0,
        rank: int = 1,
        market: str = "cn",
        **kwargs: Any,
    ):
        return get_dominant(
            underlying_symbol,
            start_date=start_date,
            end_date=end_date,
            rule=rule,
            rank=rank,
            market=market,
            **kwargs,
        )

    def get_dominant_batch(
        self,
        underlying_symbol_list: Sequence[str],
        start_date: str | int | dt.date | dt.datetime,
        end_date: str | int | dt.date | dt.datetime,
        rule: int = 0,
        rank: int = 1,
        market: str = "cn",
        **kwargs: Any,
    ):
        return get_dominant_batch(
            underlying_symbol_list,
            start_date=start_date,
            end_date=end_date,
            rule=rule,
            rank=rank,
            market=market,
            **kwargs,
        )

    def get_contracts(
        self,
        underlying_symbol: str,
        date: str | int | dt.date | dt.datetime | None = None,
        market: str = "cn",
        **kwargs: Any,
    ) -> list[str]:
        return get_contracts(
            underlying_symbol,
            date=date,
            market=market,
            **kwargs,
        )

    def get_contracts_batch(
        self,
        underlying_symbol_list: Sequence[str],
        start_date: str | int | dt.date | dt.datetime,
        end_date: str | int | dt.date | dt.datetime,
        market: str = "cn",
        **kwargs: Any,
    ):
        return get_contracts_batch(
            underlying_symbol_list,
            start_date=start_date,
            end_date=end_date,
            market=market,
            **kwargs,
        )

    def get_ex_factor(
        self,
        underlying_symbols: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        adjust_method: str = "prev_close_spread",
        rule: int = 0,
        rank: int = 1,
        market: str = "cn",
        **kwargs: Any,
    ):
        return get_future_ex_factor(
            underlying_symbols,
            start_date=start_date,
            end_date=end_date,
            adjust_method=adjust_method,
            rule=rule,
            rank=rank,
            market=market,
            **kwargs,
        )

    def get_dominant_price(
        self,
        underlying_symbols: str | list[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        frequency: str = "1d",
        fields: str | list[str] | None = None,
        adjust_type: str = "pre",
        adjust_method: str = "prev_close_spread",
        rule: int = 0,
        rank: int = 1,
        time_slice: tuple[str | dt.time, str | dt.time] | list[str | dt.time] | None = None,
        **kwargs: Any,
    ):
        return get_future_dominant_price(
            underlying_symbols,
            start_date=start_date,
            end_date=end_date,
            frequency=frequency,
            fields=fields,
            adjust_type=adjust_type,
            adjust_method=adjust_method,
            rule=rule,
            rank=rank,
            time_slice=time_slice,
            **kwargs,
        )

    def get_contract_multiplier(
        self,
        underlying_symbols: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        market: str = "cn",
        **kwargs: Any,
    ):
        return get_future_contract_multiplier(
            underlying_symbols,
            start_date=start_date,
            end_date=end_date,
            market=market,
            **kwargs,
        )

    def get_exchange_daily(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        fields: str | Sequence[str] | None = None,
        market: str = "cn",
        **kwargs: Any,
    ):
        return get_future_exchange_daily(
            order_book_ids,
            start_date=start_date,
            end_date=end_date,
            fields=fields,
            market=market,
            **kwargs,
        )

    def get_continuous_contracts(
        self,
        underlying_symbol: Any,
        start_date: str | int | dt.date | dt.datetime | None,
        end_date: str | int | dt.date | dt.datetime | None,
        type: str = "front_month",
        market: str = "cn",
        **kwargs: Any,
    ):
        return get_future_continuous_contracts(
            underlying_symbol,
            start_date,
            end_date,
            type=type,
            market=market,
            **kwargs,
        )

    def get_trading_parameters(
        self,
        order_book_ids: str | Sequence[str],
        start_date: str | int | dt.date | dt.datetime | None = None,
        end_date: str | int | dt.date | dt.datetime | None = None,
        fields: str | Sequence[str] | None = None,
        market: str = "cn",
        **kwargs: Any,
    ):
        return get_future_trading_parameters(
            order_book_ids,
            start_date=start_date,
            end_date=end_date,
            fields=fields,
            market=market,
            **kwargs,
        )


futures = _FuturesNamespace()
MarketDataRQClient = RQMarketDataClient
