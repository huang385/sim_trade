from __future__ import annotations

import datetime as dt
import warnings
from typing import TYPE_CHECKING, Sequence


if TYPE_CHECKING:
    from .market_data import RQMarketDataClient


PROPERTY_FIELDS = ("product_name", "symbol", "contract_multiplier", "strike_price")


def get_contract_property(
    client: "RQMarketDataClient",
    order_book_ids,
    start_date=None,
    end_date=None,
    fields=None,
    market="cn",
):
    client._require_cn_market(market)
    ids = _normalize_option_ids(client, order_book_ids)
    selected = _normalize_fields(fields)
    selected_unique = list(dict.fromkeys(selected))
    start = client._parse_date_input(start_date)
    end = client._parse_date_input(end_date) or dt.date.today().isoformat()
    client._validate_date_range(start, end)

    property_columns = ", ".join(
        f'properties.{client._pg_quote_identifier(field)}' for field in selected_unique
    )
    select_suffix = f", {property_columns}" if property_columns else ""
    start_value = start or "2015-01-01"
    rows = client._query_pg_rows(
        f"""
SELECT
    properties."order_book_id",
    calendar."date",
    properties."effective_date" AS "_effective_date"{select_suffix}
FROM {client._pg_table('option_contract_property')} properties
JOIN {client._pg_table('trading_dates')} calendar
  ON calendar."is_trading"
 AND calendar."date" >= GREATEST(
        DATE '2015-01-01',
        properties."effective_date",
        %s::date
     )
 AND calendar."date" <= LEAST(
        properties."end_date",
        %s::date
     )
WHERE properties."order_book_id" = ANY(%s::varchar[])
ORDER BY properties."order_book_id", calendar."date";
""",
        (start_value, end, ids),
    )
    if not rows:
        return None

    import pandas as pd

    frame = pd.DataFrame(
        rows,
        columns=["order_book_id", "trading_date", "_effective_date", *selected_unique],
    )
    frame["trading_date"] = pd.to_datetime(frame["trading_date"]).astype("datetime64[ns]")
    frame["_effective_date"] = pd.to_datetime(frame["_effective_date"]).astype("datetime64[ns]")
    if "strike_price" in frame.columns:
        frame["strike_price"] = pd.to_numeric(frame["strike_price"]).astype("float64")
    if "contract_multiplier" in frame.columns:
        multiplier = pd.to_numeric(frame["contract_multiplier"])
        if (frame["trading_date"] == frame["_effective_date"]).all() and (multiplier % 1 == 0).all():
            frame["contract_multiplier"] = multiplier.astype("int64")
        else:
            frame["contract_multiplier"] = multiplier.astype("float64")
    frame.drop(columns="_effective_date", inplace=True)
    result = frame.set_index(["order_book_id", "trading_date"])
    result.index = result.index.set_names(["order_book_id", "trading_date"])
    # rqdatac removes duplicate contract-property fields while preserving first order.
    return result.loc[:, selected_unique]


def _normalize_option_ids(client: "RQMarketDataClient", value) -> list[str]:
    if isinstance(value, str):
        requested = [value]
    else:
        try:
            requested = list(value)
        except TypeError as exc:
            raise TypeError("order_book_ids: expect a string or list of strings") from exc
    if not requested:
        raise ValueError("order_book_ids: at least one valid instrument expected, got none")
    normalized = [str(item) for item in requested]
    rows = client._query_pg_rows(
        f"""
SELECT "order_book_id"
FROM {client._pg_table('all_instruments')}
WHERE "order_book_id" = ANY(%s::varchar[])
  AND "type" = 'Option'
UNION
SELECT "order_book_id"
FROM {client._pg_table('option_contract_property')}
WHERE "order_book_id" = ANY(%s::varchar[]);
""",
        (normalized, normalized),
    )
    option_ids = {str(row[0]) for row in rows}
    valid: list[str] = []
    seen: set[str] = set()
    for order_book_id in normalized:
        if order_book_id not in option_ids:
            warnings.warn(f"invalid order_book_id: {order_book_id}", stacklevel=3)
        elif order_book_id not in seen:
            valid.append(order_book_id)
            seen.add(order_book_id)
    if not valid:
        raise ValueError("order_book_ids: at least one valid instrument expected, got none")
    return valid


def _normalize_fields(value: str | Sequence[str] | None) -> list[str]:
    if value is None:
        fields = list(PROPERTY_FIELDS)
    elif isinstance(value, list):
        fields = list(value)
    else:
        fields = [value]
    for field in fields:
        if field not in PROPERTY_FIELDS:
            raise ValueError(
                f"Contract Property: got invalided value {field}, choose any in {list(PROPERTY_FIELDS)}"
            )
    return fields
