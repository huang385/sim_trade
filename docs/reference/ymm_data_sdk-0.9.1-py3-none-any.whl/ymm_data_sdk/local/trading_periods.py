from __future__ import annotations

import datetime as dt
from typing import Any, Sequence, TYPE_CHECKING

if TYPE_CHECKING:
    from .market_data import RQMarketDataClient


def get_trading_periods(
    client: "RQMarketDataClient",
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    frequency: str = "1m",
    market: str = "cn",
):
    """Return local continuous-auction sessions with rqdatac-compatible labels."""
    client._require_cn_market(market)
    if frequency not in {"1m", "tick"}:
        raise ValueError(f"frequency: got an invalid value {frequency!r}, expected one of ['1m', 'tick']")

    start, end = _date_range(client, start_date, end_date)
    calendar_rows = client._query_pg_rows(
        f'''
SELECT "date"
FROM {client._pg_table("trading_dates")}
WHERE "is_trading"
  AND "date">=%s
  AND "date"<=%s
ORDER BY "date";
''',
        (start, end),
    )
    if not calendar_rows:
        return None

    ids = client._normalize_order_book_ids(order_book_ids)
    client.instruments(ids, market=market)
    dates = [client._coerce_date(row[0]) for row in calendar_rows]
    contract_periods = _load_contract_periods(client, ids, start, end, frequency)

    result: list[tuple[str, dt.date, str]] = []
    for order_book_id in ids:
        for date in dates:
            materialized_session = contract_periods.get((order_book_id, date))
            if materialized_session is not None:
                result.append((order_book_id, date, materialized_session))

    if not result:
        import pandas as pd

        empty = pd.DataFrame(columns=["order_book_id", "date", "trading_hours"])
        return empty.set_index(["order_book_id", "date"])

    import pandas as pd

    frame = pd.DataFrame(result, columns=["order_book_id", "date", "trading_hours"])
    return frame.set_index(["order_book_id", "date"]).sort_index()


def _date_range(client: "RQMarketDataClient", start_date: Any, end_date: Any) -> tuple[str, str]:
    start = client._parse_date_input(start_date)
    end = client._parse_date_input(end_date)
    if start is None and end is None:
        end_value = dt.date.today()
        start_value = client._shift_months(end_value, -3)
    elif start is None:
        end_value = dt.date.fromisoformat(end)
        start_value = client._shift_months(end_value, -3)
    elif end is None:
        start_value = dt.date.fromisoformat(start)
        end_value = client._shift_months(start_value, 3)
    else:
        start_value = dt.date.fromisoformat(start)
        end_value = dt.date.fromisoformat(end)
    client._validate_date_range(start_value.isoformat(), end_value.isoformat())
    return start_value.isoformat(), end_value.isoformat()


def _load_contract_periods(
    client: "RQMarketDataClient",
    order_book_ids: list[str],
    start: str,
    end: str,
    frequency: str,
) -> dict[tuple[str, dt.date], str]:
    if not order_book_ids:
        return {}
    column = "trading_hours_1m" if frequency == "1m" else "trading_hours_tick"
    rows = client._query_pg_rows(
        f'''
SELECT periods."order_book_id", calendar."date",
       periods.{client._pg_quote_identifier(column)}
FROM {client._pg_table("trading_periods")} AS periods
JOIN {client._pg_table("trading_dates")} AS calendar
  ON calendar."is_trading"
 AND calendar."date" BETWEEN periods."start_date" AND periods."end_date"
WHERE periods."order_book_id"=ANY(%s::varchar[])
  AND calendar."date">=%s
  AND calendar."date"<=%s
''',
        (order_book_ids, start, end),
    )
    return {
        (str(order_book_id), _as_date(date)): str(hours)
        for order_book_id, date, hours in rows
        if _as_date(date) is not None
    }

def _as_date(value: Any) -> dt.date | None:
    if value is None:
        return None
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    text = str(value)[:10]
    if text in {"", "0000-00-00", "2999-12-31", "None", "NaT"}:
        return None
    return dt.date.fromisoformat(text)
