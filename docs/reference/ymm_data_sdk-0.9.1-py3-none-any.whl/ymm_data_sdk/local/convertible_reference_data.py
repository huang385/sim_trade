from __future__ import annotations

import datetime as dt
import warnings
from typing import TYPE_CHECKING, Any, Sequence

from ..convertible_instrument import ConvertibleInstrument


if TYPE_CHECKING:
    from .market_data import RQMarketDataClient


ALL_COLUMNS = (
    "order_book_id",
    "symbol",
    "full_name",
    "exchange",
    "bond_type",
    "trade_type",
    "value_date",
    "maturity_date",
    "par_value",
    "coupon_rate",
    "coupon_frequency",
    "coupon_method",
    "compensation_rate",
    "total_issue_size",
    "de_listed_date",
    "stock_code",
    "conversion_start_date",
    "conversion_end_date",
    "redemption_price",
    "issue_price",
    "call_protection",
    "listed_date",
    "early_maturity_date",
    "stop_trading_date",
    "issue_method",
    "list_announcement_date",
    "pref_allocation_registration_date",
    "pref_allocation_payment_end_date",
)

DATE_COLUMNS = {
    "value_date",
    "maturity_date",
    "de_listed_date",
    "conversion_start_date",
    "conversion_end_date",
    "listed_date",
    "early_maturity_date",
    "stop_trading_date",
    "list_announcement_date",
    "pref_allocation_registration_date",
    "pref_allocation_payment_end_date",
}

NUMERIC_COLUMNS = {
    "par_value",
    "coupon_rate",
    "coupon_frequency",
    "compensation_rate",
    "total_issue_size",
    "redemption_price",
    "issue_price",
    "call_protection",
}

OBJECT_COLUMNS = (
    "order_book_id",
    "symbol",
    "full_name",
    "exchange",
    "bond_type",
    "trade_type",
    "value_date",
    "listed_date",
    "maturity_date",
    "early_maturity_date",
    "par_value",
    "coupon_rate",
    "coupon_frequency",
    "coupon_method",
    "compensation_rate",
    "total_issue_size",
    "de_listed_date",
    "stock_code",
    "conversion_start_date",
    "conversion_end_date",
    "redemption_price",
    "stop_trading_date",
    "issue_price",
    "issue_method",
    "list_announcement_date",
    "pref_allocation_registration_date",
    "pref_allocation_payment_end_date",
    "call_protection",
    "coupon_frequency_is_float",
)


def all_instruments(
    client: "RQMarketDataClient",
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
):
    client._require_cn_market(market)
    query_date = client._parse_date_input(date)
    where = ""
    params: tuple[Any, ...] = ()
    if query_date is not None:
        where = """
WHERE "listed_date" IS NOT NULL
  AND "listed_date" <= %s
  AND (
      COALESCE("stop_trading_date", "de_listed_date") IS NULL
      OR COALESCE("stop_trading_date", "de_listed_date") > %s
  )
"""
        params = (query_date, query_date)
    frame = client._query_pg_dataframe(
        f"""
SELECT {client._pg_select_list(ALL_COLUMNS + ('coupon_frequency_is_float',))}
FROM {client._pg_table('convertible_instrument_detail')}
{where}
ORDER BY "order_book_id";
""",
        params,
    )
    return _normalize_frame(frame)


def instruments(
    client: "RQMarketDataClient",
    order_book_ids: str | Sequence[str],
    market: str = "cn",
) -> ConvertibleInstrument | list[ConvertibleInstrument] | None:
    client._require_cn_market(market)
    scalar_input = isinstance(order_book_ids, str)
    ids = _ensure_list_of_strings(order_book_ids)
    unique_ids = list(dict.fromkeys(ids))
    rows, columns = client._query_pg_rows_with_columns(
        f"""
SELECT {client._pg_select_list(OBJECT_COLUMNS)}
FROM {client._pg_table('convertible_instrument_detail')}
WHERE "order_book_id" = ANY(%s::varchar[])
ORDER BY "order_book_id";
""",
        (unique_ids,),
    )
    by_id = {
        str(row[0]): ConvertibleInstrument(
            _normalize_object(dict(zip(columns, row))),
            client=client,
        )
        for row in rows
    }
    if len(ids) == 1:
        result = by_id.get(ids[0])
        if result is None:
            warnings.warn(f"unknown convertible order_book_id: {ids}", stacklevel=2)
        return result
    return [by_id[order_book_id] for order_book_id in ids if order_book_id in by_id]


def coupon_rate_table(client: "RQMarketDataClient", order_book_id: str):
    rows = client._query_pg_rows(
        f"""
SELECT "start_date", "end_date", "coupon_rate"
FROM {client._pg_table('convertible_coupon_rate')}
WHERE "order_book_id" = %s
ORDER BY "row_no";
""",
        (order_book_id,),
    )
    if not rows:
        return None
    import pandas as pd

    frame = pd.DataFrame(rows, columns=["start_date", "end_date", "coupon_rate"])
    frame["start_date"] = pd.to_datetime(frame["start_date"])
    frame["end_date"] = pd.to_datetime(frame["end_date"])
    frame["coupon_rate"] = pd.to_numeric(frame["coupon_rate"], errors="coerce").astype("float64")
    return frame.set_index(["start_date", "end_date"])


def option(
    client: "RQMarketDataClient",
    order_book_id: str,
    option_type: int | None = None,
):
    normalized_type = _normalize_option_type(option_type)
    where = '"order_book_id" = %s'
    params: tuple[Any, ...] = (order_book_id,)
    if normalized_type is not None:
        where += ' AND "option_type" = %s'
        params = (order_book_id, normalized_type)
    rows, columns = client._query_pg_rows_with_columns(
        f"""
SELECT
    "column_mask", "option_type", "start_date", "end_date", "payment_year",
    "level", "window_days", "reach_days", "frequency", "price",
    "if_include_interest", "remark"
FROM {client._pg_table('convertible_option')}
WHERE {where}
ORDER BY "row_no";
""",
        params,
    )
    if not rows:
        return None

    import pandas as pd

    frame = pd.DataFrame(rows, columns=columns)
    masks = frame.pop("column_mask")
    selected = ["option_type"]
    if normalized_type is None:
        for column in OPTION_RESULT_COLUMNS[1:]:
            position = OPTION_RESULT_COLUMNS.index(column)
            if int(masks.iloc[0]) & (1 << position):
                selected.append(column)
    else:
        selected = list(OPTION_TYPE_COLUMNS[normalized_type])
    frame = frame.loc[:, selected]
    for column in ("start_date", "end_date"):
        if column in frame:
            frame[column] = pd.to_datetime(frame[column], errors="coerce")
    frame["option_type"] = frame["option_type"].astype("int64")
    for column in ("payment_year", "window_days", "reach_days"):
        if column in frame:
            values = pd.to_numeric(frame[column], errors="coerce")
            frame[column] = values.astype("int64") if not values.isna().any() else values.astype("float64")
    for column in ("level", "price"):
        if column in frame:
            frame[column] = pd.to_numeric(frame[column], errors="coerce").astype("float64")
    if "if_include_interest" in frame:
        if frame["if_include_interest"].isna().all():
            frame["if_include_interest"] = pd.to_numeric(
                frame["if_include_interest"], errors="coerce"
            ).astype("float64")
        elif frame["if_include_interest"].isna().any():
            frame["if_include_interest"] = frame["if_include_interest"].astype("object")
        else:
            frame["if_include_interest"] = frame["if_include_interest"].astype("bool")
    return frame.reset_index(drop=True)


OPTION_RESULT_COLUMNS = (
    "option_type",
    "start_date",
    "end_date",
    "payment_year",
    "level",
    "window_days",
    "reach_days",
    "frequency",
    "price",
    "if_include_interest",
    "remark",
)

OPTION_TYPE_COLUMNS = {
    1: ("option_type", "price", "if_include_interest", "remark"),
    2: OPTION_RESULT_COLUMNS,
    3: OPTION_RESULT_COLUMNS,
    4: ("option_type", "price", "if_include_interest", "remark"),
    5: ("option_type", "price", "if_include_interest", "remark"),
    6: ("option_type", "price", "if_include_interest", "remark"),
    7: (
        "option_type",
        "start_date",
        "end_date",
        "level",
        "window_days",
        "reach_days",
        "frequency",
    ),
}


def _normalize_option_type(value: int | None) -> int | None:
    if value is None:
        return None
    try:
        normalized = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"option_type: expect a int, got {value!r}") from exc
    if normalized not in {1, 2, 3, 4, 5, 6, 7}:
        raise ValueError("option_type: expect value in (None, 1, 2, 3, 4, 5, 6, 7)")
    return normalized


def _ensure_list_of_strings(value: str | Sequence[str]) -> list[str]:
    if isinstance(value, str):
        return [value]
    result = list(value)
    for item in result:
        if not isinstance(item, str):
            raise ValueError(f"order_book_ids: expect string or list of string, got {item!r}")
    return result


def _normalize_frame(frame):
    import pandas as pd

    frequency_is_float = frame.pop("coupon_frequency_is_float").fillna(False).astype(bool)
    frame = frame.loc[:, list(ALL_COLUMNS)].copy()
    for column in DATE_COLUMNS:
        if frame[column].notna().any():
            frame[column] = pd.to_datetime(frame[column], errors="coerce").astype("datetime64[ns]")
    for column in NUMERIC_COLUMNS:
        frame[column] = pd.to_numeric(frame[column], errors="coerce").astype("float64")
    coupon_frequency = frame["coupon_frequency"]
    if (
        not coupon_frequency.isna().any()
        and not frequency_is_float.any()
        and (coupon_frequency % 1 == 0).all()
    ):
        frame["coupon_frequency"] = coupon_frequency.astype("int64")
    return frame


def _normalize_object(data: dict[str, Any]) -> dict[str, Any]:
    frequency_is_float = bool(data.pop("coupon_frequency_is_float", False))
    for column in NUMERIC_COLUMNS:
        if data.get(column) is None:
            data[column] = float("nan")
    for column in DATE_COLUMNS:
        value = data.get(column)
        if isinstance(value, dt.datetime):
            continue
        if isinstance(value, dt.date):
            data[column] = dt.datetime.combine(value, dt.time())
    value = data.get("coupon_frequency")
    if value is not None and not frequency_is_float and float(value).is_integer():
        data["coupon_frequency"] = int(value)
    return data
