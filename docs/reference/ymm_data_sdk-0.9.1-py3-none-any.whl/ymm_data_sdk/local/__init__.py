"""Local database implementations for registered ymm_data_sdk methods."""
