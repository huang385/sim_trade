from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from decimal import Decimal
from typing import TYPE_CHECKING, Any, Sequence


if TYPE_CHECKING:
    from .market_data import RQMarketDataClient


SPECIAL_STRIKE_UNDERLYINGS = {"510050.XSHG", "510300.XSHG", "159919.XSHE"}


@dataclass
class _OptionContract:
    order_book_id: str
    maturity_date: dt.date
    option_type: str
    strike_price: Decimal | float | None


def get_contracts(
    client: "RQMarketDataClient",
    underlying: str,
    option_type: str | None = None,
    maturity: str | int | None = None,
    strike: float | None = None,
    trading_date: str | int | dt.date | dt.datetime | None = None,
) -> list[str]:
    if not isinstance(underlying, str):
        raise ValueError(f"underlying: expect a string, got {underlying}")
    underlying = underlying.upper()
    query_date = client._parse_date_input(trading_date)
    rows = client._query_pg_rows(
        f"""
WITH underlying_mode AS (
    SELECT CASE
        WHEN EXISTS (
            SELECT 1
            FROM {client._pg_table('instruments_option')}
            WHERE "underlying_symbol" = %s
        ) THEN 'symbol'
        WHEN EXISTS (
            SELECT 1
            FROM {client._pg_table('instruments_option')}
            WHERE "underlying_order_book_id" = %s
        ) THEN 'order_book_id'
        ELSE NULL
    END AS "mode"
),
candidates AS (
    SELECT
        options."order_book_id",
        options."maturity_date",
        options."option_type",
        options."strike_price"
    FROM {client._pg_table('instruments_option')} options
    CROSS JOIN underlying_mode
    WHERE (
            (underlying_mode."mode" = 'symbol' AND options."underlying_symbol" = %s)
         OR (underlying_mode."mode" = 'order_book_id' AND options."underlying_order_book_id" = %s)
    )
      AND (%s::date IS NULL OR options."listed_date" <= %s::date)
      AND (%s::date IS NULL OR options."de_listed_date" >= %s::date)
)
SELECT
    0::smallint AS "row_kind",
    underlying_mode."mode",
    NULL::varchar AS "order_book_id",
    NULL::date AS "maturity_date",
    NULL::varchar AS "option_type",
    NULL::numeric AS "strike_price"
FROM underlying_mode
UNION ALL
SELECT
    1::smallint AS "row_kind",
    NULL::text AS "mode",
    candidates."order_book_id",
    candidates."maturity_date",
    candidates."option_type",
    candidates."strike_price"
FROM candidates
ORDER BY "row_kind", "order_book_id";
""",
        (
            underlying,
            underlying,
            underlying,
            underlying,
            query_date,
            query_date,
            query_date,
            query_date,
        ),
    )
    mode = next((row[1] for row in rows if int(row[0]) == 0), None)
    if mode is None:
        raise ValueError("Unknown underlying")

    contracts = [
        _OptionContract(
            order_book_id=str(row[2]),
            maturity_date=row[3],
            option_type=str(row[4]),
            strike_price=row[5],
        )
        for row in rows
        if int(row[0]) == 1
    ]
    if not contracts:
        return []

    if option_type is not None:
        if not isinstance(option_type, str):
            raise ValueError(f"option_type: expect a string, got {option_type}")
        option_type = option_type.upper()
        if option_type not in {"P", "C"}:
            raise TypeError("option_type: expect value in {'P', 'C'}")
        contracts = [contract for contract in contracts if contract.option_type == option_type]

    if maturity is not None:
        maturity_value = int(maturity)
        month = maturity_value % 100
        if month not in range(1, 13):
            raise ValueError("Unknown month")
        year = maturity_value // 100 + 2000
        contracts = [
            contract
            for contract in contracts
            if contract.maturity_date.year == year and contract.maturity_date.month == month
        ]
        if not contracts:
            return []

    if strike:
        if underlying in SPECIAL_STRIKE_UNDERLYINGS and trading_date:
            contracts = _replace_historical_strikes(client, contracts, query_date)
            if not contracts:
                return []
        return _left_match_strike(contracts, strike)
    return [contract.order_book_id for contract in contracts]


def get_contracts_batch(
    client: "RQMarketDataClient",
    underlying_list: Sequence[str],
    start_date: str | int | dt.date | dt.datetime,
    end_date: str | int | dt.date | dt.datetime,
    option_type: str | None = None,
    maturity: str | int | None = None,
    strike: float | None = None,
):
    if isinstance(underlying_list, str):
        raise TypeError("underlying_list must be a sequence of strings, not a string")
    underlyings: list[str] = []
    seen: set[str] = set()
    for value in underlying_list:
        if not isinstance(value, str):
            raise ValueError(f"underlying: expect a string, got {value}")
        normalized = value.upper()
        if normalized not in seen:
            underlyings.append(normalized)
            seen.add(normalized)
    if not underlyings:
        raise ValueError("underlying_list cannot be empty")

    start = client._parse_date_input(start_date)
    end = client._parse_date_input(end_date)
    if start is None or end is None:
        raise ValueError("start_date and end_date are required")
    client._validate_date_range(start, end)
    normalized_type = _normalize_option_type(option_type)
    maturity_year, maturity_month = _normalize_maturity(maturity)
    strike_value = strike if strike else None
    dynamic_special = (
        [value for value in underlyings if value in SPECIAL_STRIKE_UNDERLYINGS]
        if strike_value is not None
        else []
    )

    rows = client._query_pg_rows(
        _batch_sql(client),
        (
            underlyings,
            start,
            end,
            normalized_type,
            normalized_type,
            maturity_year,
            maturity_year,
            maturity_month,
            dynamic_special,
            strike_value,
            strike_value,
            strike_value,
            strike_value,
            dynamic_special,
        ),
    )
    modes = {str(row[2]): row[3] for row in rows if int(row[0]) == 0}
    unknown = [underlying for underlying in underlyings if modes.get(underlying) is None]
    if unknown:
        raise ValueError(f"Unknown underlying: {unknown[0]}")

    chains: dict[tuple[str, dt.date], list[str]] = {}
    special_rows: list[tuple[str, dt.date, str, dt.date]] = []
    input_order: dict[str, int] = {value: position for position, value in enumerate(underlyings)}
    trading_dates: set[dt.date] = set()
    for row in rows:
        row_kind = int(row[0])
        if row_kind == 1:
            underlying = str(row[2])
            date = row[4]
            trading_dates.add(date)
            chains[(underlying, date)] = list(row[5] or [])
        elif row_kind == 2:
            special_rows.append((str(row[2]), row[4], str(row[6]), row[7]))

    if special_rows:
        _fill_special_batch_chains(
            client,
            chains,
            special_rows,
            start,
            end,
            strike_value,
        )

    import pandas as pd

    records = [
        {
            "underlying": underlying,
            "date": date,
            "option_chain": chains.get((underlying, date), []),
        }
        for underlying in underlyings
        for date in sorted(trading_dates)
    ]
    result = pd.DataFrame(records, columns=["underlying", "date", "option_chain"])
    if not result.empty:
        result["date"] = pd.to_datetime(result["date"])
        result["_order"] = result["underlying"].map(input_order)
        result.sort_values(["_order", "date"], inplace=True)
        result.drop(columns="_order", inplace=True)
        result.reset_index(drop=True, inplace=True)
    return result


def _batch_sql(client: "RQMarketDataClient") -> str:
    option_table = client._pg_table("instruments_option")
    calendar_table = client._pg_table("trading_dates")
    return f"""
WITH requested AS (
    SELECT "underlying", "input_order"
    FROM unnest(%s::varchar[]) WITH ORDINALITY
         AS values("underlying", "input_order")
),
classified AS (
    SELECT
        requested."underlying",
        requested."input_order",
        CASE
            WHEN EXISTS (
                SELECT 1 FROM {option_table} options
                WHERE options."underlying_symbol" = requested."underlying"
            ) THEN 'symbol'
            WHEN EXISTS (
                SELECT 1 FROM {option_table} options
                WHERE options."underlying_order_book_id" = requested."underlying"
            ) THEN 'order_book_id'
            ELSE NULL
        END AS "mode"
    FROM requested
),
trading_days AS (
    SELECT "date"
    FROM {calendar_table}
    WHERE "is_trading"
      AND "date" >= %s::date
      AND "date" <= %s::date
),
candidates AS (
    SELECT
        classified."input_order",
        classified."underlying",
        trading_days."date",
        options."order_book_id",
        options."maturity_date",
        options."strike_price"
    FROM classified
    CROSS JOIN trading_days
    JOIN {option_table} options
      ON (
            (classified."mode" = 'symbol' AND options."underlying_symbol" = classified."underlying")
         OR (classified."mode" = 'order_book_id' AND options."underlying_order_book_id" = classified."underlying")
      )
     AND options."listed_date" <= trading_days."date"
     AND options."de_listed_date" >= trading_days."date"
    WHERE (%s::varchar IS NULL OR options."option_type" = %s::varchar)
      AND (
          %s::int IS NULL
          OR (
              EXTRACT(YEAR FROM options."maturity_date")::int = %s::int
              AND EXTRACT(MONTH FROM options."maturity_date")::int = %s::int
          )
      )
),
static_eligible AS (
    SELECT candidates.*
    FROM candidates
    WHERE NOT (candidates."underlying" = ANY(%s::varchar[]))
      AND (%s::double precision IS NULL OR candidates."strike_price" <= %s::double precision)
),
static_max_strikes AS (
    SELECT
        "input_order", "underlying", "date", "maturity_date", max("strike_price") AS "strike_price"
    FROM static_eligible
    WHERE %s::double precision IS NOT NULL
    GROUP BY "input_order", "underlying", "date", "maturity_date"
),
static_selected AS (
    SELECT eligible.*
    FROM static_eligible eligible
    LEFT JOIN static_max_strikes maxima
      ON maxima."input_order" = eligible."input_order"
     AND maxima."date" = eligible."date"
     AND maxima."maturity_date" = eligible."maturity_date"
    WHERE %s::double precision IS NULL OR eligible."strike_price" = maxima."strike_price"
),
grid AS (
    SELECT classified."input_order", classified."underlying", classified."mode", trading_days."date"
    FROM classified CROSS JOIN trading_days
),
aggregated AS (
    SELECT
        grid."input_order",
        grid."underlying",
        grid."date",
        COALESCE(
            array_agg(static_selected."order_book_id" ORDER BY static_selected."order_book_id")
                FILTER (WHERE static_selected."order_book_id" IS NOT NULL),
            ARRAY[]::varchar[]
        ) AS "option_chain"
    FROM grid
    LEFT JOIN static_selected
      ON static_selected."input_order" = grid."input_order"
     AND static_selected."date" = grid."date"
    GROUP BY grid."input_order", grid."underlying", grid."date"
)
SELECT
    0::smallint AS "row_kind",
    classified."input_order",
    classified."underlying",
    classified."mode",
    NULL::date AS "date",
    NULL::varchar[] AS "option_chain",
    NULL::varchar AS "order_book_id",
    NULL::date AS "maturity_date"
FROM classified
UNION ALL
SELECT
    1::smallint,
    aggregated."input_order",
    aggregated."underlying",
    NULL::text,
    aggregated."date",
    aggregated."option_chain",
    NULL::varchar,
    NULL::date
FROM aggregated
UNION ALL
SELECT
    2::smallint,
    candidates."input_order",
    candidates."underlying",
    NULL::text,
    candidates."date",
    NULL::varchar[],
    candidates."order_book_id",
    candidates."maturity_date"
FROM candidates
WHERE candidates."underlying" = ANY(%s::varchar[])
ORDER BY "row_kind", "input_order", "date", "order_book_id";
"""


def _fill_special_batch_chains(
    client: "RQMarketDataClient",
    chains: dict[tuple[str, dt.date], list[str]],
    special_rows: list[tuple[str, dt.date, str, dt.date]],
    start: str,
    end: str,
    strike: Any,
) -> None:
    order_book_ids = tuple(dict.fromkeys(row[2] for row in special_rows))
    frame = client._query_dataframe(
        f"""
SELECT "order_book_id", "date", "strike_price"
FROM {client._table('etf_option_daily_bar')}
WHERE "order_book_id" IN %(order_book_ids)s
  AND "date" >= toDate(%(start)s)
  AND "date" <= toDate(%(end)s)
ORDER BY "order_book_id", "date";
""",
        {"order_book_ids": order_book_ids, "start": start, "end": end},
    )
    strike_by_contract_date = {
        (str(row.order_book_id), row.date.date() if hasattr(row.date, "date") else row.date): float(row.strike_price)
        for row in frame.itertuples(index=False)
        if _is_not_nan(row.strike_price)
    }
    grouped: dict[tuple[str, dt.date], list[_OptionContract]] = {}
    for underlying, date, order_book_id, maturity_date in special_rows:
        historical_strike = strike_by_contract_date.get((order_book_id, date))
        if historical_strike is None:
            continue
        grouped.setdefault((underlying, date), []).append(
            _OptionContract(order_book_id, maturity_date, "", historical_strike)
        )
    for key, contracts in grouped.items():
        chains[key] = _left_match_strike(contracts, strike)


def _normalize_option_type(option_type: str | None) -> str | None:
    if option_type is None:
        return None
    if not isinstance(option_type, str):
        raise ValueError(f"option_type: expect a string, got {option_type}")
    value = option_type.upper()
    if value not in {"P", "C"}:
        raise TypeError("option_type: expect value in {'P', 'C'}")
    return value


def _normalize_maturity(maturity: str | int | None) -> tuple[int | None, int | None]:
    if maturity is None:
        return None, None
    value = int(maturity)
    month = value % 100
    if month not in range(1, 13):
        raise ValueError("Unknown month")
    return value // 100 + 2000, month


def _replace_historical_strikes(
    client: "RQMarketDataClient",
    contracts: list[_OptionContract],
    query_date: str | None,
) -> list[_OptionContract]:
    frame = client._query_dataframe(
        f"""
SELECT "order_book_id", "strike_price"
FROM {client._table('etf_option_daily_bar')}
WHERE "order_book_id" IN %(order_book_ids)s
  AND "date" = toDate(%(trading_date)s)
ORDER BY "order_book_id";
""",
        {
            "order_book_ids": tuple(contract.order_book_id for contract in contracts),
            "trading_date": query_date,
        },
    )
    if frame.empty:
        return []
    historical = {
        str(row.order_book_id): float(row.strike_price)
        for row in frame.itertuples(index=False)
        if _is_not_nan(row.strike_price)
    }
    return [
        _OptionContract(
            order_book_id=contract.order_book_id,
            maturity_date=contract.maturity_date,
            option_type=contract.option_type,
            strike_price=historical[contract.order_book_id],
        )
        for contract in contracts
        if contract.order_book_id in historical
    ]


def _left_match_strike(contracts: list[_OptionContract], strike: Any) -> list[str]:
    maturity_order = list(dict.fromkeys(contract.maturity_date for contract in contracts))
    result: list[str] = []
    for maturity_date in maturity_order:
        eligible = [
            contract
            for contract in contracts
            if contract.maturity_date == maturity_date
            and contract.strike_price is not None
            and contract.strike_price <= strike
        ]
        if not eligible:
            continue
        selected_strike = max(contract.strike_price for contract in eligible)
        result.extend(
            contract.order_book_id
            for contract in eligible
            if contract.strike_price == selected_strike
        )
    return result


def _is_not_nan(value: Any) -> bool:
    try:
        return value == value
    except Exception:
        return False
