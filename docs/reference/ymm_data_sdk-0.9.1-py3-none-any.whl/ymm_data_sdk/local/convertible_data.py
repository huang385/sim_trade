from __future__ import annotations

import datetime as dt
from typing import TYPE_CHECKING, Any, Sequence

import pandas as pd

if TYPE_CHECKING:
    from .market_data import RQMarketDataClient


INDICATOR_FIELDS = (
    "conversion_coefficient", "conversion_value", "conversion_premium",
    "pure_bond_value_premium", "pure_bond_value_premium_pretax",
    "yield_to_maturity", "yield_to_maturity_pretax", "yield_to_put",
    "yield_to_put_pretax", "pure_bond_value", "pure_bond_value_pretax",
    "double_low_factor", "call_trigger_price", "put_trigger_price",
    "conversion_price_reset_trigger_price", "turnover_rate", "remaining_size",
    "convertible_market_cap_ratio", "pb_ratio", "put_qualified_days",
    "call_qualified_days", "conversion_price_reset_qualified_days", "put_status",
    "call_status", "conversion_price_reset_status", "pure_bond_value_1",
    "pure_bond_value_premium_1", "iv", "delta", "theta", "gamma", "vega",
)
INDICATOR_INTEGER_FIELDS = {
    "put_qualified_days", "call_qualified_days", "conversion_price_reset_qualified_days",
    "put_status", "call_status", "conversion_price_reset_status",
}
INDICATOR_DEPRECATED_FIELDS = {
    "pure_bond_value_premium", "pure_bond_value_premium_pretax",
    "pure_bond_value", "pure_bond_value_pretax",
}
INDICATOR_RETURN_FIELDS = (
    "pure_bond_value_1", "yield_to_maturity_pretax", "pure_bond_value_pretax",
    "yield_to_put", "conversion_premium", "pure_bond_value", "put_trigger_price",
    "conversion_value", "put_status", "put_qualified_days", "call_status",
    "pure_bond_value_premium", "yield_to_put_pretax", "remaining_size",
    "call_qualified_days", "conversion_coefficient", "call_trigger_price", "iv",
    "turnover_rate", "conversion_price_reset_qualified_days",
    "conversion_price_reset_status", "conversion_price_reset_trigger_price",
    "yield_to_maturity", "pure_bond_value_premium_pretax", "double_low_factor",
    "pb_ratio", "pure_bond_value_premium_1", "convertible_market_cap_ratio",
    "delta", "theta", "gamma", "vega",
)

EVENTS = {
    "conversion_price": ("info_date", ("effective_date", "conversion_price", "change_reason"), {"effective_date"}),
    "conversion_info": ("info_date", ("total_amount_converted", "total_shares_converted", "remaining_amount", "amount_converted", "shares_converted", "end_date", "conversion_price"), {"end_date"}),
    "call_info": ("info_date", ("exercise_date", "exercise_price", "interest_included", "interest_amount", "call_amount", "record_date"), {"exercise_date", "record_date"}),
    "put_info": ("info_date", ("enrollment_start_date", "enrollment_end_date", "exercise_price", "interest_included", "interest_amount", "payment_date", "put_amount", "put_code"), {"enrollment_start_date", "enrollment_end_date", "payment_date"}),
    "cash_flow": ("payment_date", ("record_date", "cash_flow_pretax", "principal_payment", "interest_payment_pretax", "payment_date_act", "cash_flow", "interest_payment"), {"record_date", "payment_date_act"}),
    "call_announcement": ("info_date", ("update_time", "call_price", "if_issuer_call", "if_call", "first_info_date", "stop_exe_start_date", "call_price_before_tax", "stop_exe_end_date"), {"update_time", "first_info_date", "stop_exe_start_date", "stop_exe_end_date"}),
    "credit_rating": ("credit_date", ("info_date", "info_source", "institution", "credit", "rice_create_tm"), {"info_date", "rice_create_tm"}),
}


def _ids(client: "RQMarketDataClient", values: str | Sequence[str]) -> list[str]:
    if isinstance(values, str):
        requested = [values]
    else:
        requested = list(values)
    for value in requested:
        if not isinstance(value, str):
            raise ValueError(f"order_book_ids: expect string or list of string, got {value!r}")
    if not requested:
        return []
    rows = client._query_pg_rows(
        f'SELECT "order_book_id" FROM {client._pg_table("convertible_instrument_detail")} WHERE "order_book_id"=ANY(%s::varchar[])',
        (requested,),
    )
    valid = {str(row[0]) for row in rows}
    return [value for value in requested if value in valid]


def _date_range(client, start_date, end_date, default: str = "all"):
    start = client._parse_date_input(start_date)
    end = client._parse_date_input(end_date)
    if default == "three_months":
        today = dt.date.today()
        if start is None and end is None:
            end_value = today
            start_value = client._shift_months(today, -3)
            start, end = start_value.isoformat(), end_value.isoformat()
        elif start is None:
            end_value = dt.date.fromisoformat(end)
            start = client._shift_months(end_value, -3).isoformat()
        elif end is None:
            end = client._shift_months(dt.date.fromisoformat(start), 3).isoformat()
    elif default == "today":
        end = end or dt.date.today().isoformat()
    client._validate_date_range(start, end)
    return start, end


def get_event(client, dataset: str, order_book_ids, start_date=None, end_date=None, market="cn", institutions=None):
    client._require_cn_market(market)
    ids = _ids(client, order_book_ids)
    if not ids:
        return None
    index_date, columns, date_columns = EVENTS[dataset]
    default = "today" if dataset == "call_announcement" else "all"
    start, end = _date_range(client, start_date, end_date, default=default)
    where = ['"order_book_id"=ANY(%s::varchar[])']
    params: list[Any] = [ids]
    if start:
        where.append(f'"{index_date}">=%s'); params.append(start)
    if end:
        where.append(f'"{index_date}"<=%s'); params.append(end)
    if dataset == "credit_rating" and institutions:
        values = [institutions] if isinstance(institutions, str) else list(institutions)
        where.append('"institution"=ANY(%s::text[])'); params.append(values)
    selected = ("order_book_id", index_date, *columns)
    frame = client._query_pg_dataframe(
        f'''SELECT {client._pg_select_list(selected)} FROM {client._pg_table("convertible_"+dataset)}
        WHERE {" AND ".join(where)} ORDER BY "order_book_id","row_no"''', tuple(params))
    if frame.empty:
        return None
    frame[index_date] = pd.to_datetime(frame[index_date])
    for name in date_columns:
        frame[name] = pd.to_datetime(frame[name], errors="coerce")
    result = frame.set_index(["order_book_id", index_date])
    if dataset == "call_info" and not result["interest_included"].isna().any():
        result["interest_included"] = result["interest_included"].astype("int64")
    if dataset == "call_announcement":
        for name in ("call_price", "call_price_before_tax"):
            result[name] = pd.to_numeric(result[name], errors="coerce").astype("float64")
    if dataset in {"call_announcement", "credit_rating"}:
        result.sort_index(inplace=True)
    return result


def get_instrument_industry(client, order_book_ids, source="citics", level=1, date=None, market="cn"):
    client._require_cn_market(market)
    if source not in {"citics", "citics_2019", "gildata"}:
        raise ValueError(f"invalid source: {source!r}")
    if level not in {0, 1, 2, 3}:
        raise ValueError("level should be in 0,1,2,3")
    ids = _ids(client, order_book_ids)
    if not ids:
        return None
    query_date = client._parse_date_input(date) or dt.date.today().isoformat()
    fields = {
        0: ("first_industry_code", "first_industry_name", "second_industry_code", "second_industry_name", "third_industry_code", "third_industry_name"),
        1: ("first_industry_code", "first_industry_name"),
        2: ("second_industry_code", "second_industry_name"),
        3: ("third_industry_code", "third_industry_name"),
    }[level]
    rows = client._query_pg_dataframe(
        f'''SELECT DISTINCT ON ("order_book_id") "order_book_id",{client._pg_select_list(fields)}
        FROM {client._pg_table("convertible_industry_history")}
        WHERE "order_book_id"=ANY(%s::varchar[]) AND "source"=%s
          AND "start_date"<=%s AND "cancel_date">%s
        ORDER BY "order_book_id","start_date" DESC''', (ids, source, query_date, query_date))
    if rows.empty:
        result = pd.DataFrame(index=pd.Index(ids, name="order_book_id"), columns=list(fields))
    else:
        result = rows.set_index("order_book_id").reindex(ids)
    return result


def get_industry(client, industry, source="citics", date=None, market="cn"):
    client._require_cn_market(market)
    if not isinstance(industry, str):
        raise ValueError(f"industry: expect a string, got {industry!r}")
    if source not in {"citics", "citics_2019", "gildata"}:
        raise ValueError(f"invalid source: {source!r}")
    query_date = client._parse_date_input(date) or dt.date.today().isoformat()
    lifecycle = ""
    params: list[Any] = [source, query_date, query_date, industry]
    if date is not None:
        lifecycle = '''AND d."listed_date"<=%s AND (d."de_listed_date" IS NULL OR d."de_listed_date">=%s)'''
        params.extend([query_date, query_date])
    rows = client._query_pg_rows(
        f'''SELECT DISTINCT h."order_book_id" FROM {client._pg_table("convertible_industry_history")} h
        JOIN {client._pg_table("convertible_instrument_detail")} d USING("order_book_id")
        WHERE h."source"=%s AND h."start_date"<=%s AND h."cancel_date">%s
          AND %s IN (h."first_industry_code",h."first_industry_name",h."second_industry_code",
                     h."second_industry_name",h."third_industry_code",h."third_industry_name")
          {lifecycle} ORDER BY h."order_book_id"''', tuple(params))
    if rows:
        return [str(row[0]) for row in rows]
    known = client._query_pg_rows(
        f'''SELECT 1 FROM {client._pg_table("convertible_industry_taxonomy")}
        WHERE "source"=%s AND ((%s="industry_code" AND "code_supported")
                            OR (%s="industry_name" AND "name_supported"))
        LIMIT 1''', (source, industry, industry))
    return [] if known else None


def get_accrued_interest_eod(client, order_book_ids, start_date=None, end_date=None):
    ids = _ids(client, order_book_ids)
    if not ids:
        return None
    start, end = _date_range(client, start_date, end_date, "three_months")
    frame = client._query_pg_dataframe(
        f'''SELECT "order_book_id","date","accrued_interest" FROM {client._pg_table("convertible_accrued_interest_eod")}
        WHERE "order_book_id"=ANY(%s::varchar[]) AND "date">=%s AND "date"<=%s
        ORDER BY "date","order_book_id"''', (ids, start, end))
    if frame.empty:
        return None
    frame["date"] = pd.to_datetime(frame.date)
    result = frame.pivot(index="date", columns="order_book_id", values="accrued_interest")
    result.columns.name = None
    present = [value for value in ids if value in result.columns]
    return result.loc[:, present].sort_index()


def get_close_price(client, order_book_ids, start_date=None, end_date=None, fields=None, market="cn"):
    client._require_cn_market(market)
    ids = _ids(client, order_book_ids)
    if not ids:
        return None
    start, end = _date_range(client, start_date, end_date, "three_months")
    allowed = ["clean_price", "dirty_price"]
    selected = allowed if fields is None else list(set([fields] if isinstance(fields, str) else fields))
    invalid = set(selected) - set(allowed)
    if invalid:
        raise ValueError(f"invalid fields: {sorted(invalid)}")
    selected_sql = f",{client._pg_select_list(selected)}" if selected else ""
    frame = client._query_pg_dataframe(
        f'''SELECT "order_book_id","date"{selected_sql}
        FROM {client._pg_table("convertible_close_price")}
        WHERE "order_book_id"=ANY(%s::varchar[]) AND "date">=%s AND "date"<=%s
        ORDER BY "order_book_id","date"''', (ids, start, end))
    if frame.empty:
        return None
    frame["date"] = pd.to_datetime(frame.date)
    return frame.set_index(["order_book_id", "date"])


def get_indicators(client, order_book_ids, start_date=None, end_date=None, fields=None):
    ids = _ids(client, order_book_ids)
    if not ids:
        return None
    default = "three_months" if start_date is None and end_date is None else "all"
    start, end = _date_range(client, start_date, end_date, default)
    if fields is None:
        selected = list(INDICATOR_RETURN_FIELDS)
        requested = selected
    else:
        requested = [fields] if isinstance(fields, str) else list(fields)
        selected = [name for name in INDICATOR_RETURN_FIELDS if name in requested]
    invalid = set(requested) - set(INDICATOR_FIELDS)
    if invalid:
        raise ValueError(f"invalid fields: {sorted(invalid)}")
    selected_sql = f",{client._pg_select_list(selected)}" if selected else ""
    where = ['"order_book_id"=ANY(%s::varchar[])']
    params: list[Any] = [ids]
    if start:
        where.append('"date">=%s'); params.append(start)
    if end:
        where.append('"date"<=%s'); params.append(end)
    frame = client._query_pg_dataframe(
        f'''SELECT "order_book_id","date"{selected_sql}
        FROM {client._pg_table("convertible_indicators")}
        WHERE {" AND ".join(where)}
        ORDER BY "order_book_id","date"''', tuple(params))
    if frame.empty:
        return None
    frame["date"] = pd.to_datetime(frame.date)
    for name in selected:
        if name in INDICATOR_INTEGER_FIELDS and not frame[name].isna().any():
            frame[name] = frame[name].astype("int64")
        elif name in INDICATOR_DEPRECATED_FIELDS and frame[name].isna().all():
            frame[name] = pd.Series([None] * len(frame), dtype="object")
        else:
            frame[name] = pd.to_numeric(frame[name], errors="coerce").astype("float64")
    return frame.set_index(["order_book_id", "date"]).sort_index()


def get_std_discount(client, order_book_ids, start_date=None, end_date=None, market="cn"):
    client._require_cn_market(market)
    ids = _ids(client, order_book_ids)
    if not ids:
        return None
    start, end = _date_range(client, start_date, end_date, "today")
    where = ['"order_book_id"=ANY(%s::varchar[])']
    params: list[Any] = [ids]
    if start:
        where.append('"date">=%s'); params.append(start)
    if end:
        where.append('"date"<=%s'); params.append(end)
    frame = client._query_pg_dataframe(
        f'''SELECT "order_book_id","date","discount_factor" FROM {client._pg_table("convertible_std_discount")}
        WHERE {" AND ".join(where)}
        ORDER BY "order_book_id","date"''', tuple(params))
    if frame.empty:
        return None
    frame["date"] = pd.to_datetime(frame.date)
    frame["discount_factor"] = frame.discount_factor.astype("float64")
    return frame.set_index(["order_book_id", "date"])
