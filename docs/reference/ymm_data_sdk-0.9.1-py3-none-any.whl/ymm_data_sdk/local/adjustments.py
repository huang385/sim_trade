"""Dynamic adjustment helpers for locally mirrored RQ market data."""

from __future__ import annotations

import datetime as dt
import re
from collections.abc import Collection, Mapping, Sequence
from typing import Any, Literal


AdjustmentType = Literal["none", "pre", "pre_volume", "post", "post_volume"]

ADJUSTABLE_RQ_TYPES = {"CS", "ETF", "LOF"}
PRICE_COLUMNS = ("open", "high", "low", "close", "limit_up", "limit_down")
VOLUME_COLUMN = "volume"
_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def normalize_adjust_type(value: str | None) -> AdjustmentType | None:
    """Normalize public adjust_type input.

    ``None`` means rqdatac-like defaulting, which is resolved per instrument in
    ``apply_adjustment`` because tick and non-equity assets stay raw.
    """
    if value is None:
        return None
    normalized = str(value).strip().lower()
    if normalized == "none":
        return "none"
    if normalized in {"pre", "pre_volume", "post", "post_volume"}:
        return normalized  # type: ignore[return-value]
    raise ValueError(
        "unsupported adjust_type: "
        f"{value!r}; allowed=None, 'none', 'pre', 'pre_volume', 'post', 'post_volume'"
    )


def required_adjustment_columns(
    *,
    adjust_type: AdjustmentType | None,
    frequency: str,
    instrument_types: Sequence[str | None],
    available_columns: Collection[str],
) -> list[str]:
    """Return hidden columns needed to apply dynamic adjustment."""
    if frequency == "tick" or adjust_type == "none":
        return []
    if not any(rq_type in ADJUSTABLE_RQ_TYPES for rq_type in instrument_types):
        return []

    out = ["order_book_id"]
    available = set(available_columns)
    if frequency == "1d" and "date" in available:
        out.append("date")
    elif "trading_date" in available:
        out.append("trading_date")
    elif "datetime" in available:
        out.append("datetime")
    return out


def apply_adjustment(
    df: Any,
    *,
    adjust_type: AdjustmentType | None,
    frequency: str,
    instrument_lookup: Mapping[str, Mapping[str, str | None]],
    end_date: str | None,
    pg_connection: Any,
    pg_schema: str = "public",
) -> Any:
    """Apply local RQ price/volume adjustments to a query result DataFrame."""
    if df is None or df.empty or frequency == "tick" or adjust_type == "none":
        return df

    import numpy as np
    import pandas as pd

    if "order_book_id" not in df.columns:
        return df

    out = df.copy()
    price_columns = [column for column in PRICE_COLUMNS if column in out.columns]
    has_volume = VOLUME_COLUMN in out.columns
    if not price_columns and not has_volume:
        return out

    order_book_ids = out["order_book_id"].astype("string")
    effective = order_book_ids.map(
        lambda order_book_id: _effective_adjust_type(
            str(order_book_id),
            adjust_type=adjust_type,
            frequency=frequency,
            instrument_lookup=instrument_lookup,
        )
    )
    adjust_mask = effective.ne("none")
    if not bool(adjust_mask.any()):
        return out

    adjust_dates = _adjustment_dates(out, frequency)
    if adjust_dates.loc[adjust_mask].isna().any():
        missing = out.loc[adjust_mask & adjust_dates.isna(), "order_book_id"].drop_duplicates().head(5).tolist()
        raise ValueError(f"cannot apply adjustment without a row date for order_book_id(s): {missing}")

    adjusted_ids = sorted(order_book_ids.loc[adjust_mask].dropna().unique().astype(str).tolist())
    del end_date  # rqdatac-style pre adjustment uses the latest factor, not query end_date.

    need_ex = bool(price_columns) or (
        has_volume and effective.loc[adjust_mask].isin({"pre_volume", "post_volume"}).any()
    )
    need_split = has_volume and effective.loc[adjust_mask].isin({"pre", "post"}).any()

    ex_factors = (
        _query_factor_table(
            pg_connection,
            pg_schema=pg_schema,
            table_name="ex_factor",
            date_column="ex_date",
            value_column="ex_cum_factor",
            order_book_ids=adjusted_ids,
        )
        if need_ex
        else None
    )
    split_factors = (
        _query_factor_table(
            pg_connection,
            pg_schema=pg_schema,
            table_name="split",
            date_column="ex_dividend_date",
            value_column="cum_factor",
            order_book_ids=adjusted_ids,
        )
        if need_split
        else None
    )

    ex_at_row = _lookup_cum_factors(order_book_ids, adjust_dates, ex_factors) if need_ex else None
    ex_latest = _latest_cum_factors(order_book_ids, ex_factors) if need_ex else None
    split_at_row = _lookup_cum_factors(order_book_ids, adjust_dates, split_factors) if need_split else None
    split_latest = _latest_cum_factors(order_book_ids, split_factors) if need_split else None

    if price_columns:
        price_multiplier = pd.Series(np.ones(len(out), dtype="float64"), index=out.index)
        pre_mask = adjust_mask & effective.isin({"pre", "pre_volume"})
        post_mask = adjust_mask & effective.isin({"post", "post_volume"})
        if bool(pre_mask.any()):
            price_multiplier.loc[pre_mask] = ex_at_row.loc[pre_mask] / ex_latest.loc[pre_mask]
        if bool(post_mask.any()):
            price_multiplier.loc[post_mask] = ex_at_row.loc[post_mask]
        for column in price_columns:
            values = pd.to_numeric(out.loc[adjust_mask, column], errors="coerce")
            out.loc[adjust_mask, column] = values * price_multiplier.loc[adjust_mask]

    if has_volume:
        volume_multiplier = pd.Series(np.ones(len(out), dtype="float64"), index=out.index)
        mask = adjust_mask & effective.eq("pre")
        if bool(mask.any()):
            volume_multiplier.loc[mask] = split_latest.loc[mask] / split_at_row.loc[mask]
        mask = adjust_mask & effective.eq("pre_volume")
        if bool(mask.any()):
            volume_multiplier.loc[mask] = ex_latest.loc[mask] / ex_at_row.loc[mask]
        mask = adjust_mask & effective.eq("post")
        if bool(mask.any()):
            volume_multiplier.loc[mask] = 1.0 / split_at_row.loc[mask]
        mask = adjust_mask & effective.eq("post_volume")
        if bool(mask.any()):
            volume_multiplier.loc[mask] = 1.0 / ex_at_row.loc[mask]
        values = pd.to_numeric(out.loc[adjust_mask, VOLUME_COLUMN], errors="coerce")
        out.loc[adjust_mask, VOLUME_COLUMN] = values * volume_multiplier.loc[adjust_mask]

    return out


def _effective_adjust_type(
    order_book_id: str,
    *,
    adjust_type: AdjustmentType | None,
    frequency: str,
    instrument_lookup: Mapping[str, Mapping[str, str | None]],
) -> AdjustmentType:
    if frequency == "tick":
        return "none"
    rq_type = instrument_lookup.get(order_book_id, {}).get("type")
    if rq_type not in ADJUSTABLE_RQ_TYPES:
        return "none"
    return "pre" if adjust_type is None else adjust_type


def _adjustment_dates(df: Any, frequency: str):
    import pandas as pd

    if frequency == "1d" and "date" in df.columns:
        return pd.to_datetime(df["date"], errors="coerce")
    if "trading_date" in df.columns:
        dates = pd.to_datetime(df["trading_date"], errors="coerce")
    else:
        dates = pd.Series(pd.NaT, index=df.index)
    if "datetime" in df.columns:
        fallback = pd.to_datetime(df["datetime"], errors="coerce")
        dates = dates.fillna(fallback.dt.normalize())
    return pd.to_datetime(dates, errors="coerce").dt.normalize()


def _query_factor_table(
    pg_connection: Any,
    *,
    pg_schema: str,
    table_name: str,
    date_column: str,
    value_column: str,
    order_book_ids: Sequence[str],
    max_date: dt.date | None = None,
):
    import pandas as pd

    if not order_book_ids:
        return pd.DataFrame(columns=["order_book_id", "factor_date", "factor_value"])
    table = f"{_quote_ident(pg_schema)}.{_quote_ident(table_name)}"
    date_filter = f"  AND {_quote_ident(date_column)} <= %s\n" if max_date is not None else ""
    sql = f"""
SELECT
    "order_book_id",
    {_quote_ident(date_column)} AS factor_date,
    {_quote_ident(value_column)} AS factor_value
FROM {table}
WHERE "order_book_id" = ANY(%s::varchar[])
{date_filter.rstrip()}
ORDER BY "order_book_id", {_quote_ident(date_column)};
"""
    with pg_connection.cursor() as cursor:
        params: tuple[Any, ...] = (list(order_book_ids), max_date) if max_date is not None else (list(order_book_ids),)
        cursor.execute(sql, params)
        rows = cursor.fetchall()
    factors = pd.DataFrame(rows, columns=["order_book_id", "factor_date", "factor_value"])
    if factors.empty:
        return factors
    factors["order_book_id"] = factors["order_book_id"].astype("string")
    factors["factor_date"] = pd.to_datetime(factors["factor_date"], errors="coerce").dt.normalize()
    factors["factor_value"] = pd.to_numeric(factors["factor_value"], errors="coerce")
    invalid = factors["factor_value"].notna() & factors["factor_value"].le(0)
    if invalid.any():
        bad = factors.loc[invalid, ["order_book_id", "factor_date", "factor_value"]].head(5).to_dict("records")
        raise ValueError(f"non-positive adjustment factor(s): {bad}")
    return factors.dropna(subset=["order_book_id", "factor_date", "factor_value"])


def _latest_cum_factors(order_book_ids: Any, factors: Any):
    import numpy as np
    import pandas as pd

    result = pd.Series(np.ones(len(order_book_ids), dtype="float64"), index=order_book_ids.index)
    if factors is None or factors.empty:
        return result

    latest = factors.sort_values(["order_book_id", "factor_date"]).groupby("order_book_id", sort=False)["factor_value"].last()
    mapped = order_book_ids.map(lambda order_book_id: latest.get(str(order_book_id), 1.0))
    return pd.to_numeric(mapped, errors="coerce").fillna(1.0).astype("float64")


def _lookup_cum_factors(order_book_ids: Any, dates: Any, factors: Any):
    import numpy as np
    import pandas as pd

    result = pd.Series(np.ones(len(order_book_ids), dtype="float64"), index=order_book_ids.index)
    if factors is None or factors.empty:
        return result

    factor_groups = {
        str(order_book_id): group.sort_values("factor_date")
        for order_book_id, group in factors.groupby("order_book_id", sort=False)
    }
    for order_book_id, index in order_book_ids.groupby(order_book_ids, sort=False).groups.items():
        group = factor_groups.get(str(order_book_id))
        if group is None or group.empty:
            continue
        target_dates = pd.to_datetime(dates.loc[index], errors="coerce").to_numpy(dtype="datetime64[ns]")
        factor_dates = group["factor_date"].to_numpy(dtype="datetime64[ns]")
        factor_values = group["factor_value"].to_numpy(dtype="float64")
        positions = np.searchsorted(factor_dates, target_dates, side="right") - 1
        valid = positions >= 0
        if valid.any():
            result.loc[index[valid]] = factor_values[positions[valid]]
    return result


def _quote_ident(identifier: str) -> str:
    if not _IDENT_RE.match(identifier):
        raise ValueError(f"unsafe PostgreSQL identifier: {identifier!r}")
    return '"' + identifier.replace('"', '""') + '"'
