from __future__ import annotations


ASSETS = ("equity", "future", "commodity_option", "etf_option")
FREQUENCIES = ("tick", "1m", "5m", "15m", "30m", "60m", "120m", "240m", "1d")


def _authoritative_dataset(asset_type: str, frequency: str) -> str:
    if frequency == "1d":
        return f"{asset_type}_daily"
    if frequency in {"tick", "1m"}:
        return f"{asset_type}_{frequency}"
    return f"{asset_type}_{frequency}_bar"


def _table_name(asset_type: str, frequency: str) -> str:
    if frequency == "tick":
        return f"{asset_type}_tick"
    if frequency == "1d":
        return f"{asset_type}_daily_bar"
    return f"{asset_type}_{frequency}_bar"


PRICE_DIMENSIONS = tuple(
    {
        "asset_type": asset_type,
        "frequency": frequency,
        "live_dataset": f"{asset_type}_{frequency}",
        "authoritative_dataset": _authoritative_dataset(asset_type, frequency),
        "table_name": _table_name(asset_type, frequency),
    }
    for asset_type in ASSETS
    for frequency in FREQUENCIES
)

AUTHORITATIVE_DATASET_BY_DIMENSION = {
    item["live_dataset"]: item["authoritative_dataset"]
    for item in PRICE_DIMENSIONS
}
TABLE_BY_DIMENSION = {
    item["live_dataset"]: item["table_name"]
    for item in PRICE_DIMENSIONS
}


if len(PRICE_DIMENSIONS) != 36:
    raise RuntimeError("get_price routing requires exactly 36 shared dimensions")
