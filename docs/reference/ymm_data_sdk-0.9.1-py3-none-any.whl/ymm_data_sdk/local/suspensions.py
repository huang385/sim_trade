"""Suspension filtering helpers for locally mirrored RQ market data."""

from __future__ import annotations

import re
from collections.abc import Collection, Mapping, Sequence
from typing import Any


SUSPENDABLE_RQ_TYPES = {"CS", "Convertible"}
_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def required_suspension_columns(
    *,
    skip_suspended: bool,
    frequency: str,
    instrument_types: Sequence[str | None],
    available_columns: Collection[str],
) -> list[str]:
    """Return hidden columns needed to filter suspended trading days."""
    del frequency
    if not skip_suspended:
        return []
    if not any(rq_type in SUSPENDABLE_RQ_TYPES for rq_type in instrument_types):
        return []

    out = ["order_book_id"]
    available = set(available_columns)
    if "date" in available:
        out.append("date")
    elif "trading_date" in available:
        out.append("trading_date")
    elif "datetime" in available:
        out.append("datetime")
    return out


def apply_skip_suspended(
    df: Any,
    *,
    skip_suspended: bool,
    frequency: str,
    instrument_lookup: Mapping[str, Mapping[str, str | None]],
    pg_connection: Any,
    pg_schema: str = "public",
) -> Any:
    """Drop rows whose order_book_id/date is present in suspension tables."""
    del frequency
    if not skip_suspended or df is None or df.empty or "order_book_id" not in df.columns:
        return df

    import pandas as pd

    out = df.copy()
    order_book_ids = out["order_book_id"].astype("string")
    suspendable_mask = order_book_ids.map(
        lambda order_book_id: instrument_lookup.get(str(order_book_id), {}).get("type") in SUSPENDABLE_RQ_TYPES
    )
    if not bool(suspendable_mask.any()):
        return out

    row_dates = _row_dates(out)
    filter_mask = suspendable_mask & row_dates.notna()
    if not bool(filter_mask.any()):
        return out

    target_ids = sorted(order_book_ids.loc[filter_mask].dropna().unique().astype(str).tolist())
    target_dates = pd.to_datetime(row_dates.loc[filter_mask], errors="coerce").dt.date.dropna()
    if not target_ids or target_dates.empty:
        return out

    suspended = _query_suspended_dates(
        pg_connection,
        pg_schema=pg_schema,
        order_book_ids=target_ids,
        start_date=target_dates.min(),
        end_date=target_dates.max(),
    )
    if suspended.empty:
        return out

    suspended_index = pd.MultiIndex.from_frame(suspended[["order_book_id", "date"]])
    row_index = pd.MultiIndex.from_arrays(
        [
            order_book_ids.astype(str),
            pd.to_datetime(row_dates, errors="coerce").dt.normalize(),
        ],
        names=["order_book_id", "date"],
    )
    drop_mask = filter_mask & row_index.isin(suspended_index)
    if not bool(drop_mask.any()):
        return out
    return out.loc[~drop_mask].reset_index(drop=True)


def _row_dates(df: Any):
    import pandas as pd

    if "date" in df.columns:
        dates = pd.to_datetime(df["date"], errors="coerce")
    elif "trading_date" in df.columns:
        dates = pd.to_datetime(df["trading_date"], errors="coerce")
    else:
        dates = pd.Series(pd.NaT, index=df.index)
    if "datetime" in df.columns:
        fallback = pd.to_datetime(df["datetime"], errors="coerce")
        dates = dates.fillna(fallback.dt.normalize())
    return pd.to_datetime(dates, errors="coerce").dt.normalize()


def _query_suspended_dates(
    pg_connection: Any,
    *,
    pg_schema: str,
    order_book_ids: Sequence[str],
    start_date: Any,
    end_date: Any,
):
    import pandas as pd

    if not order_book_ids:
        return pd.DataFrame(columns=["order_book_id", "date"])
    stock_table = f"{_quote_ident(pg_schema)}.{_quote_ident('is_suspended')}"
    convertible_table = f"{_quote_ident(pg_schema)}.{_quote_ident('convertible_is_suspended')}"
    sql = f"""
SELECT
    "order_book_id",
    "date"
FROM {stock_table}
WHERE "order_book_id" = ANY(%s::varchar[])
  AND "date" >= %s
  AND "date" <= %s
  AND "is_suspended"
UNION ALL
SELECT
    "order_book_id",
    "date"
FROM {convertible_table}
WHERE "order_book_id" = ANY(%s::varchar[])
  AND "date" >= %s
  AND "date" <= %s
  AND "is_suspended"
ORDER BY "order_book_id", "date";
"""
    with pg_connection.cursor() as cursor:
        cursor.execute(sql, (list(order_book_ids), start_date, end_date, list(order_book_ids), start_date, end_date))
        rows = cursor.fetchall()
    suspended = pd.DataFrame(rows, columns=["order_book_id", "date"])
    if suspended.empty:
        return suspended
    suspended["order_book_id"] = suspended["order_book_id"].astype("string")
    suspended["date"] = pd.to_datetime(suspended["date"], errors="coerce").dt.normalize()
    return suspended.dropna(subset=["order_book_id", "date"]).drop_duplicates(["order_book_id", "date"])


def _quote_ident(identifier: str) -> str:
    if not _IDENT_RE.match(identifier):
        raise ValueError(f"unsafe PostgreSQL identifier: {identifier!r}")
    return '"' + identifier.replace('"', '""') + '"'
