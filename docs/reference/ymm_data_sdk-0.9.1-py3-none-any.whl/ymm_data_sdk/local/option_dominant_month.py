from __future__ import annotations

import datetime as dt
from typing import TYPE_CHECKING, Sequence


if TYPE_CHECKING:
    from .market_data import RQMarketDataClient


def get_dominant_month(
    client: "RQMarketDataClient",
    underlying_symbol,
    start_date=None,
    end_date=None,
    rule=0,
    rank=1,
    market="cn",
):
    client._require_cn_market(market)
    if rule not in {0, 1}:
        raise ValueError(f"rule: got invalided value {rule}, choose any in [0, 1]")
    if not isinstance(underlying_symbol, str):
        raise ValueError(
            f"underlying_symbol: expect a string, got {underlying_symbol}"
        )
    symbol = underlying_symbol.upper()
    start = client._parse_date_input(start_date)
    if start is None:
        rows = client._query_pg_rows(
            f"""
SELECT min("listed_date")
FROM {client._pg_table('instruments_option')}
WHERE "underlying_symbol" = %s;
""",
            (symbol,),
        )
        if not rows or rows[0][0] is None:
            raise ValueError("Unknown underlying")
        start = client._coerce_date(rows[0][0]).isoformat()
    end = client._parse_date_input(end_date) or dt.date.today().isoformat()
    client._validate_date_range(start, end)
    materialized_rank = 1 if rank == 1 else 2
    rows = client._query_pg_rows(
        f"""
SELECT "date", "dominant"
FROM {client._pg_table('option_dominant_month')}
WHERE "underlying_symbol" = %s
  AND "rule" = %s
  AND "rank" = %s
  AND "date" >= %s::date
  AND "date" <= %s::date
ORDER BY "date";
""",
        (symbol, rule, materialized_rank, start, end),
    )
    if not rows:
        return None

    import numpy as np
    import pandas as pd

    dates = np.asarray(
        [value.year * 10000 + value.month * 100 + value.day for value, _ in rows],
        dtype=np.int64,
    )
    return pd.Series(
        [str(dominant) for _, dominant in rows],
        index=pd.Index(dates, name="date"),
        name="dominant",
        dtype=object,
    )


def get_dominant_month_batch(
    client: "RQMarketDataClient",
    underlying_symbol_list: Sequence[str],
    start_date: str | int | dt.date | dt.datetime,
    end_date: str | int | dt.date | dt.datetime,
    rule: int = 0,
    rank: int = 1,
    market: str = "cn",
):
    """Return option dominant months for multiple underlyings in one query."""
    client._require_cn_market(market)
    if isinstance(underlying_symbol_list, str):
        raise TypeError("underlying_symbol_list must be a sequence of strings, not a string")
    if rule not in {0, 1}:
        raise ValueError(f"rule: got invalided value {rule}, choose any in [0, 1]")

    symbols: list[str] = []
    seen: set[str] = set()
    for value in underlying_symbol_list:
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"invalid underlying_symbol: {value!r}")
        symbol = value.strip().upper()
        if symbol not in seen:
            symbols.append(symbol)
            seen.add(symbol)
    if not symbols:
        raise ValueError("underlying_symbol_list cannot be empty")

    start = client._parse_date_input(start_date)
    end = client._parse_date_input(end_date)
    if start is None or end is None:
        raise ValueError("start_date and end_date are required")
    client._validate_date_range(start, end)
    materialized_rank = 1 if rank == 1 else 2

    rows = client._query_pg_rows(
        f"""
WITH requested_symbols AS (
    SELECT "underlying_symbol", "symbol_order"
    FROM unnest(%s::varchar[]) WITH ORDINALITY
         AS requested("underlying_symbol", "symbol_order")
),
known_symbols AS (
    SELECT DISTINCT instruments."underlying_symbol"
    FROM {client._pg_table('instruments_option')} AS instruments
    INNER JOIN requested_symbols
      ON requested_symbols."underlying_symbol" = instruments."underlying_symbol"
),
classified AS (
    SELECT
        requested_symbols."underlying_symbol",
        requested_symbols."symbol_order",
        known_symbols."underlying_symbol" IS NOT NULL AS "is_known"
    FROM requested_symbols
    LEFT JOIN known_symbols USING ("underlying_symbol")
),
trading_days AS (
    SELECT "date"
    FROM {client._pg_table('trading_dates')}
    WHERE "is_trading"
      AND "date" >= %s::date
      AND "date" <= %s::date
),
grid AS (
    SELECT
        classified."underlying_symbol",
        classified."symbol_order",
        trading_days."date"
    FROM classified
    CROSS JOIN trading_days
)
SELECT
    0::smallint AS "row_kind",
    classified."symbol_order",
    classified."underlying_symbol",
    NULL::date AS "date",
    NULL::varchar AS "dominant",
    classified."is_known"
FROM classified
UNION ALL
SELECT
    1::smallint,
    grid."symbol_order",
    grid."underlying_symbol",
    grid."date",
    dominant_month."dominant",
    TRUE
FROM grid
LEFT JOIN {client._pg_table('option_dominant_month')} AS dominant_month
  ON dominant_month."underlying_symbol" = grid."underlying_symbol"
 AND dominant_month."date" = grid."date"
 AND dominant_month."rule" = %s
 AND dominant_month."rank" = %s
ORDER BY "row_kind", "symbol_order", "date";
""",
        (symbols, start, end, rule, materialized_rank),
    )

    known = {
        str(row[2]): bool(row[5])
        for row in rows
        if int(row[0]) == 0
    }
    unknown = [symbol for symbol in symbols if not known.get(symbol, False)]
    if unknown:
        raise ValueError(f"Unknown underlying: {unknown[0]}")

    data_rows = [row for row in rows if int(row[0]) == 1]

    import numpy as np
    import pandas as pd

    if not data_rows:
        return pd.DataFrame(
            {
                "underlying_symbol": pd.Series(dtype=object),
                "date": pd.Series(dtype=np.int64),
                "dominant": pd.Series(dtype=object),
            }
        )
    return pd.DataFrame(
        {
            "underlying_symbol": pd.Series(
                [str(row[2]) for row in data_rows],
                dtype=object,
            ),
            "date": np.asarray(
                [
                    row[3].year * 10000 + row[3].month * 100 + row[3].day
                    for row in data_rows
                ],
                dtype=np.int64,
            ),
            "dominant": pd.Series(
                [None if row[4] is None else str(row[4]) for row in data_rows],
                dtype=object,
            ),
        }
    )
