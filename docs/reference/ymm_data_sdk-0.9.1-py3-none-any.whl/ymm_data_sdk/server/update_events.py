from __future__ import annotations

import asyncio
import datetime as dt
import json
import os
from pathlib import Path
import stat
import threading
import time
from dataclasses import dataclass
from typing import Any, Sequence

import psycopg
from psycopg.conninfo import conninfo_to_dict, make_conninfo

from .token_store import TokenRecord


EVENT_CHANNEL = "ymm_sdk_update_events"
EVENT_PROTOCOL_VERSION = 1
SUBSCRIBER_QUEUE_SIZE = 256
EVENT_LISTENER_DSN_FILE_ENV = "YMM_DATA_SDK_UPDATE_EVENTS_LISTENER_DSN_FILE"
EVENT_RECONCILE_INTERVAL_ENV = "YMM_DATA_SDK_UPDATE_EVENTS_RECONCILE_INTERVAL_SECONDS"
EVENT_LISTENER_USERNAME = "ymm_sdk_event_listener"
EVENT_LISTENER_HOST = "127.0.0.1"
EVENT_LISTENER_PORT = 5432
EVENT_LISTENER_DATABASE = "market_meta_RQ"
EVENT_LISTENER_APPLICATION_NAME = "ymm_data_sdk_event_broker"
DEFAULT_RECONCILE_INTERVAL_SECONDS = 60
MAX_RECONNECT_DELAY_SECONDS = 30.0


@dataclass(frozen=True)
class EventFilters:
    methods: tuple[str, ...] = ()
    source_kinds: tuple[str, ...] = ()
    statuses: tuple[str, ...] = ()


class ListenerConfigurationError(RuntimeError):
    """The dedicated update-event listener secret is absent or unsafe."""


class EventBroker:
    """One direct PostgreSQL LISTEN connection shared by all WebSocket clients."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._subscribers: dict[int, tuple[asyncio.AbstractEventLoop, asyncio.Queue[int]]] = {}
        self._next_subscriber = 1
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._dsn_file: Path | None = None
        self._reconcile_interval_seconds = DEFAULT_RECONCILE_INTERVAL_SECONDS
        self._last_reconcile_monotonic: float | None = None
        self.state = "stopped"
        self.last_error: str | None = None
        self.connected = False
        self.last_event_id: int | None = None
        self.last_notification_at: str | None = None
        self.last_reconcile_at: str | None = None
        self.reconnect_count = 0
        self.listener_host: str | None = None
        self.listener_port: int | None = None

    def configure_from_environment(self) -> None:
        raw_path = os.environ.get(EVENT_LISTENER_DSN_FILE_ENV)
        raw_interval = os.environ.get(EVENT_RECONCILE_INTERVAL_ENV)
        interval = (
            DEFAULT_RECONCILE_INTERVAL_SECONDS
            if raw_interval is None
            else _reconcile_interval(raw_interval)
        )
        self.configure(dsn_file=None if not raw_path else Path(raw_path), interval=interval)

    def configure(self, *, dsn_file: Path | None, interval: int) -> None:
        interval = _reconcile_interval(interval)
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                raise RuntimeError("event broker cannot be reconfigured while running")
            self._dsn_file = None if dsn_file is None else dsn_file.expanduser().resolve()
            self._reconcile_interval_seconds = interval
            if self._dsn_file is None:
                self.state = "misconfigured"
                self.last_error = "ListenerConfigurationError: listener secret is not configured"
            else:
                self.state = "stopped"
                self.last_error = None

    def start(self) -> None:
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return
            if self._dsn_file is None:
                self.state = "misconfigured"
                self.last_error = "ListenerConfigurationError: listener secret is not configured"
                return
            self._stop.clear()
            self.state = "starting"
            self._thread = threading.Thread(
                target=self._run,
                name="ymm-sdk-update-event-listener",
                daemon=True,
            )
            self._thread.start()

    def ensure_started(self, _record: TokenRecord | None = None) -> None:
        # The record is intentionally ignored. Durable event reads keep using
        # the ordinary SDK identity through PgBouncer, while LISTEN exclusively
        # uses the dedicated secret configured at service startup.
        self.start()

    def subscribe(self) -> tuple[int, asyncio.Queue[int]]:
        loop = asyncio.get_running_loop()
        queue: asyncio.Queue[int] = asyncio.Queue(maxsize=SUBSCRIBER_QUEUE_SIZE)
        with self._lock:
            subscriber_id = self._next_subscriber
            self._next_subscriber += 1
            self._subscribers[subscriber_id] = (loop, queue)
        return subscriber_id, queue

    def unsubscribe(self, subscriber_id: int) -> None:
        with self._lock:
            self._subscribers.pop(subscriber_id, None)

    def stop(self) -> None:
        self._stop.set()
        thread = self._thread
        if thread is not None:
            thread.join(timeout=3)
        with self._lock:
            self._thread = None
            self.connected = False
            self.state = "stopped"

    def health(self) -> tuple[bool, dict[str, Any]]:
        now = time.monotonic()
        with self._lock:
            reconcile_age = (
                None
                if self._last_reconcile_monotonic is None
                else max(0.0, now - self._last_reconcile_monotonic)
            )
            stale_after = float(self._reconcile_interval_seconds * 3)
            healthy = bool(
                self.connected
                and reconcile_age is not None
                and reconcile_age <= stale_after
            )
            state = "stale" if self.connected and not healthy else self.state
            payload = {
                "status": "ok" if healthy else "degraded",
                "event_broker_state": state,
                "event_broker_connected": self.connected,
                "event_broker_last_event_id": self.last_event_id,
                "event_broker_last_notification_at": self.last_notification_at,
                "event_broker_last_reconcile_at": self.last_reconcile_at,
                "event_broker_reconnect_count": self.reconnect_count,
                "event_broker_last_error": self.last_error,
                "event_broker_subscriber_count": len(self._subscribers),
                "event_broker_listener_host": self.listener_host,
                "event_broker_listener_port": self.listener_port,
                "event_broker_reconcile_interval_seconds": (
                    self._reconcile_interval_seconds
                ),
            }
        return healthy, payload

    def _run(self) -> None:
        retry_delay = 1.0
        while not self._stop.is_set():
            try:
                dsn_file = self._dsn_file
                if dsn_file is None:
                    raise ListenerConfigurationError("listener secret is not configured")
                conninfo, host, port = _read_listener_conninfo(dsn_file)
                with self._lock:
                    self.listener_host = host
                    self.listener_port = port
                with psycopg.connect(conninfo, autocommit=True) as connection:
                    with connection.cursor() as cursor:
                        cursor.execute(f"LISTEN {EVENT_CHANNEL}")
                    self._mark_connected()
                    self._reconcile(connection, force_broadcast=True)
                    retry_delay = 1.0
                    next_reconcile = (
                        time.monotonic() + self._reconcile_interval_seconds
                    )
                    while not self._stop.is_set():
                        timeout = max(0.0, min(1.0, next_reconcile - time.monotonic()))
                        for notification in connection.notifies(timeout=timeout, stop_after=1):
                            with self._lock:
                                self.last_notification_at = _utc_now()
                            try:
                                payload = json.loads(notification.payload)
                                event_id = int(payload["event_id"])
                                if event_id <= 0:
                                    raise ValueError("event_id must be positive")
                            except (KeyError, TypeError, ValueError, json.JSONDecodeError):
                                # Never record the payload. The durable table is
                                # authoritative, so an immediate reconcile is safe.
                                self._reconcile(connection)
                            else:
                                self._advance_watermark(event_id)
                        if time.monotonic() >= next_reconcile:
                            self._reconcile(connection)
                            next_reconcile = (
                                time.monotonic() + self._reconcile_interval_seconds
                            )
            except Exception as exc:  # noqa: BLE001 - listener must recover durably.
                self._mark_disconnected(exc)
                if self._stop.wait(retry_delay):
                    break
                with self._lock:
                    self.reconnect_count += 1
                retry_delay = min(retry_delay * 2.0, MAX_RECONNECT_DELAY_SECONDS)
        with self._lock:
            self.connected = False
            if self.state != "stopped":
                self.state = "stopped"

    def _mark_connected(self) -> None:
        with self._lock:
            self.connected = True
            self.state = "connected"
            self.last_error = None

    def _mark_disconnected(self, exc: Exception) -> None:
        with self._lock:
            self.connected = False
            self.state = (
                "misconfigured"
                if isinstance(exc, ListenerConfigurationError)
                else "reconnecting"
            )
            # Do not include raw exception messages: libpq errors can echo
            # connection strings and notification payloads.
            self.last_error = f"{type(exc).__name__}: event listener unavailable"

    def _reconcile(self, connection: Any, *, force_broadcast: bool = False) -> None:
        with connection.cursor() as cursor:
            cursor.execute("SELECT COALESCE(max(event_id), 0) FROM public.sdk_update_events")
            watermark = int(cursor.fetchone()[0])
        with self._lock:
            self.last_reconcile_at = _utc_now()
            self._last_reconcile_monotonic = time.monotonic()
        self._advance_watermark(watermark, force=force_broadcast)

    def _advance_watermark(self, event_id: int, *, force: bool = False) -> None:
        with self._lock:
            advanced = self.last_event_id is None or event_id > self.last_event_id
            if advanced:
                self.last_event_id = event_id
        if advanced or force:
            self._broadcast(event_id)

    def _broadcast(self, event_id: int) -> None:
        with self._lock:
            subscribers = list(self._subscribers.values())
        for loop, queue in subscribers:
            try:
                loop.call_soon_threadsafe(_queue_event, queue, event_id)
            except RuntimeError:
                # A concurrently closed event loop is equivalent to an already
                # disconnected subscriber and must not tear down LISTEN.
                continue


def fetch_events(
    record: TokenRecord,
    *,
    after_event_id: int,
    filters: EventFilters,
    limit: int = 1000,
) -> list[dict[str, Any]]:
    clauses = ["event_id > %s"]
    params: list[Any] = [after_event_id]
    if filters.methods:
        clauses.append("method = ANY(%s)")
        params.append(list(filters.methods))
    if filters.source_kinds:
        clauses.append("source_kind = ANY(%s)")
        params.append(list(filters.source_kinds))
    if filters.statuses:
        clauses.append("status = ANY(%s)")
        params.append(list(filters.statuses))
    params.append(limit)
    query = (
        "SELECT row_to_json(event_row)::text FROM ("
        f"SELECT {EVENT_PROTOCOL_VERSION} AS protocol_version,"
        "event_id,event_type,trading_date,source_kind,method,dataset,asset_type,"
        "frequency,table_name,status,started_at,completed_at,observed_at,last_data_at,"
        "valid_until,sealed_at,run_id,revision,datasets,reason_code,reason,metadata,created_at "
        "FROM public.sdk_update_events WHERE "
        + " AND ".join(clauses)
        + " ORDER BY event_id LIMIT %s) AS event_row"
    )
    with psycopg.connect(**_connection_kwargs(record)) as connection, connection.cursor() as cursor:
        cursor.execute(query, params)
        return [json.loads(row[0]) for row in cursor.fetchall()]


def _connection_kwargs(record: TokenRecord) -> dict[str, Any]:
    config = record.postgresql
    return {
        "host": str(config["host"]),
        "port": int(config.get("port", 5432)),
        "user": str(config["username"]),
        "password": str(config.get("password", "")),
        "dbname": str(config.get("database", "market_meta_RQ")),
        "connect_timeout": 10,
    }


def _read_listener_conninfo(path: Path) -> tuple[str, str, int]:
    try:
        metadata = path.stat()
    except OSError as exc:
        raise ListenerConfigurationError("listener secret is unavailable") from exc
    if not stat.S_ISREG(metadata.st_mode):
        raise ListenerConfigurationError("listener secret must be a regular file")
    mode = stat.S_IMODE(metadata.st_mode)
    if mode & 0o007 or mode & 0o030:
        raise ListenerConfigurationError("listener secret permissions are unsafe")
    try:
        raw = path.read_text(encoding="utf-8").strip()
        parsed = conninfo_to_dict(raw)
    except Exception as exc:
        raise ListenerConfigurationError("listener secret is invalid") from exc
    try:
        host = str(parsed["host"])
        port = int(parsed["port"])
        database = str(parsed["dbname"])
        username = str(parsed["user"])
        password = str(parsed["password"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ListenerConfigurationError("listener secret is incomplete") from exc
    if (
        host != EVENT_LISTENER_HOST
        or port != EVENT_LISTENER_PORT
        or database != EVENT_LISTENER_DATABASE
        or username != EVENT_LISTENER_USERNAME
        or not password
    ):
        raise ListenerConfigurationError("listener secret target or identity is invalid")
    return (
        make_conninfo(
            raw,
            connect_timeout=10,
            application_name=EVENT_LISTENER_APPLICATION_NAME,
        ),
        host,
        port,
    )


def _reconcile_interval(value: Any) -> int:
    try:
        interval = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("update-event reconcile interval must be an integer") from exc
    if not 1 <= interval <= 3600:
        raise ValueError("update-event reconcile interval must be between 1 and 3600 seconds")
    return interval


def _utc_now() -> str:
    return dt.datetime.now(dt.UTC).isoformat()


def _queue_event(queue: asyncio.Queue[int], event_id: int) -> None:
    if queue.full():
        while not queue.empty():
            try:
                queue.get_nowait()
            except asyncio.QueueEmpty:
                break
        queue.put_nowait(-1)
        return
    queue.put_nowait(event_id)


event_broker = EventBroker()
