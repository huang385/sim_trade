from __future__ import annotations

from dataclasses import dataclass
import ipaddress
import json
import subprocess
import threading
import time
from typing import Any, Callable

from .token_store import TokenRecord


TAILSCALE_WHOIS_TIMEOUT_SECONDS = 3.0
TAILSCALE_WHOIS_CACHE_SECONDS = 15.0


@dataclass(frozen=True)
class SourceAuthorizationError(Exception):
    status_code: int
    detail: str

    def __str__(self) -> str:
        return self.detail


class SourceAuthorizer:
    def __init__(
        self,
        *,
        runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
        monotonic: Callable[[], float] = time.monotonic,
        cache_seconds: float = TAILSCALE_WHOIS_CACHE_SECONDS,
    ) -> None:
        self._runner = runner
        self._monotonic = monotonic
        self._cache_seconds = cache_seconds
        self._cache: dict[str, tuple[float, dict[str, Any]]] = {}
        self._lock = threading.Lock()

    def authorize(self, record: TokenRecord, source_ip: str | None) -> None:
        source = record.source
        if not source:
            raise SourceAuthorizationError(
                403,
                f"source blocked for {record.user!r}: token has no source binding",
            )
        observed = _normalized_ip(source_ip, "request source IP")
        kind = source["kind"]
        if kind == "loopback":
            if not ipaddress.ip_address(observed).is_loopback:
                raise SourceAuthorizationError(
                    403,
                    f"source blocked for {record.user!r}: local identity requires loopback, received {observed}",
                )
            return
        if kind == "lan_ip":
            expected = _normalized_ip(str(source["ip"]), "configured LAN source IP")
            if observed != expected:
                raise SourceAuthorizationError(
                    403,
                    f"source blocked for {record.user!r}: expected LAN IP {expected}, received {observed}",
                )
            return
        if kind != "tailscale_device":
            raise SourceAuthorizationError(
                403,
                f"source blocked for {record.user!r}: unsupported source binding {kind!r}",
            )

        configured = {
            _normalized_ip(str(address), "configured Tailscale address")
            for address in source["addresses"]
        }
        if observed not in configured:
            raise SourceAuthorizationError(
                403,
                f"source blocked for {record.user!r}: Tailscale address {observed} is not bound to this token",
            )
        identity = self._tailscale_whois(observed)
        login = str((identity.get("UserProfile") or {}).get("LoginName") or "")
        node = identity.get("Node") or {}
        stable_id = str(node.get("StableID") or "")
        node_addresses = {
            _normalized_ip(str(address), "Tailscale WhoIs node address")
            for address in (node.get("Addresses") or [])
        }
        reasons: list[str] = []
        if login.casefold() != str(source["login"]).casefold():
            reasons.append(
                f"login mismatch (expected {source['login']!r}, received {login or '<missing>'!r})"
            )
        if stable_id != source["stable_id"]:
            reasons.append("device StableID mismatch")
        if observed not in node_addresses:
            reasons.append("request IP is absent from the WhoIs node addresses")
        if reasons:
            raise SourceAuthorizationError(
                403,
                f"source blocked for {record.user!r}: {'; '.join(reasons)}",
            )

    def _tailscale_whois(self, source_ip: str) -> dict[str, Any]:
        now = self._monotonic()
        with self._lock:
            cached = self._cache.get(source_ip)
            if cached and cached[0] > now:
                return cached[1]
        try:
            result = self._runner(
                ["tailscale", "whois", "--json", source_ip],
                text=True,
                capture_output=True,
                timeout=TAILSCALE_WHOIS_TIMEOUT_SECONDS,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise SourceAuthorizationError(
                503,
                f"Tailscale identity verification unavailable ({type(exc).__name__})",
            ) from exc
        if result.returncode != 0:
            raise SourceAuthorizationError(
                503,
                f"Tailscale identity verification unavailable (whois exit {result.returncode})",
            )
        try:
            identity = json.loads(result.stdout)
        except (TypeError, json.JSONDecodeError) as exc:
            raise SourceAuthorizationError(
                503,
                "Tailscale identity verification unavailable (invalid WhoIs response)",
            ) from exc
        if not isinstance(identity, dict):
            raise SourceAuthorizationError(
                503,
                "Tailscale identity verification unavailable (unexpected WhoIs response)",
            )
        with self._lock:
            self._cache[source_ip] = (now + self._cache_seconds, identity)
        return identity


def _normalized_ip(value: str | None, label: str) -> str:
    if not value:
        raise SourceAuthorizationError(403, f"source blocked: {label} is unavailable")
    try:
        return str(ipaddress.ip_interface(value).ip)
    except ValueError as exc:
        raise SourceAuthorizationError(403, f"source blocked: invalid {label}") from exc
