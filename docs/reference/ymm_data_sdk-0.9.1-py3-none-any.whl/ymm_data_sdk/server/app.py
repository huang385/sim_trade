from __future__ import annotations

import asyncio
import os
import time
import traceback as traceback_lib
import warnings
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Header, HTTPException, Request, Response, WebSocket, WebSocketDisconnect
from pydantic import BaseModel
from starlette.concurrency import run_in_threadpool

from ymm_data_sdk import __version__
from ymm_data_sdk.registry import PROXY_METHODS
from ymm_data_sdk.serializers import (
    MAX_PROXY_REQUEST_BYTES,
    PICKLE_ZSTD_MEDIA_TYPE,
    PROXY_ENVELOPE_KEY,
    PROXY_PROTOCOL_VERSION,
    dumps_object,
    loads_object,
)

from .rqdatac_proxy import call_rqdatac, warmup_rqdatac
from .source_auth import SourceAuthorizationError, SourceAuthorizer
from .token_store import TokenRecord, TokenStore, session_payload
from .update_events import EventFilters, event_broker, fetch_events


@asynccontextmanager
async def _service_lifespan(_: FastAPI) -> AsyncIterator[None]:
    try:
        token_store.reload()
    except Exception as exc:
        raise RuntimeError(
            f"Token snapshot load failed ({type(exc).__name__}); proxy service startup aborted"
        ) from exc
    try:
        # Startup is intentionally blocked until the single shared RQData
        # connection is ready; no requests can be served during this phase.
        # Calling directly also avoids leaving a transient executor behind
        # when lifespan startup is exercised repeatedly in tests.
        warmup_rqdatac()
    except Exception as exc:
        raise RuntimeError(
            f"RQData warmup failed ({type(exc).__name__}); proxy service startup aborted"
        ) from exc
    event_broker.configure_from_environment()
    event_broker.start()
    try:
        yield
    finally:
        event_broker.stop()


app = FastAPI(title="ymm_data_sdk rqdatac proxy", version=__version__, lifespan=_service_lifespan)
token_store = TokenStore()
source_authorizer = SourceAuthorizer()


class SessionRequest(BaseModel):
    token: str | None = None


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "version": __version__}


@app.get("/update-events/health")
def update_events_health(response: Response) -> dict[str, Any]:
    healthy, payload = event_broker.health()
    response.status_code = 200 if healthy else 503
    return {"version": __version__, **payload}


@app.websocket("/ws/update-events")
async def update_events_websocket(websocket: WebSocket) -> None:
    try:
        token = _bearer_token(websocket.headers.get("authorization"))
        record = _authorized_source_record(
            token,
            None if websocket.client is None else websocket.client.host,
        )
        filters = EventFilters(
            methods=_query_values(websocket, "method", public_methods=True),
            source_kinds=_query_values(websocket, "source_kind"),
            statuses=_query_values(websocket, "status"),
        )
        raw_after = websocket.query_params.get("after_event_id")
        after_event_id = 0 if raw_after is None else int(raw_after)
        if after_event_id < 0:
            raise ValueError("after_event_id must be non-negative")
    except HTTPException as exc:
        await websocket.close(code=4401 if exc.status_code == 401 else 4403, reason=str(exc.detail))
        return
    except (TypeError, ValueError) as exc:
        await websocket.close(code=4400, reason=str(exc))
        return

    local_record = token_store.require_local()
    event_broker.ensure_started(local_record)
    subscriber_id, wakeups = event_broker.subscribe()
    last_event_id = after_event_id
    await websocket.accept()
    try:
        while True:
            events = await run_in_threadpool(
                fetch_events,
                local_record,
                after_event_id=last_event_id,
                filters=filters,
                limit=1000,
            )
            for event in events:
                event_id = int(event["event_id"])
                if event_id <= last_event_id:
                    continue
                await websocket.send_json(event)
                last_event_id = event_id
            if len(events) == 1000:
                continue
            wakeup = await _wait_for_event_or_disconnect(websocket, wakeups)
            if wakeup is None:
                await websocket.close(
                    code=4400,
                    reason="client messages are not supported on the update-event stream",
                )
                return
            if wakeup < 0:
                await websocket.close(
                    code=1013,
                    reason="update-event consumer is too slow; reconnect with after_event_id",
                )
                return
            # The durable query above, not the notification payload, is the
            # source of truth. A watermark merely wakes the replay loop.
    except WebSocketDisconnect:
        return
    finally:
        event_broker.unsubscribe(subscriber_id)


async def _wait_for_event_or_disconnect(
    websocket: WebSocket,
    wakeups: asyncio.Queue[int],
) -> int | None:
    """Wait without retaining a subscriber after its socket has disconnected."""

    event_task = asyncio.create_task(wakeups.get())
    receive_task = asyncio.create_task(websocket.receive())
    try:
        done, _ = await asyncio.wait(
            {event_task, receive_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        if receive_task in done:
            message = receive_task.result()
            if message.get("type") == "websocket.disconnect":
                raise WebSocketDisconnect(code=int(message.get("code") or 1000))
            return None
        return event_task.result()
    finally:
        for task in (event_task, receive_task):
            if not task.done():
                task.cancel()
        await asyncio.gather(event_task, receive_task, return_exceptions=True)


@app.post("/auth/session")
def auth_session(request: SessionRequest, http_request: Request) -> dict[str, Any]:
    record = _authorized_record(request.token, http_request)
    proxy_base = os.environ.get("YMM_DATA_SDK_PUBLIC_BASE_URL", "").rstrip("/")
    proxy_endpoint = (
        f"{proxy_base}/rqdatac/call"
        if proxy_base
        else str(http_request.url_for("rqdatac_call"))
    )
    return session_payload(record, proxy_endpoint=proxy_endpoint)


@app.post("/auth/warmup")
async def auth_warmup(
    request: SessionRequest,
    http_request: Request,
) -> dict[str, Any]:
    record = _authorized_record(request.token, http_request)
    started = time.perf_counter()
    await run_in_threadpool(warmup_rqdatac)
    return {
        "user": record.user,
        "rqdatac": "ok",
        "server_rqdatac_warmup_seconds": round(time.perf_counter() - started, 6),
    }


@app.post("/rqdatac/call")
async def rqdatac_call(
    request: Request,
    authorization: str | None = Header(default=None),
) -> Response:
    token = _bearer_token(authorization)
    _authorized_record(token, request)
    content_length = request.headers.get("content-length")
    if content_length:
        try:
            declared_length = int(content_length)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="invalid Content-Length header") from exc
        if declared_length > MAX_PROXY_REQUEST_BYTES:
            raise HTTPException(status_code=413, detail="proxy request body exceeds 16 MiB")
    content_type = request.headers.get("content-type", "").split(";", 1)[0].lower()
    if content_type != PICKLE_ZSTD_MEDIA_TYPE:
        raise HTTPException(
            status_code=415,
            detail=f"Content-Type must be {PICKLE_ZSTD_MEDIA_TYPE}",
        )
    body = await request.body()
    if len(body) > MAX_PROXY_REQUEST_BYTES:
        raise HTTPException(status_code=413, detail="proxy request body exceeds 16 MiB")

    try:
        payload = loads_object(body)
        method, args, kwargs = _validate_proxy_payload(payload)
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001 - malformed client request.
        raise HTTPException(status_code=400, detail=f"invalid proxy request: {exc}") from exc

    if method not in PROXY_METHODS:
        raise HTTPException(status_code=403, detail=f"method is not allowed: {method}")

    try:
        rqdatac_started = time.perf_counter()
        result, warning_records = await run_in_threadpool(
            _call_with_warnings,
            method,
            args,
            kwargs,
        )
        rqdatac_elapsed = time.perf_counter() - rqdatac_started
    except Exception as exc:  # noqa: BLE001 - proxy should return structured remote errors.
        payload = {
            "ok": False,
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            "error_args": [_safe_error_arg(value) for value in exc.args],
            "traceback": traceback_lib.format_exc(),
        }
        raise HTTPException(status_code=500, detail=payload) from exc
    response_payload = {
        PROXY_ENVELOPE_KEY: PROXY_PROTOCOL_VERSION,
        "result": result,
        "warnings": warning_records,
        "server_rqdatac_elapsed_seconds": rqdatac_elapsed,
    }
    return Response(content=dumps_object(response_payload), media_type=PICKLE_ZSTD_MEDIA_TYPE)


def _authorized_record(token: str | None, request: Request) -> TokenRecord:
    return _authorized_source_record(
        token,
        None if request.client is None else request.client.host,
    )


def _authorized_source_record(token: str | None, source_ip: str | None) -> TokenRecord:
    try:
        record = (
            token_store.require(token.strip())
            if token and token.strip()
            else token_store.require_local()
        )
    except KeyError as exc:
        detail = "invalid token" if token and token.strip() else "local SDK identity is not configured"
        raise HTTPException(status_code=401, detail=detail) from exc
    try:
        source_authorizer.authorize(record, source_ip)
    except SourceAuthorizationError as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.detail) from exc
    return record


def _query_values(
    websocket: WebSocket,
    name: str,
    *,
    public_methods: bool = False,
) -> tuple[str, ...]:
    values = tuple(dict.fromkeys(websocket.query_params.getlist(name)))
    if any(not value for value in values):
        raise ValueError(f"{name} filters must be non-empty")
    if public_methods and any(value.startswith("rq.") for value in values):
        raise ValueError("method filters must use public ymm_data_sdk names")
    return values


def _validate_proxy_payload(
    payload: Any,
) -> tuple[str, tuple[Any, ...], dict[str, Any]]:
    if not isinstance(payload, dict):
        raise ValueError("payload must be a mapping")
    if payload.get("version") != PROXY_PROTOCOL_VERSION:
        raise ValueError(f"unsupported proxy protocol version: {payload.get('version')!r}")
    method = payload.get("method")
    args = payload.get("args", ())
    kwargs = payload.get("kwargs", {})
    if not isinstance(method, str) or not method:
        raise ValueError("method must be a non-empty string")
    if not isinstance(args, (list, tuple)):
        raise ValueError("args must be a list or tuple")
    if not isinstance(kwargs, dict):
        raise ValueError("kwargs must be a mapping")
    return method, tuple(args), kwargs


def _call_with_warnings(
    method: str,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> tuple[Any, list[dict[str, str]]]:
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        result = call_rqdatac(method, args, kwargs)
    records = [
        {
            "category": item.category.__name__,
            "category_module": item.category.__module__,
            "message": str(item.message),
        }
        for item in caught
    ]
    return result, records


def _safe_error_arg(value: Any) -> Any:
    return value if value is None or isinstance(value, (bool, int, float, str)) else repr(value)


def _bearer_token(value: str | None) -> str | None:
    if value is None:
        return None
    if not value.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="invalid authorization scheme")
    return value.split(" ", 1)[1].strip() or None
