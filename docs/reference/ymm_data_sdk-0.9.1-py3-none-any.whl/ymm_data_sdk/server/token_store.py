from __future__ import annotations

import json
import os
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ymm_data_sdk.registry import PROXY_METHODS


DEFAULT_TOKEN_STORE = "ymm_data_sdk_tokens.json"
APPLIED_SCHEMA_VERSION = 2
SUPPORTED_MODES = frozenset({"server", "local", "lan"})
REQUIRED_MODES = frozenset({"local", "lan"})
SUPPORTED_SOURCE_KINDS = frozenset({"loopback", "lan_ip", "tailscale_device"})


@dataclass(frozen=True)
class TokenRecord:
    token: str
    user: str
    clickhouse: dict[str, Any]
    postgresql: dict[str, Any]
    mode: str | None = None
    proxy_base_url: str | None = None
    source: dict[str, Any] | None = None


class TokenStore:
    def __init__(self, path: str | os.PathLike[str] | None = None) -> None:
        self.path = Path(path or os.environ.get("YMM_DATA_SDK_TOKEN_STORE", DEFAULT_TOKEN_STORE))
        self._records: dict[str, TokenRecord] | None = None

    def get(self, token: str) -> TokenRecord | None:
        if self._records is None:
            self._records = self._load()
        return self._records.get(token)

    def require(self, token: str) -> TokenRecord:
        record = self.get(token)
        if record is None:
            raise KeyError("invalid token")
        return record

    def require_local(self) -> TokenRecord:
        if self._records is None:
            self._records = self._load()
        matches = [
            record
            for record in self._records.values()
            if (record.source or {}).get("kind") == "loopback"
        ]
        if len(matches) != 1:
            raise KeyError("local SDK identity is not configured")
        return matches[0]

    def reload(self) -> None:
        """Validate and atomically replace the in-memory token snapshot."""
        self._records = self._load()

    def _load(self) -> dict[str, TokenRecord]:
        if os.name != "nt":
            mode = stat.S_IMODE(self.path.stat().st_mode)
            if mode != 0o600:
                raise PermissionError(
                    f"token store must use mode 0600: {self.path} has {mode:04o}"
                )
        payload = json.loads(self.path.read_text(encoding="utf-8"))
        if payload.get("schema_version") != APPLIED_SCHEMA_VERSION:
            raise ValueError(
                f"token store schema_version must be {APPLIED_SCHEMA_VERSION}; "
                "generate a new applied snapshot with the access-control tool"
            )
        return _load_shared_records(payload)


def _load_shared_records(payload: dict[str, Any]) -> dict[str, TokenRecord]:
    shared = _mapping(payload.get("shared"), "shared")
    proxy_shared = _mapping(shared.get("proxy"), "shared.proxy")
    clickhouse_shared = _mapping(shared.get("clickhouse"), "shared.clickhouse")
    postgresql_shared = _mapping(shared.get("postgresql"), "shared.postgresql")
    modes = _mapping(payload.get("modes"), "modes")
    tokens = _mapping(payload.get("tokens"), "tokens")

    unknown_modes = sorted(set(modes) - SUPPORTED_MODES)
    if unknown_modes:
        raise ValueError(f"unsupported token-store modes: {unknown_modes!r}")
    missing_modes = sorted(REQUIRED_MODES - set(modes))
    if missing_modes:
        raise ValueError(f"token-store modes are missing: {missing_modes!r}")

    scheme = str(proxy_shared.get("scheme") or "http").lower()
    if scheme not in {"http", "https"}:
        raise ValueError("shared.proxy.scheme must be 'http' or 'https'")
    proxy_port = _port(proxy_shared.get("port"), "shared.proxy.port")

    _reject_credentials(clickhouse_shared, "shared.clickhouse")
    _reject_credentials(postgresql_shared, "shared.postgresql")

    mode_hosts: dict[str, str] = {}
    for mode in modes:
        mode_config = _mapping(modes[mode], f"modes.{mode}")
        host = str(mode_config.get("host") or "").strip()
        if not host:
            raise ValueError(f"modes.{mode}.host is required")
        mode_hosts[mode] = host

    records: dict[str, TokenRecord] = {}
    for token, raw_item in tokens.items():
        token = str(token)
        if not token:
            raise ValueError("token records must not use an empty token")
        item = _mapping(raw_item, "token record")
        user = str(item.get("user") or "").strip()
        label = user or "<unnamed>"
        unknown_fields = sorted(
            set(item) - {"user", "mode", "source", "clickhouse", "postgresql"}
        )
        if unknown_fields:
            raise ValueError(
                f"token record {label!r} contains unsupported fields: {unknown_fields!r}"
            )
        mode = str(item.get("mode") or "").strip()
        if mode not in SUPPORTED_MODES:
            raise ValueError(
                f"token record {label!r} has unsupported mode {mode!r}; "
                f"expected one of {sorted(SUPPORTED_MODES)!r}"
            )
        clickhouse_credentials = _credentials(
            item.get("clickhouse"),
            f"token record {label!r}.clickhouse",
        )
        postgresql_credentials = _credentials(
            item.get("postgresql"),
            f"token record {label!r}.postgresql",
        )
        source = _source_binding(item.get("source"), f"token record {label!r}.source")
        if mode not in mode_hosts:
            raise ValueError(f"token record {label!r} references missing mode {mode!r}")
        if (source["kind"] == "loopback") != (mode == "server"):
            raise ValueError(
                f"token record {label!r}: loopback source and server mode must be used together"
            )
        host = mode_hosts[mode]
        records[token] = TokenRecord(
            token=token,
            user=user,
            mode=mode,
            proxy_base_url=f"{scheme}://{host}:{proxy_port}",
            clickhouse={**clickhouse_shared, "host": host, **clickhouse_credentials},
            postgresql={**postgresql_shared, "host": host, **postgresql_credentials},
            source=source,
        )
    local_records = [
        record
        for record in records.values()
        if (record.source or {}).get("kind") == "loopback"
    ]
    if len(local_records) > 1:
        raise ValueError("token store must contain at most one loopback identity")
    return records


def _mapping(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"{label} must be an object")
    return dict(value)


def _port(value: Any, label: str) -> int:
    try:
        port = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be an integer") from exc
    if not 1 <= port <= 65535:
        raise ValueError(f"{label} must be between 1 and 65535")
    return port


def _reject_credentials(config: dict[str, Any], label: str) -> None:
    forbidden = sorted({"username", "password"} & set(config))
    if forbidden:
        raise ValueError(f"{label} must not contain per-user fields: {forbidden!r}")


def _credentials(value: Any, label: str) -> dict[str, str]:
    config = _mapping(value, label)
    unknown = sorted(set(config) - {"username", "password"})
    if unknown:
        raise ValueError(f"{label} contains non-credential fields: {unknown!r}")
    if "username" not in config or "password" not in config:
        raise ValueError(f"{label} must contain username and password")
    return {
        "username": str(config["username"]),
        "password": str(config["password"]),
    }


def _source_binding(value: Any, label: str) -> dict[str, Any]:
    source = _mapping(value, label)
    kind = str(source.get("kind") or "").strip()
    if kind not in SUPPORTED_SOURCE_KINDS:
        raise ValueError(
            f"{label}.kind must be one of {sorted(SUPPORTED_SOURCE_KINDS)!r}"
        )
    if kind == "loopback":
        unknown = sorted(set(source) - {"kind"})
        if unknown:
            raise ValueError(f"{label} contains unsupported fields: {unknown!r}")
        return {"kind": kind}
    if kind == "lan_ip":
        unknown = sorted(set(source) - {"kind", "ip"})
        if unknown:
            raise ValueError(f"{label} contains unsupported fields: {unknown!r}")
        ip = str(source.get("ip") or "").strip()
        if not ip:
            raise ValueError(f"{label}.ip is required")
        return {"kind": kind, "ip": ip}

    unknown = sorted(
        set(source) - {"kind", "login", "stable_id", "hostname", "addresses"}
    )
    if unknown:
        raise ValueError(f"{label} contains unsupported fields: {unknown!r}")
    login = str(source.get("login") or "").strip()
    stable_id = str(source.get("stable_id") or "").strip()
    addresses_raw = source.get("addresses")
    if not isinstance(addresses_raw, list) or not addresses_raw:
        raise ValueError(f"{label}.addresses must be a non-empty list")
    addresses = [str(address).strip() for address in addresses_raw]
    if not login or not stable_id or any(not address for address in addresses):
        raise ValueError(f"{label} requires login, stable_id and non-empty addresses")
    return {
        "kind": kind,
        "login": login,
        "stable_id": stable_id,
        "hostname": str(source.get("hostname") or "").strip(),
        "addresses": addresses,
    }


def session_payload(record: TokenRecord, proxy_endpoint: str) -> dict[str, Any]:
    if record.proxy_base_url:
        proxy_endpoint = f"{record.proxy_base_url.rstrip('/')}/rqdatac/call"
    return {
        "user": record.user,
        "proxy_endpoint": proxy_endpoint,
        "clickhouse": record.clickhouse,
        "postgresql": record.postgresql,
        "allowed_methods": sorted(PROXY_METHODS),
    }
