from __future__ import annotations

import argparse
import ast
import os
from pathlib import Path
from typing import Any

from ymm_data_sdk import __version__


DEFAULT_HOST = "0.0.0.0"
DEFAULT_PORT = 18080


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="ymm-data-sdk-server")
    subparsers = parser.add_subparsers(dest="command", required=True)

    start = subparsers.add_parser("start", help="Start the ymm_data_sdk proxy server.")
    start.add_argument("--config", help="Path to a flat server.toml config file.")
    start.add_argument("--host", help="Bind host, default from config or 0.0.0.0.")
    start.add_argument("--port", type=int, help="Bind port, default from config or 18080.")
    start.add_argument("--public-url", help="Public LAN base URL, e.g. http://192.168.11.172:18080.")
    start.add_argument("--token-store", help="Path to the generated applied token snapshot.")
    start.add_argument("--rqdatac-license-file", help="Path to rqdatac license text file.")
    start.add_argument("--rqdatac-license", help="Raw rqdatac license or username:password. Prefer file.")
    start.add_argument("--rqdatac-conf", help="Full rqdatac tcp://... URI.")
    start.add_argument("--reload", action="store_true", help="Pass reload=True to uvicorn.")

    args = parser.parse_args(argv)
    if args.command == "start":
        start_server(args)


def start_server(args: argparse.Namespace) -> None:
    print(f"[ymm-data-sdk-server] version={__version__}", flush=True)
    config = _load_flat_toml(Path(args.config)) if args.config else {}

    host = str(_pick(args.host, config.get("host"), DEFAULT_HOST))
    port = int(_pick(args.port, config.get("port"), DEFAULT_PORT))
    public_url = _pick(args.public_url, config.get("public_url"))
    token_store = _pick(args.token_store, config.get("token_store"))
    license_file = _pick(args.rqdatac_license_file, config.get("rqdatac_license_file"))
    license_value = _pick(args.rqdatac_license, config.get("rqdatac_license"))
    rqdatac_conf = _pick(args.rqdatac_conf, config.get("rqdatac_conf"))
    listener_dsn_file = config.get("update_events_listener_postgres_dsn_file")
    reconcile_interval = int(
        config.get("update_events_reconcile_interval_seconds", 60)
    )
    if not 1 <= reconcile_interval <= 3600:
        raise SystemExit(
            "update_events_reconcile_interval_seconds must be between 1 and 3600"
        )
    reload = bool(_pick(args.reload, config.get("reload"), False))

    _set_env_if_value("YMM_DATA_SDK_TOKEN_STORE", token_store)
    _set_env_if_value("YMM_DATA_SDK_PUBLIC_BASE_URL", public_url)
    _set_env_if_value("YMM_DATA_SDK_RQDATAC_LICENSE_FILE", license_file)
    _set_env_if_value("YMM_DATA_SDK_RQDATAC_LICENSE", license_value)
    _set_env_if_value("YMM_DATA_SDK_RQDATAC_CONF", rqdatac_conf)
    _set_env_if_value(
        "YMM_DATA_SDK_UPDATE_EVENTS_LISTENER_DSN_FILE", listener_dsn_file
    )
    _set_env_if_value(
        "YMM_DATA_SDK_UPDATE_EVENTS_RECONCILE_INTERVAL_SECONDS",
        reconcile_interval,
    )

    if not os.environ.get("YMM_DATA_SDK_TOKEN_STORE"):
        raise SystemExit("token_store is required; set it in config or pass --token-store")

    try:
        import uvicorn
    except ImportError as exc:
        raise SystemExit("uvicorn is required on the server machine; install it before starting ymm-data-sdk-server") from exc

    print(f"[ymm-data-sdk-server] token_store={os.environ['YMM_DATA_SDK_TOKEN_STORE']}", flush=True)
    if os.environ.get("YMM_DATA_SDK_PUBLIC_BASE_URL"):
        print(f"[ymm-data-sdk-server] public_url={os.environ['YMM_DATA_SDK_PUBLIC_BASE_URL']}", flush=True)
    if os.environ.get("YMM_DATA_SDK_RQDATAC_LICENSE_FILE"):
        print(f"[ymm-data-sdk-server] rqdatac_license_file={os.environ['YMM_DATA_SDK_RQDATAC_LICENSE_FILE']}", flush=True)
    elif os.environ.get("YMM_DATA_SDK_RQDATAC_LICENSE") or os.environ.get("YMM_DATA_SDK_RQDATAC_CONF"):
        print("[ymm-data-sdk-server] rqdatac license/conf loaded from environment/config", flush=True)
    if os.environ.get("YMM_DATA_SDK_UPDATE_EVENTS_LISTENER_DSN_FILE"):
        print("[ymm-data-sdk-server] update_event_listener=dedicated_secret_file", flush=True)

    uvicorn.run("ymm_data_sdk.server.app:app", host=host, port=port, reload=reload)


def _pick(*values: Any) -> Any:
    for value in values:
        if value is not None:
            return value
    return None


def _set_env_if_value(key: str, value: Any) -> None:
    if value is not None and str(value).strip():
        os.environ[key] = str(value).strip()


def _load_flat_toml(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise SystemExit(f"config file does not exist: {path}")
    out: dict[str, Any] = {}
    for lineno, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        line = _strip_comment(raw_line).strip()
        if not line:
            continue
        if line.startswith("["):
            raise SystemExit(f"{path}:{lineno}: sections are not supported; use flat key = value config")
        if "=" not in line:
            raise SystemExit(f"{path}:{lineno}: expected key = value")
        key, value = line.split("=", 1)
        key = key.strip()
        if not key:
            raise SystemExit(f"{path}:{lineno}: empty key")
        out[key] = _parse_toml_value(value.strip(), path=path, lineno=lineno)
    return out


def _strip_comment(line: str) -> str:
    quote: str | None = None
    escaped = False
    for idx, char in enumerate(line):
        if escaped:
            escaped = False
            continue
        if char == "\\":
            escaped = True
            continue
        if char in {"'", '"'}:
            quote = None if quote == char else char if quote is None else quote
            continue
        if char == "#" and quote is None:
            return line[:idx]
    return line


def _parse_toml_value(value: str, *, path: Path, lineno: int) -> Any:
    lowered = value.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if value.startswith('"') and value.endswith('"'):
        try:
            return ast.literal_eval(value)
        except Exception as exc:
            raise SystemExit(f"{path}:{lineno}: invalid quoted string {value!r}") from exc
    if value.startswith("'") and value.endswith("'"):
        return value[1:-1]
    try:
        return int(value)
    except ValueError:
        pass
    raise SystemExit(f"{path}:{lineno}: unsupported value {value!r}; use quoted strings, integers, or booleans")


if __name__ == "__main__":
    main()
