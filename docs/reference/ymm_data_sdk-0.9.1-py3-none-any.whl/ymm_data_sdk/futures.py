from __future__ import annotations

import datetime as dt
from typing import Any, Sequence

from .dispatch import dispatch


def get_dominant(
    underlying_symbol: str,
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    rule: int = 0,
    rank: int = 1,
    market: str = "cn",
) -> Any:
    return dispatch(
        "futures.get_dominant",
        underlying_symbol,
        start_date=start_date,
        end_date=end_date,
        rule=rule,
        rank=rank,
        market=market,
    )


def get_dominant_batch(
    underlying_symbol_list: Sequence[str],
    start_date: str | int | dt.date | dt.datetime,
    end_date: str | int | dt.date | dt.datetime,
    rule: int = 0,
    rank: int = 1,
    market: str = "cn",
) -> Any:
    return dispatch(
        "futures.get_dominant_batch",
        underlying_symbol_list,
        start_date=start_date,
        end_date=end_date,
        rule=rule,
        rank=rank,
        market=market,
    )


def get_contracts(
    underlying_symbol: str,
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> list[str]:
    return dispatch(
        "futures.get_contracts",
        underlying_symbol,
        date=date,
        market=market,
    )


def get_contracts_batch(
    underlying_symbol_list: Sequence[str],
    start_date: str | int | dt.date | dt.datetime,
    end_date: str | int | dt.date | dt.datetime,
    market: str = "cn",
) -> Any:
    return dispatch(
        "futures.get_contracts_batch",
        underlying_symbol_list,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def get_ex_factor(
    underlying_symbols: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    adjust_method: str = "prev_close_spread",
    rule: int = 0,
    rank: int = 1,
    market: str = "cn",
) -> Any:
    return dispatch(
        "futures.get_ex_factor",
        underlying_symbols,
        start_date=start_date,
        end_date=end_date,
        adjust_method=adjust_method,
        rule=rule,
        rank=rank,
        market=market,
    )


def get_dominant_price(
    underlying_symbols: str | list[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    frequency: str = "1d",
    fields: str | list[str] | None = None,
    adjust_type: str = "pre",
    adjust_method: str = "prev_close_spread",
    rule: int = 0,
    rank: int = 1,
    time_slice: tuple[str | dt.time, str | dt.time] | list[str | dt.time] | None = None,
) -> Any:
    return dispatch(
        "futures.get_dominant_price",
        underlying_symbols,
        start_date=start_date,
        end_date=end_date,
        frequency=frequency,
        fields=fields,
        adjust_type=adjust_type,
        adjust_method=adjust_method,
        rule=rule,
        rank=rank,
        time_slice=time_slice,
    )


def get_contract_multiplier(
    underlying_symbols: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "futures.get_contract_multiplier",
        underlying_symbols,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def get_exchange_daily(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "futures.get_exchange_daily",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
        market=market,
    )


def get_continuous_contracts(
    underlying_symbol: Any,
    start_date: str | int | dt.date | dt.datetime | None,
    end_date: str | int | dt.date | dt.datetime | None,
    type: str = "front_month",
    market: str = "cn",
) -> Any:
    return dispatch(
        "futures.get_continuous_contracts",
        underlying_symbol,
        start_date,
        end_date,
        type=type,
        market=market,
    )


def get_trading_parameters(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "futures.get_trading_parameters",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
        market=market,
    )


def get_member_rank(
    obj: str,
    trading_date: str | int | dt.date | dt.datetime | None = None,
    rank_by: str = "volume",
    **kwargs: Any,
) -> Any:
    return dispatch(
        "futures.get_member_rank",
        obj,
        trading_date=trading_date,
        rank_by=rank_by,
        **kwargs,
    )


def get_warehouse_stocks(
    underlying_symbols: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "futures.get_warehouse_stocks",
        underlying_symbols,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )


def get_basis(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    frequency: str = "1d",
    dividend_adjusted: bool = False,
    market: str = "cn",
) -> Any:
    return dispatch(
        "futures.get_basis",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        fields=fields,
        frequency=frequency,
        dividend_adjusted=dividend_adjusted,
        market=market,
    )


def get_current_basis(
    order_book_ids: str | Sequence[str],
    dividend_adjusted: bool = False,
    market: str = "cn",
) -> Any:
    return dispatch(
        "futures.get_current_basis",
        order_book_ids,
        dividend_adjusted=dividend_adjusted,
        market=market,
    )


def get_roll_yield(
    underlying_symbols: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    type: str = "main_sub",
    rule: int = 0,
    market: str = "cn",
) -> Any:
    return dispatch(
        "futures.get_roll_yield",
        underlying_symbols,
        start_date=start_date,
        end_date=end_date,
        type=type,
        rule=rule,
        market=market,
    )


def get_predicted_dividend_point(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "futures.get_predicted_dividend_point",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )
