from __future__ import annotations

import datetime as dt
from typing import Any, Sequence

from .dispatch import dispatch


def get_components(
    order_book_ids: str | Sequence[str],
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "etf.get_components",
        order_book_ids,
        date=date,
        market=market,
    )


def get_cash_components(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch(
        "etf.get_cash_components",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
        market=market,
    )
