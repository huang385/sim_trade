from __future__ import annotations

import pickle
from typing import Any


PICKLE_ZSTD_MEDIA_TYPE = "application/x-ymm-data-sdk-pickle-zstd"
PROXY_PROTOCOL_VERSION = 1
PROXY_ENVELOPE_KEY = "__ymm_data_sdk_proxy_envelope__"
MAX_PROXY_REQUEST_BYTES = 16 * 1024 * 1024


def dumps_object(value: Any) -> bytes:
    import zstandard as zstd

    payload = pickle.dumps(value, protocol=5)
    return zstd.ZstdCompressor(level=3).compress(payload)


def loads_object(payload: bytes) -> Any:
    import zstandard as zstd

    raw = zstd.ZstdDecompressor().decompress(payload)
    return pickle.loads(raw)
