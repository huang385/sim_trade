from __future__ import annotations

import atexit
from collections import deque
from contextlib import AbstractContextManager
from dataclasses import dataclass
import os
import threading
import time
from typing import Callable

from .config import SessionConfig
from .exceptions import YMMDataSDKError
from .local.market_data import RQMarketDataClient


DEFAULT_POOL_SIZE = 2
MAX_POOL_SIZE = 4
DEFAULT_RECYCLE_SECONDS = 30 * 60
DEFAULT_ACQUIRE_TIMEOUT_SECONDS = 120.0


@dataclass
class _IdleClient:
    client: RQMarketDataClient
    released_at: float


class LocalClientPool:
    def __init__(
        self,
        session: SessionConfig,
        *,
        max_size: int,
        recycle_seconds: float = DEFAULT_RECYCLE_SECONDS,
        acquire_timeout_seconds: float = DEFAULT_ACQUIRE_TIMEOUT_SECONDS,
        factory: Callable[[SessionConfig], RQMarketDataClient] | None = None,
    ) -> None:
        if not 1 <= max_size <= MAX_POOL_SIZE:
            raise ValueError(f"local_pool_size must be between 1 and {MAX_POOL_SIZE}")
        self.session = session
        self.max_size = max_size
        self.recycle_seconds = recycle_seconds
        self.acquire_timeout_seconds = acquire_timeout_seconds
        self._factory = factory or _build_client
        self._condition = threading.Condition()
        self._idle: deque[_IdleClient] = deque()
        self._all: set[RQMarketDataClient] = set()
        self._creating = 0
        self._closed = False

    def acquire(self) -> RQMarketDataClient:
        deadline = time.monotonic() + self.acquire_timeout_seconds
        while True:
            stale: list[RQMarketDataClient] = []
            create = False
            with self._condition:
                if self._closed:
                    raise YMMDataSDKError("local connection pool is closed")
                now = time.monotonic()
                while self._idle:
                    entry = self._idle.popleft()
                    if now - entry.released_at < self.recycle_seconds:
                        return entry.client
                    self._all.discard(entry.client)
                    stale.append(entry.client)
                if len(self._all) + self._creating < self.max_size:
                    self._creating += 1
                    create = True
                else:
                    remaining = deadline - now
                    if remaining <= 0:
                        raise YMMDataSDKError(
                            f"timed out waiting for a local database connection "
                            f"(pool_size={self.max_size})"
                        )
                    self._condition.wait(timeout=remaining)
            for client in stale:
                client.close()
            if create:
                try:
                    client = self._factory(self.session)
                except Exception:
                    with self._condition:
                        self._creating -= 1
                        self._condition.notify()
                    raise
                with self._condition:
                    self._creating -= 1
                    if self._closed:
                        close_now = True
                    else:
                        self._all.add(client)
                        close_now = False
                    self._condition.notify()
                if close_now:
                    client.close()
                    raise YMMDataSDKError("local connection pool was closed during connection creation")
                return client

    def release(self, client: RQMarketDataClient, *, discard: bool = False) -> None:
        close_now = discard
        with self._condition:
            if client not in self._all:
                close_now = True
            elif self._closed or discard:
                self._all.discard(client)
                close_now = True
            else:
                self._idle.append(_IdleClient(client=client, released_at=time.monotonic()))
            self._condition.notify()
        if close_now:
            client.close()

    def close(self) -> None:
        with self._condition:
            if self._closed:
                return
            self._closed = True
            clients = list(self._all)
            self._all.clear()
            self._idle.clear()
            self._condition.notify_all()
        for client in clients:
            client.close()

    def stats(self) -> dict[str, int | bool]:
        with self._condition:
            return {
                "max_size": self.max_size,
                "clients": len(self._all),
                "idle": len(self._idle),
                "in_use": len(self._all) - len(self._idle),
                "creating": self._creating,
                "closed": self._closed,
            }

    def invalidate_update_status_caches(self) -> None:
        with self._condition:
            clients = list(self._all)
        for client in clients:
            client.invalidate_update_status_cache()


class LocalClientLease(AbstractContextManager[RQMarketDataClient]):
    def __init__(self, pool: LocalClientPool) -> None:
        self.pool = pool
        self.client: RQMarketDataClient | None = None

    def __enter__(self) -> RQMarketDataClient:
        self.client = self.pool.acquire()
        return self.client

    def __exit__(self, exc_type, exc, traceback) -> bool:
        if self.client is not None:
            self.pool.release(self.client, discard=_is_connection_error(exc))
            self.client = None
        return False


_LOCK = threading.RLock()
_POOLS: dict[SessionConfig, LocalClientPool] = {}
_PID = os.getpid()


def lease_local_client(session: SessionConfig) -> LocalClientLease:
    return LocalClientLease(_pool_for(session))


def local_pool_stats(session: SessionConfig) -> dict[str, int | bool]:
    return _pool_for(session).stats()


def invalidate_update_status_caches() -> None:
    """Invalidate routing watermarks for every pooled client in this process."""

    _reset_after_fork()
    with _LOCK:
        pools = list(_POOLS.values())
    for pool in pools:
        pool.invalidate_update_status_caches()


def close_local_pool(session: SessionConfig | None = None) -> None:
    _reset_after_fork()
    with _LOCK:
        if session is None:
            pools = list(_POOLS.values())
            _POOLS.clear()
        else:
            pool = _POOLS.pop(session, None)
            pools = [pool] if pool is not None else []
    for pool in pools:
        pool.close()


def _pool_for(session: SessionConfig) -> LocalClientPool:
    _reset_after_fork()
    with _LOCK:
        pool = _POOLS.get(session)
        if pool is None:
            pool = LocalClientPool(session, max_size=session.local_pool_size)
            _POOLS[session] = pool
        return pool


def _reset_after_fork() -> None:
    global _PID
    pid = os.getpid()
    if pid == _PID:
        return
    with _LOCK:
        pools = list(_POOLS.values())
        _POOLS.clear()
        _PID = pid
    for pool in pools:
        pool.close()


def _build_client(session: SessionConfig) -> RQMarketDataClient:
    ch = session.clickhouse
    pg = session.postgresql
    return RQMarketDataClient(
        connection_mode="local",
        ch_host=ch.host,
        ch_port=ch.port,
        ch_http_port=ch.http_port,
        ch_database=ch.database,
        ch_username=ch.username,
        ch_password=ch.password,
        pg_host=pg.host,
        pg_port=pg.port,
        pg_database=pg.database,
        pg_username=pg.username,
        pg_password=pg.password,
        pg_schema=pg.schema,
        secure=ch.secure,
    )


def _is_connection_error(exc: BaseException | None) -> bool:
    if exc is None:
        return False
    if isinstance(exc, (ConnectionError, OSError)):
        return True
    return type(exc).__name__ in {
        "OperationalError",
        "InterfaceError",
        "NetworkError",
        "SocketTimeoutError",
    }


atexit.register(close_local_pool)
