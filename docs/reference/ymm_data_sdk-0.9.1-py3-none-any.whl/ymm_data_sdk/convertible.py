from __future__ import annotations

import datetime as dt
from typing import Any, Sequence

from .convertible_instrument import ConvertibleInstrument
from .dispatch import dispatch


def all_instruments(
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any:
    return dispatch("convertible.all_instruments", date=date, market=market)


def instruments(
    order_book_ids: str | Sequence[str],
    market: str = "cn",
) -> ConvertibleInstrument | list[ConvertibleInstrument] | None:
    return dispatch("convertible.instruments", order_book_ids, market=market)


def is_suspended(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
) -> Any:
    return dispatch(
        "convertible.is_suspended",
        order_book_ids,
        start_date=start_date,
        end_date=end_date,
    )


def get_conversion_price(order_book_ids, start_date=None, end_date=None, market="cn") -> Any:
    return dispatch("convertible.get_conversion_price", order_book_ids, start_date, end_date, market)


def get_conversion_info(order_book_ids, start_date=None, end_date=None, market="cn") -> Any:
    return dispatch("convertible.get_conversion_info", order_book_ids, start_date, end_date, market)


def get_call_info(order_book_ids, start_date=None, end_date=None, market="cn") -> Any:
    return dispatch("convertible.get_call_info", order_book_ids, start_date, end_date, market)


def get_put_info(order_book_ids, start_date=None, end_date=None, market="cn") -> Any:
    return dispatch("convertible.get_put_info", order_book_ids, start_date, end_date, market)


def get_cash_flow(order_book_ids, start_date=None, end_date=None, market="cn") -> Any:
    return dispatch("convertible.get_cash_flow", order_book_ids, start_date, end_date, market)


def get_instrument_industry(order_book_ids, source="citics", level=1, date=None, market="cn") -> Any:
    return dispatch("convertible.get_instrument_industry", order_book_ids, source, level, date, market)


def get_industry(industry, source="citics", date=None, market="cn") -> Any:
    return dispatch("convertible.get_industry", industry, source, date, market)


def get_accrued_interest_eod(order_book_ids, start_date=None, end_date=None) -> Any:
    return dispatch("convertible.get_accrued_interest_eod", order_book_ids, start_date, end_date)


def get_call_announcement(order_book_ids, start_date=None, end_date=None, market="cn") -> Any:
    return dispatch("convertible.get_call_announcement", order_book_ids, start_date, end_date, market)


def get_close_price(order_book_ids, start_date=None, end_date=None, fields=None, market="cn") -> Any:
    return dispatch("convertible.get_close_price", order_book_ids, start_date, end_date, fields, market)


def get_indicators(order_book_ids, start_date=None, end_date=None, fields=None) -> Any:
    return dispatch("convertible.get_indicators", order_book_ids, start_date, end_date, fields)


def get_credit_rating(order_book_ids, start_date=None, end_date=None, institutions=None, market="cn") -> Any:
    return dispatch(
        "convertible.get_credit_rating",
        order_book_ids,
        start_date,
        end_date,
        institutions,
        market,
    )


def get_std_discount(order_book_ids, start_date=None, end_date=None, market="cn") -> Any:
    return dispatch("convertible.get_std_discount", order_book_ids, start_date, end_date, market)
