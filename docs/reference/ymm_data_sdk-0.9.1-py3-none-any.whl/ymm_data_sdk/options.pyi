import datetime as dt
from typing import Any, Sequence

def get_contracts(
    underlying: str,
    option_type: str | None = None,
    maturity: str | int | None = None,
    strike: float | None = None,
    trading_date: str | int | dt.date | dt.datetime | None = None,
) -> list[str]: ...

def get_contracts_batch(
    underlying_list: Sequence[str],
    start_date: str | int | dt.date | dt.datetime,
    end_date: str | int | dt.date | dt.datetime,
    option_type: str | None = None,
    maturity: str | int | None = None,
    strike: float | None = None,
) -> Any: ...

def get_greeks(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    model: str = "implied_forward",
    price_type: str = "close",
    frequency: str = "1d",
    market: str = "cn",
) -> Any: ...

def get_contract_property(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...

def get_dominant_month(
    underlying_symbol: str,
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    rule: int = 0,
    rank: int = 1,
    market: str = "cn",
) -> Any: ...

def get_dominant_month_batch(
    underlying_symbol_list: Sequence[str],
    start_date: str | int | dt.date | dt.datetime,
    end_date: str | int | dt.date | dt.datetime,
    rule: int = 0,
    rank: int = 1,
    market: str = "cn",
) -> Any: ...

def get_indicators(
    underlying_symbols: str | Sequence[str],
    maturity: str | int,
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...
