import datetime as dt
from typing import Any, Sequence

def get_dominant(
    underlying_symbol: str,
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    rule: int = 0,
    rank: int = 1,
    market: str = "cn",
) -> Any: ...

def get_dominant_batch(
    underlying_symbol_list: Sequence[str],
    start_date: str | int | dt.date | dt.datetime,
    end_date: str | int | dt.date | dt.datetime,
    rule: int = 0,
    rank: int = 1,
    market: str = "cn",
) -> Any: ...

def get_contracts(
    underlying_symbol: str,
    date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> list[str]: ...

def get_contracts_batch(
    underlying_symbol_list: Sequence[str],
    start_date: str | int | dt.date | dt.datetime,
    end_date: str | int | dt.date | dt.datetime,
    market: str = "cn",
) -> Any: ...

def get_ex_factor(
    underlying_symbols: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    adjust_method: str = "prev_close_spread",
    rule: int = 0,
    rank: int = 1,
    market: str = "cn",
) -> Any: ...

def get_dominant_price(
    underlying_symbols: str | list[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    frequency: str = "1d",
    fields: str | list[str] | None = None,
    adjust_type: str = "pre",
    adjust_method: str = "prev_close_spread",
    rule: int = 0,
    rank: int = 1,
    time_slice: tuple[str | dt.time, str | dt.time] | list[str | dt.time] | None = None,
) -> Any: ...

def get_contract_multiplier(
    underlying_symbols: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...

def get_exchange_daily(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...

def get_continuous_contracts(
    underlying_symbol: Any,
    start_date: str | int | dt.date | dt.datetime | None,
    end_date: str | int | dt.date | dt.datetime | None,
    type: str = "front_month",
    market: str = "cn",
) -> Any: ...

def get_trading_parameters(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    market: str = "cn",
) -> Any: ...

def get_member_rank(
    obj: str,
    trading_date: str | int | dt.date | dt.datetime | None = None,
    rank_by: str = "volume",
    **kwargs: Any,
) -> Any: ...

def get_warehouse_stocks(
    underlying_symbols: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...

def get_basis(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    fields: str | Sequence[str] | None = None,
    frequency: str = "1d",
    dividend_adjusted: bool = False,
    market: str = "cn",
) -> Any: ...

def get_current_basis(
    order_book_ids: str | Sequence[str],
    dividend_adjusted: bool = False,
    market: str = "cn",
) -> Any: ...

def get_roll_yield(
    underlying_symbols: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    type: str = "main_sub",
    rule: int = 0,
    market: str = "cn",
) -> Any: ...

def get_predicted_dividend_point(
    order_book_ids: str | Sequence[str],
    start_date: str | int | dt.date | dt.datetime | None = None,
    end_date: str | int | dt.date | dt.datetime | None = None,
    market: str = "cn",
) -> Any: ...
