from __future__ import annotations

import argparse
import datetime as dt
import json
import statistics
import time
from pathlib import Path
from typing import Any, Callable


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="ymm-data-sdk-acceptance")
    parser.add_argument("--token", required=True)
    parser.add_argument("--server-url", required=True)
    parser.add_argument("--output", default="ymm_data_sdk_user_acceptance_report.json")
    parser.add_argument("--iterations", type=int, default=5)
    parser.add_argument("--price-id", default="000001.XSHE")
    parser.add_argument("--price-date", default="2026-01-05")
    parser.add_argument("--max-local-p95", type=float, default=3.0)
    parser.add_argument("--max-proxy-overhead-p95", type=float, default=1.5)
    args = parser.parse_args(argv)
    if args.iterations < 2:
        raise SystemExit("--iterations must be at least 2")

    import ymm_data_sdk
    from ymm_data_sdk.registry import LOCAL_METHODS, PROXY_METHODS
    from ymm_data_sdk.remote_proxy import call_proxy_with_diagnostics

    initialized_at = time.perf_counter()
    ymm_data_sdk.init(token=args.token, server_url=args.server_url)
    init_seconds = time.perf_counter() - initialized_at
    session = ymm_data_sdk.get_session()

    cold_started = time.perf_counter()
    cold_result = ymm_data_sdk.get_price(
        args.price_id,
        start_date=args.price_date,
        end_date=args.price_date,
        frequency="1d",
        fields=["close", "volume"],
    )
    cold_local_seconds = time.perf_counter() - cold_started
    warmup_report = ymm_data_sdk.warmup(local=True, proxy=False)

    missing_wrappers = sorted(
        method for method in set(LOCAL_METHODS) | set(PROXY_METHODS)
        if not callable(_resolve(ymm_data_sdk, method))
    )
    missing_session_proxy = sorted(set(PROXY_METHODS) - set(session.allowed_methods))
    extra_session_proxy = sorted(set(session.allowed_methods) - set(PROXY_METHODS))

    local_cases = [
        (
            "get_price_1d",
            lambda: ymm_data_sdk.get_price(
                args.price_id,
                start_date=args.price_date,
                end_date=args.price_date,
                frequency="1d",
                fields=["close", "volume"],
            ),
        ),
        (
            "get_price_1m",
            lambda: ymm_data_sdk.get_price(
                args.price_id,
                start_date=args.price_date,
                end_date=args.price_date,
                frequency="1m",
                fields=["close", "volume"],
            ),
        ),
        (
            "get_trading_dates",
            lambda: ymm_data_sdk.get_trading_dates(
                start_date=args.price_date,
                end_date=args.price_date,
            ),
        ),
    ]
    local_results = [
        _benchmark(name, function, args.iterations, args.max_local_p95)
        for name, function in local_cases
    ]

    proxy_total: list[float] = []
    proxy_rqdatac: list[float] = []
    proxy_overhead: list[float] = []
    proxy_summary: dict[str, Any] = {}
    for index in range(args.iterations + 1):
        started = time.perf_counter()
        result, diagnostics = call_proxy_with_diagnostics(
            session,
            "get_yield_curve",
            (),
            {
                "start_date": args.price_date,
                "end_date": args.price_date,
                "tenor": None,
                "market": "cn",
            },
        )
        total = time.perf_counter() - started
        rqdatac_elapsed = float(diagnostics["server_rqdatac_elapsed_seconds"])
        if index == 0:
            proxy_summary = _summarize(result)
            continue
        proxy_total.append(total)
        proxy_rqdatac.append(rqdatac_elapsed)
        proxy_overhead.append(max(0.0, total - rqdatac_elapsed))
    proxy_result = {
        "name": "get_yield_curve",
        "iterations": args.iterations,
        "total_seconds": _timing_summary(proxy_total),
        "server_rqdatac_seconds": _timing_summary(proxy_rqdatac),
        "non_rqdatac_overhead_seconds": _timing_summary(proxy_overhead),
        "threshold_p95_seconds": args.max_proxy_overhead_p95,
        "status": "ok" if _p95(proxy_overhead) <= args.max_proxy_overhead_p95 else "slow",
        "result": proxy_summary,
    }

    completeness_ok = not missing_wrappers and not missing_session_proxy and not extra_session_proxy
    performance_ok = all(case["status"] == "ok" for case in local_results) and proxy_result["status"] == "ok"
    report = {
        "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "server_url": args.server_url,
        "init_seconds": round(init_seconds, 6),
        "connection_reuse_and_warmup": {
            "cold_local_seconds": round(cold_local_seconds, 6),
            "cold_local_result": _summarize(cold_result),
            "explicit_local_warmup": warmup_report,
        },
        "method_completeness": {
            "local_methods": len(LOCAL_METHODS),
            "proxy_methods": len(PROXY_METHODS),
            "total_methods": len(LOCAL_METHODS) + len(PROXY_METHODS),
            "missing_wrappers": missing_wrappers,
            "missing_session_proxy_methods": missing_session_proxy,
            "unexpected_session_proxy_methods": extra_session_proxy,
            "status": "ok" if completeness_ok else "failed",
        },
        "local_performance": local_results,
        "proxy_performance": proxy_result,
        "ok": completeness_ok and performance_ok,
    }
    output = Path(args.output)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))
    print(f"[report] {output}")
    ymm_data_sdk.close()
    if not report["ok"]:
        raise SystemExit(1)


def _resolve(root: Any, method: str) -> Any:
    value = root
    for part in method.split("."):
        value = getattr(value, part, None)
        if value is None:
            return None
    return value


def _benchmark(
    name: str,
    function: Callable[[], Any],
    iterations: int,
    threshold: float,
) -> dict[str, Any]:
    function()
    timings: list[float] = []
    result: Any = None
    for _ in range(iterations):
        started = time.perf_counter()
        result = function()
        timings.append(time.perf_counter() - started)
    return {
        "name": name,
        "iterations": iterations,
        "seconds": _timing_summary(timings),
        "threshold_p95_seconds": threshold,
        "status": "ok" if _p95(timings) <= threshold else "slow",
        "result": _summarize(result),
    }


def _timing_summary(values: list[float]) -> dict[str, float]:
    return {
        "min": round(min(values), 6),
        "median": round(statistics.median(values), 6),
        "p95": round(_p95(values), 6),
        "max": round(max(values), 6),
    }


def _p95(values: list[float]) -> float:
    ordered = sorted(values)
    index = max(0, min(len(ordered) - 1, int(0.95 * len(ordered) + 0.999999) - 1))
    return ordered[index]


def _summarize(value: Any) -> dict[str, Any]:
    summary: dict[str, Any] = {"type": type(value).__name__}
    shape = getattr(value, "shape", None)
    if shape is not None:
        summary["shape"] = list(shape)
    try:
        summary["len"] = len(value)
    except Exception:
        pass
    return summary


if __name__ == "__main__":
    main()
