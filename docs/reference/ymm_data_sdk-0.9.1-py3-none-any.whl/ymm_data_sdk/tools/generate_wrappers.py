from __future__ import annotations

import inspect
import json
from typing import Any


EXAMPLE_METHODS = [
    "get_yield_curve",
    "futures.get_dominant",
    "futures.get_contracts",
    "futures.get_ex_factor",
    "futures.get_dominant_price",
    "futures.get_contract_multiplier",
    "futures.get_exchange_daily",
    "futures.get_continuous_contracts",
    "futures.get_trading_parameters",
    "futures.get_member_rank",
    "futures.get_warehouse_stocks",
    "futures.get_basis",
    "futures.get_current_basis",
    "futures.get_roll_yield",
    "futures.get_predicted_dividend_point",
    "options.get_contracts",
    "options.get_contracts_batch",
    "options.get_contract_property",
    "options.get_dominant_month",
    "options.get_dominant_month_batch",
    "options.get_greeks",
    "options.get_indicators",
    "convertible.all_instruments",
    "convertible.instruments",
    "convertible.get_conversion_price",
    "convertible.get_conversion_info",
    "convertible.get_call_info",
    "convertible.get_put_info",
    "convertible.get_cash_flow",
    "convertible.is_suspended",
    "convertible.get_instrument_industry",
    "convertible.get_industry",
    "convertible.get_accrued_interest_eod",
    "convertible.get_call_announcement",
    "convertible.get_close_price",
    "convertible.get_indicators",
    "convertible.get_credit_rating",
    "convertible.get_std_discount",
    "index_indicator",
    "index_components",
    "index_weights",
    "index_weights_ex",
    "etf.get_components",
    "etf.get_cash_components",
]


def main() -> None:
    import rqdatac

    payload: dict[str, Any] = {}
    for method in EXAMPLE_METHODS:
        obj = rqdatac
        for part in method.split("."):
            obj = getattr(obj, part)
        payload[method] = {
            "signature": str(inspect.signature(obj)),
            "doc": inspect.getdoc(obj) or "",
        }
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
