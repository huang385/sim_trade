from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import time
import traceback
from pathlib import Path
from typing import Any, Callable


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="ymm-data-sdk-smoke")
    parser.add_argument("--token", default=os.environ.get("YMM_DATA_SDK_TOKEN"))
    parser.add_argument("--server-url", default=os.environ.get("YMM_DATA_SDK_SERVER_URL"))
    parser.add_argument("--output", default="ymm_data_sdk_smoke_report.json")
    parser.add_argument("--price-id", default="000001.XSHE")
    parser.add_argument("--price-date", default="2026-01-05")
    parser.add_argument("--dominant-symbol", default="IF")
    parser.add_argument("--dominant-date", default="2026-01-05")
    parser.add_argument("--denied-method", default="current_snapshot")
    parser.add_argument("--skip-proxy", action="store_true")
    parser.add_argument("--skip-negative", action="store_true")
    args = parser.parse_args(argv)

    if not args.token:
        raise SystemExit("token is required; pass --token or set YMM_DATA_SDK_TOKEN")
    if not args.server_url:
        raise SystemExit("server URL is required; pass --server-url or set YMM_DATA_SDK_SERVER_URL")

    import ymm_data_sdk
    from ymm_data_sdk.dispatch import dispatch
    from ymm_data_sdk.registry import backend_for
    from ymm_data_sdk.remote_proxy import call_proxy, create_session

    report: dict[str, Any] = {
        "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "server_url": args.server_url,
        "cases": [],
    }

    def add_case(name: str, backend: str, func: Callable[[], Any], *, expect_error: bool = False) -> None:
        started = time.perf_counter()
        case: dict[str, Any] = {"name": name, "backend": backend}
        try:
            result = func()
        except Exception as exc:  # noqa: BLE001 - smoke report should capture all failures.
            case.update(
                {
                    "status": "expected_error" if expect_error else "failed",
                    "elapsed_sec": round(time.perf_counter() - started, 6),
                    "error_type": type(exc).__name__,
                    "error_message": str(exc),
                }
            )
            if not expect_error:
                case["traceback"] = traceback.format_exc()
        else:
            case.update(
                {
                    "status": "failed" if expect_error else "ok",
                    "elapsed_sec": round(time.perf_counter() - started, 6),
                    "summary": summarize_object(result),
                }
            )
            if expect_error:
                case["error_message"] = "expected an error but call succeeded"
        report["cases"].append(case)
        print(f"[{case['status']}] {name} ({case['elapsed_sec']}s)")

    add_case(
        "init",
        "auth/session",
        lambda: ymm_data_sdk.init(token=args.token, server_url=args.server_url) or ymm_data_sdk.get_session(),
    )
    add_case(
        "warmup_local",
        "local",
        lambda: ymm_data_sdk.warmup(local=True, proxy=False),
    )
    add_case(
        "get_price",
        backend_for("get_price"),
        lambda: ymm_data_sdk.get_price(
            args.price_id,
            start_date=args.price_date,
            end_date=args.price_date,
            frequency="1d",
            fields=["close", "volume"],
        ),
    )
    add_case(
        "futures.get_dominant",
        backend_for("futures.get_dominant"),
        lambda: ymm_data_sdk.futures.get_dominant(
            args.dominant_symbol,
            start_date=args.dominant_date,
            end_date=args.dominant_date,
        ),
    )
    add_case(
        "all_instruments",
        backend_for("all_instruments"),
        lambda: ymm_data_sdk.all_instruments(type="CS", date=args.price_date).head(5),
    )
    add_case(
        "get_trading_dates",
        backend_for("get_trading_dates"),
        lambda: ymm_data_sdk.get_trading_dates(start_date=args.price_date, end_date=args.price_date),
    )
    add_case(
        "get_previous_trading_date",
        backend_for("get_previous_trading_date"),
        lambda: ymm_data_sdk.get_previous_trading_date(args.price_date),
    )
    add_case(
        "get_next_trading_date",
        backend_for("get_next_trading_date"),
        lambda: ymm_data_sdk.get_next_trading_date(args.price_date),
    )
    add_case(
        "get_night_trading_dates",
        backend_for("get_night_trading_dates"),
        lambda: ymm_data_sdk.get_night_trading_dates(start_date=args.price_date, end_date=args.price_date),
    )
    if not args.skip_proxy:
        add_case("get_yield_curve", backend_for("get_yield_curve"), lambda: ymm_data_sdk.get_yield_curve())
    if not args.skip_negative:
        add_case(
            "invalid_token",
            "auth/session",
            lambda: create_session(token="__invalid_ymm_data_sdk_token__", server_url=args.server_url),
            expect_error=True,
        )
        add_case(
            "unregistered_method",
            "disabled",
            lambda: dispatch("__not_registered__"),
            expect_error=True,
        )
        if args.denied_method:
            add_case(
                "proxy_denied_method",
                "proxy-permission",
                lambda: call_proxy(ymm_data_sdk.get_session(), args.denied_method, (), {}),
                expect_error=True,
            )

    report["ok"] = all(case["status"] in {"ok", "expected_error"} for case in report["cases"])
    output = Path(args.output)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(f"[report] {output}")
    ymm_data_sdk.close()
    if not report["ok"]:
        raise SystemExit(1)


def summarize_object(value: Any) -> dict[str, Any]:
    out: dict[str, Any] = {"type": type(value).__name__}
    if value is None:
        return out
    shape = getattr(value, "shape", None)
    if shape is not None:
        out["shape"] = list(shape)
    try:
        out["len"] = len(value)
    except Exception:
        pass
    columns = getattr(value, "columns", None)
    if columns is not None:
        out["columns"] = [str(col) for col in list(columns)[:20]]
    index = getattr(value, "index", None)
    if index is not None and not callable(index) and len(index) > 0:
        out["index_min"] = str(index.min())
        out["index_max"] = str(index.max())
    if isinstance(value, (list, tuple)) and value:
        out["first"] = str(value[0])
        out["last"] = str(value[-1])
    return out


if __name__ == "__main__":
    main()
